// Issue #61: public changelog + build identity stamp.
// Style matches site-ops-test.js (axios + assert, spawns api.js).
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const axios = require('axios');
const assert = require('assert');

const TEST_PORT = 3206;
const BASE = `http://127.0.0.1:${TEST_PORT}`;
const FAKE_SHA = 'abcdef0123456789abcdef0123456789abcdef01';
const FAKE_SHORT = FAKE_SHA.slice(0, 7);
const FAKE_DEPLOYED = '2026-09-07T02:00:00Z';

let child;

function startServer(extraEnv) {
    const grantsFile = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'docdocgo-changelog-')), 'grants.json');
    child = spawn(process.execPath, ['api.js'], {
        cwd: __dirname,
        env: {
            ...process.env,
            PORT: String(TEST_PORT),
            GRANTS_FILE: grantsFile,
            AUTH_TEST_MODE: '1',
            ...extraEnv
        },
        stdio: ['ignore', 'pipe', 'pipe']
    });
    child.stderr.on('data', (d) => process.stderr.write(`[child] ${d}`));
}

async function waitForHealth() {
    for (let i = 0; i < 60; i++) {
        try {
            const res = await axios.get(`${BASE}/api/health`, { validateStatus: () => true, timeout: 5000 });
            if (res.status === 200) return;
        } catch (e) { /* not up yet */ }
        await new Promise((r) => setTimeout(r, 250));
    }
    throw new Error('api did not become ready');
}

async function stopServer() {
    if (!child) return;
    child.kill('SIGTERM');
    child = null;
    await new Promise((r) => setTimeout(r, 300));
}

async function runTests() {
    console.log('--- Changelog / version tests (issue #61) ---');

    // Static artefacts
    const buildInfo = JSON.parse(fs.readFileSync(path.join(__dirname, 'build-info.json'), 'utf8'));
    assert.strictEqual(typeof buildInfo.sha, 'string');
    assert.strictEqual(typeof buildInfo.shortSha, 'string');
    assert.ok('deployedAt' in buildInfo);
    assert.strictEqual(typeof buildInfo.versionLabel, 'string');
    console.log('✅ build-info.json shape');

    const entries = JSON.parse(fs.readFileSync(path.join(__dirname, 'changelog.json'), 'utf8'));
    assert.ok(Array.isArray(entries) && entries.length > 0, 'changelog.json should be a non-empty array');
    for (const e of entries) {
        assert.strictEqual(typeof e.date, 'string', 'entry.date');
        assert.strictEqual(typeof e.title, 'string', 'entry.title');
        assert.strictEqual(typeof e.before, 'string', 'entry.before');
        assert.strictEqual(typeof e.now, 'string', 'entry.now');
        assert.ok(e.before.length > 0 && e.now.length > 0, 'before/now must be non-empty');
    }
    console.log('✅ changelog.json before/now entries');

    const htmlPath = path.join(__dirname, 'html', 'changelog.html');
    assert.ok(fs.existsSync(htmlPath), 'html/changelog.html must exist');
    const html = fs.readFileSync(htmlPath, 'utf8');
    assert.ok(html.includes('__DOCDOCGO_SHORT_SHA__'), 'changelog.html must include shortSha stamp placeholder');
    assert.ok(html.includes('__DOCDOCGO_GIT_SHA__'), 'changelog.html must include full SHA stamp placeholder');
    assert.ok(/Before/i.test(html) && /Now/i.test(html), 'changelog.html should render Before/Now');
    assert.ok(html.includes('/api/version'), 'changelog.html fetches /api/version');
    assert.ok(html.includes('/api/changelog'), 'changelog.html fetches /api/changelog');
    console.log('✅ html/changelog.html stamps + Before/Now');

    const nginx = fs.readFileSync(path.join(__dirname, 'nginx.conf'), 'utf8');
    assert.ok(/location\s+=\s+\/changelog\s*\{/.test(nginx), 'nginx must have location = /changelog');
    assert.ok(/location\s+=\s+\/changelog\/\s*\{/.test(nginx), 'nginx must have location = /changelog/');
    assert.ok(/location\s+=\s+\/changelog\/\s*\{[\s\S]*?return\s+301\s+https:\/\/docdocgo\.lak\.nz\/changelog/.test(nginx), 'nginx /changelog/ must 301 to https://docdocgo.lak.nz/changelog (#66)');
    // Public locations must not sit behind auth_request in the same block.
    const changelogBlock = nginx.slice(nginx.indexOf('location = /changelog'));
    const snippet = changelogBlock.slice(0, changelogBlock.indexOf('location = /changelog.html') + 80);
    assert.ok(!/auth_request/.test(snippet), 'changelog locations must not use auth_request');
    console.log('✅ nginx.conf public /changelog locations');

    const entry = fs.readFileSync(path.join(__dirname, 'entrypoint.sh'), 'utf8');
    assert.ok(/BUILD_SHA/.test(entry), 'entrypoint must honour BUILD_SHA');
    assert.ok(/build-info\.json/.test(entry), 'entrypoint must write build-info.json');
    assert.ok(/DOCDOCGO_GIT_SHA/.test(entry), 'entrypoint may alias DOCDOCGO_GIT_SHA');
    console.log('✅ entrypoint.sh stamp contract');

    // Live /api/version with BUILD_SHA
    startServer({ BUILD_SHA: FAKE_SHA, DEPLOYED_AT: FAKE_DEPLOYED });
    try {
        await waitForHealth();
        const ver = await axios.get(`${BASE}/api/version`, { validateStatus: () => true });
        assert.strictEqual(ver.status, 200, '/api/version should be 200');
        assert.strictEqual(ver.data.sha, FAKE_SHA);
        assert.strictEqual(ver.data.shortSha, FAKE_SHORT);
        assert.strictEqual(ver.data.deployedAt, FAKE_DEPLOYED);
        assert.strictEqual(typeof ver.data.packageVersion, 'string');
        assert.ok(ver.data.versionLabel);
        console.log('✅ GET /api/version respects BUILD_SHA + DEPLOYED_AT');

        const cl = await axios.get(`${BASE}/api/changelog`, { validateStatus: () => true });
        assert.strictEqual(cl.status, 200);
        assert.ok(Array.isArray(cl.data.entries));
        assert.ok(cl.data.entries.every((e) => e.before && e.now));
        console.log('✅ GET /api/changelog returns before/now entries');
    } finally {
        await stopServer();
    }

    // Alias: DOCDOCGO_GIT_SHA when BUILD_SHA unset
    startServer({ DOCDOCGO_GIT_SHA: FAKE_SHA, DOCDOCGO_DEPLOYED_AT: FAKE_DEPLOYED, BUILD_SHA: '', DEPLOYED_AT: '' });
    try {
        await waitForHealth();
        const ver = await axios.get(`${BASE}/api/version`, { validateStatus: () => true });
        assert.strictEqual(ver.status, 200);
        assert.strictEqual(ver.data.sha, FAKE_SHA);
        assert.strictEqual(ver.data.shortSha, FAKE_SHORT);
        console.log('✅ DOCDOCGO_GIT_SHA alias works when BUILD_SHA unset');
    } finally {
        await stopServer();
    }

    console.log('\n--- All changelog/version tests passed ---');
}

runTests().catch((err) => {
    console.error('\n❌ Changelog test suite failed:');
    console.error(err && err.stack ? err.stack : err);
    if (child) child.kill('SIGTERM');
    process.exit(1);
});
