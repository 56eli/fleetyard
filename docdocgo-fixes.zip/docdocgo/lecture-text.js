const fs = require('fs');
const vm = require('vm');

// Shared lecture text loading + cleaning. api.js, quality-check.js and
// quality-tests.js all use this so the WEBVTT/cue cleanup and the Hawkins
// ASR hotword list live in exactly ONE server-side copy. Data files on disk
// are READ-ONLY (project rule) — fixes live here.
//
// The hotword list is ALSO mirrored in rag/populate.py (_correct_lecture_text)
// and html/hawkins-lecture-fixes.js (browser). Keep all copies in sync; order
// matters (specific -> generic).

// Corpus key charsets (GoluGit #2 / DOC-001). FILE_KEY_RE matches every corpus
// key, including the six legacy '&' titles
// (The_Levels_of_Consciousness_Subjective_&_Social_Consequences_Mar_2002_Part_1/2/3,
// Overcoming_Doubt,_Skepticism_&_Disbelief_Aug_2008_Part_1/2/3). Verified
// charset across all 307 keys: A-Z a-z 0-9 _ , & (hyphen allowed, unused).
// EXTRA_KEY_RE is deliberately stricter for NEW extra-sources sidecars: no '&'.
const FILE_KEY_RE = /^[a-zA-Z0-9_,\-&]+$/;
const EXTRA_KEY_RE = /^[a-zA-Z0-9_,\-]+$/;

// DOC-032 / GoluGit #30: punctuation-split series — map legacy keys to the
// comma + _enxautogen_html convention used by sibling parts. Data files stay
// read-only; remapping is load-time only. Old keys remain resolvable via
// resolveLectureKey() for /api/read compatibility.
const LECTURE_KEY_ALIASES = {
    'Dialogue_Questions_and_Answers_Dec_2003_Part_3':
        'Dialogue,_Questions,_and_Answers_Dec_2003_Part_3_enxautogen_html'
};

// DOC-011 / GoluGit #12: 16 book filenames were truncated mid-word at ~28–30
// chars. Canonical keys are the full slugified titles; data files stay
// read-only and remapping is load-time only. Legacy truncated keys remain
// resolvable via resolveBookKey() / resolveSourceKey() for /api/read,
// /api/quote, and exact-key search filters.
const BOOK_KEY_ALIASES = {
    along_the_path_to_enlightenmen: 'along_the_path_to_enlightenment',
    daily_reflections_from_dr_dav: 'daily_reflections_from_dr_david_r_hawkins',
    discovery_of_the_presence_of_g: 'discovery_of_the_presence_of_god',
    dissolving_the_ego_realizing_: 'dissolving_the_ego_realizing_the_self',
    I_reality_and_subj: 'I_reality_and_subjectivity',
    in_the_world_but_not_of_it__t: 'in_the_world_but_not_of_it',
    letting_go__the_pathway_of_sur: 'letting_go__the_pathway_of_surrender',
    power_vs_force__the_hidden_de: 'power_vs_force__the_hidden_determinants_of_human_behavior',
    reality_spirituality_and_mode: 'reality_spirituality_and_modern_man',
    the_ego_is_not_the_real_you__w: 'the_ego_is_not_the_real_you__wisdom_to_transcend_the_mind_and_realize_the_self',
    the_eye_of_the_i__from_which_n: 'the_eye_of_the_i__from_which_nothing_is_hidden',
    the_highest_level_of_enlighten: 'the_highest_level_of_enlightenment',
    the_map_of_consciousness_expla: 'the_map_of_consciousness_explained',
    the_path_to_spiritual_advancem: 'the_path_to_spiritual_advancement',
    the_wisdom_of_dr_david_r_haw: 'the_wisdom_of_dr_david_r_hawkins',
    transcending_the_levels_of_con: 'transcending_the_levels_of_consciousness'
};

function resolveLectureKey(key) {
    return LECTURE_KEY_ALIASES[key] || key;
}

function resolveBookKey(key) {
    return BOOK_KEY_ALIASES[key] || key;
}

function resolveSourceKey(key) {
    return resolveBookKey(resolveLectureKey(key));
}

function canonicalizeLectureKeys(lectures, lectureMeta) {
    const outLectures = { ...lectures };
    const outMeta = { ...lectureMeta };
    for (const [from, to] of Object.entries(LECTURE_KEY_ALIASES)) {
        if (!outLectures[from]) continue;
        if (!outLectures[to]) {
            outLectures[to] = outLectures[from];
            if (outMeta[from]) outMeta[to] = outMeta[from];
        }
        delete outLectures[from];
        delete outMeta[from];
    }
    return { lectures: outLectures, lectureMeta: outMeta };
}

function canonicalizeBookKeys(books) {
    const out = { ...books };
    for (const [from, to] of Object.entries(BOOK_KEY_ALIASES)) {
        if (!out[from]) continue;
        if (!out[to]) out[to] = out[from];
        delete out[from];
    }
    return out;
}


// --- Load-time text hygiene (DOC-010/012/013-subset/014/015/016) ---
// Deterministic, corpus-wide transforms applied to EVERY load path (lectures,
// books, extra sources, overlays) so /api/read and /api/search serve clean
// text without touching the READ-ONLY data files. Publisher/platform
// boilerplate (DOC-012) is stripped after the unambiguous ingest-damage
// pass via loadCleanText(). Lectures then get DOC-018 transcript normalisation
// (quote fold / Audible / density tag). Running headers / page numbers
// (DOC-013) are stripped in stripRunningChrome() after publisher boilerplate.
// Copyright / © / rights-reserved legal chrome is stripped in
// stripCopyrightFluff() (after publisher boilerplate, before running chrome).
//
// DOC-016: Korean Hangul subtitle interleaves (Sedona Seminar Dec 2008 Parts
// 1–4 were captured from a Korean-subtitled track). Strip Hangul runs — and
// the punctuation/whitespace that belonged only to those runs — so English
// sentences rejoin cleanly.
// DOC-017: extend the same idea to other non-Latin script noise (CJK, kana,
// Cyrillic, Arabic) embedded in English ASR, plus a tiny high-confidence
// glossary autocorrect and collapse of `....` filler runs.

// Non-Latin script letters as a fraction of document length. Matches the
// DOC-016 audit metric (Hangul/CJK/Cyrillic/Arabic/etc. code points / chars).
// Used as an ingest-time soft flag when the share exceeds ~0.5%.
// Greek included since the #18 residue audit (a stray `τη` ASR crumb was
// invisible to the metric because the range was missing).
const NON_LATIN_CHAR_RE = /[\u0370-\u03FF\u1F00-\u1FFF\u0400-\u04FF\u0600-\u06FF\u3040-\u30FF\u3400-\u4DBF\u4E00-\u9FFF\uAC00-\uD7A3\uF900-\uFAFF]/g;
const NON_LATIN_SHARE_WARN = 0.005; // 0.5%

function nonLatinShare(text) {
    const s = String(text);
    if (!s.length) return 0;
    const hits = s.match(NON_LATIN_CHAR_RE);
    return hits ? hits.length / s.length : 0;
}

function warnIfNonLatinHeavy(key, text) {
    const share = nonLatinShare(text);
    if (share > NON_LATIN_SHARE_WARN) {
        console.warn(`[ingest] ${key}: non-Latin share ${(share * 100).toFixed(2)}% exceeds 0.5% threshold`);
    }
    return share;
}

// DOC-018 transcript normalisation (period-density tag + word chunks, quote
// folding, Audible platform lines) lives in normaliseTranscriptText() /
// describeTranscriptNormalisation() below — still deterministic, still
// read-only on data files.


function cleanIngestArtifacts(text) {
    let s = String(text);

    // (1) Encoding damage (DOC-015):
    // Undecoded HTML entities from the ingest step (M&amp;Ms). Only the
    // common named entities — a full decoder could damage rare legit text.
    s = s.replace(/&amp;/g, '&')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/&nbsp;/g, ' ');
    // Raw C0 control characters: vertical tab / form feed were paragraph
    // breaks in the source PDFs; the rest is binary noise. TAB/NL/CR stay.
    s = s.replace(/[\x0B\x0C]/g, '\n').replace(/[\x00-\x08\x0E-\x1F]/g, '');
    // U+FFFD replacement characters (bad ASR decode) — drop them.
    s = s.replace(/\uFFFD/g, '');
    // Non-Latin script noise in English text (DOC-016 Hangul + DOC-017 CJK /
    // kana / Cyrillic / Arabic / Greek / GoluGit #17+#18). Runs of those
    // scripts plus the whitespace/punctuation that sat only with them.
    // Verified: Sedona Parts 1–4 lose 100% of Hangul; ~40 other transcripts
    // lose embedded CJK/Cyrillic crumbs ("핑 hoggy", "ощущas"); the one
    // Greek crumb ("read τη fair") loses just the `τη`. Latin-1 (é, ñ)
    // stays — those can be legitimate. Mid-token garble like "sub었는데" /
    // "Exсperiencelly" loses only the non-Latin fragment.
    s = s.replace(/(?:[\u0370-\u03FF\u1F00-\u1FFF\u0400-\u04FF\u0600-\u06FF\u1100-\u11FF\u3040-\u30FF\u3130-\u318F\u3400-\u4DBF\u4E00-\u9FFF\uA960-\uA97F\uAC00-\uD7A3\uD7B0-\uD7FF\uF900-\uFAFF]+[\s.,!?;:'"…·、。！？「」『』（）()\-–—]*)+/g, '');
    // DOC-017: collapse ASR/OCR `....` filler runs (4+ dots) to a single space.
    s = s.replace(/\.{4,}/g, ' ');
    // UTF-8-read-as-Latin-1 mojibake (CafÃ© -> Café). General but strict
    // decoders for real 3-byte (E0-EF + two continuations) and 2-byte
    // (C2-DF + continuation) sequences; they cannot match well-formed text.
    // 3-byte runs FIRST — a 2-byte pass would half-eat real 3-byte runs.
    s = s.replace(/([\u00e0-\u00ef])([\u0080-\u00bf])([\u0080-\u00bf])/g, (m, b1, b2, b3) =>
        String.fromCharCode(((b1.charCodeAt(0) & 0x0f) << 12) | ((b2.charCodeAt(0) & 0x3f) << 6) | (b3.charCodeAt(0) & 0x3f)));
    s = s.replace(/([\u00c2-\u00df])([\u0080-\u00bf])/g, (m, b1, b2) =>
        String.fromCharCode(((b1.charCodeAt(0) & 0x1f) << 6) | (b2.charCodeAt(0) & 0x3f)));

    // (2) Ingest markers (DOC-010): full-line `====…====` banners — filename
    // headers/footers (`====_A_Map_of_Consciousness_enxautogen_html_====`),
    // truncated-title headers (`====_Letting Go_ the Pathway of Sur_====`),
    // and OCR batch separators (`==== 20241228_143016 ====`). Verified: a
    // full-line filter catches 100% of the 1,426 corpus occurrences.
    s = s.split('\n').filter(line => {
        const t = line.trim();
        return !(t.startsWith('====') || t.endsWith('===='));
    }).join('\n');

    // (3) Separator runs (DOC-013 subset): full-line runs of hyphens,
    // underscores or equals (PDF horizontal rules). Asterisk runs stay —
    // printed books use `*`/`***` as intentional scene breaks.
    s = s.split('\n').filter(line => !/^[-_=]{5,}$/.test(line.trim())).join('\n');

    // (4) Whitespace artifacts (DOC-014): trim line-end spaces FIRST (some
    // "blank" lines contain a lone space, and trimming them after the
    // newline collapse would re-create 4+ newline runs), then collapse 2+
    // blank lines to one (4,481 runs of 4+ newlines in the books), then
    // collapse INTERIOR 4+ space runs (PDF line-join gaps; 99.9% interior,
    // measured). Leading indentation is deliberately preserved (allowlist).
    s = s.replace(/[ \t]+$/gm, '')
        .replace(/\n{3,}/g, '\n\n')
        .replace(/(?<=\S) {4,}(?=\S)/g, ' ');

    // DOC-017 high-confidence ASR glossary (systematic mis-hears). Tiny and
    // deliberate — only phrases confirmed wrong in multiple transcripts.
    s = s.replace(/\bcollaborated level of [Cc]onsciousness\b/g, 'calibrated level of Consciousness');
    s = s.replace(/\bCreative [Ll]ife (?:actually )?rains? the snow\b/g, 'Creative Life Center');
    s = s.replace(/\bwe rain snow for you\b/gi, 'we at Creative Life Center');

    // (5) Glued / missing spaces (GoluGit #20). OCR drops the space after
    // `,`/`:`/`;` in citations (`Watts,Alan`, `AZ:Veritas`, `2003;Klein`),
    // after `.`/`?` before a capital (`worried.The`, `bootstraps?Why`), and
    // between a short lowercase word and a capital (`ofMaharshi`, `thisMap`).
    // Insertions only — words never change, so chapter offsets shift by whole
    // spaces at most. Deliberately NOT handled: digit-letter glue (99% legit
    // ordinals/decades: `20th`, `1960s`), `?`-as-letter OCR damage (`de?ned`
    // fi-ligature vs `it?creation` punctuation glue — indistinguishable
    // deterministically), and `U.S.Army`-style caps-initial glue (kept to
    // protect `U.S.`/`D.T.` initials).
    s = fixGluedSpaces(s);

    // DOC-039 / #64: residual OCR — fi ligatures, remaining ?-glue, ofthe,
    // and the eye_of_the_i duplicated fragment. Ligatures first so
    // de?ned/Justi?es/Sel?sh are not split as punctuation glue.
    s = applyResidualOcrFixes(s);

    // DOC-064 / #101: PvF letter-space + glue leftovers. Phrase-scoped —
    // not a general single-letter join (I was / A person must survive).
    s = applyPvfOcrFixes(s);

    // DOC-065 / #129: common-word misspellings (publically ×1, greatful ×2).
    // Targeted list, not a dictionary.
    s = applyCommonMisspellings(s);

    // DOC-066 / #132: space-before punct, word-word double-spaces, OCR `~o`.
    // Does not strip U+200C/U+200D (Lamsa_bible Syriac ZWNJ/ZWJ).
    s = applyPunctuationSpacing(s);

    return s;
}

// DOC-039 / #64: six known residual OCR sites. Targeted list, not a dictionary.
function applyResidualOcrFixes(text) {
    let s = String(text);
    s = s.replace(/de\?ned/gi, 'defined');
    s = s.replace(/Justi\?es/g, 'Justifies');
    s = s.replace(/justi\?es/gi, 'justifies');
    s = s.replace(/Sel\?sh/g, 'Selfish');
    s = s.replace(/sel\?sh/gi, 'selfish');
    // leftover letter-?-letter is punctuation glue (Get it?creation)
    s = s.replace(/([a-z])\?([a-z])/g, '$1? $2');
    s = s.replace(/\bofthe\b/g, 'of the');
    s = s.replace(/what is really ['‘']the the mind is to see that/g,
        "what is really 'the One'. The way out of the mind is to see that");
    return s;
}

function applyPvfOcrFixes(text) {
    let s = String(text);
    s = s.replace(/\bF OREWORD\b/g, 'FOREWORD');
    s = s.replace(/\bP REFACE\b/g, 'PREFACE');
    s = s.replace(/\bA BOUT THE A UTHOR\b/g, 'ABOUT THE AUTHOR');
    s = s.replace(/\bI magine\b/g, 'Imagine');
    s = s.replace(/\bW hile\b/g, 'While');
    s = s.replace(/\bT he\b/g, 'The');
    // DOC-067 / #140: remaining letter-space. `T o` in PvF chapter 10.
    // Standalone `t he` only — never join `didn't he` / `isn't he` (apostrophe
    // is a JS word boundary, so a naive `\bt he\b` would smash contractions).
    s = s.replace(/\bT o\b/g, 'To');
    s = s.replace(/(?<![A-Za-z\u2019'])t he\b/g, 'the');
    s = s.replace(/\bp atriotism\b/g, 'patriotism');
    s = s.replace(/\bP atriotism\b/g, 'Patriotism');
    s = s.replace(/\ba mericanism\b/g, 'americanism');
    s = s.replace(/\bA mericanism\b/g, 'Americanism');
    s = s.replace(/\bg od\b/g, 'god');
    s = s.replace(/\bG od\b/g, 'God');
    s = s.replace(/\bfr eedom\b/g, 'freedom');
    s = s.replace(/\bf reedom\b/g, 'freedom');
    s = s.replace(/\bF reedom\b/g, 'Freedom');
    s = s.replace(/\bl iberty\b/g, 'liberty');
    s = s.replace(/\bL iberty\b/g, 'Liberty');
    s = s.replace(/\bDuringWorldWar II\b/g, 'During World War II');
    s = s.replace(/\bRamanaMaharshi\b/g, 'Ramana Maharshi');
    s = s.replace(/\bNis-argadatta Maharaja\b/g, 'Nisargadatta Maharaj');
    s = s.replace(/\bJacquesMayol\b/g, 'Jacques Mayol');
    s = s.replace(/\ball-or-nonemuscle\b/g, 'all-or-none muscle');
    s = s.replace(/\bstrongmuscle\b/g, 'strong muscle');
    s = s.replace(/\bdemonstrableweakening\b/g, 'demonstrable weakening');
    s = s.replace(/\btestmus-cle\b/g, 'test muscle');
    s = s.replace(/\bkinesiologicalmuscle\b/g, 'kinesiological muscle');
    return s;
}

function applyCommonMisspellings(text) {
    let s = String(text);
    s = s.replace(/\bpublically\b/gi, 'publicly');
    s = s.replace(/\bgreatful\b/gi, 'grateful');
    return s;
}

function applyPunctuationSpacing(text) {
    let s = String(text);
    // Space before comma (`word ,` → `word,`).
    s = s.replace(/(\w) ,/g, '$1,');
    // Space before period, not part of an ellipsis chain (`. . .` / `..`).
    s = s.replace(/(?<!\.) \.(?!\.)/g, '.');
    // Collapse 2+ spaces between word-chars (ticket `\w  \w`). Repeat for runs.
    let prev;
    do {
        prev = s;
        s = s.replace(/(\w) {2,}(\w)/g, '$1 $2');
    } while (s !== prev);
    // OCR `d` → `~o` in I_AM_THAT. Do not touch approximation tildes.
    s = s.replace(/I really ~o not know/g, 'I really do not know');
    // Re-glue after collapsing `word .Next` / `word ,Next` into missing-space punct.
    s = fixGluedSpaces(s);
    return s;
}

// Publisher / platform boilerplate (DOC-012 / GoluGit #13). Applied after
// cleanIngestArtifacts on every load path. Targets known promo blocks, Audible
// chrome, URL/email lines, and the repeated Hay House medical-disclaimer
// paragraph — not chapter body. Verified: Chapter 1 offsets for letting_go
// and truth_vs_falsehood stay content-identical (only front/back matter
// shrinks).
function stripPublisherBoilerplate(text) {
    let s = String(text);

    // (1) Hay House newsletter promo (verbatim across ~19 books; newlines vary).
    // From "Enjoy uplifting personal stories" through "Visit www.hayhouse.com
    // to sign-up today" (optional trailing punctuation).
    s = s.replace(
        /Enjoy uplifting personal stories[\s\S]*?Visit www\.hayhouse\.com to sign-up today\.?/gi,
        ''
    );

    // (2) Hay House country URL directory (USA/Australia/UK/South Africa/India).
    // Match the block as consecutive "Hay House <Country>:" lines.
    s = s.replace(
        /(?:^|\n)(?:\s*Hay House (?:USA|Australia|UK|South Africa|south Africa|India)\s*:\s*®?www\.hayhouse\.[^\n]*\n?){2,}/gi,
        '\n'
    );

    // (3) Audible platform chrome on satsang transcripts.
    // Intro only — NEVER eat past the first Welcome sentence. Overlays put
    // "This is Audible Welcome to … Center." on the SAME line as real dialogue
    // ("Hi, Dr. Hawkins"), so a newline-eating grab wiped whole lectures.
    s = s.replace(
        /This is Audible\.?\s*(?:\[[^\]]*\]\s*)?(?:(?:Hello and )?welcome to Dr\. David R\. Hawkins' \d{4} Satsang[^.]*\.\s*)?/gi,
        ''
    );
    // Follow-on Audible session/disc chrome sentences (same intro block).
    s = s.replace(/^Session number[^.]*\.\s*/gim, '');
    s = s.replace(/^This is [Dd]isc[^.]*\.\s*/gm, '');
    s = s.replace(/Audible hopes you have enjoyed this program\.?/gi, '');

    // (4) Standalone URL / www / email lines (and bare URL tokens on their own
    // line with optional trailing ®). Also drop inline publisher emails that
    // only appear in catalogue/contact lines.
    s = s.split('\n').filter(line => {
        const t = line.trim();
        if (!t) return true;
        if (/^(?:https?:\/\/|www\.)\S+$/i.test(t)) return false;
        if (/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(t)) return false;
        // "Hay House USA: www.hayhouse.com®" leftovers (single-line form)
        if (/^Hay House [^:]{2,40}:\s*®?www\.hayhouse\.\S+$/i.test(t)) return false;
        // "Published … www.hayhouse.com®" / "info@hayhouse…" catalogue lines
        if (/^Published (?:and distributed )?in the United States by:.*hayhouse/i.test(t)) return false;
        return true;
    }).join('\n');

    // Inline emails — drop every address token so /api/search cannot hit them
    // (DOC-012 done-when: searching any email from the corpus returns 0).
    s = s.replace(/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi, '');

    // Remaining bare http(s)/www tokens (catalogue blurbs, HealYourLife.com®).
    // No \b before www — OCR glues Visit_www.HealYourLife.com® with underscore.
    s = s.replace(/https?:\/\/[^\s<>)"']+/gi, '');
    s = s.replace(/www\.[^\s<>)"']+/gi, '');

    // (5) Repeated Hay House medical disclaimer (~16–18 books). Drop the
    // three-sentence paragraph; chapter body never contains this wording.
    // "author" / "authors" both appear (Along the Path uses plural).
    s = s.replace(
        /The authors? of this book do(?:es)? not dispense medical advice[\s\S]{0,500}?the authors? and the publisher assume no responsibility for your actions\./gi,
        ''
    );

    // (6) Standard "All rights reserved…" copyright paragraph (front matter).
    s = s.replace(
        /All rights reserved\. No part of this book may be reproduced[\s\S]{0,500}?prior written permission of the publisher\./gi,
        ''
    );

    // Collapse whitespace left by block removals (same rules as DOC-014).
    s = s.replace(/[ \t]+$/gm, '')
        .replace(/\n{3,}/g, '\n\n')
        .replace(/(?<=\S) {4,}(?=\S)/g, ' ');

    return s;
}


// Copyright / rights-reserved legal chrome (corpus search pollution).
// Applied after publisher boilerplate on every load path. Targets © notices,
// "All rights reserved" blocks, Institute/Veritas map-copyright footers
// (including glued-to-body forms in the_evolution_of_consciousness), and
// similar recording boilerplate (e.g. Mooji Media). Does NOT strip
// biographical or bibliographic mentions of "Institute for Spiritual
// Research" / "Veritas Publishing" that lack a © / rights-reserved marker.
function stripCopyrightFluff(text) {
    let s = String(text);

    // Institute / Veritas (or OCR "Veritus") map-of-consciousness copyright
    // chrome — standalone OR glued onto the next sentence. Optional "Table "
    // prefix and optional space after ©. Leave the following prose intact.
    // Allow OCR typos: Reeerch/Research, bba/dba, Veritus/Veritas.
    s = s.replace(
        /(?:Table\s+)?©\s*The Institute for Spiritual R\w+,?\s*Inc\.?,?\s*(?:[db]ba\/?\s*)?Verit\w+ Publishing\.?\s*/gi,
        ''
    );

    // Chart reproduction notice that rides with the map copyright.
    s = s.replace(/^This chart cannot be reproduced\.?\s*$/gim, '');
    s = s.replace(/\bThis chart cannot be reproduced\.?\s*/gi, '');

    // "Copyright © 2012 by David R. Hawkins" / Trust / Society / ashram —
    // whole line or run through end-of-line. Year lists like 1995, 1998, 2002.
    // Also "Copyright © Sri Ramanasramam, 1985" (name before year) and short
    // permission credits "Copyright © Name. Used by permission."
    s = s.replace(
        /Copyright\s*©\s*\d{4}(?:\s*,\s*\d{4})*(?:\s*[-–—]\s*\d{4})?(?:\s+by\s+[^\n]{0,160})?/gi,
        ''
    );
    s = s.replace(
        /Copyright\s*©\s+[A-Z][^\n.]{0,80}?(?:,\s*)?\d{4}\.?/gi,
        ''
    );
    s = s.replace(
        /Copyright\s*©\s+[A-Z][^\n.]{0,80}?\.\s*Used by permission\.?/gi,
        ''
    );

    // Bare "© YEAR by …" / "© YEAR Name" permission crumbs (Gleick etc.).
    s = s.replace(
        /©\s*\d{4}(?:\s*,\s*\d{4})*(?:\s+by\s+[^\n.]{0,80}|\s+[A-Z][^\n.]{0,60})?\.?/g,
        ''
    );

    // TOC / outline "Copyright Page" entries (not prose).
    s = s.replace(/^Copyright Page\s*$/gim, '');

    // Bare "© 2024 by …" (no Copyright word) on its own line — covered above.

    // Broader "All rights reserved" legal blocks beyond the Hay House form
    // already handled in stripPublisherBoilerplate (book reproduction clause).
    s = s.replace(
        /All rights reserved\.?\s*No part of (?:this|the)\s+(?:book|recording|program|material)[\s\S]{0,600}?(?:publisher|Ltd|Inc|Society|permission)[^\n.]{0,80}\./gi,
        ''
    );
    s = s.replace(/\bAll [Rr]ights [Rr]eserved\.?\s*/g, '');

    // "The material in this book may not be reproduced…" (Veritas front matter).
    s = s.replace(
        /The material in this book may not be reproduced[\s\S]{0,350}?\./gi,
        ''
    );

    // Mooji Media recording boilerplate (lectures) — full legal sentence,
    // including the trailing "without Mooji Media Ltd.'s express consent."
    s = s.replace(
        /Copyright\s*©\s*\d{4}\s+Mooji Media Ltd\.?\s*All [Rr]ights [Rr]eserved\.?[\s\S]{0,280}?express consent\.?/gi,
        ''
    );
    // Orphan crumbs if Copyright line was already partially stripped.
    s = s.replace(/^Mooji Media Ltd\.\s*$/gim, '');
    s = s.replace(/^'?s express consent\.?\s*$/gim, '');
    s = s.replace(/Mooji Media Ltd\.\s*'?s express consent\.?/gi, '');

    s = s.replace(/[ \t]+$/gm, '')
        .replace(/\n{3,}/g, '\n\n')
        .replace(/(?<=\S) {4,}(?=\S)/g, ' ');

    return s;
}

// Running headers / footers / standalone page numbers (DOC-013 / GoluGit #14).
// Applied after publisher strip on every load path. Drop known Book-of-Slides /
// Veritas repeating chrome, OCR trailing-dash page crumbs (`197-`), bare
// digits only when they sit in a chrome cluster (near an author/title/footer
// line), and short ALL-CAPS / copyright lines that repeat across pages.
// Do NOT strip bare \d{1,4} corpus-wide — in books those are mostly
// map-of-consciousness calibration table values (TVF ~874 tableish vs ~1 crumb).
function stripRunningChrome(text) {
    const lines = String(text).split('\n');
    const trimmed = lines.map((l) => l.trim());
    const freq = new Map();
    for (const t of trimmed) {
        if (!t || t.length > 80) continue;
        freq.set(t, (freq.get(t) || 0) + 1);
    }
    const MIN_REPEAT = 8;
    const CHROME_WINDOW = 3;
    const STRUCTURAL = /^(chapter|part|section|contents|index|preface|appendix|introduction|acknowledgements?|foreword|afterword|bibliography|glossary|notes)$/i;

    function isKnownChrome(t) {
        if (/^DAVID R\. HAWKINS, M\.D\., PH\.D\.[-–—.\s]*$/i.test(t)) return true;
        if (/^BOOK OF SLIDES[-–—.\s]*$/i.test(t)) return true;
        if (/^-?\s*Author:\s*Susan Hawkins$/i.test(t)) return true;
        if (/^©\s*The Institute for Spiritual Research\b/i.test(t)) return true;
        return false;
    }

    function nearChrome(i) {
        const lo = Math.max(0, i - CHROME_WINDOW);
        const hi = Math.min(trimmed.length - 1, i + CHROME_WINDOW);
        for (let j = lo; j <= hi; j++) {
            if (j !== i && isKnownChrome(trimmed[j])) return true;
        }
        return false;
    }

    function nearDigitRule(i) {
        const lo = Math.max(0, i - 2);
        const hi = Math.min(trimmed.length - 1, i + 2);
        for (let j = lo; j <= hi; j++) {
            if (j !== i && /^\d{1,4}[-–—_=]{2,}$/.test(trimmed[j])) return true;
        }
        return false;
    }

    function isPageMarker(t, i) {
        // Trailing-dash OCR crumbs (`197-`) — always drop.
        if (/^\d{1,4}\s*[-–—]\s*$/.test(t)) return true;
        // Full-line digit + dash-rule (`196-----------------------`) — the
        // multi-dash page rules the single-dash crumb rule missed (#14
        // residue). Calibration ranges (`190-195`) and bare table digits
        // never match: this needs 2+ trailing dashes and nothing else.
        if (/^\d{1,4}[-–—_=]{2,}$/.test(t)) return true;
        // Bare digits ONLY inside a BoS/Veritas chrome cluster or next to a
        // digit-rule line (the `403` / `40` page-number echoes that follow
        // `403-----------------`). Full ranges like `190-195` are
        // calibration table values in TVF — keep them.
        if (/^\d{1,4}$/.test(t) && (nearChrome(i) || nearDigitRule(i))) return true;
        return false;
    }

    function isRepeatedRunningHeader(t) {
        const n = freq.get(t) || 0;
        if (n < MIN_REPEAT) return false;
        if (t.length < 3 || t.length > 80) return false;
        if (STRUCTURAL.test(t)) return false;
        if (/©|copyright|all rights reserved|\bpublish(?:er|ing)\b/i.test(t)) return true;
        const letters = t.replace(/[^A-Za-z]/g, '');
        if (letters.length < 3) return false;
        const upper = letters.replace(/[^A-Z]/g, '').length;
        // ALL-CAPS short titles that repeat page after page (running heads).
        return (upper / letters.length) >= 0.85 && t.length <= 60;
    }

    let s = lines.filter((_, i) => {
        const t = trimmed[i];
        if (!t) return true;
        if (isKnownChrome(t)) return false;
        if (isPageMarker(t, i)) return false;
        if (isRepeatedRunningHeader(t)) return false;
        return true;
    }).join('\n');

    // Trailing dash-rules glued to prose line ends by the phone-OCR
    // (`…Luciferic----------------`, 8 corpus hits, all phone_ocr) strip
    // before the whitespace cleanup. 4+ dash-type chars at a line end is
    // never legitimate prose (an interrupted-speech dash is one character).
    s = s.replace(/[-–—_=]{4,}$/gm, '')
        .replace(/[ \t]+$/gm, '')
        .replace(/\n{3,}/g, '\n\n')
        .replace(/(?<=\S) {4,}(?=\S)/g, ' ');
    return s;
}

// Glued / missing spaces (GoluGit #20). Pure single-space insertions; see
// the call site in cleanIngestArtifacts for the deliberately-excluded cases.
// Legit camel words observed corpus-wide — split nothing on this list.
const GLUE_CAMEL_ALLOW = new Set(['iPod', 'iPad', 'eBay', 'eBook', 'iTube']);

function fixGluedSpaces(text) {
    let s = String(text);
    // Comma/colon/semicolon glued to a letter (`Watts,Alan`, `AZ:Veritas`).
    // Digit-flanked commas (`1,000`) survive: a letter must follow. Digit
    // before colon excluded (clock times `12:30`); `cal 200`-style digit-
    // after-colon untouched for the same reason.
    s = s.replace(/,(?=[A-Za-z])/g, ', ');
    s = s.replace(/(?<![0-9]):(?=[A-Za-z])/g, ': ');
    s = s.replace(/;(?=[A-Za-z])/g, '; ');
    // Sentence punctuation glued to a capital (`worried.The`,
    // `bootstraps?Why`). Lowercase-before-dot keeps decimals and `U.S.`-style
    // initials intact (the dot before the letter blocks those); ellipsis
    // (`...The`) is guarded the same way.
    s = s.replace(/(?<![A-Z0-9.])([A-Za-z])\.([A-Z][a-z])/g, '$1. $2');
    s = s.replace(/([a-z])([?!])([A-Z])/g, '$1$2 $3');
    // Lowercase word glued to a capitalised word (`ofMaharshi`, `thisMap`,
    // `Who'sWho` fragments `inWho`/`sWho`, `psychologistWilliam`). No length
    // cap: every uncapped instance in this read-only corpus is glue — the
    // only legit camel words are the 5 allowlisted below.
    // ponytail: a future legit camel word would get split — move it to
    // GLUE_CAMEL_ALLOW if that ever happens (test pins the full split set).
    s = s.replace(/(?<![A-Za-z])([a-z]+)([A-Z][A-Za-z]+)/g, (m, p1, p2) =>
        GLUE_CAMEL_ALLOW.has(m) ? m : `${p1} ${p2}`);
    // Spoken-URL glue (`DrHawkinsInfo`, `DrHawkins.info` — one lecture series).
    // Lives here, not in applyHawkinsHotwords, so the browser hotword mirror
    // (hawkins-lecture-fixes.js) needs no sync.
    s = s.replace(/\bDrHawkins\.info\b/g, 'Dr Hawkins info');
    s = s.replace(/\bDrHawkinsInfo\b/g, 'Dr Hawkins Info');
    s = s.replace(/\bDrHawkins\b/g, 'Dr Hawkins');
    // DOC-054: OCR dropped the space in a few function-word glues.
    s = s.replace(/\bfromthe\b/g, 'from the');
    s = s.replace(/\bthatthe\b/g, 'that the');
    s = s.replace(/\bbodymidline\b/g, 'body midline');
    return s;
}

// Trailing ASR hallucination loops + subtitle crumbs (GoluGit #34). Source
// transcripts end in `you are you are ...` agreement loops, Amara credit
// lines, and stray cue-position words (`here`); the pipeline used to serve
// those as the document ending. End-anchored only — mid-text speech is never
// touched. The loop run strips only when the remainder still ends with
// sentence punctuation, so this never manufactures a mid-sentence cut; docs
// truncated mid-sentence in SOURCE stay as-is (no text to recover). Genuinely
// cut overlay tails are out of scope for the same reason.
// Bare `you`/`we` sit INSIDE runs only (`... you are you we all you are
// here` — the middle `you`/`we` are loop babble, never sentence words). They
// are listed last so full phrases (`you are`, `we all`) match first, and the
// >=2-token + remainder-punctuation guards still apply.
const ASR_LOOP_PHRASE = "you are|you're|you know|oh|yeah|here|there|we all|you here|know here|all here|oh yeah|if|not|to|you|we|know";
const ASR_LOOP_RUN_RE = new RegExp('((?:\\s*\\b(?:' + ASR_LOOP_PHRASE + ')\\b[.,]?)+(?:\\s*\\byou\\b)?)\\s*$', 'i');
const ASR_LOOP_LEAD_RE = new RegExp('^\\s*\\b(?:' + ASR_LOOP_PHRASE + ')\\b[.,]?', 'i');
const SENT_END_RE = /[.?!]["'\u201d\u2019)\]]?\s*$/;

function stripTrailingAsrJunk(text) {
    let s = String(text);
    // Amara subtitle credit at the tail — own line or same-line after the
    // closing sentence (`... O Lord. Subtitles by the Amara.org community`).
    s = s.replace(/(^|\n|[.?!])\s*Subtitles by the Amara\.org community\.?\s*$/i, '$1');
    // DOC-052 / GoluGit #89: drop identical-token decoder runs in the tail
    // before the end-anchored `here` strip, so a `$10.`/`Yes.` loop does not
    // shield a leftover cue-word.
    s = collapseIdenticalTokenRunsAtEof(s);
    // Hallucinated agreement loop (`you are you are ...`, `you know`, `oh`,
    // `yeah`, trailing `here`). A trailing dangling `you` (`... you are you`)
    // belongs to the same loop — allowed as the run's tail, never as the
    // whole run. Single dangling words (`actually`, `Butler`, `God`) are
    // speech, not loops, and stay.
    // The maximal run can start too early (`Yeah. oh you are ... here` — the
    // `Yeah` is loop vocabulary but the sentence before it is the real
    // remainder), so move one leading phrase at a time from run to remainder
    // until the remainder ends with sentence punctuation (max 3 moves).
    const m = s.match(ASR_LOOP_RUN_RE);
    if (m) {
        let head = '';
        let tail = m[1];
        const base = s.slice(0, m.index);
        for (let i = 0; i < 4; i++) {
            const tokens = tail.match(/\b[a-z']+\b/gi) || [];
            const hasPhrase = /\byou (?:are|know)\b/i.test(tail) || /\byou're\b/i.test(tail);
            if (!(tokens.length >= 3 || (tokens.length >= 2 && hasPhrase))) break;
            const rest = base + head;
            if (SENT_END_RE.test(rest)) {
                s = rest.replace(/\s+$/, '');
                break;
            }
            const lead = tail.match(ASR_LOOP_LEAD_RE);
            if (!lead) break;
            head += lead[0];
            tail = tail.slice(lead[0].length);
        }
    }
    // Stray cue-position word after a finished sentence (`truth. here`).
    s = s.replace(/([.?!])\s+(here|there)\.?\s*$/i, '$1');
    return s;
}

// Token: `$10.` / `440,` / a word with optional trailing punct. Four or more
// consecutive identical copies in the last IDENTICAL_TOKEN_TAIL_CHARS is a
// decoder loop, not speech (`no no no` stays).
const IDENTICAL_TOKEN_TAIL_CHARS = 800;
const IDENTICAL_TOKEN_MIN_RUN = 4;
const IDENTICAL_TOKEN_RE = /(\$?\d+(?:\.\d+)?|[A-Za-z][A-Za-z']*)[.,]?/;
const IDENTICAL_TOKEN_RUN_RE = new RegExp(
    '(' + IDENTICAL_TOKEN_RE.source + ')(?:\\s+\\1){' + (IDENTICAL_TOKEN_MIN_RUN - 1) + ',}',
    'gi'
);

function collapseIdenticalTokenRunsAtEof(text, windowChars) {
    const s = String(text);
    const win = windowChars == null ? IDENTICAL_TOKEN_TAIL_CHARS : windowChars;
    const splitAt = s.length > win ? s.length - win : 0;
    const head = s.slice(0, splitAt);
    let tail = s.slice(splitAt);
    const next = tail.replace(IDENTICAL_TOKEN_RUN_RE, '');
    if (next === tail) return s;
    // Only tidy spaces when a run was actually dropped, so this is a
    // fixpoint on already-clean served text.
    tail = next.replace(/[ \t]{2,}/g, ' ');
    return head + tail;
}

// DOC-053 / GoluGit #90: a lecture (often Part 2/3) whose first 80 chars
// lack a capital start, or begin with `...` / lowercase `and `, so search
// and the reader would treat a mid-clause fragment as a clean opening.
// Data files are read-only; we flag rather than recut. Do not add overlay
// files for these — overlayCount must stay 0 or the full set.
function looksAbruptStart(text) {
    const s = String(text).replace(/^\s+/, '');
    if (!s) return false;
    const head = s.slice(0, 80);
    if (/^\.{2,}/.test(head)) return true;
    if (/^and /.test(head)) return true;
    return !/^[A-Z"'\u201C\u2018(\[]/.test(s);
}

// DOC-054: word-level OCR/ASR damage that survives ingest hygiene.
// Phrase-scoped. Does not rewrite bare principal/piece/Thane/eagle.
function applyDoc054Fixes(text) {
    let s = String(text);
    // Power vs Force OCR chapter heads: "C HAPTER E LEVEN" → "CHAPTER ELEVEN".
    s = s.replace(/C HAPTER\s+([A-Z](?:[ -]+[A-Z]+)*)/g, (_, w) => 'CHAPTER ' + w.replace(/ /g, ''));
    s = s.replace(/\bM an has freedom/g, 'Man has freedom');
    s = s.replace(/\bbecaus you\b/g, 'because you');
    s = s.replace(/The Science of Peacer\./g, 'The Science of Peace.');
    s = s.replace(/\bmembership of PLACT web site\b/g, 'membership of the FACTNet web site');
    s = s.replace(/\bJust bottles my mind\./gi, 'Just boggles my mind.');
    s = s.replace(/\bHunan what's his name/gi, "Hussein what's his name");
    s = s.replace(/\bit occured itself\b/gi, 'it cured itself');
    s = s.replace(/\bthey're conciousness\b/gi, 'their consciousness');
    s = s.replace(/\bconciousness\b/gi, 'consciousness');
    s = s.replace(/\bleaming God for\b/gi, 'blaming God for');
    s = s.replace(/\bleaming\b/g, 'learning');
    s = s.replace(/\bAdvita\b/g, 'Advaita');
    s = s.replace(/\bspiritual eagle\b/gi, 'spiritual ego');
    s = s.replace(/\bprincipal of becoming\b/gi, 'principle of becoming');
    s = s.replace(/\bpiece of mind\b/gi, 'peace of mind');
    s = s.replace(/a certain peace of mind\.\s*a certain peace of mind/gi, 'a certain peace of mind');
    s = s.replace(/\bManaharshi\b/g, 'Maharshi');
    s = s.replace(/\bDaskarPatrita\b/g, 'the Maharshi');
    s = s.replace(/\bdiplomatic cores\b/gi, 'diplomatic corps');
    s = s.replace(/\bthe amount of Maharishi Nisargadatta Maharaj\b/gi, 'the likes of Maharshi Nisargadatta Maharaj');
    s = s.replace(/\bsubnal energy\b/gi, 'subtle energy');
    return s;
}

function loadCleanText(text) {
    return applyPunctuationSpacing(applyDoc054Fixes(stripTrailingAsrJunk(stripRunningChrome(stripCopyrightFluff(stripPublisherBoilerplate(cleanIngestArtifacts(text)))))));
}


// --- Transcript normalisation (GoluGit #19 / DOC-018) ---
// Unpunctuated ASR overlays sit near 0 periods/1k chars; dialogue-heavy
// satsangs sit ~25–36. Full ML punctuation restoration / true-casing is out
// of scope for a deterministic load-time pass. Instead:
//   1. Fold curly quotes/dashes to straight (corpus-side half of DOC-008).
//   2. Strip Audible platform intro/outro lines (DOC-012 transcript subset).
//   3. Measure period density; tag below-band lectures `raw_asr` and expose
//      word-count chunks so callers can re-chunk without sentence splits.
//   4. Stamp normalisationVersion on every lecture meta record.
// Upper band is 40 (not the issue's illustrative 25) so short-utterance
// satsangs stay `normal` rather than being mis-tagged as raw ASR.

const NORMALISATION_VERSION = 'doc-018-v1';
const PERIOD_DENSITY_MIN = 8;   // periods per 1,000 chars
const PERIOD_DENSITY_MAX = 40;  // dialogue-heavy satsangs measured ≤36.2
const RAW_ASR_WORD_CHUNK = 200;

function periodDensity(text) {
    const s = String(text);
    if (!s.length) return 0;
    const periods = (s.match(/\./g) || []).length;
    return (periods * 1000) / s.length;
}

function foldQuoteVariants(text) {
    // Curly → straight so typed contractions match lecture text; books keep
    // their typography (search-time folding is a separate DOC-008 concern).
    return String(text)
        .replace(/[\u2018\u2019\u201A\u201B]/g, "'")
        .replace(/[\u201C\u201D\u201E\u201F]/g, '"')
        .replace(/[\u2013\u2014]/g, '-');
}

function stripAudibleBoilerplate(text) {
    // Platform chrome only — keep "Welcome to Dr. …" content. Case-sensitive
    // so "audible voice" in Q&A is untouched. Amara subtitle credits ride
    // here too: the caption track baked them mid-sentence in two lectures
    // (`... question? Subtitles by the Amara.org community consequence ...`,
    // GoluGit #34) — never speech, strip every occurrence.
    let s = String(text);
    s = s.replace(/^This is Audible\.?\s*(?:\[[^\]]*\]\s*)?/gm, '');
    s = s.replace(/\s*Audible hopes you(?:'ve| have) enjoyed this program\.?/g, '');
    s = s.replace(/\s*Subtitles by(?: the Amara\.org community|\s+\S+)\.?/gi, '');
    return s;
}

function normaliseTranscriptText(text) {
    // Lecture/overlay-only (not books): quote fold + Audible strip after
    // shared ingest hygiene.
    return foldQuoteVariants(stripAudibleBoilerplate(text));
}

function chunkByWordCount(text, wordsPerChunk) {
    const size = wordsPerChunk || RAW_ASR_WORD_CHUNK;
    const s = String(text);
    const chunks = [];
    const re = /\S+/g;
    let m;
    let words = [];
    let chunkStart = null;
    let lastEnd = 0;
    const flush = () => {
        if (!words.length) return;
        chunks.push({
            index: chunks.length,
            offset: chunkStart,
            wordCount: words.length,
            text: s.slice(chunkStart, lastEnd)
        });
        words = [];
        chunkStart = null;
    };
    while ((m = re.exec(s))) {
        if (chunkStart === null) chunkStart = m.index;
        words.push(m[0]);
        lastEnd = m.index + m[0].length;
        if (words.length >= size) flush();
    }
    flush();
    return chunks;
}

function describeTranscriptNormalisation(text) {
    const density = periodDensity(text);
    const inBand = density >= PERIOD_DENSITY_MIN && density <= PERIOD_DENSITY_MAX;
    const transcriptTag = density < PERIOD_DENSITY_MIN ? 'raw_asr' : 'normal';
    const meta = {
        normalisationVersion: NORMALISATION_VERSION,
        periodDensity: Math.round(density * 1000) / 1000,
        transcriptTag,
        inBand
    };
    if (transcriptTag === 'raw_asr') {
        meta.chunks = chunkByWordCount(text, RAW_ASR_WORD_CHUNK);
        meta.chunkWordSize = RAW_ASR_WORD_CHUNK;
    }
    return meta;
}


function loadJsonDataSource(filePath, objectKey) {
    if (!fs.existsSync(filePath)) return {};
    try {
        let code = fs.readFileSync(filePath, 'utf8');
        // const declarations don't create sandbox properties in vm.runInNewContext;
        // replace with var so the assignment becomes a global property.
        code = code.replace(/^\s*const /, 'var ');
        const sandbox = { the_json_obj: {}, the_json_obj_books: {} };
        vm.runInNewContext(code, sandbox, { filename: filePath });
        return { [objectKey]: sandbox[objectKey] || {} };
    } catch (err) {
        console.error(`Failed to parse ${filePath}:`, err.message);
        return {};
    }
}

function reflowLongLines(text) {
    // Break oversize lines at sentence boundaries so /api/read is readable.
    // Used for the Health lecture leftover AND batch-20 overlays (one paragraph).
    // Pass 1: classic ". Capital" (books + cleaned old ASR).
    // Pass 2: any ". " except abbreviations — new large-v3 lines often start lowercase ("Uh,").
    // Pass 3: clause breaks for leftover mega-runs (thousands of chars with no ". ").
    //         Display-only: words are never changed, only line breaks added.
    return String(text).split('\n').map(line => {
        if (line.length <= 700) return line;
        let s = line.replace(/(?<!\b(?:Dr|Mr|Mrs|Ms|Prof|St|Sr|Jr|vs|etc|[A-Z]))\.\s+(?=[A-Z"'\u201C])/g, '.\n');
        s = s.split('\n').map(chunk => {
            if (chunk.length <= 1200) return chunk;
            return chunk.replace(/(?<!\b(?:Dr|Mr|Mrs|Ms|Prof|St|Sr|Jr|vs|etc))\.\s+/g, '.\n');
        }).join('\n');
        s = s.split('\n').map(chunk => {
            // DOC-046: unpunctuated ASR dumps (~1300 chars, almost no ". ")
            // were skipped at 2000. Inner 1500 skipped the 1227 dump after comma split.
            if (chunk.length <= 900) return chunk;
            let c = chunk.replace(/, +/g, ',\n');
            c = c.split('\n').map(seg => {
                if (seg.length <= 900) return seg;
                return seg
                    .replace(/\band\s+/g, '\nand ')
                    .replace(/\bso\s+/g, '\nso ')
                    .replace(/\bbut\s+/g, '\nbut ')
                    .replace(/\bbecause\s+/g, '\nbecause ');
            }).join('\n');
            return c;
        }).join('\n');
        return s.trim();
    }).join('\n');
}

function applyHawkinsHotwords(text, opts) {
    const rewriteEagle = !opts || opts.rewriteEagle !== false;
    let out = String(text);
    if (rewriteEagle) {
        // Protect real "Eagle Scout" from the ego hotword (new ASR + old corpus).
        out = out
            .replace(/\bEagle Scout\b/g, '\u0000EAGLE_SCOUT\u0000')
            .replace(/\beagle\b/gi, (m) => m[0] === 'E' ? 'Ego' : m === m.toUpperCase() ? 'EGO' : 'ego')
            .replace(/\u0000EAGLE_SCOUT\u0000/g, 'Eagle Scout');
    }
    return out
        .replace(/\bBen\s+Loud[oe]n\b/gi, 'Bin Laden')
        .replace(/\bbin loudon\b/gi, 'Bin Laden')
        .replace(/\bbin raven\b/gi, 'Bin Laden')
        .replace(/\bcrozack\b/gi, 'Prozac')
        .replace(/\bArmando\s+Maharishi\b/gi, 'Ramana Maharshi')
        .replace(/\bRamana\s+Maharishi\b/gi, 'Ramana Maharshi')
        .replace(/\ba\s+tractor\s+fields?\b/gi, 'attractor field')
        .replace(/\btractor\s+fields?\b/gi, 'attractor field')
        .replace(/\battractive\s+fields?\b/gi, 'attractor field')
        .replace(/\battractor\s+fuels?\b/gi, 'attractor field')
        .replace(/Gloria\s+in\s+Excelsior\s+Steel/gi, 'Gloria in Excelsis Deo')
        .replace(/Korean\s+Excelsior\s+Steel/gi, 'Gloria in Excelsis Deo')
        .replace(/\bExcelsior\s+Steel\b/gi, 'Excelsis Deo')
        // DOC-061: Gloria in Excelsis Deo ASR variants that escaped the Steel-only hotword.
        // Specific phrases first. Do not touch "Glorian Ross".
        .replace(/Gloria and Excelsior God beat the guy didn't know it's and on Earth Goodwill to men/gi, 'Gloria in Excelsis Deo. Peace on Earth, goodwill to men')
        .replace(/Gloria and Excelsior that fries you(?: you)?['’]re/gi, "Gloria in Excelsis Deo. If you're")
        .replace(/Gloria in Excelsior Praise/gi, 'Gloria in Excelsis Deo. Praise')
        .replace(/Gloria and Excelsior Studio/gi, 'Gloria in Excelsis Deo')
        .replace(/where to God in the highest/gi, 'Glory to God in the highest')
        .replace(/Maria in excelsious deal/gi, 'Gloria in Excelsis Deo')
        .replace(/glory in excelsious deal/gi, 'Gloria in Excelsis Deo')
        .replace(/glorian\s+excelsior(?:['’]?s)?\s+deal/gi, 'Gloria in Excelsis Deo')
        .replace(/Gloria and excelsior['’]?s deal/gi, 'Gloria in Excelsis Deo')
        .replace(/\ban\s+Excelsior['’]?s\s+deal\b/gi, 'Gloria in Excelsis Deo')
        .replace(/\bExcelsior['’]?s\s+deal\b/gi, 'Gloria in Excelsis Deo')
        .replace(/\bexcelsious\s+diaw\b/gi, 'Excelsis Deo')
        .replace(/\bexcelsious\s+deal\b/gi, 'Gloria in Excelsis Deo')
        .replace(/\bexcelsious\b/gi, 'excelsis')
        .replace(/\bglor(?:ia|y)\s+and\s+Excelsior\b/gi, 'Gloria in Excelsis Deo')
        .replace(/Gloria\s+and\s+Excelsior\b/gi, 'Gloria in Excelsis Deo')
        .replace(/Gloria\s+in\s+Excelsior\b/gi, 'Gloria in Excelsis Deo')
        .replace(/Gloria in Excelsis Deo that fries you(?: you)?['’]re/gi, "Gloria in Excelsis Deo. If you're")
        .replace(/\b5:40\b/g, '540')
        .replace(/\bRomana\b/g, 'Ramana')
        .replace(/\bRamona\b/g, 'Ramana')
        .replace(/\bRamada\b/g, 'Ramana')
        .replace(/\bMr\.\s*Godadamara\b/gi, 'Nisargadatta Maharaj')
        .replace(/Godada\s+Maharaj/gi, 'Nisargadatta Maharaj')
        .replace(/Godada\w*/gi, 'Nisargadatta')
        .replace(/\bClomagnum\b/gi, 'Cro-Magnon')
        .replace(/\binfill man\b/gi, 'Neanderthal man')
        .replace(/\bKill-Town Man\b/gi, 'Neanderthal man')
        .replace(/\bKilton man\b/gi, 'Neanderthal man')
        .replace(/\bAustralopis(?:\s+Popis)?\b/gi, 'Australopithecus')
        .replace(/\bAustralopopis\b/gi, 'Australopithecus')
        .replace(/\bnon-integers\b/gi, 'non-integrous')
        .replace(/\bnon-integrists\b/gi, 'non-integrous')
        .replace(/\bintegrists\b/gi, 'integrous')
        .replace(/\bDo you just said\b/gi, 'Did you just say')
        .replace(/\bthat which is Caesar\b(?!'s)/gi, "that which is Caesar's")
        .replace(/\binlet that rode\b/gi, 'intellectual road')
        .replace(/Homo erectus,\s*Antho,\s*Australopithecus/gi, 'Homo erectus, Australopithecus')
        // #104: ASR "cities"/"city" for siddhis — phrase-only, not biblical cities
        .replace(/\bachieve the cities\b/gi, 'achieve the siddhis')
        .replace(/\ba certain city\b/gi, 'a certain siddhi')
        // DOC-047: Cancer (and shared health-lecture intro) ASR homophones.
        // Phrase-scoped so "position"/"secretary"/"conference" elsewhere stay.
        .replace(/\bHawkins position for\b/gi, 'Hawkins practice for')
        .replace(/\bform of secretary and group therapy\b/gi, 'form of individual and group therapy')
        .replace(/\bmysterious conference\b/gi, 'mysterious conditions')
        // DOC-050: health-lecture stock intro ASR (glossary / intro-template).
        // Phrase-scoped so "cycle"/"Dave"/"you" elsewhere stay.
        .replace(/\bcycle analysis\b/gi, 'psychoanalysis')
        .replace(/\bI'm gonna psychiatrist\b/gi, "I've been a psychiatrist")
        .replace(/\bgonna psychiatrist\b/gi, 'been a psychiatrist')
        .replace(/\bpsychothermicology\b/gi, 'psychopharmacology')
        .replace(/\bpsychoanalist\b/gi, 'psychoanalyst')
        .replace(/\bof specialized\b/gi, 'I specialized')
        .replace(/\bphysician in the psychiatrist\b/gi, 'physician and psychiatrist')
        .replace(/\bDid you're the research and\b/gi, 'I did research in')
        .replace(/\bDid you're the research\b/gi, 'I did research in')
        .replace(/\bthe second analyst\b/gi, 'psychoanalyst')
        .replace(/\byou I'm Dr\b/gi, "I'm Dr")
        .replace(/\ba psychoanalysis\b/gi, 'psychoanalysis')
        .replace(/\bbeen as a psychiatrist\b/gi, 'been a psychiatrist')
        .replace(/\bDr\. Dave Hawkins\b/gi, 'Dr. David Hawkins')
        .replace(/\bIn today's talk is going to be\b/gi, "Today's talk is going to be")
        .replace(/\bresearcher and the relationship between nutrition and the relationship to alcoholism\b/gi, 'researcher into the relationship between nutrition and alcoholism')
        .replace(/\bfields of psychoanalysis psychopharmacology Psychotherapy group therapy\b/gi, 'fields of psychoanalysis, psychopharmacology, psychotherapy, group therapy')
        // DOC-051 / #88: proper-name ASR (phrase-scoped)
        .replace(/\bair fat\b/gi, 'Arafat')
        .replace(/\blaboratory retrievers\b/gi, 'Labrador retrievers')
        .replace(/\bCatholics Diocese\b/gi, 'Catholic Diocese')
        .replace(/\bMingu['’]s Mountain\b/gi, 'Mingus Mountain')
        .replace(/\bunderstand Campbell's\b/gi, 'understand camels')
        // DOC-062 / #100: Volume I-V / Verification lecture ASR (phrase-scoped)
        .replace(/\bpower versus Forest(?:er)?\b/gi, 'power versus Force')
        .replace(/\bor here election like this\b/gi, 'or hear a lecture like this')
        .replace(/\bshark Cathedrals?\b/gi, 'Chartres Cathedral')
        .replace(/\b503 genuine Flexin so all forms symbolic of their symbolic these to do this and itself is 540\b/gi, '[inaudible] itself is 540')
        .replace(/\bthe agreeing chin the background\b/gi, 'the echoing in the background')
        .replace(/\bgoing to ohmaster\b/gi, 'going to a master')
        .replace(/\benergy dingo\b/gi, 'energy field')
        .replace(/\ba very famous Butler\b/gi, 'a very famous author')
        .replace(/\bthird must stay\b/gi, 'third-month stay')
        .replace(/\binterdication\b/gi, 'inner dictation')
        .replace(/\bif David our Hawkins\b/gi, 'Dr. David R. Hawkins')
        .replace(/Dr\. David Hawkins Tay reung['’]s son Keck tosa\.?/gi, 'Dr. David R. Hawkins.')
        .replace(/Tay reung['’]s son Keck tosa\.?/gi, '')
        .replace(/\bDavid our Hawkins\b/gi, 'David R. Hawkins')
        // #142: Integris / integers / inlet / Forester (phrase-scoped Forest).
        // Do not global-replace Forest (forest-for-the-trees, Amazon forest).
        .replace(/\bthe integers\b/gi, 'the integrity')
        .replace(/\bintegers\b/gi, 'integrous')
        .replace(/\bIntegris\b/gi, 'integrous')
        .replace(/\binlet\b/gi, (m) => m[0] === 'I' ? 'Intellect' : 'intellect')
        .replace(/\bForester intimidation\b/gi, 'force or intimidation')
        .replace(/\bart on Forest\b/gi, 'Ardennes Forest')
        .replace(/\byard and Forest\b/gi, 'Ardennes Forest')
        .replace(/^(\s*)it here (?=[A-Z])/i, '$1')
        .replace(/^(\s*)here (?=What\b)/i, '$1')
        .replace(/^(\s*)here take my word/i, '$1Take my word')
        // #145: Verification Part 1 opening thanks + Darwin ASR (phrase-scoped).
        .replace(/Thank you very much for school\.?\s*(?:here\s+)?Yeah,\s*yeah\.\s*here\s*/gi, 'Thank you very much. ')
        .replace(/Thank you very much for school/gi, 'Thank you very much')
        .replace(/Darwin['’]s\s+Love\s+Revolution/gi, "Darwin's evolution")
        .replace(/\b(\w+)\s+\1\b/gi, (m, w) => w);
}

// DOC-046: collapse ASR stutter loops (exact line dups, ellipsis restarts,
// repeated 4–12 word clauses). Words are not invented — repeats are dropped.
function collapseAsrStutters(text) {
    let s = collapseRepeatedClauses(String(text));
    s = s.replace(/\b(?:to have a relationship with (?:the|your) mind,?\s*){2,}/gi,
        'to have a relationship with the mind, ');
    // Leftover #78 (comment 1707): near-repeats, not exact 4–12 word copies.
    s = s.replace(/as each thing comes up, you let it go(?:, and as it comes up, you let it go)+/gi,
        'as each thing comes up, you let it go');
    s = s.replace(/\b(does not cause the next thing of his wings going up)\s+which\s+\1/gi, '$1');
    return collapseConsecutiveTripleDuplicates(applyDoc055Fixes(collapseLineRestarts(s)));
}

function collapseRepeatedClauses(s) {
    for (let n = 12; n >= 4; n--) {
        const re = new RegExp(
            String.raw`\b((?:[\w']+[.,]?\s+){${n - 1}}[\w']+)(?:[,;]?\s+(?:and\s+)?\1)+\b`,
            'gi'
        );
        s = s.replace(re, '$1');
    }
    return s;
}

function collapseLineRestarts(text) {
    const lines = String(text).split('\n');
    const out = [];
    for (let i = 0; i < lines.length; i++) {
        const cur = lines[i];
        const next = i + 1 < lines.length ? lines[i + 1] : null;
        if (next == null) {
            out.push(cur);
            continue;
        }
        const a = cur.trim();
        const b = next.trim();
        if (a && a === b) continue;
        if (a && /\.\.\.\s*$/.test(a)) {
            const stem = a.replace(/\.\.\.\s*$/, '').trim();
            if (stem.length >= 20 && b.startsWith(stem)) continue;
        }
        const a2 = a.replace(/^And\s+/i, '');
        const b2 = b.replace(/^And\s+/i, '');
        if (a && b && a !== b && a2.toLowerCase() === b2.toLowerCase()) continue;
        out.push(cur);
    }
    return out.join('\n');
}

// DOC-055 / GoluGit #84: mid-document ASR hallucination runs, unbracketed
// laughter chrome, leftover subtitle credits, and a few word-salad passages.
// Phrase-scoped / run-length gated. Call-and-response like `Mung?` ×14 stays.
const DOC055_TOKEN_RE = /(\$?\d+(?:\.\d+)?|[A-Za-z][A-Za-z']*)[.,!?]?/g;
const DOC055_MIN_IDENTICAL_RUN = 12;
const DOC055_MIN_PHRASE_COPIES = 8;
const DOC055_KEEP_RUN_TOKEN = new Set(['mung?']);
const DOC055_LAUGHTER_KEEP_BEFORE = /\b(of|the|into|and|use|choosing|value|with|for|by|about|and so)\s+$/i;

function applyDoc055Fixes(text) {
    let s = String(text);
    s = s.replace(/\s*Subtitles by(?: the Amara\.org community|\s+\S+)\.?/gi, '');
    s = s.replace(
        /I'll do DoCo hoping in a hunting department I do-di-da-po God, oh, do or II\? Told him to the kid out and auto the big enemy fulkin to King come with a dog Oh Go, go Thank you\.\s*Thank you\./g,
        '[inaudible side conversation]'
    );
    s = s.replace(
        /\s*in like is not the same\.\.!\s*same in the dinosaur\s+and (?:bin loudon|Bin Laden)\s*/gi,
        ' '
    );
    s = s.replace(/\s*I'm in like certainly is not the same in the kitty\s*/gi, ' ');
    // Leftover Advaita Aug 2002 P2 crowd-noise / OCR (#84 comment 1944).
    s = s.replace(/\bpoor hole\b/gi, 'portal');
    s = s.replace(/\bAhmad is tämä style\b/gi, 'talk-show style');
    s = s.replace(/\s*Spe millennials gives purrs costing\s*/g, ' ');
    s = s.replace(
        /(Prozac would have felt better in some other kind of way or another careful\s*){2,}/gi,
        'Prozac would have felt better in some other kind of way or another. Careful: '
    );
    s = s.replace(/\s*one scaly\s+and vicious with drag\s*/gi, ' ');
    // Remainder #84: Sedona Dec 2008 P4 L1059 was a 9-dot run (12+ already folded).
    s = s.replace(/\.(?:\s+\.){8,}/g, '.');
    s = s.replace(
        /Well, there were things that happened wrong and that whiskey smelt shit\.\s*It didn't grow in the dogdies that night and that peach was out halfway sh tym\.\s*But, you know, people intended to be on the drozzling\./g,
        '[inaudible side conversation]'
    );
    // DOC-062 / #100: Volume I P2 kinesiology-demo ASR salad (ticket allows [inaudible demo]).
    s = s.replace(
        /For another minute\.\s*Let me know why\.\s*Only mind let me know\.\s*Rock Hill has positive energy every rock kind of energy as a video game changes contract videos now\./g,
        '[inaudible demo]'
    );
    s = collapseMidDocIdenticalTokenRuns(s);
    s = collapseRepeatedShortPhrases(s);
    s = bracketLaughterMarkers(s);
    return s.replace(/[ \t]{2,}/g, ' ').replace(/[ \t]+\n/g, '\n');
}

function collapseMidDocIdenticalTokenRuns(text, minRun) {
    const s = String(text);
    const min = minRun == null ? DOC055_MIN_IDENTICAL_RUN : minRun;
    const matches = [...s.matchAll(DOC055_TOKEN_RE)];
    if (!matches.length) return s;
    let out = '';
    let last = 0;
    let i = 0;
    while (i < matches.length) {
        let j = i + 1;
        const canon = matches[i][0].toLowerCase();
        while (j < matches.length) {
            const gap = s.slice(
                matches[j - 1].index + matches[j - 1][0].length,
                matches[j].index
            );
            if (matches[j][0].toLowerCase() !== canon || !/^[\s-]*$/.test(gap)) break;
            j++;
        }
        if (j - i >= min && !DOC055_KEEP_RUN_TOKEN.has(canon)) {
            const start = matches[i].index;
            const end = matches[j - 1].index + matches[j - 1][0].length;
            out += s.slice(last, start);
            out += replacementForIdenticalRun(matches[i][0], canon);
            last = end;
        }
        i = j;
    }
    out += s.slice(last);
    return out;
}

function replacementForIdenticalRun(original, canon) {
    const bare = canon.replace(/[.,!?]/g, '');
    if (/^\d{3}\.\d{2}$/.test(bare)) return '';
    if (/^\$/.test(canon)) return '';
    if (bare === 'ha' || bare === 'hah' || bare === 'hmm' || bare === 'hmmm') return '[laughter]';
    if (bare === 'e' || bare === 'da' || bare === 'dum' || bare === 'la' || bare === 'na') return '[music]';
    if (bare === 'amen' || bare === 'krishna') return original.replace(/[.,!?]+$/, '') + ' [chanting]';
    if (bare === 'bye' || bare === 'goodbye') return '[goodbyes]';
    if (bare === 'music') return '[music]';
    return original;
}

function collapseRepeatedShortPhrases(text, minCopies) {
    const min = minCopies == null ? DOC055_MIN_PHRASE_COPIES : minCopies;
    let s = String(text);
    for (let n = 3; n >= 2; n--) s = collapseNgramRuns(s, n, min);
    return s;
}

function collapseNgramRuns(s, nWords, minCopies) {
    const matches = [...s.matchAll(DOC055_TOKEN_RE)];
    if (matches.length < nWords * minCopies) return s;
    let out = '';
    let last = 0;
    let i = 0;
    while (i + nWords <= matches.length) {
        const phrase = matches.slice(i, i + nWords).map((m) => m[0].toLowerCase()).join(' ');
        let copies = 1;
        let pos = i + nWords;
        while (pos + nWords <= matches.length) {
            const next = matches.slice(pos, pos + nWords).map((m) => m[0].toLowerCase()).join(' ');
            const gap = s.slice(
                matches[pos - 1].index + matches[pos - 1][0].length,
                matches[pos].index
            );
            if (next !== phrase || !/^[\s-]*$/.test(gap)) break;
            copies++;
            pos += nWords;
        }
        if (copies >= minCopies) {
            const start = matches[i].index;
            const end = matches[pos - 1].index + matches[pos - 1][0].length;
            out += s.slice(last, start);
            out += s.slice(start, matches[i + nWords - 1].index + matches[i + nWords - 1][0].length);
            last = end;
            i = pos;
            continue;
        }
        i++;
    }
    out += s.slice(last);
    return out;
}

function bracketLaughterMarkers(text) {
    let s = String(text);
    s = s.replace(/\b(?:laughter\s+){1,}laughter\b/gi, '[laughter]');
    s = s.replace(/\blaughter\b/gi, (m, offset, str) => {
        const before = str.slice(Math.max(0, offset - 24), offset);
        if (/\[$/.test(before) || /\[laughter\]\s*$/i.test(before)) return m;
        if (DOC055_LAUGHTER_KEEP_BEFORE.test(before)) return m;
        return '[laughter]';
    });
    s = s.replace(/(?:\[laughter\]\s*){2,}/gi, '[laughter] ');
    return s;
}

function identicalTokenRunCensus(text, minRun) {
    const s = String(text);
    const min = minRun == null ? DOC055_MIN_IDENTICAL_RUN : minRun;
    const matches = [...s.matchAll(DOC055_TOKEN_RE)];
    const runs = [];
    let i = 0;
    while (i < matches.length) {
        let j = i + 1;
        const canon = matches[i][0].toLowerCase();
        while (j < matches.length) {
            const gap = s.slice(
                matches[j - 1].index + matches[j - 1][0].length,
                matches[j].index
            );
            if (matches[j][0].toLowerCase() !== canon || !/^[\s-]*$/.test(gap)) break;
            j++;
        }
        if (j - i >= min) runs.push({ token: matches[i][0], n: j - i, index: matches[i].index });
        i = j;
    }
    return runs;
}

// DOC-046 reflow can isolate calibration numbers (`440,\n445 \nso Hitler`) which
// quality-check treats as WebVTT cue lines. Fold them back; do not drop them.
function rejoinIsolatedNumericLines(text) {
    const out = [];
    for (const line of String(text).split('\n')) {
        if (/^\d{1,3}$/.test(line.trim())) {
            if (out.length) {
                out[out.length - 1] = out[out.length - 1].replace(/\s*$/, '') + ' ' + line.trim();
            }
            continue;
        }
        out.push(line);
    }
    return out.join('\n');
}


// GoluGit #146: consecutive triple-duplicate ASR stutter (3+ word phrases,
// 3+ back-to-back copies → keep one). Distinct from DOC-055 / #84 (8+/12+
// hallucination runs) and from rhetorical near-repeats that are not identical
// (`Out of nothingness arises A/B/C`). 2-word loops (`wake up` ×3 hypnosis
// cadence) stay on the DOC-055 minCopies=8 gate.
function collapseConsecutiveTripleDuplicates(text) {
    const s = String(text);
    const matches = [...s.matchAll(DOC055_TOKEN_RE)];
    if (matches.length < 9) return s;
    const toks = matches.map((m) => m[0].toLowerCase().replace(/[.,!?]+$/, ''));
    const maxN = 8;
    const minCopies = 3;
    const minN = 3;
    const ngramEq = (i, j, n) => {
        for (let k = 0; k < n; k++) {
            if (toks[i + k] !== toks[j + k]) return false;
        }
        return true;
    };
    const gapOk = (a, b) => {
        const gap = s.slice(
            matches[a].index + matches[a][0].length,
            matches[b].index
        );
        return /^[\s.,!?;:\-]*$/.test(gap);
    };
    let out = '';
    let last = 0;
    let i = 0;
    while (i < matches.length) {
        let collapsed = false;
        const maxHere = Math.min(maxN, Math.floor((matches.length - i) / minCopies));
        for (let n = maxHere; n >= minN; n--) {
            let allSame = true;
            for (let k = 1; k < n; k++) {
                if (toks[i + k] !== toks[i]) { allSame = false; break; }
            }
            if (allSame) continue; // 1-token runs (Mung? ×14) stay on DOC-055
            if (!ngramEq(i, i + n, n) || !gapOk(i + n - 1, i + n)) continue;
            if (!ngramEq(i, i + 2 * n, n) || !gapOk(i + 2 * n - 1, i + 2 * n)) continue;
            let copies = 3;
            let pos = i + 3 * n;
            while (pos + n <= matches.length && ngramEq(i, pos, n) && gapOk(pos - 1, pos)) {
                copies++;
                pos += n;
            }
            if (copies >= minCopies) {
                const start = matches[i].index;
                const keepEnd = matches[i + n - 1].index + matches[i + n - 1][0].length;
                const runEnd = matches[pos - 1].index + matches[pos - 1][0].length;
                out += s.slice(last, start);
                out += s.slice(start, keepEnd);
                last = runEnd;
                i = pos;
                collapsed = true;
                break;
            }
        }
        if (!collapsed) i++;
    }
    out += s.slice(last);
    return out;
}

function applyOverlayText(ov) {
    // Overlays skip the generic eagle→ego pass (protects "Eagle Scout")
    // but still get ingest hygiene (the 12 corpus U+FFFD live in overlay
    // text), DOC-018 transcript normalisation (quote fold + Audible strip),
    // sentence reflow + the rest of the hotword list.
    // "tractor field" is a real large-v3 miss; leaving overlays raw shipped that.
    return applyDoc056LectureDedup(applyDoc054Fixes(collapseAsrStutters(applyHawkinsHotwords(
        rejoinIsolatedNumericLines(reflowLongLines(normaliseTranscriptText(loadCleanText(ov)))),
        { rewriteEagle: false }
    ))));
}

function cleanLectureText(text) {
    // 0-all-merged-no-timestamps_json.js still contains WEBVTT headers and
    // leftover WebVTT cue numbers (isolated "1"/"2"/... lines). Strip them
    // so snippets and RAG chunks are not polluted. Ingest hygiene (markers,
    // whitespace, encoding — DOC-010/013/014/015) plus publisher/platform
    // boilerplate (DOC-012) via loadCleanText, then DOC-018 transcript
    // normalisation (quote fold / Audible / density). Do NOT touch data
    // files on disk — project rule says data files are read-only, fixes live here.
    let s = normaliseTranscriptText(loadCleanText(text))
        .replace(/\bWEBVTT\b\s*/g, '')
        .replace(/\n\s*\d{1,3}\s*\n/g, '\n')
        .replace(/\n{3,}/g, '\n\n');
    // WEBVTT cues were ~40-char fragments split mid-sentence (avg line 42 chars).
    // Reflow consecutive lines that don't end with a sentence terminator so
    // /api/read and RAG chunks return readable paragraphs instead of shards.
    const paras = s.split(/\n{2,}/);
    const reflowed = paras.map(para => {
        const lines = para.split('\n').map(l => l.trim()).filter(Boolean);
        if (lines.length <= 1) return lines.join('\n');
        const out = [];
        let buf = lines[0];
        for (let i = 1; i < lines.length; i++) {
            const nxt = lines[i];
            if (buf.startsWith('====') || nxt.startsWith('====')) { out.push(buf); buf = nxt; continue; }
            if (/[.!?:"\u2014\u2013]$/.test(buf)) { out.push(buf); buf = nxt; }
            else if (buf.length > 550) { out.push(buf); buf = nxt; }
            else buf = buf + ' ' + nxt;
        }
        out.push(buf);
        return out.join('\n');
    }).join('\n\n');
    // Cue-number stripping + reflow can EXPOSE a junk tail that loadCleanText
    // could not see (e.g. `truth.\n\n119\nhere` — the `119` shielded the
    // `here`). Run the end-anchored strip again on the final text.
    return applyDoc056LectureDedup(applyDoc054Fixes(stripTrailingAsrJunk(collapseAsrStutters(
        applyHawkinsHotwords(rejoinIsolatedNumericLines(reflowLongLines(reflowed)), { rewriteEagle: true })
    ))));
}

function overlayDir() {
    return process.env.LECTURE_OVERLAY_DIR || require('path').join(__dirname, 'overlays');
}

function extraSourcesDir() {
    return process.env.EXTRA_SOURCES_DIR || require('path').join(__dirname, 'extra-sources');
}

function readOverlay(key) {
    const p = require('path').join(overlayDir(), key + '.txt');
    if (!fs.existsSync(p)) return null;
    const t = fs.readFileSync(p, 'utf8').trim();
    return t || null;
}

// DOC-056 / #85: drop later copies of ≥14-word verbatim windows (phone_ocr
// concatenated photography passes). Keep-first; only run when the document's
// duplicated-14-gram ratio is already ≥0.5% so notes with a few repeated
// sentences stay intact.
const DUP_WINDOW = 14;
const DUP_RATIO_MIN = 0.005;

function duplicated14GramRatio(text, window) {
    const n = window || DUP_WINDOW;
    const words = String(text).match(/\S+/g) || [];
    if (words.length < n) return 0;
    const seen = new Set();
    let dup = 0;
    const total = words.length - n + 1;
    for (let i = 0; i < total; i++) {
        const g = words.slice(i, i + n).join(' ').toLowerCase();
        if (seen.has(g)) dup++;
        else seen.add(g);
    }
    return dup / total;
}

function collapseRepeatedWordWindows(text, window) {
    const n = window || DUP_WINDOW;
    const s = String(text);
    const tokens = [];
    const re = /\S+/g;
    let m;
    while ((m = re.exec(s))) {
        tokens.push({ w: m[0], start: m.index, end: m.index + m[0].length });
    }
    if (tokens.length < n * 2) return s;
    const firstAt = new Map();
    const drop = new Uint8Array(tokens.length);
    const keyAt = (i) => {
        const parts = new Array(n);
        for (let j = 0; j < n; j++) parts[j] = tokens[i + j].w.toLowerCase();
        return parts.join('\0');
    };
    let i = 0;
    while (i <= tokens.length - n) {
        if (drop[i]) { i++; continue; }
        const key = keyAt(i);
        if (!firstAt.has(key)) {
            firstAt.set(key, i);
            i++;
            continue;
        }
        const p = firstAt.get(key);
        let L = n;
        const maxL = Math.min(tokens.length - i, tokens.length - p);
        while (L < maxL && tokens[i + L].w.toLowerCase() === tokens[p + L].w.toLowerCase()) L++;
        for (let k = 0; k < L; k++) drop[i + k] = 1;
        i += L;
    }
    let out = s.slice(0, tokens[0].start);
    let prevKept = -1;
    for (let t = 0; t < tokens.length; t++) {
        if (drop[t]) continue;
        if (prevKept >= 0) {
            if (prevKept + 1 === t) {
                out += s.slice(tokens[prevKept].end, tokens[t].start);
            } else {
                const gap = s.slice(tokens[prevKept].end, tokens[t].start);
                out += /\n/.test(gap) ? '\n' : ' ';
            }
        }
        out += tokens[t].w;
        prevKept = t;
    }
    if (prevKept >= 0) out += s.slice(tokens[prevKept].end);
    return out.replace(/\n{3,}/g, '\n\n');
}

function collapseDuplicatedBlocks(text) {
    if (duplicated14GramRatio(text) < DUP_RATIO_MIN) return String(text);
    return collapseRepeatedWordWindows(text);
}

// DOC-056 leftover / #85: What_is_the_World Feb 2009 P2 re-reads three slide
// sentences after the commentary. Keep the first copy; drop the later echo.
// Phrase-scoped — not a global 14-gram collapse (ratio is already < 0.5%).
function dropLaterCopies(text, re) {
    let n = 0;
    return String(text).replace(re, (m) => (++n === 1 ? m : ''));
}

function applyDoc056LectureDedup(text) {
    let s = String(text);
    s = dropLaterCopies(
        s,
        /Human life is an expression of God's will by which the Godhead fulfills the actualization of infinite potentiality\./g
    );
    s = dropLaterCopies(
        s,
        /Man is just a highly evolved hominid and therefore merely a biologic species(?: and genus)?,? and spirituality is a product of imagination\./g
    );
    s = dropLaterCopies(
        s,
        /(?:With the removal of perception, then )?the radiance of divinity shines forth as the exquisite beauty and perfection of the world\./g
    );
    return s.replace(/[ \t]{2,}/g, ' ').replace(/[ \t]+\n/g, '\n');
}

// DOC-059 / #97: extra-source OCR remainder (discord / Barret / phone).
// Phrase-scoped — not global lite/Sli/the T/Politize/pre-ther.
function applyExtraSourceOcrFixes(text) {
    let s = String(text);
    // Discord photos
    s = s.replace(/\bIt did not reac\b/g, 'It did not reach');
    s = s.replace(/^\s*Sli\s*$/gm, '');
    s = s.replace(/\bDAVID R\. HAWKING\b/g, 'DAVID R. HAWKINS');
    // Barret notes
    s = s.replace(/\byour lite\b/g, 'your life');
    s = s.replace(/\ball lite\b/g, 'all life');
    s = s.replace(/\bof lite\b/g, 'of life');
    s = s.replace(/\bpertection\b/g, 'perfection');
    s = s.replace(/\. no intervention takes place/g, '. If no intervention takes place');
    s = s.replace(/\bwill occur it Shame is banishment\b/g, 'will occur. Shame is banishment');
    s = s.replace(/\bwit-nessing\b/g, 'witnessing');
    s = s.replace(/\bomnip-otentiality\b/g, 'omnipotentiality');
    s = s.replace(/\bposi-tion\b/g, 'position');
    s = s.replace(/\bpositional-ity\b/g, 'positionality');
    s = s.replace(/Realization ofthe Self and the T/g, 'Realization of the Self as the I');
    s = s.replace(/Realization of the Self and the T/g, 'Realization of the Self as the I');
    // Phone photos
    s = s.replace(/\bAllen Abduction\b/g, 'Alien Abduction');
    s = s.replace(/\bAllen abduction\b/g, 'Alien abduction');
    s = s.replace(/\bYou told looksee things revealed even 25 to 30 was later\b/g,
        'You told, look, see things revealed even 25 to 30 years later');
    s = s.replace(/\bPerception is programable\b/g, 'Perception is programmable');
    s = s.replace(/\bCondition depend on women\b/g, 'Conditioning depends');
    s = s.replace(/\bdiagnable\b/g, 'diagnosable');
    s = s.replace(/\bexplaination\b/g, 'explanation');
    s = s.replace(/\barmier\b/g, 'armies');
    s = s.replace(/\bcmpulsion\b/g, 'compulsion');
    s = s.replace(/\bKeshma\b/g, 'Krishna');
    s = s.replace(/\bexcept though me\b/g, 'except through me');
    s = s.replace(/\breconcil it\b/g, 'reconcile it');
    s = s.replace(/\bThe pre-ther populate\b/g, 'The predator populate');
    s = s.replace(/\bPolitize the specialness\b/g, 'Politicize the specialness');
    // DOC-054 remainder (Barret notes + phone OCR).
    s = s.replace(/\bsurender-ing\b/g, 'surrendering');
    s = s.replace(/\bspiritu-ally\b/g, 'spiritually');
    s = s.replace(/\bcaled,/g, 'called,');
    s = s.replace(/\btheres practically\b/g, "there's practically");
    s = s.replace(/\bthe affect I am the Way\b/g, 'the effect I am the Way');
    s = s.replace(/\bConsciousness Iself\b/g, 'Consciousness Itself');
    s = s.replace(/I surrender to Thane, O Lord/g, 'I surrender to Thee, O Lord');
    s = s.replace(/\bDvinity\b/g, 'Divinity');
    s = s.replace(/\bdiffereent\b/g, 'different');
    s = s.replace(/Dohng, The 430/g, 'Tao, The 430');
    s = s.replace(/\bauto-matic\b/g, 'automatic');
    return s;
}

function loadExtraSources() {
    const dir = extraSourcesDir();
    const out = {};
    if (!fs.existsSync(dir)) return out;
    for (const fn of fs.readdirSync(dir)) {
        if (!fn.endsWith('.txt')) continue;
        const key = fn.slice(0, -4);
        // Fail loudly (not silently skip): an unloadable sidecar would quietly
        // vanish from /api/files and the corpus counts. api.js's startup catch
        // turns this into an exit(1) — same convention as the key-collide check.
        if (!EXTRA_KEY_RE.test(key)) {
            throw new Error(`extra-source key not loadable (charset ${EXTRA_KEY_RE.toString()}): ${key}`);
        }
        const t = fs.readFileSync(require('path').join(dir, fn), 'utf8').trim();
        if (t) {
            const cleaned = collapseDuplicatedBlocks(applyExtraSourceOcrFixes(loadCleanText(t)));
            warnIfNonLatinHeavy(key, cleaned);
            out[key] = cleaned;
        }
    }
    return out;
}

// Books load through the same hygiene pass as lectures (DOC-010/014/015):
// the `====_Title_====` banners, PDF whitespace artifacts, and encoding
// damage live in merged-book-texts_json_1.js too. Keeps every cleaning rule
// in this one module (the UI bundle still cleans client-side — see the
// UI-parity issue).
function loadBookTexts(htmlDir) {
    const bookData = loadJsonDataSource(require('path').join(htmlDir, 'merged-book-texts_json_1.js'), 'the_json_obj_books');
    const books = bookData.the_json_obj_books || {};
    const cleaned = {};
    for (const k of Object.keys(books)) {
        const c = loadCleanText(books[k]);
        warnIfNonLatinHeavy(k, c);
        cleaned[k] = c;
    }
    // DOC-011: remap truncated mid-word book keys to full slugified titles.
    return { the_json_obj_books: canonicalizeBookKeys(cleaned), rawCount: Object.keys(books).length };
}

function loadLectureTexts(htmlDir) {
    const lectureData = loadJsonDataSource(require('path').join(htmlDir, '0-all-merged-no-timestamps_json.js'), 'the_json_obj');
    const lectures = lectureData.the_json_obj || {};
    const cleaned = {};
    const lectureMeta = {};
    let dirty = 0;
    let overlaid = 0;
    let rawAsr = 0;
    for (const k of Object.keys(lectures)) {
        const before = lectures[k].length;
        let c = cleanLectureText(lectures[k]);
        if (c.length !== before) dirty++;
        const canonKey = resolveLectureKey(k);
        const ov = readOverlay(k) || (canonKey !== k ? readOverlay(canonKey) : null);
        if (ov) {
            c = applyOverlayText(ov);
            overlaid++;
        }
        warnIfNonLatinHeavy(k, c);
        cleaned[k] = c;
        const meta = describeTranscriptNormalisation(c);
        if (looksAbruptStart(c)) meta.startsAbruptly = true;
        lectureMeta[k] = meta;
        if (meta.transcriptTag === 'raw_asr') rawAsr++;
    }
    // DOC-032: remap punctuation-split legacy keys to the sibling convention.
    const canon = canonicalizeLectureKeys(cleaned, lectureMeta);
    return {
        lectures: canon.lectures,
        lectureMeta: canon.lectureMeta,
        rawCount: Object.keys(lectures).length,
        cleanedCount: dirty,
        overlayCount: overlaid,
        rawAsrCount: rawAsr,
        normalisationVersion: NORMALISATION_VERSION
    };
}

module.exports = {
    loadJsonDataSource,
    cleanIngestArtifacts,
    fixGluedSpaces,
    GLUE_CAMEL_ALLOW,
    stripTrailingAsrJunk,
    collapseIdenticalTokenRunsAtEof,
    IDENTICAL_TOKEN_TAIL_CHARS,
    IDENTICAL_TOKEN_MIN_RUN,
    looksAbruptStart,
    stripPublisherBoilerplate,
    stripCopyrightFluff,
    stripRunningChrome,
    loadCleanText,
    applyDoc054Fixes,
    cleanLectureText,
    loadLectureTexts,
    loadBookTexts,
    readOverlay,
    overlayDir,
    reflowLongLines,
    collapseAsrStutters,
    collapseConsecutiveTripleDuplicates,
    applyDoc055Fixes,
    identicalTokenRunCensus,
    DOC055_MIN_IDENTICAL_RUN,
    DOC055_KEEP_RUN_TOKEN,
    applyHawkinsHotwords,
    applyOverlayText,
    applyResidualOcrFixes,
    applyPvfOcrFixes,
    applyCommonMisspellings,
    applyPunctuationSpacing,
    loadExtraSources,
    applyExtraSourceOcrFixes,
    collapseDuplicatedBlocks,
    applyDoc056LectureDedup,
    collapseRepeatedWordWindows,
    duplicated14GramRatio,
    extraSourcesDir,
    nonLatinShare,
    warnIfNonLatinHeavy,
    NON_LATIN_SHARE_WARN,
    normaliseTranscriptText,
    foldQuoteVariants,
    stripAudibleBoilerplate,
    periodDensity,
    chunkByWordCount,
    describeTranscriptNormalisation,
    NORMALISATION_VERSION,
    PERIOD_DENSITY_MIN,
    PERIOD_DENSITY_MAX,
    RAW_ASR_WORD_CHUNK,
    FILE_KEY_RE,
    EXTRA_KEY_RE,
    LECTURE_KEY_ALIASES,
    BOOK_KEY_ALIASES,
    resolveLectureKey,
    resolveBookKey,
    resolveSourceKey
};
