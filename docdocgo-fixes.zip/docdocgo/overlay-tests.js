const assert = require('assert');
const path = require('path');
const { cleanLectureText, loadLectureTexts, readOverlay, applyOverlayText } = require('./lecture-text');

let passed = 0;
let failed = 0;
function test(name, fn) {
    try { fn(); console.log(`  ✅ ${name}`); passed++; }
    catch (err) { console.log(`  ❌ ${name}`); console.log(`     ${err.message}`); failed++; }
}

console.log('\n--- overlay / hotword regression ---');

test('Eagle Scout is not rewritten to Ego Scout', () => {
    const s = cleanLectureText('The Eagle Scout calibrates five points higher.');
    assert.ok(s.includes('Eagle Scout'), s);
    assert.ok(!s.includes('Ego Scout'), s);
});

test('standalone eagle still becomes ego', () => {
    const s = cleanLectureText('The eagle will say no.');
    assert.match(s, /ego will say/i);
});

test('Ben Loudon / Louden become Bin Laden', () => {
    assert.match(cleanLectureText('picture Ben Loudon and pull'), /Bin Laden/);
    assert.match(cleanLectureText('Unless Ben Louden changes'), /Bin Laden/);
    assert.match(cleanLectureText('we cannot say that bin loudon is evil'), /Bin Laden/);
    assert.match(cleanLectureText('we cannot say bin raven is wrong'), /Bin Laden/);
});

test('Ramana Maharishi becomes Ramana Maharshi', () => {
    assert.match(cleanLectureText('In Ramana Maharishi he said'), /Ramana Maharshi/);
});

test('overlay apply does not rewrite Eagle Scout, does rewrite tractor field', () => {
    const s = applyOverlayText('The Eagle Scout saw a tractor field.');
    assert.ok(s.includes('Eagle Scout'), s);
    assert.ok(!s.includes('Ego Scout'), s);
    assert.match(s, /attractor field/);
    assert.ok(!/\btractor\s+field\b/i.test(s), s);
});

const CONTROL = 'A_Map_of_Consciousness_enxautogen_html';
const OCT = 'Spiritual_Traps_Oct_2005_Part_2_enxautogen_html';
const OVER = 'Alignment_Apr_2005_Part_2_enxautogen_html';

const loaded = loadLectureTexts(path.join(__dirname, 'html'));

test('corpus key count unchanged (overlay does not add/remove keys)', () => {
    assert.strictEqual(loaded.rawCount, Object.keys(loaded.lectures).length);
    assert.ok(loaded.rawCount >= 200, `only ${loaded.rawCount} keys`);
});

test('control lecture is not overlaid', () => {
    assert.strictEqual(readOverlay(CONTROL), null);
    assert.ok(loaded.lectures[CONTROL]);
});

test('Oct 2005 Part 2 is overlaid by the re-ASR (known-bad transcription replaced)', () => {
    const ov = readOverlay(OCT);
    assert.ok(ov, 'overlay missing — re-ASR not shipped');
    const served = loaded.lectures[OCT];
    assert.strictEqual(served, applyOverlayText(ov));
    assert.ok(!/WEBVTT/.test(served), 'overlay still has WEBVTT');
    assert.ok(!/-->/.test(served), 'overlay still has cue arrows');
    assert.ok(served.split(/\s+/).length > 5000, `re-ASR overlay unexpectedly short (${served.split(/\s+/).length} words)`);
    const maxLine = Math.max(...served.split('\n').map(l => l.length));
    assert.ok(maxLine < 900, `re-ASR Part 2 still has a runaway line (${maxLine})`);
});

test('batch-20 worst key is overlaid when overlay files are present', () => {
    const ov = readOverlay(OVER);
    if (!ov) {
        console.log('     (skip — overlays/ not mounted in this environment)');
        return;
    }
    const served = applyOverlayText(ov);
    assert.strictEqual(loaded.lectures[OVER], served);
    assert.ok(!/WEBVTT/.test(served), 'overlay still has WEBVTT');
    assert.ok(!/-->/.test(served), 'overlay still has cue arrows');
    assert.ok(served.split(/\s+/).length > 200, 'overlay too short');
    const rawMax = Math.max(...ov.split('\n').map(l => l.length));
    const maxLine = Math.max(...served.split('\n').map(l => l.length));
    assert.ok(served.split('\n').length > ov.split('\n').length, 'reflow did not add sentence breaks');
    assert.ok(maxLine < rawMax, `reflow did not shrink longest line (${maxLine} vs raw ${rawMax})`);
});

test('Devotion Sep 2002 Part 1 is overlaid (run-on 938 replaced by re-ASR)', () => {
    const DEV = 'Devotion_The_Way_to_God_Through_the_Heart_Sep_2002_Part_1';
    const ov = readOverlay(DEV);
    assert.ok(ov, 'overlay missing — Devotion Part 1 not shipped');
    const served = loaded.lectures[DEV];
    assert.strictEqual(served, applyOverlayText(ov));
    assert.ok(!/WEBVTT/.test(served), 'overlay still has WEBVTT');
    assert.ok(!/-->/.test(served), 'overlay still has cue arrows');
    assert.ok(served.split(/\s+/).length > 5000, `Devotion Part 1 overlay unexpectedly short (${served.split(/\s+/).length} words)`);
    const maxLine = Math.max(...served.split('\n').map(l => l.length));
    assert.ok(maxLine < 900, `Devotion Part 1 still has a runaway line (${maxLine})`);
});

test('overlayCount is 0 or 230 (full batch), never a silent partial)', () => {
    const n = loaded.overlayCount || 0;
    assert.ok(n === 0 || n === 230, `overlayCount=${n}`);
});

test('DOC-047: Cancer opening ASR homophones (practice / individual / conditions)', () => {
    const snippet = "I'm Dr. David Hawkins position for 35 years and specialized in the field of psychiatry. For years. I worked in the fields of psychoanalysis and Psychotherapy various form of secretary and group therapy. heart disease hypertension the alcoholism drug addiction all of the mysterious conference all them.";
    const s = cleanLectureText(snippet);
    assert.match(s, /Hawkins practice for/);
    assert.ok(!/Hawkins position for/i.test(s), s);
    assert.match(s, /form of individual and group therapy/);
    assert.ok(!/form of secretary and group therapy/i.test(s), s);
    assert.match(s, /mysterious conditions/);
    assert.ok(!/mysterious conference/i.test(s), s);
    const cancer = loaded.lectures.Cancer_enxautogen_html;
    assert.ok(cancer, 'Cancer lecture missing');
    const head = cancer.slice(0, 2500);
    assert.match(head, /Hawkins practice for/);
    assert.ok(!/Hawkins position for/i.test(head), head.slice(0, 200));
    assert.match(head, /form of individual and group therapy/);
    assert.match(cancer, /mysterious conditions/);
    assert.ok(!/mysterious conference/i.test(cancer));
    const healthKeys = [
        'A_Map_of_Consciousness_enxautogen_html',
        'Alcoholism_enxautogen_html',
        'Cancer_enxautogen_html',
        'Death_and_Dying_enxautogen_html',
        'Depression_enxautogen_html',
        'Drug_Addiction_and_Alcoholism_enxautogen_html',
        'Handling_Major_Crises_enxautogen_html',
        'Health_enxautogen_html',
        'Illness_and_SelfHealing_enxautogen_html',
        'Losing_Weight_enxautogen_html',
        'Pain_and_Suffering_enxautogen_html',
        'Sexuality_enxautogen_html',
        'Spiritual_First_Aid_enxautogen_html',
        'Stress_enxautogen_html',
        'The_Aging_Process_enxautogen_html',
        'Worry,_Fear,_and_Anxiety_enxautogen_html'
    ];
    assert.strictEqual(healthKeys.length, 16);
    for (const k of healthKeys) {
        const t = loaded.lectures[k];
        assert.ok(t, `missing health lecture ${k}`);
        assert.ok(!/Hawkins position for/i.test(t), `${k} still has position-for`);
        assert.ok(!/form of secretary and group therapy/i.test(t), `${k} still has secretary`);
        assert.ok(!/mysterious conference/i.test(t), `${k} still has conference`);
    }
});

test('DOC-050: health-lecture stock intro ASR glossary', () => {
    const forbidden = [
        /cycle analysis/i,
        /gonna psychiatrist/i,
        /psychothermicology/i,
        /psychoanalist/i,
        /of specialized/i,
        /physician in the psychiatrist/i
    ];
    const snippet = "work for many years in the field of cycle analysis. I'm gonna psychiatrist for the last 35 years. psychothermicology psychoanalist. of specialized in the treatment. physician in the psychiatrist for 35 years. Did you're the research and psychopharmacology? you I'm Dr. David. I've been as a. Dr. Dave Hawkins. In today's talk is going to be on X. researcher and the relationship between nutrition and the relationship to alcoholism.";
    const s = cleanLectureText(snippet);
    for (const re of forbidden) {
        assert.ok(!re.test(s), `snippet still matches ${re}: ${s}`);
    }
    assert.match(s, /psychoanalysis/);
    assert.match(s, /I've been a psychiatrist/);
    assert.match(s, /psychopharmacology/);
    assert.match(s, /psychoanalyst/);
    assert.match(s, /I specialized/);
    assert.match(s, /physician and psychiatrist/);
    assert.match(s, /I did research in/);
    assert.match(s, /I'm Dr\. David/);
    assert.match(s, /Dr\. David Hawkins/);
    assert.match(s, /Today's talk is going to be/);
    assert.match(s, /researcher into the relationship between nutrition and alcoholism/);
    const healthKeys = [
        'A_Map_of_Consciousness_enxautogen_html',
        'Alcoholism_enxautogen_html',
        'Cancer_enxautogen_html',
        'Death_and_Dying_enxautogen_html',
        'Depression_enxautogen_html',
        'Drug_Addiction_and_Alcoholism_enxautogen_html',
        'Handling_Major_Crises_enxautogen_html',
        'Health_enxautogen_html',
        'Illness_and_SelfHealing_enxautogen_html',
        'Losing_Weight_enxautogen_html',
        'Pain_and_Suffering_enxautogen_html',
        'Sexuality_enxautogen_html',
        'Spiritual_First_Aid_enxautogen_html',
        'Stress_enxautogen_html',
        'The_Aging_Process_enxautogen_html',
        'Worry,_Fear,_and_Anxiety_enxautogen_html'
    ];
    assert.strictEqual(healthKeys.length, 16);
    for (const k of healthKeys) {
        const t = loaded.lectures[k];
        assert.ok(t, `missing health lecture ${k}`);
        const intro = t.slice(0, 800);
        for (const re of forbidden) {
            assert.ok(!re.test(intro), `${k} intro still matches ${re}: ${intro.slice(0, 220)}`);
        }
    }
    const alc = loaded.lectures.Alcoholism_enxautogen_html.slice(0, 800);
    assert.ok(!/In today's talk is going to be/i.test(alc), alc);
    assert.match(alc, /Today's talk is going to be/);
    assert.match(alc, /researcher into the relationship between nutrition and alcoholism/);
    assert.ok(!/researcher and the relationship between nutrition and the relationship to/i.test(alc), alc);
    const sex = loaded.lectures.Sexuality_enxautogen_html.slice(0, 400);
    assert.match(sex, /I've been a psychiatrist/);
    assert.ok(!/I'm been a psychiatrist/i.test(sex), sex);
});

test('DOC-061: Gloria in Excelsis Deo ASR variants; Glorian Ross stays', () => {
    const s = cleanLectureText(
        "Dr. Gloria and Excelsior God beat the guy didn't know it's and on Earth Goodwill to men. " +
        'I conclude as I began Gloria and Excelsior Studio. where to God in the highest. ' +
        'professor Gloria in Excelsior Praise be the Lord. ' +
        "with Gloria and Excelsior that fries you you're reading the wrong book. " +
        "it starts and it ends with Gloria and excelsior's deal. " +
        'So we say glorian excelsior deal. ' +
        'Maria in excelsious deal to the O Lord. ' +
        "An Excelsior's deal. " +
        'We started glory and Excelsior. ' +
        'Glorian Ross calls it her pet.'
    );
    assert.ok(!/Excelsior/i.test(s), s);
    assert.ok(!/excelsious/i.test(s), s);
    assert.match(s, /Gloria in Excelsis Deo\. Peace on Earth, goodwill to men/);
    assert.match(s, /Gloria in Excelsis Deo/);
    assert.match(s, /Glory to God in the highest/);
    assert.match(s, /If you're reading the wrong book/);
    assert.match(s, /Glorian Ross/);
    assert.ok(!/Gloria Ross/i.test(s), s);
});

test('DOC-054: lecture word-level ASR/OCR sites', () => {
    const L = loaded.lectures;
    const dilemma = L.The_Human_Dilemma_Aug_2007_Part_3_enxautogen_html;
    assert.match(dilemma, /Advaita/);
    assert.ok(!/\bAdvita\b/.test(dilemma));
    assert.match(dilemma, /spiritual ego wants to take over/);
    assert.ok(!/spiritual eagle/.test(dilemma));
    const cancer = L.Cancer_enxautogen_html;
    assert.match(cancer, /peace of mind/);
    assert.ok(!/piece of mind/.test(cancer));
    assert.ok((cancer.match(/a certain peace of mind/g) || []).length === 1, 'doubled peace of mind remains');
    const aging = L.The_Aging_Process_enxautogen_html;
    assert.match(aging, /principle of becoming increasingly conscious/);
    assert.ok(!/principal of becoming/.test(aging));
    const perc = L.Perception_and_Illusion_Distortions_of_Reality_May_2002_Part_2_enxautogen_html;
    assert.match(perc, /Maharshi/);
    assert.ok(!/Manaharshi/.test(perc));
    const comm = L.Spiritual_Community_Jun_2003_Part_1_enxautogen_html;
    assert.match(comm, /diplomatic corps/);
    assert.ok(!/diplomatic cores/.test(comm));
    const real = L.Realization_of_the_Self_as_the_I_Nov_2003_Part_2_enxautogen_html;
    assert.match(real, /likes of Maharshi Nisargadatta Maharaj/);
    assert.ok(!/amount of Maharishi/.test(real));
    const succ = L.Success_Oct_2009_Part_3_enxautogen_html;
    assert.match(succ, /subtle energy analysis/);
    assert.ok(!/subnal/.test(succ));
    const vol1 = L.Volume_I_Power_vs_Force_Muscle_Testing_Part_1_enxautogen_html;
    assert.match(vol1, /Just boggles my mind/);
    assert.match(vol1, /Hussein what's his name/);
    const vol3 = L.Volume_III_Advanced_States_of_Consciousness_Part_1_enxautogen_html;
    assert.match(vol3, /it cured itself/);
    assert.ok(!/occured itself/.test(vol3));
    const vol4 = L.Volume_IV_Consciousness_How_to_Tell_the_Truth_About_Anything_Part_2_enxautogen_html;
    assert.match(vol4, /their consciousness/);
    assert.ok(!/conciousness/.test(vol4));
    const vol5 = L.Volume_V_Undoing_the_Barriers_to_Spiritual_Progress_Part_2_enxautogen_html;
    assert.match(vol5, /blaming God for/);
    assert.ok(!/leaming God/.test(vol5));
    const levels = L['The_Levels_of_Consciousness_Subjective_&_Social_Consequences_Mar_2002_Part_2_enxautogen_html'];
    assert.ok(!/DaskarPatrita/.test(levels));
    assert.match(levels, /the Maharshi was dying/);
});

test('DOC-055: mid-doc hallucination runs, laughter chrome, credits, salad', () => {
    const L = loaded.lectures;
    const { identicalTokenRunCensus, applyDoc055Fixes, DOC055_KEEP_RUN_TOKEN } = require('./lecture-text');

    const ha = applyDoc055Fixes('The norm is to get divorced, right? ' + Array(20).fill('Ha!').join(' ') + ' Many people live in a different way.');
    assert.match(ha, /\[laughter\]/);
    assert.ok(!/Ha! Ha! Ha!/.test(ha), ha);

    const three = applyDoc055Fixes('Done. no no no thanks.');
    assert.match(three, /no no no thanks/);

    const mung = applyDoc055Fixes(Array(14).fill('Mung?').join(' ') + ' Yes. It\'s Mungu Boyangtum.');
    assert.ok((mung.match(/Mung\?/g) || []).length === 14, mung);

    const sub = applyDoc055Fixes('kitty Subtitles by LibKem in like is not the same..! same in the dinosaur \nand bin loudon \nbut they both calibrate');
    assert.ok(!/Subtitles by/i.test(sub), sub);
    assert.ok(!/dinosaur/.test(sub), sub);
    assert.match(sub, /but they both calibrate/);

    const salad = applyDoc055Fixes("I'll do DoCo hoping in a hunting department I do-di-da-po God, oh, do or II? Told him to the kid out and auto the big enemy fulkin to King come with a dog Oh Go, go Thank you.\nThank you.\nThe answer is that question.");
    assert.match(salad, /\[inaudible side conversation\]/);
    assert.ok(!/DoCo hoping/.test(salad));
    assert.match(salad, /The answer is that question/);

    const sedona = L.A_Unique_Sedona_Seminar_Dec_2008_Part_4_enxautogen_html;
    assert.ok(sedona);
    assert.ok((sedona.match(/Ha!/g) || []).length < 12);
    assert.match(sedona, /\[laughter\]/);
    assert.ok(!/\.(?:\s+\.){8,}/.test(sedona), 'spaced period run of 9+ still live');
    assert.match(sedona, /Oh, it's a nice cool day\./);
    assert.match(sedona, /he finds that he feels sorry for himself/);
    assert.ok(!/\?\s+(?:\.\s*){8,}/.test(sedona));

    const root = L.Realizing_the_Root_of_Consciousness_Meditative_and_Contemplative_Techniques_Jun_2002_Part_1_enxautogen_html;
    assert.ok(!/007\.00 007\.00/.test(root));

    const handling = L.Handling_Spiritual_Challenges_Apr_2010_Part_1_enxautogen_html;
    assert.ok(!/204\. 204\. 204\./.test(handling));
    assert.match(handling, /The world is at 204\./);

    const satsang9 = L.Satsang_Series_Volume_IX_Part_5_enxautogen_html;
    assert.ok((satsang9.match(/Mung\?/g) || []).length >= 12);

    const real = L.Realization_of_the_Self_as_the_I_Nov_2003_Part_2_enxautogen_html;
    assert.ok(!/DoCo hoping/.test(real));
    assert.match(real, /\[inaudible side conversation\]/);

    const advaita = L.Advaita_The_Way_to_God_Through_Mind_Aug_2002_Part_2_enxautogen_html;
    assert.ok(!/Subtitles by/i.test(advaita));
    assert.ok(!/same in the dinosaur/.test(advaita));
    assert.ok(!/in like certainly/.test(advaita));
    assert.ok(!/bin loudon/i.test(advaita));
    assert.ok(!/bin raven/i.test(advaita));
    assert.ok(!/poor hole/i.test(advaita));
    assert.ok(!/crozack/i.test(advaita));
    assert.ok(!/Ahmad is tämä/i.test(advaita));
    assert.ok(!/Spe millennials/.test(advaita));
    assert.match(advaita, /left that portal open/);
    assert.match(advaita, /talk-show style where the microphone goes around/);
    assert.match(advaita, /so Prozac would be maybe even useful/);
    assert.match(advaita, /the dog's wagging tail is 500/);
    assert.match(advaita, /but they both calibrate the same level/);

    const transc = L.Transcending_Obstacles_Sep_2005_Part_3;
    assert.ok(!/whiskey smelt/.test(transc));
    assert.match(transc, /\[inaudible side conversation\]/);
    assert.match(transc, /foot out of the bear trap/);

    const pain = L.Pain_and_Suffering_enxautogen_html;
    assert.match(pain, /use of laughter/);
    assert.match(pain, /choosing of laughter/);

    const alc = L.Alcoholism_enxautogen_html;
    assert.match(alc, /value of laughter/);

    const what = L.Spiritual_Life_In_Today_s_World_Oct_2010_Part_2_enxautogen_html;
    const copies = (what.match(/What is it\?/g) || []).length;
    assert.ok(copies < 8, 'What is it? still looping: ' + copies);

    const badRuns = [];
    for (const [k, t] of Object.entries(L)) {
        for (const r of identicalTokenRunCensus(t, 12)) {
            if (DOC055_KEEP_RUN_TOKEN.has(String(r.token).toLowerCase())) continue;
            badRuns.push(`${k}: ${r.token} x${r.n}`);
        }
    }
    assert.deepStrictEqual(badRuns, []);

    let subHits = 0;
    for (const t of Object.values(L)) {
        if (/Subtitles by/i.test(t)) subHits++;
    }
    assert.strictEqual(subHits, 0);
});

test('DOC-056 leftover: What_is_the_World Feb 2009 P2 slide echoes once', () => {
    const L = loadLectureTexts(path.join(__dirname, 'html')).lectures;
    const w = L.What_is_the_World_Feb_2009_Part_2_enxautogen_html;
    assert.ok(w);
    const human = (w.match(/Human life is an expression of God's will by which the Godhead fulfills the actualization of infinite potentiality\./g) || []).length;
    const hominid = (w.match(/Man is just a highly evolved hominid and therefore merely a biologic species/g) || []).length;
    const radiance = (w.match(/the radiance of divinity shines forth as the exquisite/g) || []).length;
    assert.strictEqual(human, 1, 'human life passage x' + human);
    assert.strictEqual(hominid, 1, 'hominid passage x' + hominid);
    assert.strictEqual(radiance, 1, 'radiance passage x' + radiance);
    assert.match(w, /The infinite potentiality of divinity is to be anything/);
    assert.match(w, /That is a current political positionality/);
    assert.match(w, /So that state occurs, consciousness level 600 and up/);
    assert.match(w, /Calibrates at 560/);
});


test('#145: Verification Part 1 for-school / Darwin evolution', () => {
    const snippet = "Here. Thank you very much for school. here Yeah, yeah. here No, I'm so pleased to see everyone here. What's his name Darwin? Darwin's Love Revolution based on causality";
    const s = cleanLectureText(snippet);
    assert.match(s, /Thank you very much/);
    assert.ok(!/for school/i.test(s), s);
    assert.ok(!/Love Revolution/i.test(s), s);
    assert.match(s, /Darwin's evolution/);
    const L = loaded.lectures.Verification_of_Spiritual_Realities_Part_1_enxautogen_html;
    assert.ok(L, 'Verification Part 1 missing');
    const head = L.slice(0, 800);
    assert.match(head, /Thank you very much/);
    assert.ok(!/for school/i.test(L), head);
    assert.ok(!/Love Revolution/i.test(L), String(L.match(/Darwin.{0,40}/)));
    assert.match(L, /Darwin's evolution/);
});

console.log(`\noverlay-tests: ${passed} passed, ${failed} failed`);
if (failed > 0) process.exit(1);
