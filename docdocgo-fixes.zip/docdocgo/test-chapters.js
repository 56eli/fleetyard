const assert = require('assert');

// These functions will be implemented in api.js (Task 2)
// For now, require api.js and destructure — this will fail until they're exported
const { parseChapters, findChapter, relocateTocChapters } = require('./api');

let passed = 0;
let failed = 0;

function test(name, fn) {
    try {
        fn();
        console.log(`  ✅ ${name}`);
        passed++;
    } catch (err) {
        console.log(`  ❌ ${name}`);
        console.log(`     ${err.message}`);
        failed++;
    }
}

// ============================================================
// parseChapters(text) tests
// ============================================================
console.log('\n--- parseChapters tests ---');

test('returns empty array for empty text', () => {
    const chapters = parseChapters('');
    assert.deepStrictEqual(chapters, []);
});

test('returns empty array when no chapters found', () => {
    const chapters = parseChapters('This is just some text with no chapter markers at all.');
    assert.deepStrictEqual(chapters, []);
});

test('detects a single chapter with title on same line', () => {
    const text = 'CHAPTER 1: The Beginning\nSome intro text here.';
    const chapters = parseChapters(text);
    assert.strictEqual(chapters.length, 1);
    assert.strictEqual(chapters[0].number, 1);
    assert.strictEqual(chapters[0].title, 'The Beginning');
    assert.strictEqual(chapters[0].offset, 0);
});

test('detects a single chapter with title on next line', () => {
    const text = 'CHAPTER 1\nThe Beginning\nSome intro text here.';
    const chapters = parseChapters(text);
    assert.strictEqual(chapters.length, 1);
    assert.strictEqual(chapters[0].number, 1);
    assert.strictEqual(chapters[0].title, 'The Beginning');
    assert.strictEqual(chapters[0].offset, 0);
});

test('detects chapter without title', () => {
    const text = 'CHAPTER 3\nSome body text starts here.';
    const chapters = parseChapters(text);
    assert.strictEqual(chapters.length, 1);
    assert.strictEqual(chapters[0].number, 3);
    assert.strictEqual(chapters[0].title, null);
});

test('detects multiple chapters with titles', () => {
    const text = [
        'CHAPTER 1',
        'The First Chapter',
        'Body text of chapter one.',
        'CHAPTER 2: The Second',
        'Body text of chapter two.',
        'CHAPTER 3',
        'Final chapter text.',
    ].join('\n');
    const chapters = parseChapters(text);
    assert.strictEqual(chapters.length, 3);
    assert.strictEqual(chapters[0].number, 1);
    assert.strictEqual(chapters[0].title, 'The First Chapter');
    assert.strictEqual(chapters[1].number, 2);
    assert.strictEqual(chapters[1].title, 'The Second');
    assert.strictEqual(chapters[2].number, 3);
    assert.strictEqual(chapters[2].title, null);
});

test('handles chapters with same-line title using colon separator', () => {
    const text = 'CHAPTER 5: Consciousness and Beyond\nDeep text follows.';
    const chapters = parseChapters(text);
    assert.strictEqual(chapters.length, 1);
    assert.strictEqual(chapters[0].number, 5);
    assert.strictEqual(chapters[0].title, 'Consciousness and Beyond');
});

test('handles leading text before first chapter', () => {
    const text = [
        'Preface or introduction text here.',
        'CHAPTER 1',
        'The Real Start',
        'Chapter body.',
    ].join('\n');
    const chapters = parseChapters(text);
    // The preface is not a chapter — first chapter starts at CHAPTER 1
    assert(chapters.length >= 1, 'Should find at least the first chapter');
    assert.strictEqual(chapters[0].number, 1);
    assert.strictEqual(chapters[0].title, 'The Real Start');
});

// ============================================================
// findChapter(chapters, offset) tests
// ============================================================
console.log('\n--- findChapter tests ---');

test('returns null for empty chapters array', () => {
    const result = findChapter([], 100);
    assert.strictEqual(result, null);
});

test('returns first chapter when offset is at start', () => {
    const chapters = [
        { number: 1, title: 'Intro', offset: 0 },
        { number: 2, title: 'Middle', offset: 500 },
        { number: 3, title: 'End', offset: 1200 },
    ];
    const result = findChapter(chapters, 0);
    assert.strictEqual(result.number, 1);
    assert.strictEqual(result.title, 'Intro');
});

test('returns correct chapter for offset in middle of text', () => {
    const chapters = [
        { number: 1, title: 'Intro', offset: 0 },
        { number: 2, title: 'Middle', offset: 500 },
        { number: 3, title: 'End', offset: 1200 },
    ];
    const result = findChapter(chapters, 700);
    assert.strictEqual(result.number, 2);
    assert.strictEqual(result.title, 'Middle');
});

test('returns last chapter when offset is beyond last chapter start', () => {
    const chapters = [
        { number: 1, title: 'Intro', offset: 0 },
        { number: 2, title: 'End', offset: 500 },
    ];
    const result = findChapter(chapters, 9999);
    assert.strictEqual(result.number, 2);
    assert.strictEqual(result.title, 'End');
});

test('returns correct chapter at exact boundary between chapters', () => {
    const chapters = [
        { number: 1, title: 'First', offset: 0 },
        { number: 2, title: 'Second', offset: 500 },
    ];
    // Offset 500 should belong to chapter 2 (the start of chapter 2)
    const result = findChapter(chapters, 500);
    assert.strictEqual(result.number, 2);
});

test('returns first chapter for offset just before second chapter', () => {
    const chapters = [
        { number: 1, title: 'First', offset: 0 },
        { number: 2, title: 'Second', offset: 500 },
    ];
    const result = findChapter(chapters, 499);
    assert.strictEqual(result.number, 1);
});

test('returns null when offset is before all chapters (preface/front matter)', () => {
    const chapters = [
        { number: 1, title: 'First', offset: 100 },
        { number: 2, title: 'Last', offset: 500 },
    ];
    // offset 0 is before first chapter at offset 100 — preface content, return null
    const result = findChapter(chapters, 0);
    assert.strictEqual(result, null);
});

// ============================================================
// Run-together books (no newlines, mid-line chapter markers)
// ============================================================
console.log('\n--- run-together books (mid-line chapter markers) ---');

test('detects mid-line numeric chapter markers in run-together text', () => {
    const text = 'Some intro text.  Chapter 1: The Beginning.  Chapter 2: Real Stuff.  More text.';
    const chapters = parseChapters(text);
    assert.strictEqual(chapters.length, 2);
    assert.strictEqual(chapters[0].number, 1);
    assert.strictEqual(chapters[0].title, 'The Beginning');
    // Offsets must be absolute character offsets into the raw content string
    assert.strictEqual(chapters[0].offset, text.indexOf('Chapter 1:'));
    assert.strictEqual(chapters[1].number, 2);
    assert.strictEqual(chapters[1].title, 'Real Stuff');
    assert.strictEqual(chapters[1].offset, text.indexOf('Chapter 2:'));
});

test('detects mid-line all-caps spelled-out markers (e.g. CHAPTER TWELVE.)', () => {
    const text = 'Prefatory text.  CHAPTER TWELVE.    The Emotions.    Body text.  CHAPTER TWENTY-ONE.  Spiritual Research.  More.';
    const chapters = parseChapters(text);
    assert.strictEqual(chapters.length, 2);
    assert.strictEqual(chapters[0].number, 12);
    assert.strictEqual(chapters[0].title, 'The Emotions');
    assert.strictEqual(chapters[0].offset, text.indexOf('CHAPTER TWELVE'));
    // Hyphenated number words
    assert.strictEqual(chapters[1].number, 21);
    assert.strictEqual(chapters[1].title, 'Spiritual Research');
    assert.strictEqual(chapters[1].offset, text.indexOf('CHAPTER TWENTY-ONE'));
});

test('findChapter maps run-together offsets to the right chapters', () => {
    const text = 'Front matter.  Chapter 1: Start.  Chapter 2: Middle.  Chapter 3: End.  Tail.';
    const chapters = parseChapters(text);
    const ch1 = text.indexOf('Chapter 1:');
    const ch2 = text.indexOf('Chapter 2:');
    const ch3 = text.indexOf('Chapter 3:');
    assert.strictEqual(findChapter(chapters, ch1 - 1), null); // front matter before first chapter
    assert.strictEqual(findChapter(chapters, ch2 + 1).number, 2);
    assert.strictEqual(findChapter(chapters, ch3 - 1).number, 2);
    assert.strictEqual(findChapter(chapters, ch3).number, 3);
    assert.strictEqual(findChapter(chapters, text.length - 1).number, 3);
});

test('ignores cross-references and citations mid-line', () => {
    // "(See ... Chapter 6.)" and "Chapter 13: Explanations, p. 265" are not chapter headings
    const crossRef = 'Read the chart first. (See Brain Physiology Chart, Chapter 6.) Then continue reading.';
    assert.deepStrictEqual(parseChapters(crossRef), []);
    const citation = 'From Reality and Subjectivity (2007), Chapter 13: Explanations, p. 265 is used with permission.';
    assert.deepStrictEqual(parseChapters(citation), []);
    // Lowercase cross-references must not match either
    assert.deepStrictEqual(parseChapters('This is explored in greater detail in chapter nine.  Q: What is grace?'), []);
});

test('keeps line-start behavior when a book also has mid-line references', () => {
    const text = [
        'CHAPTER 1: The Beginning',
        'Some text. (See Chapter 2.) More text.',
        'CHAPTER 2: The End',
        'Final text.'
    ].join('\n');
    const chapters = parseChapters(text);
    // Newline-separated books parse exactly as before — no mid-line entries added
    assert.strictEqual(chapters.length, 2);
    assert.strictEqual(chapters[0].number, 1);
    assert.strictEqual(chapters[1].number, 2);
});

// ============================================================
// I_AM_THAT dialogue markers (pass 3)
// ============================================================
console.log('\n--- I_AM_THAT dialogue markers (pass 3) ---');

test('detects numbered I_AM_THAT style dialogues in run-together text', () => {
    const text = 'Front matter and TOC.  1. The Sense of "I am"  Questioner: It is a matter of daily experience...  2. Obsession with the body  Questioner: Maharaj, you are sitting...';
    const chapters = parseChapters(text);
    assert.strictEqual(chapters.length, 2);
    assert.strictEqual(chapters[0].number, 1);
    assert.strictEqual(chapters[0].title, 'The Sense of "I am"');
    assert.strictEqual(chapters[1].number, 2);
    assert.strictEqual(chapters[1].title, 'Obsession with the body');
});

test('detects the last dialogue in I_AM_THAT style text', () => {
    const text = 'Stuff before.  100. Understanding leads to Freedom  Questioner: How can I know truth?  101. Jnani does not Grasp nor Hold  Questioner: What is Jnani?  Afterword.';
    const chapters = parseChapters(text);
    const last = chapters[chapters.length - 1];
    assert.strictEqual(last.number, 101);
    assert.strictEqual(last.title, 'Jnani does not Grasp nor Hold');
});

test('ignores TOC entries (titles containing other dialogue numbers)', () => {
    // TOC entries look like: 1. First  2. Second  3. Third  ...  101. Last
    // They contain other dialogue numbers in the "title" region.
    // The I_AM_THAT regex requires Questioner: so TOC-only text should find nothing.
    // Avoid using "Chapter N." in the text to not trigger pass 2 mid-line matching.
    const tocText = 'Book Contents.  1. First Dialogue  2. Second  3. Third  (no Questioner here)  99. Last one.  Afterword.';
    // No Questioner: present — pass 3 should find nothing.
    const chapters = parseChapters(tocText);
    assert.strictEqual(chapters.length, 0, 'TOC entries without Questioner should not match');
});

test('I_AM_THAT dialogue regex does not false-positive on cross-refs', () => {
    // Cross-references like "(See Chapter 6.)" should NOT match dialogue pattern
    const text = 'Some text. (See Chapter 6.) More text.  Another reference (see 12. Some title).';
    // No Questioner: present, so nothing should be detected
    const chapters = parseChapters(text);
    assert.strictEqual(chapters.length, 0);
});

// ============================================================
// Be_as_you_are space-separated CHAPTER markers
// ============================================================
console.log('\n--- Be_as_you_are space-separated CHAPTER markers ---');

test('detects CHAPTER N   Title format with spaces instead of colon', () => {
    const text = 'Intro text.  CHAPTER 1   The nature of the Self   The essence of Sri Ramana teachings is contained...  CHAPTER 2   Self-awareness and Self-ignorance   Sri Ramana occasionally...';
    const chapters = parseChapters(text);
    assert.strictEqual(chapters.length, 2);
    assert.strictEqual(chapters[0].number, 1);
    assert.strictEqual(chapters[0].title, 'The nature of the Self');
    assert.strictEqual(chapters[1].number, 2);
    assert.strictEqual(chapters[1].title, 'Self-awareness and Self-ignorance');
});

test('trims body text after space-separated chapter titles', () => {
    // Real Be_as_you_are format: CHAPTER 1   Title   Body text starts here with a capital.
    const text = 'Preface.  CHAPTER 5   Self-enquiry – practice   Beginners in self-enquiry were advised by Sri Ramana to...';
    const chapters = parseChapters(text);
    assert.strictEqual(chapters.length, 1);
    assert.strictEqual(chapters[0].number, 5);
    // Title should be trimmed: only "Self-enquiry – practice" not the body text
    assert.strictEqual(chapters[0].title, 'Self-enquiry – practice');
});

test('existing mid-line colon/period markers still work alongside space markers', () => {
    const text = 'Front.  Chapter 1: Teachers and Students.  Some content.  CHAPTER 2   Second Chapter   Body.  Chapter 3: Final.';
    const chapters = parseChapters(text);
    assert.strictEqual(chapters.length, 3);
    assert.strictEqual(chapters[0].title, 'Teachers and Students');
    assert.strictEqual(chapters[1].title, 'Second Chapter');
    assert.strictEqual(chapters[2].title, 'Final');
});

// ============================================================
// relocateTocChapters — snap TOC-only hits to body headings
// ============================================================
console.log('\n--- relocateTocChapters tests ---');

test('leaves well-spread chapters alone', () => {
    const text = 'x'.repeat(50000);
    const chapters = [
        { number: 1, title: 'A', offset: 100 },
        { number: 2, title: 'B', offset: 40000 },
    ];
    const out = relocateTocChapters(text, chapters);
    assert.strictEqual(out, chapters);
});

test('snaps spaced OCR headings past a clustered TOC', () => {
    const toc = 'Chapter 1: Alpha\nChapter 2: Beta\nChapter 3: Gamma\n';
    const body = 'x'.repeat(30000) + 'C HAPTER O NE\n\nAlpha\n'
        + 'y'.repeat(30000) + 'C HAPTER T WO\n\nBeta\n'
        + 'z'.repeat(30000) + 'C HAPTER T HREE\n\nGamma\n';
    const text = toc + body;
    const raw = parseChapters(text);
    assert.ok(raw[0].offset < 100, 'pass 1 should keep the TOC offsets');
    const relocated = relocateTocChapters(text, raw);
    assert.strictEqual(relocated.length, 3);
    assert.strictEqual(relocated[0].number, 1);
    assert.strictEqual(relocated[0].title, 'Alpha');
    assert.ok(relocated[0].offset > 20000);
    assert.ok(relocated[2].offset > relocated[0].offset + 40000);
});

test('snaps CHAPTER\\nN headings past a clustered TOC', () => {
    const toc = 'Chapter 1: Intro\nChapter 2: Grief\nChapter 3: Fear\n';
    const body = 'x'.repeat(30000) + '\nCHAPTER\n\n1\n\nINTRO\n'
        + 'y'.repeat(30000) + '\nCHAPTER\n\n2\n\nGRIEF\n'
        + 'z'.repeat(30000) + '\nCHAPTER\n\n3\n\nFEAR\n';
    const relocated = relocateTocChapters(toc + body, parseChapters(toc + body));
    assert.strictEqual(relocated.length, 3);
    assert.strictEqual(relocated[1].number, 2);
    assert.strictEqual(relocated[1].title, 'GRIEF');
    assert.ok(relocated[1].offset > 20000);
});

// ============================================================
// Summary
// ============================================================
console.log(`\n--- Results: ${passed} passed, ${failed} failed ---`);
if (failed > 0) {
    process.exit(1);
} else {
    console.log('All tests passed!');
}
