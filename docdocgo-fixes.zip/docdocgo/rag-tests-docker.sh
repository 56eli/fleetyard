#!/bin/sh
# Run RAG endpoint tests against the live Docker service.
# Usage:  bash rag-tests-docker.sh
#
# Expects: rag service running on localhost:9432 (or $RAG_HOST:$RAG_PORT).

RAG_HOST="${RAG_HOST:-127.0.0.1}"
RAG_PORT="${RAG_PORT:-9432}"
BASE_URL="http://${RAG_HOST}:${RAG_PORT}"
PASS=0
FAIL=0

pass() { echo "✅ $1"; PASS=$((PASS+1)); }
fail() { echo "❌ $1"; FAIL=$((FAIL+1)); }

# ── Wait for the service ───────────────────────────────────
echo "Waiting for RAG service at ${BASE_URL}…"
for i in $(seq 1 30); do
    if curl -sf "${BASE_URL}/health" >/dev/null 2>&1; then
        echo "RAG service is ready."
        break
    fi
    sleep 2
done

# ── 1. Health ──────────────────────────────────────────────
if curl -sf "${BASE_URL}/health" | grep -q '"ok"'; then
    pass "Health check"
else
    fail "Health check"
fi

# ── 2. Search with query ───────────────────────────────────
RESP=$(curl -sf -X POST "${BASE_URL}/search" \
    -H 'Content-Type: application/json' \
    -d '{"query":"non-duality","top_k":5}')
if echo "$RESP" | grep -q '"results"'; then
    pass "Search returns results"
else
    fail "Search returns results"
fi

# ── 3. top_k respected ─────────────────────────────────────
COUNT=$(echo "$RESP" | grep -o '"total":[0-9]*' | grep -o '[0-9]*')
if [ "$COUNT" -le 5 ] && [ "$COUNT" -gt 0 ]; then
    pass "top_k respected (${COUNT} results)"
else
    fail "top_k respected (got ${COUNT})"
fi

# ── 4. Score ordering (descending) ─────────────────────────
SCORES=$(echo "$RESP" | grep -o '"score":[0-9.]*' | sed 's/score://g')
if echo "$SCORES" | awk 'NR>1 && $1>prev{exit 1} {prev=$1} END{exit 0}'; then
    pass "Scores in descending order"
else
    fail "Scores in descending order"
fi

# ── 5. Source filter ───────────────────────────────────────
RESP2=$(curl -sf -X POST "${BASE_URL}/search" \
    -H 'Content-Type: application/json' \
    -d '{"query":"duality","sources":["david_r_hawkins.txt"]}')
if echo "$RESP2" | grep -q '"results"'; then
    pass "Source filter works"
else
    fail "Source filter works"
fi

# ── 6. Missing query → 400 ─────────────────────────────────
HTTP_CODE=$(curl -s -o /dev/null -w '%{http_code}' -X POST "${BASE_URL}/search" \
    -H 'Content-Type: application/json' \
    -d '{}')
if [ "$HTTP_CODE" = "400" ]; then
    pass "Missing query returns 400"
else
    fail "Missing query returns 400 (got ${HTTP_CODE})"
fi

# ── 7. Embed endpoint ──────────────────────────────────────
RESP3=$(curl -sf -X POST "${BASE_URL}/embed" \
    -H 'Content-Type: application/json' \
    -d '{"query":"test"}')
if echo "$RESP3" | grep -q '"embedding"' && echo "$RESP3" | grep -q '"dimensions"'; then
    pass "Embed endpoint"
else
    fail "Embed endpoint"
fi

# ── Summary ────────────────────────────────────────────────
echo ""
echo "========================================"
echo "RAG tests: ${PASS} passed, ${FAIL} failed"
echo "========================================"
if [ "$FAIL" -gt 0 ]; then
    exit 1
fi
exit 0
