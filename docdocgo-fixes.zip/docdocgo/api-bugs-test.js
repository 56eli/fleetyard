// E2E tests for the /api/search input-validation fixes (GitLab issue #30)
// plus DOC-004 / DOC-005 / DOC-009 API edge cases.
// Same style as rate-limit-test.js: spawns its own api.js, axios + assert.
//
//   duplicate ?q (array)            -> 400, not 500
//   limit outside 1..1000           -> 400, not negative total_pages
//   invalid regex (useRegex=true)   -> 400, not 500 / silent empty
//   page=0 / page=-3                -> normalized to page 1
//   page=100000                     -> empty results, page echoed
//   /api/docs                       -> rate limiting + literal-text notes, and
//                                      the /api/read example points at a real file
//   '&' filenames                   -> /api/read + /api/quote 200 (six titles 400'd before)
//   /api/files loop                 -> every listed file opens via /api/read,
//                                      and every served doc passes ingest
//                                      hygiene (no ==== banners, separator
//                                      lines, 4+ whitespace runs, entities,
//                                      controls, U+FFFD, mojibake, Hangul)
//   ingest hygiene unit fixtures    -> cleanIngestArtifacts transforms + word
//                                      preservation; q=Café now matches after
//                                      mojibake decode + Unicode  fix;
//                                      Sedona Dec 2008 Parts 1–4 Hangul-free
//                                      (DOC-016) + nonLatinShare 0.5% check
//   stopword-only q                 -> 0 matches + ignored_terms (DOC-004)
//   digit token q=01010900          -> matches under default wholeWords (DOC-005)
//   invalid filter                  -> 400 + valid_filters (DOC-009)
//   all-hawkins-books               -> includes Book of Slides (DOC-009)
//                                      controls, U+FFFD, mojibake, URLs/emails,
//                                      Audible chrome, Hay House promo)
//   ingest hygiene unit fixtures    -> cleanIngestArtifacts / loadCleanText
//                                      transforms + word preservation; q=Café
//                                      matches after mojibake decode; DOC-012
//                                      strips publisher/platform boilerplate
//   DOC-018 transcript normalisation   -> band|raw_asr+chunks, Audible strip, quote fold
//   DOC-042 /api/* wrong-method + unknown path -> JSON 405/404, not Express HTML
const { spawn } = require('child_process');
const path = require('path');
const http = require('http');
const axios = require('axios');
const assert = require('assert');

const TEST_PORT = 3222;
const BASE = `http://127.0.0.1:${TEST_PORT}`;

// Fresh socket per request. The suite blocks its own event loop for seconds
// (in-process loadLectureTexts) while earlier keep-alive sockets idle past
// the server's 5s keepAliveTimeout; reusing them then fails with a bogus
// `socket hang up`. Disabling pooling makes every request independent.
axios.defaults.httpAgent = new http.Agent({ keepAlive: false });

let child;

function startServer() {
    child = spawn(process.execPath, ['api.js'], {
        cwd: path.join(__dirname),
        // RATE_LIMIT_MAX is raised so the read-everything loop (test 12) isn't
        // throttled by the default 100 req/15 min bucket. Rate-limit behavior
        // itself is pinned by rate-limit-test.js on its own server.
        env: { ...process.env, PORT: String(TEST_PORT), RATE_LIMIT_MAX: '1000', SEARCH_BUDGET_MS: '20000' },
        stdio: ['ignore', 'pipe', 'pipe']
    });
    child.stderr.on('data', (d) => process.stderr.write(`[child] ${d}`));
}

async function waitForHealth() {
    for (let i = 0; i < 60; i++) {
        try {
            const res = await axios.get(`${BASE}/api/health`, { validateStatus: () => true, timeout: 5000 });
            if (res.status === 200) return;
        } catch (e) { /* not up yet */ }
        await new Promise((r) => setTimeout(r, 1000));
    }
    throw new Error('api did not become ready');
}

async function runTests() {
    console.log('--- API Bug-Fix E2E Tests ---');
    startServer();
    try {
        await waitForHealth();
        console.log('Target server ready.');

        // 1. Duplicate ?q arrives as an array -> 400 (was a 500 TypeError).
        const dup = await axios.get(`${BASE}/api/search?q=love&q=%5B`, { validateStatus: () => true });
        assert.strictEqual(dup.status, 400, 'duplicate ?q should be 400');
        assert(/single string/.test(dup.data.error), '400 body should explain the q constraint');
        console.log('✅ duplicate ?q → 400 (not 500)');

        // 2. limit out of range -> 400 with a clear message.
        for (const bad of ['-1', '0', '1001', 'abc']) {
            const res = await axios.get(`${BASE}/api/search?q=love&limit=${bad}`, { validateStatus: () => true });
            assert.strictEqual(res.status, 400, `limit=${bad} should be 400`);
            assert(/limit/.test(res.data.error), `limit=${bad} error should mention limit`);
        }
        console.log('✅ limit=-1/0/1001/abc → 400');

        // 3. Valid limit still works, and total_pages uses ceil(total/limit).
        const valid = await axios.get(`${BASE}/api/search?q=love&filter=books&limit=5`, { validateStatus: () => true });
        assert.strictEqual(valid.status, 200, 'valid limit should be 200');
        assert.strictEqual(valid.data.limit, 5, 'limit echoed in response');
        assert.strictEqual(valid.data.total_pages, Math.ceil(valid.data.total_matches / 5), 'total_pages = ceil(total/limit)');
        assert(valid.data.total_pages >= 1, 'total_pages should be positive');
        console.log('✅ limit=5 → 200, total_pages=ceil(total/5)');

        // 4. Invalid regex -> 400 (was 500; short ones were silently empty).
        const badRegex = await axios.get(`${BASE}/api/search?q=%5Ba-z-&useRegex=true`, { validateStatus: () => true });
        assert.strictEqual(badRegex.status, 400, 'invalid regex should be 400');
        assert(/Invalid regular expression/.test(badRegex.data.error), '400 body should say the regex is invalid');
        const shortBadRegex = await axios.get(`${BASE}/api/search?q=%5B&useRegex=true`, { validateStatus: () => true });
        assert.strictEqual(shortBadRegex.status, 400, 'short invalid regex should also be 400');
        console.log('✅ invalid regex → 400 (long and short)');

        // 4b. Commas are preserved in the query (GoluGit #4 / DOC-003). The old
        //     global comma strip corrupted regex ranges (a{2,3} -> a{23}) and
        //     silently rewrote literal queries (love, peace -> love peace).
        const commaEcho = await axios.get(`${BASE}/api/search`, { params: { q: 'love, peace', limit: 1 }, validateStatus: () => true });
        assert.strictEqual(commaEcho.status, 200, 'comma query should be 200');
        assert.strictEqual(commaEcho.data.query, 'love, peace', 'query must be echoed verbatim, commas intact');
        assert(commaEcho.data.total_matches > 0, 'comma query should still match (comma-blind keyword mode)');
        const commaRegex = await axios.get(`${BASE}/api/search`, { params: { q: 's{2,3}', useRegex: 'true', limit: 1 }, validateStatus: () => true });
        assert.strictEqual(commaRegex.status, 200, 'comma-range regex should be 200');
        assert.strictEqual(commaRegex.data.query, 's{2,3}', 'regex quantifier range must survive unchanged');
        assert(commaRegex.data.total_matches > 0, `s{2,3} must match ss/sss runs (e.g. "bliss"); got ${commaRegex.data.total_matches}`);
        const commaPhrase = await axios.get(`${BASE}/api/search`, { params: { q: 'Dissolving the Ego, Realizing the Self', limit: 5 }, validateStatus: () => true });
        assert.strictEqual(commaPhrase.status, 200, 'comma phrase should be 200');
        assert(commaPhrase.data.total_matches > 0, 'comma phrase exists verbatim in the corpus (ALSO BY lists)');
        assert(
            commaPhrase.data.results.some(r => r.snippet.toLowerCase().includes('dissolving the ego, realizing the self')),
            'exact-phrase detection should center on the comma-containing phrase'
        );
        const commaStop = await axios.get(`${BASE}/api/search`, { params: { q: 'the, of', limit: 1 }, validateStatus: () => true });
        assert.strictEqual(commaStop.status, 200, 'comma stop-word query should be 200');
        assert.strictEqual(commaStop.data.total_matches, 0, 'comma-attached stop words must still be filtered');
        // Formatted numbers stay one token (digit-flanked commas don't split):
        // "1,000" searches for the formatted number, not "1" + "000" noise.
        const formatted = await axios.get(`${BASE}/api/search`, { params: { q: '1,000', limit: 1 }, validateStatus: () => true });
        assert.strictEqual(formatted.status, 200, 'formatted-number query should be 200');
        assert(formatted.data.total_matches > 0, '"1,000" occurs in the corpus and must match as one token');
        assert(formatted.data.total_matches < 1000, `one-token "1,000" must not explode into single-digit noise (got ${formatted.data.total_matches})`);
        // Comma-blind equality: a comma between space-separated words changes nothing.
        const withComma = await axios.get(`${BASE}/api/search`, { params: { q: 'love, peace', limit: 1 }, validateStatus: () => true });
        const noComma = await axios.get(`${BASE}/api/search`, { params: { q: 'love peace', limit: 1 }, validateStatus: () => true });
        assert.strictEqual(withComma.data.total_matches, noComma.data.total_matches, 'a comma between words must not change keyword matching');
        // The min-3 gate counts RAW characters of the query as sent: "a,b" is
        // 3 chars and runs (its tokens still go through stop-word filtering) —
        // documented decision, see AGENTS.md.
        const shortComma = await axios.get(`${BASE}/api/search`, { params: { q: 'a,b', limit: 1 }, validateStatus: () => true });
        assert.strictEqual(shortComma.status, 200, 'q=a,b is 3 raw characters and should run');
        assert(shortComma.data.total_matches > 0, 'q=a,b matches whole-word "b" occurrences');
        console.log('✅ commas preserved: verbatim echo, s{2,3} range, comma-phrase matching, stop-word filtering, formatted numbers, comma-blind equality');

        // 5. page normalization: 0 and negatives become page 1 with results.
        for (const p of ['0', '-3', 'abc']) {
            const res = await axios.get(`${BASE}/api/search?q=love&filter=books&limit=5&page=${p}`, { validateStatus: () => true });
            assert.strictEqual(res.status, 200, `page=${p} should be 200`);
            assert.strictEqual(res.data.page, 1, `page=${p} should normalize to 1`);
            assert(res.data.results.length > 0, `page=${p} should return first-page results`);
        }
        console.log('✅ page=0/-3/abc → page 1 with results');

        // 6. Huge page: echoed as-is, empty results (consistent with "past the last page").
        const huge = await axios.get(`${BASE}/api/search?q=love&filter=books&limit=5&page=100000`, { validateStatus: () => true });
        assert.strictEqual(huge.status, 200, 'page=100000 should be 200');
        assert.strictEqual(huge.data.page, 100000, 'page echoed');
        assert.strictEqual(huge.data.results.length, 0, 'past-last page returns no results');
        console.log('✅ page=100000 → empty results, page echoed');

        // 7. /api/docs publishes the new behavior + a real /api/read example.
        const docs = await axios.get(`${BASE}/api/docs`, { validateStatus: () => true });
        assert.strictEqual(docs.status, 200, 'docs should be 200');
        assert(docs.data.rate_limiting, 'docs should publish rate limiting');
        assert(docs.data.notes && /HTML-like queries/.test(docs.data.notes.html_queries), 'docs should document literal-text behavior');
        const searchDocs = docs.data.endpoints['/api/search'];
        assert(searchDocs && searchDocs.results, 'docs should publish one /api/search result schema');
        assert(/match_count/.test(JSON.stringify(searchDocs.results)), 'docs should document match_count');
        assert(/doc_match_count/.test(JSON.stringify(searchDocs.results)), 'docs should document doc_match_count');
        assert(/title/.test(JSON.stringify(searchDocs.results)), 'docs should document title');
        assert(/kind/.test(JSON.stringify(searchDocs.results)), 'docs should document kind');
        assert(/chapter/.test(JSON.stringify(searchDocs.results)), 'docs should document chapter');
        assert(/offset/.test(searchDocs.parameters.page), 'docs should say offset is rejected');
        const example = docs.data.endpoints['/api/read/:filename'].example.replace('/api/read/', '');
        const readRes = await axios.get(`${BASE}/api/read/${encodeURIComponent(example)}`, { validateStatus: () => true });
        assert.strictEqual(readRes.status, 200, `docs example ${example} should be a real file`);
        console.log('✅ /api/docs: rate limiting + literal-text notes; example filename resolves');

        // 7b. DOC-045: undocumented offset query param is rejected (page+limit paginate).
        const badOffset = await axios.get(`${BASE}/api/search?q=ego&limit=5&offset=5`, { validateStatus: () => true });
        assert.strictEqual(badOffset.status, 400, 'offset query param should be 400');
        assert(/offset/.test(badOffset.data.error), '400 body should mention offset');
        assert.strictEqual(badOffset.data.docs, '/api/docs');
        console.log('✅ offset query param → 400');

        // 8. Search time budget: with SEARCH_BUDGET_MS=1 any real corpus scan
        // must stop early and return the partial-result flag (P1-1 mitigation).
        const budgetChild = spawn(process.execPath, ['api.js'], {
            cwd: __dirname,
            env: { ...process.env, PORT: '3206', SEARCH_BUDGET_MS: '1' },
            stdio: ['ignore', 'ignore', 'pipe']
        });
        try {
            const budgetBase = `http://127.0.0.1:3206`;
            let up = false;
            for (let i = 0; i < 60; i++) {
                try {
                    const h = await axios.get(`${budgetBase}/api/health`, { validateStatus: () => true, timeout: 5000 });
                    if (h.status === 200) { up = true; break; }
                } catch (e) { /* not up yet */ }
                await new Promise((r) => setTimeout(r, 500));
            }
            assert(up, 'budget server should come up');
            const tr = await axios.get(`${budgetBase}/api/search?q=consciousness&limit=3`, { validateStatus: () => true, timeout: 10000 });
            assert.strictEqual(tr.status, 200, 'budget-truncated search should still be 200');
            assert.strictEqual(tr.data.truncated, true, `search with 1ms budget must be flagged truncated (got ${JSON.stringify(tr.data).slice(0, 200)})`);
            assert(Number.isInteger(tr.data.total_matches), 'total_matches should still be an integer');
            console.log('✅ SEARCH_BUDGET_MS=1 → search returns 200 with truncated: true (partial results, no hang)');
        } finally {
            budgetChild.kill('SIGTERM');
        }

        // 9. 3-char core terms work; shorter and stop-word-only queries stay empty.
        const ego = await axios.get(`${BASE}/api/search?q=ego&filter=books&limit=5`, { validateStatus: () => true });
        assert.strictEqual(ego.status, 200, 'q=ego should be 200');
        assert(ego.data.total_matches > 0, 'q=ego should find matches');
        const short = await axios.get(`${BASE}/api/search?q=ab`, { validateStatus: () => true });
        assert.strictEqual(short.status, 200, 'q=ab should be 200');
        assert.strictEqual(short.data.total_matches, 0, 'q=ab should be empty (min 3)');
        const stop = await axios.get(`${BASE}/api/search?q=the`, { validateStatus: () => true });
        assert.strictEqual(stop.status, 200, 'q=the should be 200');
        assert.strictEqual(stop.data.total_matches, 0, 'q=the should be empty (stop word)');
        assert(Array.isArray(stop.data.ignored_terms) && stop.data.ignored_terms.includes('the'),
            'DOC-004: q=the must name ignored_terms');
        console.log('✅ q=ego → matches; q=ab / q=the → empty (+ ignored_terms)');

        // 10. '&' filenames are readable. Six corpus titles contain '&' and
        //     400'd before the validation fix:
        //     The_Levels_of_Consciousness_Subjective_&_Social_Consequences_Mar_2002_Part_1/2/3,
        //     Overcoming_Doubt,_Skepticism_&_Disbelief_Aug_2008_Part_1/2/3.
        const ampFile = 'The_Levels_of_Consciousness_Subjective_&_Social_Consequences_Mar_2002_Part_1_enxautogen_html';
        const ampRaw = await axios.get(`${BASE}/api/read/${ampFile}`, { validateStatus: () => true });
        assert.strictEqual(ampRaw.status, 200, "'&' filename should be readable (raw & in path)");
        assert.strictEqual(ampRaw.data.path, ampFile, 'path echoed unchanged');
        assert(typeof ampRaw.data.content === 'string' && ampRaw.data.content.length > 0, 'content should be served');
        const ampEnc = await axios.get(`${BASE}/api/read/${encodeURIComponent(ampFile)}`, { validateStatus: () => true });
        assert.strictEqual(ampEnc.status, 200, "'&' filename should be readable (%26-encoded, as the frontend sends it)");
        assert.strictEqual(ampEnc.data.path, ampFile, 'decoded path echoed unchanged');
        const ampOther = await axios.get(`${BASE}/api/read/Overcoming_Doubt,_Skepticism_&_Disbelief_Aug_2008_Part_1_enxautogen_html`, { validateStatus: () => true });
        assert.strictEqual(ampOther.status, 200, 'Overcoming_Doubt,_Skepticism_&_Disbelief should be readable');
        // The widened charset must still reject everything outside it.
        const evil = await axios.get(`${BASE}/api/read/${encodeURIComponent('../secret')}`, { validateStatus: () => true });
        assert.strictEqual(evil.status, 400, 'path traversal must still be rejected');
        assert(/Invalid filename/.test(evil.data.error), 'traversal rejection should be the charset 400');
        console.log('✅ /api/read opens "&" filenames (raw & and %26 forms); traversal still 400');

        // 11. /api/quote shares the validation regex — '&' filenames must resolve
        //     (quote links are /se/?read=<path>#q-<prefix>-<len>).
        const normPrefix = String(ampRaw.data.content).toLowerCase().replace(/\s+/g, ' ').trim().slice(0, 24);
        const qRes = await axios.get(`${BASE}/api/quote/${ampFile}`, { params: { p: normPrefix, n: 60 }, validateStatus: () => true });
        assert.strictEqual(qRes.status, 200, "'&' filename quote link should resolve");
        assert(typeof qRes.data.quote === 'string' && qRes.data.quote.length > 0, 'quote body should be returned');
        console.log('✅ /api/quote resolves on "&" filenames');

        // 12. Read-everything loop: every entry /api/files lists must open via
        //     /api/read — catches any future corpus key that uses a character
        //     the filename validation rejects. Server runs RATE_LIMIT_MAX=1000.
        //     The six '&' keys are derived from the listing (not hard-coded), so
        //     the test self-heals if they are ever renamed.
        const filesList = await axios.get(`${BASE}/api/files`, { validateStatus: () => true });
        assert.strictEqual(filesList.status, 200, '/api/files should be 200');
        const names = filesList.data.files;
        // Deliberate full-corpus pin: 307 documents today. If the corpus
        // legitimately shrinks below this, revisit the bound consciously.
        assert(names.length >= 300, `expected the full corpus in /api/files, got ${names.length}`);
        const ampKeys = names.filter((n) => n.includes('&'));
        assert.strictEqual(ampKeys.length, 6, `expected exactly six legacy '&' corpus keys, got ${ampKeys.length}`);
        const ampAll = await Promise.all(ampKeys.map((n) =>
            axios.get(`${BASE}/api/read/${encodeURIComponent(n)}`, { validateStatus: () => true })));
        ampAll.forEach((r, i) => assert.strictEqual(r.status, 200, `${ampKeys[i]} -> HTTP ${r.status}`));
        console.log(`✅ all six '&' keys readable (derived from /api/files, not hard-coded)`);
        const unreadable = [];
        const hygieneViolations = [];
        for (let i = 0; i < names.length; i += 8) {
            const batch = names.slice(i, i + 8);
            const responses = await Promise.all(batch.map((n) =>
                axios.get(`${BASE}/api/read/${encodeURIComponent(n)}`, { validateStatus: () => true })));
            responses.forEach((r, j) => {
                if (r.status !== 200) unreadable.push(`${names[i + j]} -> HTTP ${r.status}`);
                // Load-time ingest hygiene invariants (DOC-010/#11, DOC-013/#14,
                // DOC-014/#15, DOC-015/#16) hold for EVERY served document:
                // no ==== banners, no separator-rule lines, no 4+ whitespace
                // runs (leading indentation allowlisted), no undecoded
                // entities / C0 controls / U+FFFD / mojibake.
                const c = r.status === 200 && r.data && typeof r.data.content === 'string' ? r.data.content : '';
                if (!c) return;
                const n = names[i + j];
                if (c.includes('====')) hygieneViolations.push(`${n}: ==== ingest marker survives`);
                if (/\n{4,}/.test(c)) hygieneViolations.push(`${n}: 4+ newline run survives`);
                if (/(?<=\S) {4,}(?=\S)/.test(c)) hygieneViolations.push(`${n}: interior 4+ space run survives`);
                if (/^[-_=]{5,}$/m.test(c)) hygieneViolations.push(`${n}: separator-run line survives`);
                if (/&(amp|lt|gt|quot|#39|nbsp);/.test(c)) hygieneViolations.push(`${n}: undecoded HTML entity survives`);
                if (/[\x00-\x08\x0B\x0C\x0E-\x1F]/.test(c)) hygieneViolations.push(`${n}: C0 control char survives`);
                if (c.includes('\uFFFD')) hygieneViolations.push(`${n}: U+FFFD replacement char survives`);
                if (/[\u00c2-\u00df\u00e0-\u00ef][\u0080-\u00bf]/.test(c)) hygieneViolations.push(`${n}: mojibake survives`);
                // DOC-016/017: no Hangul / CJK / kana / Cyrillic / Arabic script noise.
                if (/[\u1100-\u11FF\u3130-\u318F\uAC00-\uD7A3]/.test(c)) hygieneViolations.push(`${n}: Hangul survives (DOC-016)`);
                if (/[\u0400-\u04FF\u0600-\u06FF\u3040-\u30FF\u3400-\u4DBF\u4E00-\u9FFF\uF900-\uFAFF]/.test(c)) hygieneViolations.push(`${n}: non-Latin script noise survives (DOC-017)`);
                // DOC-012: no URL / email / Audible chrome / Hay House promo.
                if (/https?:\/\/\S|www\.\S/i.test(c)) hygieneViolations.push(`${n}: URL survives (DOC-012)`);
                if (/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i.test(c)) hygieneViolations.push(`${n}: email survives (DOC-012)`);
                if (/This is Audible|Audible hopes you have enjoyed/i.test(c)) hygieneViolations.push(`${n}: Audible chrome survives (DOC-012)`);
                if (/Enjoy uplifting personal stories/i.test(c)) hygieneViolations.push(`${n}: Hay House promo survives (DOC-012)`);
            });
        }
        assert.strictEqual(unreadable.length, 0, `all /api/files entries must be readable via /api/read:\n${unreadable.join('\n')}`);
        console.log(`✅ /api/read returns 200 for all ${names.length} files listed by /api/files`);
        assert.strictEqual(hygieneViolations.length, 0, `served text must pass ingest hygiene (DOC-010/013/014/015/016):\n${hygieneViolations.slice(0, 10).join('\n')}`);
        console.log(`✅ all ${names.length} served documents are ingest-hygiene clean (no ==== banners, separator lines, 4+ whitespace runs, entities, controls, U+FFFD, mojibake, Hangul)`);
        assert.strictEqual(hygieneViolations.length, 0, `served text must pass ingest hygiene (DOC-010/012/013/014/015):\n${hygieneViolations.slice(0, 10).join('\n')}`);
        console.log(`✅ all ${names.length} served documents are ingest-hygiene clean (no ==== banners, separator lines, 4+ whitespace runs, entities, controls, U+FFFD, mojibake, URLs/emails, Audible/Hay House promo)`);

        // 13. RAG family degrades gracefully when the optional RAG service is
        //     down (DOC-002): all four proxy endpoints answer fast 503 JSON
        //     with a hint (no hang, no bare 502, no crash), input validation
        //     still runs first (400s), and /api/health/deps reports
        //     'degraded' — while with a RAG service up, everything proxies
        //     through untouched and deps flips to 'ok'.
        {
            // (a) RAG down: point the proxy at a closed port so the
            //     availability probe fails fast (ECONNREFUSED).
            const downChild = spawn(process.execPath, ['api.js'], {
                cwd: __dirname,
                env: {
                    ...process.env,
                    PORT: '3207',
                    RAG_HOST: '127.0.0.1',
                    RAG_PORT: '1',
                    RAG_PROBE_TIMEOUT_MS: '1000',
                    RAG_PROBE_TTL_MS: '60000'
                },
                stdio: ['ignore', 'ignore', 'pipe']
            });
            try {
                const downBase = 'http://127.0.0.1:3207';
                let down = false;
                for (let i = 0; i < 60; i++) {
                    try {
                        const h = await axios.get(`${downBase}/api/health`, { validateStatus: () => true, timeout: 5000 });
                        if (h.status === 200) { down = true; break; }
                    } catch (e) { /* not up yet */ }
                    await new Promise((r) => setTimeout(r, 500));
                }
                assert(down, 'RAG-down server should come up');

                // Validation happens before the availability check.
                const noQuery = await axios.post(`${downBase}/api/rag`, {}, { validateStatus: () => true });
                assert.strictEqual(noQuery.status, 400, 'missing query should stay 400 even with RAG down');
                const badSources = await axios.post(`${downBase}/api/rag`, { query: 'courage', sources: 'not-an-array' }, { validateStatus: () => true });
                assert.strictEqual(badSources.status, 400, 'sources as a string should be 400, not a 500');
                const badTopK = await axios.post(`${downBase}/api/rag`, { query: 'courage', top_k: 'lots' }, { validateStatus: () => true });
                assert.strictEqual(badTopK.status, 400, 'top_k as a string should be 400');

                // All four RAG-family endpoints: clean 503 JSON with a hint.
                const t0 = Date.now();
                const ragDown = await axios.post(`${downBase}/api/rag`, { query: 'courage' }, { validateStatus: () => true, timeout: 15000 });
                assert.strictEqual(ragDown.status, 503, 'POST /api/rag with RAG down should be 503');
                assert(/not available/.test(ragDown.data.error), '503 body should say the service is not available');
                assert(ragDown.data.hint && /api\/search/.test(ragDown.data.hint), '503 body should point at /api/search');
                assert.strictEqual(ragDown.data.dependencies, '/api/health/deps', '503 body should point at /api/health/deps');
                const ctxDown = await axios.post(`${downBase}/api/rag/context`, { query: 'courage' }, { validateStatus: () => true, timeout: 15000 });
                assert.strictEqual(ctxDown.status, 503, 'POST /api/rag/context with RAG down should be 503');
                const calDown = await axios.post(`${downBase}/api/calibrate`, { text: 'courage' }, { validateStatus: () => true, timeout: 15000 });
                assert.strictEqual(calDown.status, 503, 'POST /api/calibrate with RAG down should be 503');
                const srcDown = await axios.get(`${downBase}/api/rag/sources`, { validateStatus: () => true, timeout: 15000 });
                assert.strictEqual(srcDown.status, 503, 'GET /api/rag/sources with RAG down should be 503');
                assert(Date.now() - t0 < 15000, 'RAG-down responses must not hang');

                // A second call is served from the cached probe: immediate.
                const ragDown2 = await axios.post(`${downBase}/api/rag`, { query: 'courage' }, { validateStatus: () => true, timeout: 5000 });
                assert.strictEqual(ragDown2.status, 503, 'second POST /api/rag should also be 503');
                // Dependency report: always 200, degraded, rag down.
                const depsDown = await axios.get(`${downBase}/api/health/deps`, { validateStatus: () => true, timeout: 15000 });
                assert.strictEqual(depsDown.status, 200, '/api/health/deps should always be 200');
                assert.strictEqual(depsDown.data.status, 'degraded', 'deps status should be degraded with RAG down');
                assert.strictEqual(depsDown.data.dependencies.rag.status, 'down', 'deps should report rag as down');
                console.log('✅ RAG down → fast 503 JSON with hint on all four endpoints; validations stay 400; /api/health/deps reports degraded');
            } finally {
                downChild.kill('SIGTERM');
            }

            // (b) RAG up: a mock speaking the documented service contract
            //     (/health, /search, /context, /sources — see rag-tests.js)
            //     must be proxied through unchanged.
            const mockRequests = [];
            const mockRAG = http.createServer((req, res) => {
                let body = '';
                req.on('data', (c) => { body += c; });
                req.on('end', () => {
                    mockRequests.push(`${req.method} ${req.url} ${body}`);
                    res.setHeader('Content-Type', 'application/json');
                    if (req.url === '/health') return res.end(JSON.stringify({ status: 'ok' }));
                    if (req.url === '/search') {
                        return res.end(JSON.stringify({
                            query: JSON.parse(body).query,
                            results: [{ chunk: { source: 'mock.txt', text: 'mock chunk' }, score: 0.99 }],
                            total: 1
                        }));
                    }
                    if (req.url === '/context') {
                        return res.end(JSON.stringify({ context: 'mock context block', system_instructions: 'mock instructions' }));
                    }
                    if (req.url === '/sources') return res.end(JSON.stringify({ sources: ['mock.txt'] }));
                    res.statusCode = 404;
                    res.end(JSON.stringify({ error: 'not found' }));
                });
            });
            await new Promise((resolve) => mockRAG.listen(0, '127.0.0.1', resolve));
            const mockPort = mockRAG.address().port;
            const upChild = spawn(process.execPath, ['api.js'], {
                cwd: __dirname,
                env: { ...process.env, PORT: '3208', RAG_HOST: '127.0.0.1', RAG_PORT: String(mockPort), RAG_PROBE_TTL_MS: '60000' },
                stdio: ['ignore', 'ignore', 'pipe']
            });
            try {
                const upBase = 'http://127.0.0.1:3208';
                let ready = false;
                for (let i = 0; i < 60; i++) {
                    try {
                        const h = await axios.get(`${upBase}/api/health`, { validateStatus: () => true, timeout: 5000 });
                        if (h.status === 200) { ready = true; break; }
                    } catch (e) { /* not up yet */ }
                    await new Promise((r) => setTimeout(r, 500));
                }
                assert(ready, 'RAG-up server should come up');

                const rag = await axios.post(`${upBase}/api/rag`, { query: 'courage', top_k: 3 }, { validateStatus: () => true, timeout: 15000 });
                assert.strictEqual(rag.status, 200, 'POST /api/rag with RAG up should proxy 200');
                assert.strictEqual(rag.data.query, 'courage', 'proxy must pass the RAG response through');
                assert.strictEqual(rag.data.total, 1, 'proxy must pass the RAG results through');
                const depsUp = await axios.get(`${upBase}/api/health/deps`, { validateStatus: () => true, timeout: 15000 });
                assert.strictEqual(depsUp.status, 200, '/api/health/deps should stay 200 when up');
                assert.strictEqual(depsUp.data.status, 'ok', 'deps status should be ok with RAG answering');
                assert.strictEqual(depsUp.data.dependencies.rag.status, 'up', 'deps should report rag as up');
                const cal = await axios.post(`${upBase}/api/calibrate`, { text: 'courage' }, { validateStatus: () => true, timeout: 15000 });
                assert.strictEqual(cal.status, 200, 'POST /api/calibrate with RAG up should proxy 200');
                assert(cal.data.calibration_context && cal.data.calibration_context.context === 'mock context block', 'calibrate should pass the RAG context through');
                const srcs = await axios.get(`${upBase}/api/rag/sources`, { validateStatus: () => true, timeout: 15000 });
                assert.strictEqual(srcs.status, 200, 'GET /api/rag/sources with RAG up should proxy 200');
                assert.deepStrictEqual(srcs.data.sources, ['mock.txt'], 'rag/sources should pass through');
                assert(mockRequests.some((r) => /^POST \/search /.test(r) && r.includes('"top_k":3')), 'mock RAG should receive the proxied payload with top_k');
                console.log('✅ RAG up → /search, /calibrate, /sources proxy through; /api/health/deps reports ok');
            } finally {
                upChild.kill('SIGTERM');
                mockRAG.close();
            }
        }

        // 14. Search-quality fixes (DOC-006/007/008): quoted-phrase mode
        //     counts phrase occurrences; multi-word keyword responses carry
        //     phrase_match_count + search_mode/count_basis and flag the
        //     20,000-result cap; typographic variants fold (isn't ≡ isn’t);
        //     short punctuation/non-ASCII queries match instead of silently
        //     returning 0; regex with a literal " compiles unchanged.
        // 15. Load-time ingest hygiene (DOC-010/#11, DOC-012/#13,
        //     DOC-013/#14 separator subset, DOC-014/#15, DOC-015/#16): every
        //     load path (lectures, books, extra sources, overlays) runs
        //     loadCleanText (= cleanIngestArtifacts + stripPublisherBoilerplate),
        //     so /api/read and /api/search serve text without ingest banners,
        //     PDF whitespace artifacts, encoding damage, or publisher/platform
        //     boilerplate — without touching the read-only data files.
        {
            // (a) Phrase mode: exact-phrase counts only.
            const phrase = await axios.get(`${BASE}/api/search`, { params: { q: '"Heal Your Life"', limit: 3 }, validateStatus: () => true });
            assert.strictEqual(phrase.status, 200, 'quoted phrase query should be 200');
            assert.strictEqual(phrase.data.search_mode, 'phrase', 'a fully-quoted query runs in phrase mode');
            assert.strictEqual(phrase.data.count_basis, 'phrase-occurrences');
            // Ground truth: the regex-mode literal count for this phrase is
            // 20 occurrences in 19 files after DOC-012 promo strip. Update consciously if the corpus changes.
            assert.strictEqual(phrase.data.total_matches, 20, 'phrase mode must count phrase occurrences');
            assert.strictEqual(phrase.data.files_count, 19);
            assert(phrase.data.results.every(r => /heal\s+your\s+life/i.test(r.snippet)), 'phrase snippets must contain the phrase');

            // DOC-012 strips Audible platform intros — use a surviving phrase pin.
            // DOC-018 strips Audible platform intros — use a surviving phrase pin.
            const phrase2 = await axios.get(`${BASE}/api/search`, { params: { q: '"power vs force"', limit: 3 }, validateStatus: () => true });
            assert.strictEqual(phrase2.data.search_mode, 'phrase');
            assert.strictEqual(phrase2.data.total_matches, 5, '5 occurrences of power vs force');
            assert.strictEqual(phrase2.data.files_count, 1);
            assert(phrase2.data.results.every(r => /power\s+vs\s+force/i.test(r.match_text[0])), 'match_text is the phrase occurrence');

            // (b) Keyword mode stays keyword mode but reports the honest
            //     phrase count alongside the group count, and flags the cap.
            const kwPhrase = await axios.get(`${BASE}/api/search`, { params: { q: 'power vs force', limit: 1 }, validateStatus: () => true });
            assert.strictEqual(kwPhrase.status, 200);
            assert.strictEqual(kwPhrase.data.search_mode, 'keywords');
            assert.strictEqual(kwPhrase.data.count_basis, 'keyword-groups');
            assert(kwPhrase.data.total_matches > 1000, 'keyword-group count is still the (large) group count');
            assert.strictEqual(kwPhrase.data.phrase_match_count, 5, 'phrase_match_count must equal the phrase-mode count');
            // Cap pin: a denser multi-word query still hits the 20,000-result ceiling.
            const kw = await axios.get(`${BASE}/api/search`, { params: { q: 'consciousness is', limit: 1 }, validateStatus: () => true });
            assert.strictEqual(kw.status, 200);
            assert.strictEqual(kw.data.truncated, true, 'the 20,000-result cap must set truncated');
            assert(/20,000-result cap/.test(kw.data.notice), 'notice must name the cap');

            // (c) Hybrid: quoted phrase + keywords — groups must contain the
            //     phrase, and the phrase is echoed.
            // Keyword co-located with the phrase (Louise appears in Hay House blurbs).
            const hyb = await axios.get(`${BASE}/api/search`, { params: { q: '"Heal Your Life" Louise', limit: 5 }, validateStatus: () => true });
            assert.strictEqual(hyb.status, 200);
            assert.strictEqual(hyb.data.search_mode, 'keywords');
            assert.deepStrictEqual(hyb.data.phrases, ['Heal Your Life']);
            assert(hyb.data.total_matches > 0 && hyb.data.total_matches <= 20, 'hybrid groups are bounded by phrase occurrences');
            assert.strictEqual(hyb.data.phrase_match_count, 20);
            assert(hyb.data.results.every(r =>
                /heal\s+your\s+life/i.test(r.snippet) && /louise/i.test(r.snippet)
            ), 'hybrid groups must contain BOTH the quoted phrase and the keyword');
            // Keyword present in the same docs but not near the phrase → no phrase-only groups.
            const hybFar = await axios.get(`${BASE}/api/search`, { params: { q: '"Heal Your Life" forgiveness', limit: 5 }, validateStatus: () => true });
            assert.strictEqual(hybFar.status, 200);
            assert.strictEqual(hybFar.data.phrase_match_count, 20, 'docs still contain the phrase + far keyword');
            assert.strictEqual(hybFar.data.total_matches, 0, 'hybrid must not return phrase-only groups when keyword is not nearby');
            const hybMiss = await axios.get(`${BASE}/api/search`, { params: { q: '"Heal Your Life" xyzqwe123notreal', limit: 5 }, validateStatus: () => true });
            assert.strictEqual(hybMiss.status, 200);
            assert.strictEqual(hybMiss.data.total_matches, 0, 'hybrid must not return phrase-only groups when keyword never matches');

            // (c2) Hybrid whose keyword remainder is ALL stopwords must NOT
            //     build RegExp('') (empty keyword regex) — treat as phrase
            //     scan only and stay bounded/fast.
            const hybStop = await axios.get(`${BASE}/api/search`, { params: { q: '"Heal Your Life" the', limit: 5 }, validateStatus: () => true });
            assert.strictEqual(hybStop.status, 200, 'hybrid+stopword remainder must not 500');
            assert.strictEqual(hybStop.data.search_mode, 'keywords');
            assert.deepStrictEqual(hybStop.data.phrases, ['Heal Your Life']);
            assert(hybStop.data.total_matches > 0 && hybStop.data.total_matches <= 20,
                'hybrid+stopword remainder must stay phrase-bounded, not explode via empty regex');
            assert.strictEqual(hybStop.data.phrase_match_count, 20);

            // (d) Folding: either apostrophe variant finds both (DOC-008).
            const straight = await axios.get(`${BASE}/api/search`, { params: { q: "isn't", limit: 1 }, validateStatus: () => true });
            const curly = await axios.get(`${BASE}/api/search`, { params: { q: 'isn’t', limit: 1 }, validateStatus: () => true });
            assert.strictEqual(straight.data.total_matches, curly.data.total_matches, "isn't and isn’t must return identical counts");
            // Exact union of the pre-fold counts: 1,593 (straight-only,
            // transcripts) + 241 (curly-only, books). Update consciously if
            // the corpus changes.
            assert.strictEqual(straight.data.total_matches, 1834);
            assert(straight.data.files_count >= 290, 'union of straight (279 files) and curly (20 files)');
            const dontS = await axios.get(`${BASE}/api/search`, { params: { q: "don't", limit: 1 }, validateStatus: () => true });
            const dontC = await axios.get(`${BASE}/api/search`, { params: { q: 'don’t', limit: 1 }, validateStatus: () => true });
            assert.strictEqual(dontS.data.total_matches, dontC.data.total_matches, "don't and don’t must return identical counts");
            assert(dontS.data.total_matches > 9000, "don't must now find books too (straight-only was 9,049)");

            // (e) Short punctuation / non-ASCII queries match (DOC-007).
            const eacute = await axios.get(`${BASE}/api/search`, { params: { q: 'é', limit: 1 }, validateStatus: () => true });
            assert.strictEqual(eacute.status, 200, 'q=é should be 200, not gated');
            assert(eacute.data.total_matches > 0, 'q=é must match (é occurs in the corpus)');
            const emdash = await axios.get(`${BASE}/api/search`, { params: { q: '—', limit: 1 }, validateStatus: () => true });
            assert(emdash.data.total_matches > 1000, 'q=— must match the em dashes in the books');
            const bareQuote = await axios.get(`${BASE}/api/search`, { params: { q: '"', limit: 1 }, validateStatus: () => true });
            assert(bareQuote.data.total_matches > 5000, 'q=" must match straight AND curly quotes (folded)');
            // 1-2 character ASCII queries stay gated.
            const ab = await axios.get(`${BASE}/api/search`, { params: { q: 'ab', limit: 1 }, validateStatus: () => true });
            assert.strictEqual(ab.data.total_matches, 0, 'q=ab stays empty (min-3 gate, ASCII-only exemption)');

            // (f) Regex mode: a literal " compiles unchanged (it always did —
            //     the min-3 gate was what swallowed it), and phrase syntax
            //     is OFF in regex mode (quotes are pattern characters).
            const rq = await axios.get(`${BASE}/api/search`, { params: { q: '"', useRegex: 'true', limit: 1 }, validateStatus: () => true });
            assert.strictEqual(rq.status, 200);
            assert.strictEqual(rq.data.search_mode, 'regex');
            // Straight-quote regex pin. Was 2,590; DOC-017 non-Latin strip
            // can drop a quote glued to a script-noise crumb (…ж").
            // Now 1,848: the 230-overlay batch swapped base transcripts for
            // re-ASR text carrying fewer straight quotes (files_count stayed 18).
            assert.strictEqual(rq.data.total_matches, 1848);
            assert.strictEqual(rq.data.files_count, 18);
            const rqw = await axios.get(`${BASE}/api/search`, { params: { q: '"\\w+"', useRegex: 'true', limit: 1 }, validateStatus: () => true });
            assert.strictEqual(rqw.status, 200);
            assert(rqw.data.total_matches > 0, 'regex containing a literal quote compiles and matches');

            // (g) Unicode word boundaries: multi-char diacritic words keep
            //     their exact pre-change counts. Was 137; the #20 glued-space
            //     fix splits `naïveWestern` (power_vs_force) into `naïve
            //     Western`, revealing one more whole-word `naïve` (138).
            const naive = await axios.get(`${BASE}/api/search`, { params: { q: 'naïve', limit: 1 }, validateStatus: () => true });
            assert.strictEqual(naive.data.total_matches, 138, 'naïve count 138 after #20 naïveWestern split (was 137)');
            assert.strictEqual(naive.data.files_count, 17);

            console.log('✅ phrase mode + phrase_match_count + cap flag; hybrid phrases; apostrophe folding; short punctuation queries; regex quote; Unicode boundaries');
        }

        // 15. Load-time ingest hygiene (DOC-010/#11, DOC-013/#14 separator
        //     subset, DOC-014/#15, DOC-015/#16, DOC-016/#17): every load path
        //     (lectures, books, extra sources, overlays) runs
        //     cleanIngestArtifacts, so /api/read and /api/search serve text
        //     without ingest banners, PDF whitespace artifacts, encoding
        //     damage, or Korean Hangul subtitle interleaves — without
        //     touching the read-only data files. (Unit fixtures + API-level
        //     pins; the per-document corpus sweep lives in test 12.)
        {
            const { cleanIngestArtifacts, nonLatinShare, NON_LATIN_SHARE_WARN } = require('./lecture-text');
            // (a) Unit fixtures: [name, input, expected output].
            const wordCount = (t) => t.split(/\s+/).filter(Boolean).length;
            const cases = [
                ['filename banner line dropped', '====_A_Map_of_Consciousness_enxautogen_html_====\nReal content.', 'Real content.'],
                ['OCR timestamp banner dropped', 'before\n==== 1516166162759553064_0 ====\nafter', 'before\nafter'],
                ['truncated-title header dropped', '    ====_Letting Go_ the Pathway of Sur_====\nALSO BY THE AUTHOR', 'ALSO BY THE AUTHOR'],
                ['PDF separator-rule line dropped', 'one\n____________________________\ntwo', 'one\ntwo'],
                ['asterisk scene break preserved', 'one\n***\ntwo', 'one\n***\ntwo'],
                ['4+ newline runs collapse', 'a\n\n\n\n\nb', 'a\n\nb'],
                ['lone-space blank lines collapse', 'a\n \n \nb', 'a\n\nb'],
                ['adjacent interior space runs collapse', 'a    b    c', 'a b c'],
                ['leading indentation preserved', '    Indented verse line', '    Indented verse line'],
                ['entities decode', 'M&amp;Ms &quot;quoted&quot; &lt;text&gt;', 'M&Ms "quoted" <text>'],
                ['VT becomes newline, noise control stripped', 'a\x0Bb\x07c', 'a\nbc'],
                ['U+FFFD dropped', 'bad\ufffdly decoded', 'badly decoded'],
                ['Latin-1 mojibake decodes', 'CafÃ© au lait', 'Café au lait'],
                ['Korean subtitle sentence stripped (DOC-016)',
                    'handled with reason and logic. 이성과 논리로서 접근되어야만 합니다. Faith and reason.',
                    'handled with reason and logic. Faith and reason.'],
                ['inline Korean gloss stripped (DOC-016)', 'Charm, 매력. I got it right.', 'Charm, I got it right.'],
                ['CJK crumb stripped (DOC-017)', 'perhaps taught by so 핑 hoggy too', 'perhaps taught by so hoggy too'],
                ['Cyrillic crumb stripped (DOC-017)', 'i see ощущas next', 'i see as next'],
                ['dot filler collapsed (DOC-017)', 'wait....really', 'wait really'],
                ['glossary calibrated (DOC-017)', 'The collaborated level of Consciousness is key.', 'The calibrated level of Consciousness is key.'],
                ['clean text is a no-op', 'The quick brown fox jumps.', 'The quick brown fox jumps.']
            ];
            cases.forEach(([name, input, expected]) => {
                const got = cleanIngestArtifacts(input);
                assert.strictEqual(got, expected, `${name}: got ${JSON.stringify(got)}`);
            });
            console.log(`✅ cleanIngestArtifacts unit fixtures (${cases.length} cases)`);
            // (b) Hygiene must never eat real content: a marker-free passage
            //     keeps its exact word count.
            const passage = 'Consciousness is the fundamental reality.\n\nThe experiencer is not separate from the experience.';
            assert.strictEqual(wordCount(cleanIngestArtifacts(passage)), wordCount(passage), 'word count must be preserved on clean text');
            console.log('✅ hygiene preserves word count on clean text');

            // (c) API pins: the ==== banners are gone from search AND read.
            const markerSearch = await axios.get(`${BASE}/api/search`, {
                params: { q: '====', limit: 5 }, validateStatus: () => true, timeout: 10000 });
            assert.strictEqual(markerSearch.status, 200, 'search for ==== should be 200');
            assert.strictEqual(markerSearch.data.total_matches, 0, `searching for ==== must find nothing (got ${markerSearch.data.total_matches})`);
            console.log('✅ /api/search?q===== → 0 matches (banners gone from search)');

            // (d) DOC-015 done-when: the mojibake "CafÃ©" now decodes, so a
            //     search for the CORRECT spelling finds Truth vs. Falsehood.
            //     (Also exercises the Unicode-aware whole-word boundaries:
            //     ASCII \b can never match a word ENDING in é.)
            const cafeSearch = await axios.get(`${BASE}/api/search`, {
                params: { q: 'Café', limit: 10 }, validateStatus: () => true, timeout: 10000 });
            assert.strictEqual(cafeSearch.status, 200, 'search for Café should be 200');
            assert(cafeSearch.data.total_matches >= 1, 'searching for "Café" must now match (mojibake decoded)');
            assert(cafeSearch.data.results.some((r) => r.path === 'truth_vs_falsehood'),
                `expected truth_vs_falsehood among Café matches, got ${(cafeSearch.data.results || []).map((r) => r.path).join(', ')}`);
            const cafeLower = await axios.get(`${BASE}/api/search`, {
                params: { q: 'café', limit: 10 }, validateStatus: () => true, timeout: 10000 });
            assert.strictEqual(cafeLower.status, 200, 'search for café should be 200');
            assert(cafeLower.data.total_matches >= 1, 'case-insensitive matching must survive the accent');
            console.log(`✅ /api/search?q=Café matches ${cafeSearch.data.files_count} file(s) incl. truth_vs_falsehood (mojibake decoded + Unicode word boundaries)`);

            // (e) Regression pin: letting_go's truncated-title banner is gone
            //     from /api/read, and the heavy-marker OCR extra is clean.
            const lg = await axios.get(`${BASE}/api/read/letting_go__the_pathway_of_sur`, { validateStatus: () => true, timeout: 10000 });
            assert.strictEqual(lg.status, 200, 'letting_go should be readable');
            assert(!lg.data.content.includes('===='), 'letting_go banner must be stripped from /api/read');
            assert(lg.data.content.length > 100000, `letting_go body must survive hygiene (got ${lg.data.content.length} chars)`);
            const ocr = await axios.get(`${BASE}/api/read/Book_of_Slides_discord_ocr`, { validateStatus: () => true, timeout: 10000 });
            assert.strictEqual(ocr.status, 200, 'Book_of_Slides_discord_ocr should be readable');
            assert(!ocr.data.content.includes('===='), 'OCR banner separators must be stripped from /api/read');
            assert(ocr.data.content.length > 10000, `OCR body must survive hygiene (got ${ocr.data.content.length} chars)`);
            console.log('✅ /api/read: letting_go + Book_of_Slides_discord_ocr banners stripped, bodies intact');

            // (f) DOC-016: Korean Hangul subtitle interleaves stripped from the
            //     four Sedona Seminar Dec 2008 parts; nonLatinShare() flags
            //     docs above the 0.5% ingest threshold.
            const hangulRe = /[\u1100-\u11FF\u3130-\u318F\uAC00-\uD7A3]/;
            const sedonaKeys = [
                'A_Unique_Sedona_Seminar_Dec_2008_Part_1_enxautogen_html',
                'A_Unique_Sedona_Seminar_Dec_2008_Part_2_enxautogen_html',
                'A_Unique_Sedona_Seminar_Dec_2008_Part_3_enxautogen_html',
                'A_Unique_Sedona_Seminar_Dec_2008_Part_4_enxautogen_html'
            ];
            for (const key of sedonaKeys) {
                const r = await axios.get(`${BASE}/api/read/${encodeURIComponent(key)}`, { validateStatus: () => true, timeout: 10000 });
                assert.strictEqual(r.status, 200, `${key} should be readable`);
                assert(!hangulRe.test(r.data.content), `${key} must contain no Hangul after ingest strip`);
                assert(nonLatinShare(r.data.content) <= NON_LATIN_SHARE_WARN,
                    `${key} non-Latin share ${(nonLatinShare(r.data.content) * 100).toFixed(2)}% must be <= 0.5%`);
                assert(r.data.content.length > 10000, `${key} English body must survive strip (got ${r.data.content.length})`);
            }
            console.log('✅ /api/read: Sedona Dec 2008 Parts 1–4 have no Hangul; non-Latin share ≤ 0.5%');

            // nonLatinShare metric mirrors the DOC-016 audit (Hangul chars / doc length).
            const contaminated = 'English. 이성과 논리로서 접근되어야만 합니다. More English.';
            assert(nonLatinShare(contaminated) > NON_LATIN_SHARE_WARN, 'contaminated fixture must exceed 0.5%');
            assert.strictEqual(nonLatinShare(cleanIngestArtifacts(contaminated)), 0, 'strip must drive non-Latin share to 0');
            assert.strictEqual(nonLatinShare('Pure English only.'), 0, 'Latin-only text has 0 non-Latin share');
            console.log('✅ nonLatinShare ingest-time language check (0.5% threshold)');

            // (g) DOC-018: transcript normalisation — every lecture is in the
            //     period-density band OR tagged raw_asr with word-count chunks;
            //     Audible platform lines stripped; curly quotes folded on
            //     lecture/overlay path; meta exposed on /api/read + /api/files.
            const {
                foldQuoteVariants, stripAudibleBoilerplate,
                chunkByWordCount, describeTranscriptNormalisation,
                NORMALISATION_VERSION, PERIOD_DENSITY_MIN,
                PERIOD_DENSITY_MAX, RAW_ASR_WORD_CHUNK
            } = require('./lecture-text');

            assert.strictEqual(foldQuoteVariants('isn\u2019t \u201Cyes\u201D \u2014 no'), "isn't \"yes\" - no",
                'curly quotes/dashes must fold to straight');
            assert.strictEqual(
                stripAudibleBoilerplate('This is Audible. [gentle music] Welcome to Satsang.\nBody.\nAudible hopes you have enjoyed this program.'),
                'Welcome to Satsang.\nBody.',
                'Audible intro/outro must strip, content kept'
            );
            assert(/audible voice/.test(stripAudibleBoilerplate('I speak in an audible voice today.')),
                'lowercase "audible voice" must be preserved');
            const chunks = chunkByWordCount('one two three four five six', 2);
            assert.strictEqual(chunks.length, 3, 'chunkByWordCount should emit 3 size-2 chunks');
            assert.strictEqual(chunks[0].wordCount, 2);
            assert.strictEqual(chunks[0].text, 'one two');
            assert.strictEqual(chunks[2].text, 'five six');
            const rawMeta = describeTranscriptNormalisation('word '.repeat(500)); // ~0 periods
            assert.strictEqual(rawMeta.transcriptTag, 'raw_asr');
            assert(Array.isArray(rawMeta.chunks) && rawMeta.chunks.length >= 2, 'raw_asr must expose word chunks');
            assert.strictEqual(rawMeta.normalisationVersion, NORMALISATION_VERSION);
            const punctuated = 'Hello world this is a longer sentence for density checks. '.repeat(40);
            const okMeta = describeTranscriptNormalisation(punctuated);
            assert.strictEqual(okMeta.transcriptTag, 'normal');
            assert(okMeta.inBand, 'punctuated fixture must be in band');
            assert(!okMeta.chunks, 'normal lectures do not carry chunks');
            console.log('✅ DOC-018 unit fixtures (fold, Audible, density tag, chunks)');

            const files = await axios.get(`${BASE}/api/files`, { validateStatus: () => true, timeout: 10000 });
            assert.strictEqual(files.status, 200);
            assert.strictEqual(files.data.transcript_normalisation.version, NORMALISATION_VERSION);
            assert.deepStrictEqual(files.data.transcript_normalisation.period_density_band,
                [PERIOD_DENSITY_MIN, PERIOD_DENSITY_MAX]);
            const rawKeys = files.data.transcript_normalisation.raw_asr;
            assert(Array.isArray(rawKeys), 'raw_asr list required');
            assert(rawKeys.length >= 1, 'corpus must still have some raw_asr lectures');
            console.log(`✅ /api/files transcript_normalisation: ${rawKeys.length} raw_asr`);

            // Exhaustive: loadLectureTexts meta (no extra HTTP), then pin API for one raw + one normal.
            const { loadLectureTexts } = require('./lecture-text');
            const loaded = loadLectureTexts(path.join(__dirname, 'html'));
            assert.strictEqual(loaded.normalisationVersion, NORMALISATION_VERSION);
            let outside = 0;
            for (const [k, meta] of Object.entries(loaded.lectureMeta)) {
                const ok = meta.inBand || (meta.transcriptTag === 'raw_asr' && Array.isArray(meta.chunks) && meta.chunks.length > 0);
                if (!ok) outside++;
                assert.strictEqual(meta.normalisationVersion, NORMALISATION_VERSION, k);
                if (meta.transcriptTag === 'raw_asr') {
                    assert(meta.periodDensity < PERIOD_DENSITY_MIN, `${k} raw_asr density`);
                    assert(meta.chunks.every((c) => c.wordCount <= RAW_ASR_WORD_CHUNK), `${k} chunk size`);
                } else {
                    assert(meta.inBand, `${k} must be in band when not raw_asr (density=${meta.periodDensity})`);
                }
            }
            assert.strictEqual(outside, 0, 'every lecture must be in-band or raw_asr+chunks');
            assert.strictEqual(loaded.rawAsrCount, rawKeys.length, 'files list must match loadLectureTexts raw_asr count');
            console.log(`✅ DOC-018 corpus: ${loaded.rawCount} lectures all in-band or raw_asr+chunks (${loaded.rawAsrCount} raw_asr)`);

            const rawKey = rawKeys[0];
            const rawRead = await axios.get(`${BASE}/api/read/${encodeURIComponent(rawKey)}`, {
                validateStatus: () => true, timeout: 15000 });
            assert.strictEqual(rawRead.status, 200);
            assert.strictEqual(rawRead.data.transcriptTag, 'raw_asr');
            assert.strictEqual(rawRead.data.normalisationVersion, NORMALISATION_VERSION);
            assert(Array.isArray(rawRead.data.chunks) && rawRead.data.chunks.length >= 1, 'raw_asr /api/read must include chunks');
            assert.strictEqual(rawRead.data.chunks[0].index, 0);
            assert(rawRead.data.chunks[0].text.length > 0);

            const normalKey = 'Satsang_Series_Volume_IX_Part_5_enxautogen_html';
            const normalRead = await axios.get(`${BASE}/api/read/${encodeURIComponent(normalKey)}`, {
                validateStatus: () => true, timeout: 15000 });
            assert.strictEqual(normalRead.status, 200);
            assert.strictEqual(normalRead.data.transcriptTag, 'normal');
            assert(normalRead.data.periodDensity >= PERIOD_DENSITY_MIN);
            assert.strictEqual(normalRead.data.chunks, undefined, 'normal lectures omit chunks');

            // Audible platform chrome gone from known intros/outros.
            for (const k of [
                'satsang_june_2010',
                'Satsang_Series_Volume_II_Part_1_enxautogen_html',
                'Satsang_Series_Volume_IX_Part_6_enxautogen_html'
            ]) {
                const r = await axios.get(`${BASE}/api/read/${encodeURIComponent(k)}`, {
                    validateStatus: () => true, timeout: 15000 });
                assert.strictEqual(r.status, 200, k);
                assert(!/This is Audible/i.test(r.data.content), `${k} Audible intro must be stripped`);
                assert(!/Audible hopes you/i.test(r.data.content), `${k} Audible outro must be stripped`);
            }
            // False-positive guard: medical "audible voice" Q&A survives.
            const voice = await axios.get(`${BASE}/api/read/${encodeURIComponent('Handling_Spiritual_Challenges_Apr_2010_Part_3_enxautogen_html')}`, {
                validateStatus: () => true, timeout: 15000 });
            assert.strictEqual(voice.status, 200);
            assert(/audible voice/i.test(voice.data.content), 'non-platform "audible voice" must remain');
            console.log('✅ DOC-018 /api/read meta + Audible strip pins');
        }


        // --- DOC-004: stopword-only queries name the ignored terms ---
        {
            const ofOnly = await axios.get(`${BASE}/api/search?q=of&limit=5`, { validateStatus: () => true });
            assert.strictEqual(ofOnly.status, 200, 'q=of should be 200');
            assert.strictEqual(ofOnly.data.total_matches, 0, 'q=of is stopword-only');
            assert(Array.isArray(ofOnly.data.ignored_terms) && ofOnly.data.ignored_terms.includes('of'),
                'ignored_terms must name "of"');
            assert(/stop words/i.test(ofOnly.data.notice || ''), 'notice should explain stop words');
            // "and" is NOT a stop word — must still return hits (regression pin).
            const andQ = await axios.get(`${BASE}/api/search?q=and&limit=5`, { validateStatus: () => true });
            assert.strictEqual(andQ.status, 200, 'q=and should be 200');
            assert(!andQ.data.ignored_terms, 'q=and must not report ignored_terms');
            assert(andQ.data.total_matches > 0, 'q=and is searchable (not a stop word)');
            const ofBadFilter = await axios.get(
                `${BASE}/api/search?q=of&filter=nonexistent-filter&limit=5`,
                { validateStatus: () => true }
            );
            assert.strictEqual(ofBadFilter.status, 400, 'q=of + invalid filter must be 400 (not stopword empty)');
            assert(Array.isArray(ofBadFilter.data.valid_filters), 'valid_filters listed on short+bad filter');
            console.log('✅ DOC-004: stopword-only → ignored_terms; q=and still matches; filter-before-short-gate');
        }

        // --- DOC-005: digit-bearing tokens match under default wholeWords=true ---
        // ==== timestamp banners (20241228_HHMMSS) are stripped by DOC-010 hygiene;
        // pin a DVD timestamp that remains in Book_of_Slides_phone_ocr body text.
        {
            const digDefault = await axios.get(`${BASE}/api/search?q=01010900&limit=5`, { validateStatus: () => true });
            assert.strictEqual(digDefault.status, 200, 'q=01010900 should be 200');
            assert(digDefault.data.total_matches > 0,
                'q=01010900 must match under default wholeWords=true');
            assert.strictEqual(digDefault.data.options.wholeWords, true, 'default wholeWords stays true');
            console.log(`✅ DOC-005: q=01010900 → ${digDefault.data.total_matches} matches with default wholeWords`);
        }

        // --- DOC-009: invalid filter → 400; Book of Slides in all-hawkins-books ---
        {
            const badFilter = await axios.get(
                `${BASE}/api/search?q=consciousness&filter=nonexistent-filter&limit=5`,
                { validateStatus: () => true }
            );
            assert.strictEqual(badFilter.status, 400, 'invalid filter must be 400 (not silent empty)');
            assert(/Invalid filter/.test(badFilter.data.error || ''), '400 body should say Invalid filter');
            assert(Array.isArray(badFilter.data.valid_filters), 'valid_filters must be listed');
            for (const expected of ['all', 'books', 'all-hawkins-books', 'lectures']) {
                assert(badFilter.data.valid_filters.includes(expected), `valid_filters must include ${expected}`);
            }
            const exact = await axios.get(
                `${BASE}/api/search?q=consciousness&filter=letting_go__the_pathway_of_sur&limit=5`,
                { validateStatus: () => true }
            );
            assert.strictEqual(exact.status, 200, 'exact source-key filter should be 200');
            assert(exact.data.total_matches > 0, 'exact source-key filter should find hits');

            // 01010900 lives in Book_of_Slides_phone_ocr — must be reachable via hawkins filter.
            const slideHit = await axios.get(
                `${BASE}/api/search?q=01010900&filter=all-hawkins-books&limit=20`,
                { validateStatus: () => true }
            );
            assert.strictEqual(slideHit.status, 200, 'slides-via-hawkins search should be 200');
            assert(slideHit.data.total_matches > 0,
                'all-hawkins-books must include Book of Slides (01010900 lives only there)');
            const slidePaths = new Set((slideHit.data.results || []).map((r) => r.path));
            assert([...slidePaths].some((p) => /Book_of_Slides/.test(p)),
                'hawkins results must include a Book_of_Slides_* path');
            console.log(`✅ DOC-009: invalid filter → 400; all-hawkins-books includes Book of Slides`);
        }

        // --- DOC-012: publisher/platform boilerplate stripper ---
        {
            const { loadCleanText, stripPublisherBoilerplate } = require('./lecture-text');
            const boilerCases = [
                ['Audible intro+outro stripped',
                    "Body.\nThis is Audible. [gentle music] Welcome to Dr. David R. Hawkins' 2010 Satsang series.\nTalk.\nAudible hopes you have enjoyed this program.\n",
                    'Body.\nTalk.\n\n'],
                ['Hay House promo block stripped',
                    'Front.\nEnjoy uplifting personal stories, how-to articles and healing advice along with videos and empowering quotes within Heal Your Life.\n\nHave an uplifting story to tell and a passion for writing? Sharpen your writing skills with insider tips from Your Writing Life.\n\nSign Up\n\nNow! Get inspired!\nVisit www.hayhouse.com to sign-up today\nChapter 1 body.',
                    'Front.\n\nChapter 1 body.'],
                ['URL and email tokens stripped (DOC-066 collapses the gap)',
                    'Contact info@hayhouse.com or visit www.example.com for more.\nReal sentence.',
                    'Contact or visit for more.\nReal sentence.']
            ];
            boilerCases.forEach(([name, input, expected]) => {
                const got = loadCleanText(input);
                assert.strictEqual(got, expected, `${name}: got ${JSON.stringify(got)}`);
            });
            // Chapter 1 body unchanged vs ingest-only clean for letting_go.
            const lg = await axios.get(`${BASE}/api/read/letting_go__the_pathway_of_sur`, { validateStatus: () => true, timeout: 10000 });
            assert.strictEqual(lg.status, 200, 'letting_go should be readable for DOC-012 pin');
            const lgRaw = lg.data.content;
            const ch1 = lgRaw.search(/CHAPTER\s+1\b/i);
            assert(ch1 >= 0, 'letting_go must still expose CHAPTER 1');
            assert(/chapter\s+1\b/i.test(lgRaw.slice(ch1, ch1 + 80)), 'CHAPTER 1 heading survives DOC-012');
            // Search pins: publisher URLs / Audible chrome are gone.
            // useRegex so multi-word queries are not keyword-expanded
            // ("This is Audible" as keywords matches thousands of groups).
            for (const q of ['hayhouse\\.com', 'This is Audible', 'info@hayhouse\\.com', 'Audible hopes you have enjoyed']) {
                const r = await axios.get(`${BASE}/api/search`, {
                    params: { q, useRegex: true, limit: 5 }, validateStatus: () => true, timeout: 10000 });
                assert.strictEqual(r.status, 200, `regex search ${q} should be 200`);
                assert.strictEqual(r.data.total_matches, 0, `regex ${q} must find nothing after DOC-012 (got ${r.data.total_matches})`);
            }
            console.log('✅ DOC-012: Audible/Hay House/URL/email boilerplate stripped; chapter 1 intact; search pins clean');
            // stripPublisherBoilerplate is a no-op on already-clean text.
            assert.strictEqual(stripPublisherBoilerplate('Pure chapter body.'), 'Pure chapter body.');
        }


        // --- DOC-013: running headers / page numbers (chrome-cluster only) ---
        {
            const { loadCleanText, stripRunningChrome } = require('./lecture-text');
            // Bare digits next to BoS chrome + trailing-dash crumbs drop; body stays.
            const sample = [
                'Body before.',
                'DAVID R. HAWKINS, M.D., PH.D.',
                '197',
                '196-',
                'BOOK OF SLIDES',
                '© The Institute for Spiritual Research, Inc. dba Veritas Publishing',
                '- Author: Susan Hawkins',
                'REAL CONTENT HERE.',
                'Body after.'
            ].join('\n');
            const got = loadCleanText(sample);
            assert.strictEqual(got, 'Body before.\nREAL CONTENT HERE.\nBody after.',
                `DOC-013 fixture strip failed: ${JSON.stringify(got)}`);
            // Structural CHAPTER headings + numbers survive (no chrome nearby).
            const chapters = Array.from({ length: 10 }, (_, i) => `CHAPTER\n\n${i + 1}\n\nBody ${i + 1}.`).join('\n');
            const chOut = stripRunningChrome(chapters);
            assert.strictEqual((chOut.match(/^CHAPTER$/mg) || []).length, 10, 'CHAPTER headings must survive DOC-013');
            for (let i = 1; i <= 10; i++) {
                assert(new RegExp(`^CHAPTER\\n\\n${i}\\n\\nBody ${i}\\.`, 'm').test(chOut),
                    `CHAPTER ${i} number must survive DOC-013`);
            }
            // Lone bare digits WITHOUT chrome are calibration/table values — keep.
            assert.strictEqual(stripRunningChrome('Para.\n\n197\n\nNext.'), 'Para.\n\n197\n\nNext.');
            assert.strictEqual(
                stripRunningChrome('Born-again Christians\n\n350\n\nChristian Science\n\n410'),
                'Born-again Christians\n\n350\n\nChristian Science\n\n410',
                'calibration table values must survive DOC-013');
            // Live pin: phone OCR loses BoS chrome; continuous read.
            const phone = await axios.get(`${BASE}/api/read/Book_of_Slides_phone_ocr`, { validateStatus: () => true, timeout: 15000 });
            assert.strictEqual(phone.status, 200, 'Book_of_Slides_phone_ocr should be readable');
            const pc = phone.data.content || '';
            assert(!/^DAVID R\. HAWKINS, M\.D\., PH\.D\.[-–—.\s]*$/im.test(pc), 'running author header must not survive');
            assert(!/^BOOK OF SLIDES[-–—.\s]*$/im.test(pc), 'BOOK OF SLIDES running title must not survive');
            assert(!/©\s*The Institute for Spiritual Research/i.test(pc), 'Veritas footer chrome must not survive');
            assert(!/^\d{1,4}\s*[-–—]\s*$/m.test(pc), 'trailing-dash OCR page crumbs must not survive');
            // Negative pin: TVF calibration tables keep standalone values.
            const tvf = await axios.get(`${BASE}/api/read/truth_vs_falsehood`, { validateStatus: () => true, timeout: 20000 });
            assert.strictEqual(tvf.status, 200, 'truth_vs_falsehood should be readable');
            const tvfContent = tvf.data.content || '';
            const born = tvfContent.search(/Born-again Christians/i);
            assert(born >= 0, 'TVF must still mention Born-again Christians');
            const afterBorn = tvfContent.slice(born, born + 80);
            assert(/\b350\b/.test(afterBorn), `TVF calibration value 350 must survive near Born-again Christians; got ${JSON.stringify(afterBorn)}`);
            const sears = tvfContent.search(/Sears, Roebuck \(catalog era\)/i);
            assert(sears >= 0, 'TVF must still mention Sears, Roebuck (catalog era)');
            assert(/\b350\b/.test(tvfContent.slice(sears, sears + 80)), 'TVF Sears calibration 350 must survive');
            // discovery: Jakob Bohm / 500
            const disc = await axios.get(`${BASE}/api/read/discovery_of_the_presence_of_g`, { validateStatus: () => true, timeout: 20000 });
            assert.strictEqual(disc.status, 200, 'discovery_of_the_presence_of_g should be readable');
            const discContent = disc.data.content || '';
            const bohm = discContent.search(/Bohm,\s*Jakob/i);
            assert(bohm >= 0, 'discovery must still mention Bohm, Jakob');
            assert(/\b500\b/.test(discContent.slice(bohm, bohm + 60)), 'discovery Bohm calibration 500 must survive');
            const bareDigits = (tvfContent.match(/^\d{1,4}$/mg) || []).length;
            assert(bareDigits > 800, `TVF should keep ~885 table digits (got ${bareDigits})`);
            console.log(`✅ DOC-013: BoS chrome stripped; TVF/discovery calibration tables intact (tvf bare digits=${bareDigits})`);
        }

        // --- DOC-017: non-Latin ASR noise + glossary ---
        {
            const noiseRe = /[\u0400-\u04FF\u0600-\u06FF\u3040-\u30FF\u3400-\u4DBF\u4E00-\u9FFF\uAC00-\uD7A3\uF900-\uFAFF]/;
            const pins = [
                'Thought_and_Ideation_Feb_2004_Part_2_enxautogen_html',
                'Thought_and_Ideation_Feb_2004_Part_3_enxautogen_html',
                'Spiritual_Truth_vs_Spiritual_Fantasy_Jun_2006_Part_2_enxautogen_html',
                'Happiness_Apr_2009_Part_3_enxautogen_html',
                'Creation_vs_Evolution_Oct_2007_Part_1_enxautogen_html'
            ];
            for (const key of pins) {
                const r = await axios.get(`${BASE}/api/read/${encodeURIComponent(key)}`, { validateStatus: () => true, timeout: 10000 });
                assert.strictEqual(r.status, 200, `${key} should be readable`);
                assert(!noiseRe.test(r.data.content || ''), `${key} must have no CJK/Cyrillic/Hangul/Arabic after DOC-017`);
            }
            const badRe = await axios.get(`${BASE}/api/search`, {
                params: { q: 'collaborated level of Consciousness', useRegex: true, limit: 5 },
                validateStatus: () => true, timeout: 10000
            });
            assert.strictEqual(badRe.status, 200);
            assert.strictEqual(badRe.data.total_matches, 0, 'collaborated mis-hear must be glossary-fixed');
            console.log('✅ DOC-017: non-Latin script noise stripped on pin lectures; glossary calibrated');
        }

        // --- DOC-030: every document has a human-readable title ---
        {
            const files = await axios.get(`${BASE}/api/files`, { validateStatus: () => true, timeout: 10000 });
            assert.strictEqual(files.status, 200);
            const list = files.data.files || [];
            const names = files.data.names || {};
            assert.strictEqual(Object.keys(names).length, list.length,
                `names must cover every /api/files entry (got ${Object.keys(names).length}/${list.length})`);
            const bad = [];
            for (const f of list) {
                const title = names[f];
                if (!title) bad.push(`${f}: missing title`);
                else if (/enxautogen/i.test(title)) bad.push(`${f}: title still has enxautogen (${title})`);
                else if (title.includes('_')) bad.push(`${f}: title still has underscore (${title})`);
            }
            assert.strictEqual(bad.length, 0, `DOC-030 title problems:\n${bad.slice(0, 15).join('\n')}`);
            assert.strictEqual(names.letting_go__the_pathway_of_surrender, 'Letting Go: The Pathway of Surrender');
            const emo = 'Emotions_and_Sensations_Apr_2004_Part_2_enxautogen_html';
            assert.strictEqual(names[emo], 'Emotions and Sensations (Apr 2004), Part 2');
            const read = await axios.get(`${BASE}/api/read/${encodeURIComponent(emo)}`, { validateStatus: () => true, timeout: 10000 });
            assert.strictEqual(read.status, 200);
            assert.strictEqual(read.data.title, 'Emotions and Sensations (Apr 2004), Part 2');
            console.log(`✅ DOC-030: all ${list.length} /api/files entries have human titles; overrides + derived pins OK`);
        }

        // --- DOC-020: chapter extraction for previously empty/null-title books ---
        {
            const pins = [
                ['healing_and_recovery', 15, 'A Map of Consciousness'],
                ['dissolving_the_ego_realizing_', 11, 'NATURE OF THE EGO'],
                ['the_ego_is_not_the_real_you__w', 3, 'The Nature of the self (Ego/Mind)'],
                ['along_the_path_to_enlightenmen', 366, 'January 1'],
                ['daily_reflections_from_dr_dav', 366, 'January 1'],
                ['satsang_june_2010', 4, 'Session 1']
            ];
            for (const [key, minCount, firstTitle] of pins) {
                const r = await axios.get(`${BASE}/api/read/${encodeURIComponent(key)}`, { validateStatus: () => true, timeout: 20000 });
                assert.strictEqual(r.status, 200, `${key} readable`);
                const ch = r.data.chapters || [];
                assert(ch.length >= minCount, `${key} expected >= ${minCount} chapters, got ${ch.length}`);
                assert(ch.every((c) => c.title && String(c.title).trim()), `${key} has untitled chapters`);
                assert(ch.every((c, i) => i === 0 || c.offset > ch[i - 1].offset), `${key} offsets must increase`);
                if (firstTitle) assert.strictEqual(ch[0].title, firstTitle, `${key} first title`);
            }
            // Gloria gate: other Satsang_Series_* keys must not get hymn-hit "sessions".
            const viii = await axios.get(`${BASE}/api/read/Satsang_Series_Volume_VIII_Part_1_enxautogen_html`, { validateStatus: () => true, timeout: 15000 });
            assert.strictEqual(viii.status, 200);
            assert.strictEqual((viii.data.chapters || []).length, 0, 'Volume VIII must not get Gloria session chapters');
            console.log('✅ DOC-020: six previously empty/null-title docs now have titled, monotonic chapters');
        }


        // --- Copyright / © legal fluff strip ---
        {
            const { stripCopyrightFluff } = require('./lecture-text');
            const fixture = [
                'Body before.',
                '©The Institute for Spiritual Research, Inc. dba Veritus Publishing Eighty-four percent of the population transcends 10.',
                'Table © The Institute for Spiritual Research, Inc. dba Veritas Publishing From those who have been called enlightened.',
                'Copyright © 2024 by the David and Susan Hawkins Revocable Trust',
                'Copyright Page',
                'Copyright © Sri Ramanasramam, 1985 All rights reserved',
                'Copyright © 2020 Mooji Media Ltd. All Rights Reserved. No part of this recording may be reproduced without Mooji Media Ltd.\'s express consent.',
                'Founding President, Institute for Spiritual Research Sedona',
                'Sedona, AZ: Veritas Publishing. (Six 5-hour CD/DVDs.)',
                'a court case took place to establish copyright of the work.'
            ].join('\n');
            const out = stripCopyrightFluff(fixture);
            assert(!/©/.test(out), 'fixture must lose all © markers');
            assert(!/Copyright\s*©/i.test(out), 'fixture must lose Copyright ©');
            assert(!/Copyright Page/.test(out), 'TOC Copyright Page must go');
            assert(!/Mooji Media Ltd/i.test(out), 'Mooji legal block must go');
            assert(/Eighty-four percent of the population transcends 10/.test(out), 'glued body after Institute© must survive');
            assert(/From those who have been called enlightened/.test(out), 'glued body after Table© must survive');
            assert(/Founding President, Institute for Spiritual Research/.test(out), 'bio Institute mention must survive');
            assert(/Sedona, AZ: Veritas Publishing/.test(out), 'bibliographic Veritas must survive');
            assert(/establish copyright of the work/.test(out), 'substantive copyright prose must survive');

            // Live pin: evolution_of_consciousness glued Institute© + body
            const evo = await axios.get(`${BASE}/api/read/the_evolution_of_consciousness`, { validateStatus: () => true, timeout: 20000 });
            assert.strictEqual(evo.status, 200);
            assert(!/©/.test(evo.data.content), 'evo must have no © after strip');
            assert(!/Copyright\s*©/i.test(evo.data.content), 'evo must have no Copyright ©');
            assert(/Eighty-four percent of the population transcends 10/.test(evo.data.content), 'evo glued body must survive');

            // Live pin: Book_of_Slides_phone_ocr OCR-typo Institute footer
            const bos = await axios.get(`${BASE}/api/read/Book_of_Slides_phone_ocr`, { validateStatus: () => true, timeout: 20000 });
            assert.strictEqual(bos.status, 200);
            assert(!/\u00A9|©/.test(bos.data.content), 'BoS phone OCR must lose Institute © chrome');

            // Corpus-wide: no © left in /api/files sample via search for copyright symbol noise
            const circ = await axios.get(`${BASE}/api/search`, { params: { q: '©', limit: 5 }, validateStatus: () => true, timeout: 30000 });
            assert.strictEqual(circ.status, 200);
            const circHits = (circ.data.results || circ.data.matches || []).length;
            // Prefer total if exposed
            const circTotal = circ.data.total_matches ?? circ.data.total ?? circHits;
            assert.strictEqual(circTotal, 0, `search for © must be 0, got ${circTotal}`);

            const rights = await axios.get(`${BASE}/api/search`, { params: { q: '"All rights reserved"', limit: 5 }, validateStatus: () => true, timeout: 30000 });
            assert.strictEqual(rights.status, 200);
            const rightsTotal = rights.data.total_matches ?? rights.data.total ?? (rights.data.results || []).length;
            assert.strictEqual(rightsTotal, 0, `All rights reserved must be 0, got ${rightsTotal}`);

            console.log('✅ Copyright fluff: fixture + evo glue + corpus © / rights-reserved pins');
        }



        // --- DOC-011: full book slugs; legacy truncated keys still resolve ---
        {
            const { BOOK_KEY_ALIASES, resolveBookKey, loadBookTexts } = require('./lecture-text');
            const legacy = Object.keys(BOOK_KEY_ALIASES);
            assert.strictEqual(legacy.length, 16, 'expected 16 truncated book aliases');

            const loaded = loadBookTexts('html').the_json_obj_books;
            for (const [from, to] of Object.entries(BOOK_KEY_ALIASES)) {
                assert.strictEqual(resolveBookKey(from), to);
                assert.ok(loaded[to], `canonical book missing after load: ${to}`);
                assert.ok(!(from in loaded), `legacy truncated key must not remain loaded: ${from}`);
            }

            const files = await axios.get(`${BASE}/api/files`, { validateStatus: () => true, timeout: 20000 });
            assert.strictEqual(files.status, 200);
            const list = files.data.files || [];
            const names = files.data.names || {};
            const kinds = files.data.kinds || {};

            const truncInFiles = list.filter((f) => legacy.includes(f));
            assert.deepStrictEqual(truncInFiles, [], `truncated keys must not appear in /api/files: ${truncInFiles}`);
            for (const to of Object.values(BOOK_KEY_ALIASES)) {
                assert.ok(list.includes(to), `full slug missing from /api/files: ${to}`);
                assert.ok(names[to], `names missing for ${to}`);
                assert.ok(kinds[to], `kinds missing for ${to}`);
            }

            // Legacy truncated keys still resolve via alias on /api/read.
            const sampleLegacy = 'letting_go__the_pathway_of_sur';
            const sampleCanon = BOOK_KEY_ALIASES[sampleLegacy];
            const readLegacy = await axios.get(`${BASE}/api/read/${encodeURIComponent(sampleLegacy)}`, { validateStatus: () => true, timeout: 15000 });
            assert.strictEqual(readLegacy.status, 200, 'legacy truncated key must still resolve');
            assert.strictEqual(readLegacy.data.path, sampleCanon, 'legacy read path should report canonical slug');
            const readCanon = await axios.get(`${BASE}/api/read/${encodeURIComponent(sampleCanon)}`, { validateStatus: () => true, timeout: 15000 });
            assert.strictEqual(readCanon.status, 200);
            assert.strictEqual(readCanon.data.path, sampleCanon);

            const filterLegacy = await axios.get(
                `${BASE}/api/search?q=surrender&filter=${encodeURIComponent(sampleLegacy)}&limit=5`,
                { validateStatus: () => true, timeout: 20000 }
            );
            assert.strictEqual(filterLegacy.status, 200, 'exact filter by legacy truncated key must work');
            assert(filterLegacy.data.total_matches > 0, 'legacy filter should find hits');

            console.log('✅ DOC-011: no truncated book keys in /api/files; full slugs present; legacy aliases resolve');
        }

        // --- DOC-032: Dialogue Dec 2003 punctuation-split naming ---
        {
            const { loadLectureTexts, resolveLectureKey, LECTURE_KEY_ALIASES } = require('./lecture-text');
            const legacy = 'Dialogue_Questions_and_Answers_Dec_2003_Part_3';
            const canon = 'Dialogue,_Questions,_and_Answers_Dec_2003_Part_3_enxautogen_html';
            assert.strictEqual(resolveLectureKey(legacy), canon);
            assert.strictEqual(LECTURE_KEY_ALIASES[legacy], canon);

            const { lectures } = loadLectureTexts('html');
            const parts = Object.keys(lectures).filter((k) => /Dialogue.*Answers.*Dec_2003/i.test(k)).sort();
            assert.deepStrictEqual(parts, [
                'Dialogue,_Questions,_and_Answers_Dec_2003_Part_1_enxautogen_html',
                'Dialogue,_Questions,_and_Answers_Dec_2003_Part_2_enxautogen_html',
                'Dialogue,_Questions,_and_Answers_Dec_2003_Part_3_enxautogen_html'
            ], `Dialogue Dec 2003 parts must share one naming convention: ${JSON.stringify(parts)}`);
            assert(!(legacy in lectures), 'legacy Part_3 key must not remain in the lecture map');

            // Audit: no two lecture keys differ only by commas (ignore _enxautogen_html).
            const stem = (k) => k.replace(/_enxautogen_html$/i, '').replace(/,/g, '');
            const byStem = new Map();
            for (const k of Object.keys(lectures)) {
                const s = stem(k);
                if (!byStem.has(s)) byStem.set(s, []);
                byStem.get(s).push(k);
            }
            const splits = [...byStem.entries()].filter(([, v]) => v.length > 1);
            assert.strictEqual(splits.length, 0, `punctuation-split series remain: ${JSON.stringify(splits)}`);

            const files = await axios.get(`${BASE}/api/files`, { validateStatus: () => true, timeout: 20000 });
            assert.strictEqual(files.status, 200);
            const list = files.data.files || files.data.keys || Object.keys(files.data.names || {});
            assert(list.includes(canon), 'canonical Part_3 must appear in /api/files');
            assert(!list.includes(legacy), 'legacy Part_3 must not appear in /api/files');

            const readCanon = await axios.get(`${BASE}/api/read/${encodeURIComponent(canon)}`, { validateStatus: () => true, timeout: 15000 });
            assert.strictEqual(readCanon.status, 200);
            const readLegacy = await axios.get(`${BASE}/api/read/${encodeURIComponent(legacy)}`, { validateStatus: () => true, timeout: 15000 });
            assert.strictEqual(readLegacy.status, 200, 'legacy Part_3 key must still resolve via alias');
            assert.strictEqual(readLegacy.data.path, canon, 'legacy read path should report canonical key');

            console.log('✅ DOC-032: Dialogue Dec 2003 Parts 1–3 share one naming; legacy alias resolves; no other comma-splits');
        }

        // --- DOC-043: single-keyword ranking + no 1-word-over-2-word inversion ---
        // Same suite child (SEARCH_BUDGET_MS=20000). A second api.js corpus load
        // starved the regex quote pin under the default 2s budget.
        {
            const rankBase = BASE;
                const kinA = await axios.get(`${rankBase}/api/search?q=kinesiology&limit=30`, { validateStatus: () => true, timeout: 30000 });
                const kinB = await axios.get(`${rankBase}/api/search?q=kinesiology&limit=30`, { validateStatus: () => true, timeout: 30000 });
                assert.strictEqual(kinA.status, 200);
                assert.strictEqual(kinB.status, 200);
                assert(kinA.data.results.length >= 2, 'kinesiology should return multiple hits');
                const sig = (rows) => rows.map((r) => `${r.path}:${r.offset}:${r.score}`).join('|');
                assert.strictEqual(sig(kinA.data.results), sig(kinB.data.results), 'repeat searches must keep identical order');

                const ego = await axios.get(`${rankBase}/api/search?q=ego%20surrender&limit=1000`, { validateStatus: () => true, timeout: 30000 });
                assert.strictEqual(ego.status, 200);
                const byMc = new Map();
                for (const r of ego.data.results) {
                    const mc = r.match_count;
                    if (!byMc.has(mc)) byMc.set(mc, []);
                    byMc.get(mc).push(r.score);
                    if (r.match_count === 1) {
                        assert(r.score < 6, `mc:1 score ${r.score} must sit below the mc:2 floor`);
                    }
                }
                assert(byMc.has(2), `ego surrender should include mc:2 groups, got ${[...byMc.keys()]}`);
                if (byMc.has(1)) {
                    const max1 = Math.max(...byMc.get(1));
                    const min2 = Math.min(...byMc.get(2));
                    assert(max1 < min2, `mc:1 score ${max1} must not outrank mc:2 score ${min2}`);
                } else {
                    assert(ego.data.results.every((r) => r.match_count >= 2), 'first page must not put mc:1 above mc:2');
                }

                const cons = await axios.get(`${rankBase}/api/search?q=consciousness&limit=1000`, { validateStatus: () => true, timeout: 30000 });
                assert.strictEqual(cons.status, 200);
                assert(!cons.data.truncated, 'consciousness ranking scan must finish within SEARCH_BUDGET_MS');
                const consScores = new Set(cons.data.results.map((r) => r.score));
                assert(consScores.size > 1, `consciousness scores must vary, got ${consScores.size} unique`);
                const uniqueOrder = [];
                const totalPages = Math.max(1, cons.data.total_pages || 1);
                for (let page = 1; page <= Math.min(totalPages, 10) && uniqueOrder.length < 10; page++) {
                    const chunk = page === 1
                        ? cons
                        : await axios.get(`${rankBase}/api/search?q=consciousness&limit=1000&page=${page}`, { validateStatus: () => true, timeout: 30000 });
                    assert.strictEqual(chunk.status, 200);
                    for (const r of chunk.data.results) {
                        if (!uniqueOrder.includes(r.path)) uniqueOrder.push(r.path);
                        if (uniqueOrder.length >= 10) break;
                    }
                }
                assert(uniqueOrder.length >= 10, `need ≥10 unique docs in score order, got ${uniqueOrder.length}`);
                const top10 = uniqueOrder.slice(0, 10);
                const rest = uniqueOrder.slice(10, 20);
                const totals = {};
                for (const p of [...top10, ...rest]) {
                    const one = await axios.get(
                        `${rankBase}/api/search?q=consciousness&filter=${encodeURIComponent(p)}&limit=1`,
                        { validateStatus: () => true, timeout: 20000 }
                    );
                    assert.strictEqual(one.status, 200, `filter=${p} should be 200`);
                    totals[p] = one.data.total_matches;
                }
                for (let i = 0; i < top10.length - 1; i++) {
                    assert(
                        totals[top10[i]] >= totals[top10[i + 1]],
                        `top docs must be density-ordered: ${top10[i]}=${totals[top10[i]]} vs ${top10[i + 1]}=${totals[top10[i + 1]]}`
                    );
                }
                if (rest.length) {
                    const minTop = Math.min(...top10.map((p) => totals[p]));
                    const maxRest = Math.max(...rest.map((p) => totals[p]));
                    assert(minTop >= maxRest, `top 10 density (${minTop}) must beat next docs (${maxRest})`);
                }
                console.log('✅ DOC-043: keyword scores vary; density ranks single-word; mc:1 never outranks mc:2; order is deterministic');
        }

        {
            // DOC-042: wrong-method and unknown /api/* must be JSON, not Express HTML.
            const jsonHeaders = (res) => String(res.headers['content-type'] || '').includes('application/json');
            const isHtmlErrorPage = (res) => {
                const body = typeof res.data === 'string' ? res.data : JSON.stringify(res.data || '');
                return /Cannot (GET|POST|PUT|PATCH|DELETE) [/]api/i.test(body) || /text[/]html/i.test(String(res.headers['content-type'] || ''));
            };

            const ragGet = await axios.get(`${BASE}/api/rag`, { validateStatus: () => true });
            assert.strictEqual(ragGet.status, 405, 'GET /api/rag (POST-only) should be 405, not Express 404 HTML');
            assert(jsonHeaders(ragGet), `GET /api/rag content-type should be JSON, got ${ragGet.headers['content-type']}`);
            assert(!isHtmlErrorPage(ragGet), 'GET /api/rag must not be the Express HTML error page');
            assert.strictEqual(typeof ragGet.data, 'object');
            assert.ok(ragGet.data.error, '405 body should include error');
            assert.strictEqual(ragGet.data.docs, '/api/docs');
            const ragAllow = String(ragGet.headers.allow || '');
            assert(ragAllow.split(',').map((s) => s.trim()).includes('POST'), `Allow should list POST, got ${ragAllow}`);

            const searchPost = await axios.post(`${BASE}/api/search`, { q: 'ego' }, { validateStatus: () => true });
            assert.strictEqual(searchPost.status, 405, 'POST /api/search should be 405 JSON');
            assert(jsonHeaders(searchPost), `POST /api/search content-type should be JSON, got ${searchPost.headers['content-type']}`);
            assert(!isHtmlErrorPage(searchPost), 'POST /api/search must not be Express HTML');
            assert.strictEqual(searchPost.data.docs, '/api/docs');
            const searchAllow = String(searchPost.headers.allow || '');
            assert(searchAllow.split(',').map((s) => s.trim()).includes('GET'), `Allow should list GET, got ${searchAllow}`);

            const unknown = await axios.get(`${BASE}/api/zzz`, { validateStatus: () => true });
            assert.strictEqual(unknown.status, 404, 'unknown /api/* should be 404');
            assert(jsonHeaders(unknown), `unknown /api/* content-type should be JSON, got ${unknown.headers['content-type']}`);
            assert(!isHtmlErrorPage(unknown), 'unknown /api/* must not be Express HTML');
            assert.strictEqual(typeof unknown.data, 'object');
            assert.ok(unknown.data.error, '404 body should include error');
            assert.strictEqual(unknown.data.docs, '/api/docs');

            const options = await axios.options(`${BASE}/api/search`, {
                headers: { Origin: 'https://example.com', 'Access-Control-Request-Method': 'GET' },
                validateStatus: () => true
            });
            assert.strictEqual(options.status, 204, 'CORS preflight OPTIONS /api/search must stay 204');
            assert.ok(options.headers['access-control-allow-origin'], 'preflight should keep CORS headers');

            console.log('✅ DOC-042: /api/* wrong-method is 405 JSON with Allow; unknown path is 404 JSON; OPTIONS unchanged');
        }

        // --- DOC-045: unified search result schema across modes ---
        {
            const CORE = ['path', 'title', 'kind', 'offset', 'match_text', 'snippet', 'score', 'proximity', 'match_count', 'doc_match_count'];
            const keysOf = (r) => Object.keys(r).sort();
            const assertCore = (r, label) => {
                for (const k of CORE) {
                    assert(k in r, `${label} missing ${k}; keys=${keysOf(r)}`);
                }
                assert(Number.isInteger(r.match_count) && r.match_count >= 1, `${label} match_count`);
            };

            const bookKey = 'letting_go__the_pathway_of_surrender';
            const bookRead = await axios.get(`${BASE}/api/read/${encodeURIComponent(bookKey)}`, { validateStatus: () => true, timeout: 15000 });
            assert.strictEqual(bookRead.status, 200);
            assert((bookRead.data.chapters || []).length > 0, `${bookKey} must have parsed chapters`);

            const kw = await axios.get(
                `${BASE}/api/search?q=ego&filter=${encodeURIComponent(bookKey)}&limit=8`,
                { validateStatus: () => true, timeout: 30000 }
            );
            const phrase = await axios.get(
                `${BASE}/api/search?q=${encodeURIComponent('"letting go"')}&filter=${encodeURIComponent(bookKey)}&limit=8`,
                { validateStatus: () => true, timeout: 30000 }
            );
            const regex = await axios.get(
                `${BASE}/api/search?q=ego&useRegex=true&filter=${encodeURIComponent(bookKey)}&limit=8`,
                { validateStatus: () => true, timeout: 30000 }
            );
            assert.strictEqual(kw.status, 200);
            assert.strictEqual(phrase.status, 200);
            assert.strictEqual(regex.status, 200);
            assert(kw.data.results.length > 0, 'keyword book hits');
            assert(phrase.data.results.length > 0, 'phrase book hits');
            assert(regex.data.results.length > 0, 'regex book hits');
            assert.strictEqual(kw.data.search_mode, 'keywords');
            assert.strictEqual(phrase.data.search_mode, 'phrase');
            assert.strictEqual(regex.data.search_mode, 'regex');

            for (const [label, res] of [['keywords', kw], ['phrase', phrase], ['regex', regex]]) {
                for (const r of res.data.results) {
                    assertCore(r, `${label} ${r.path}`);
                    assert('chapter' in r, `${label} book result must include chapter`);
                    assert(r.chapter === null || (typeof r.chapter === 'string' && /^Chapter /.test(r.chapter)), `${label} chapter shape: ${r.chapter}`);
                }
                assert.deepStrictEqual(keysOf(res.data.results[0]), keysOf(kw.data.results[0]), `${label} key set must match keywords`);
            }
            assert.strictEqual(phrase.data.results[0].match_count, 1, 'phrase match_count is 1 per occurrence');
            assert.strictEqual(regex.data.results[0].match_count, 1, 'regex match_count is 1 per match');

            const lectures = await axios.get(
                `${BASE}/api/search?q=ego&filter=lectures&limit=8`,
                { validateStatus: () => true, timeout: 30000 }
            );
            assert.strictEqual(lectures.status, 200);
            assert(lectures.data.results.length > 0, 'lecture hits');
            for (const r of lectures.data.results) {
                assertCore(r, `lecture ${r.path}`);
                assert(!('chapter' in r), `lecture must omit chapter; keys=${keysOf(r)}`);
            }
            console.log('✅ DOC-045: keyword/phrase/regex share one result key set; offset rejected');
        }

        // --- DOC-044: per-document match aggregate ---
        {
            const bookKey = 'letting_go__the_pathway_of_surrender';
            const kw = await axios.get(
                `${BASE}/api/search?q=ego&filter=${encodeURIComponent(bookKey)}&limit=8`,
                { validateStatus: () => true, timeout: 30000 }
            );
            assert.strictEqual(kw.status, 200);
            assert(kw.data.results.length > 0, 'keyword book hits');
            assert.strictEqual(kw.data.files_count, 1);
            assert.strictEqual(kw.data.doc_counts.length, 1);
            assert.strictEqual(kw.data.doc_counts[0].path, bookKey);
            assert.strictEqual(kw.data.doc_counts[0].doc_match_count, kw.data.total_matches);
            for (const r of kw.data.results) {
                assert.strictEqual(r.doc_match_count, kw.data.total_matches, 'entry total equals filter total_matches');
                assert(r.doc_match_count > r.match_count || r.doc_match_count >= 1, 'doc_match_count is a document total');
            }

            const page = await axios.get(
                `${BASE}/api/search?q=consciousness&limit=5`,
                { validateStatus: () => true, timeout: 60000 }
            );
            assert.strictEqual(page.status, 200);
            assert(!page.data.truncated, 'consciousness keyword should scan the corpus');
            assert(page.data.doc_counts.length > 10, 'doc_counts lists documents beyond this page');
            assert.strictEqual(page.data.doc_counts.length, page.data.files_count);
            for (let i = 1; i < page.data.doc_counts.length; i++) {
                const a = page.data.doc_counts[i - 1];
                const b = page.data.doc_counts[i];
                assert(
                    a.doc_match_count > b.doc_match_count
                    || (a.doc_match_count === b.doc_match_count && a.path <= b.path),
                    `doc_counts not ranked: ${a.path}=${a.doc_match_count} vs ${b.path}=${b.doc_match_count}`
                );
            }
            const top = page.data.doc_counts[0];
            assert(top.doc_match_count >= page.data.doc_counts[page.data.doc_counts.length - 1].doc_match_count);
            const probe = await axios.get(
                `${BASE}/api/search?q=consciousness&filter=${encodeURIComponent(top.path)}&limit=1`,
                { validateStatus: () => true, timeout: 30000 }
            );
            assert.strictEqual(probe.status, 200);
            assert.strictEqual(top.doc_match_count, probe.data.total_matches, 'doc_counts matches filter=path total_matches');
            for (const r of page.data.results) {
                const row = page.data.doc_counts.find((d) => d.path === r.path);
                assert(row, `doc_counts missing ${r.path}`);
                assert.strictEqual(r.doc_match_count, row.doc_match_count);
            }

            const phrase = await axios.get(
                `${BASE}/api/search?q=${encodeURIComponent('"letting go"')}&filter=${encodeURIComponent(bookKey)}&limit=3`,
                { validateStatus: () => true, timeout: 30000 }
            );
            assert.strictEqual(phrase.status, 200);
            assert(phrase.data.results.length > 0);
            assert.strictEqual(phrase.data.results[0].match_count, 1);
            assert.strictEqual(phrase.data.results[0].doc_match_count, phrase.data.total_matches);
            console.log('✅ DOC-044: doc_match_count is the document total; doc_counts ranks without paging');
        }

        // --- DOC-041: search results carry title and kind ---
        {
            const files = await axios.get(`${BASE}/api/files`, { validateStatus: () => true });
            assert.strictEqual(files.status, 200);
            const names = files.data.names;
            const kinds = files.data.kinds;
            const BOOK_KINDS = new Set(['hawkins_book', 'reference', 'slides_ocr']);

            const ego = await axios.get(`${BASE}/api/search?q=ego&limit=5`, {
                validateStatus: () => true, timeout: 30000
            });
            assert.strictEqual(ego.status, 200);
            assert(ego.data.results.length > 0, 'ego hits');
            for (const r of ego.data.results) {
                assert.strictEqual(typeof r.title, 'string', `title type ${r.path}`);
                assert(r.title.length > 0, `empty title for ${r.path}`);
                assert.strictEqual(r.title, names[r.path], `title must match /api/files names[${r.path}]`);
                assert.strictEqual(typeof r.kind, 'string', `kind type ${r.path}`);
                assert.strictEqual(r.kind, kinds[r.path], `kind must match /api/files kinds[${r.path}]`);
            }

            const bookKey = 'letting_go__the_pathway_of_surrender';
            const book = await axios.get(
                `${BASE}/api/search?q=ego&filter=${encodeURIComponent(bookKey)}&limit=3`,
                { validateStatus: () => true, timeout: 30000 }
            );
            assert.strictEqual(book.status, 200);
            assert(book.data.results.length > 0);
            for (const r of book.data.results) {
                assert(r.title.length > 0);
                assert(BOOK_KINDS.has(r.kind), `book kind ${r.kind}`);
                assert.strictEqual(r.kind, kinds[bookKey]);
            }

            const lectures = await axios.get(`${BASE}/api/search?q=ego&filter=lectures&limit=3`, {
                validateStatus: () => true, timeout: 30000
            });
            assert.strictEqual(lectures.status, 200);
            assert(lectures.data.results.length > 0);
            for (const r of lectures.data.results) {
                assert(r.title.length > 0, `lecture title ${r.path}`);
                assert.strictEqual(r.kind, kinds[r.path]);
            }
            console.log('✅ DOC-041: search results carry title and kind (no /api/files join)');
        }

        console.log('\n--- All API Bug-Fix Tests Passed Successfully ---');
    } finally {
        child.kill('SIGTERM');
    }
}

runTests().catch((err) => {
    console.error('\n❌ API Bug-Fix Test Suite Failed:');
    console.error(err.message);
    if (err.response) console.error(err.response.status, JSON.stringify(err.response.data).slice(0, 300));
    child.kill('SIGTERM');
    process.exit(1);
});
