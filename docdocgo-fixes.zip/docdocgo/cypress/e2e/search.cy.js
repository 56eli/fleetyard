describe('DocDocGo Search UI', () => {
  beforeEach(() => {
    // /se/ is login-gated. Mint a session for the seeded captain via
    // /api/test-login (only available when the api runs with AUTH_TEST_MODE=1 —
    // the test stack, never production).
    cy.request({ url: '/api/test-login?user_id=1298076640043073548', failOnStatusCode: false });
    cy.visit('/se/');
  });

  it('successfully loads the search page', () => {
    cy.get('h1').should('contain', 'Enhanced DRH Search');
    cy.get('#searchInput').should('be.visible');
    cy.get('#maxResultsInput').should('have.attr', 'max', '1000');
    cy.get('#filterSelect option').should('have.length', 4);
    cy.get('#sourceInput').should('be.visible');
    cy.get('#readSource').should('be.visible').and('not.have.attr', 'href');
    cy.get('#sourceList option', { timeout: 10000 }).should('have.length.at.least', 20);
    cy.get('#sourceList option').then(($opts) => {
      const vals = [...$opts].map((o) => o.value);
      expect(vals, 'typeahead uses catalog titles').to.include('Power vs. Force');
      expect(vals).to.include('I AM THAT (Nisargadatta Maharaj)');
      expect(vals.some((v) => /hidden de/i.test(v)), 'no truncated keys').to.be.false;
    });
    cy.contains('pick a title in Only this and click Read');
    cy.get('body').should('not.contain', 'RAG Vector Search');
  });

  // DOC-007 / DOC-040: client gate matches /api/search — pure ASCII 1–2
  // char queries stay blocked; punctuation / non-ASCII short queries pass.
  it('enforces 3-character minimum for pure ASCII queries only', () => {
    cy.get('#searchInput', { timeout: 10000 }).should('be.visible').type('ab');
    cy.get('#searchButton').click();
    cy.get('.message').should('contain', 'Please enter at least 3 characters');
  });

  it('allows short punctuation / non-ASCII queries past the client gate', () => {
    // Bare quote: client must NOT show the 3-char message. Older APIs may
    // still return 0 results; after #39 they return matches. Either way the
    // gate must not reject the query client-side.
    cy.get('#searchInput', { timeout: 10000 }).should('be.visible').type('"');
    cy.get('#searchButton').click();
    // Wait until Searching… settles into either results or a final message.
    cy.get('.results-count, .message', { timeout: 20000 }).should(($el) => {
      const t = $el.text();
      expect(t).not.to.match(/^Searching/i);
      expect(t, 'must not hard-gate short punctuation').not.to.include('at least 3 characters');
    });
  });

  it('finds a 3-character core term', () => {
    cy.get('#searchInput').type('ego');
    cy.get('#searchButton').click();
    cy.get('.results-count').should('be.visible');
    cy.get('.results-count').invoke('text').should((t) => {
      const n = Number((String(t).match(/Found (\d+)/) || [])[1]);
      expect(n, 'ego total is more than the default 100-result window').to.be.gt(100);
    });
    cy.get('.card').should('have.length.at.least', 1);
  });

  it('filters by source (Books)', () => {
    // Wait for populating filters to finish
    cy.get('#filterSelect').should('be.visible');
    // Ensure filter options are loaded
    cy.get('#filterSelect option').should('have.length', 4);
    
    // Select "Books Only"
    cy.get('#filterSelect').select('books');

    cy.get('#searchInput').type('consciousness');
    cy.get('#searchButton').click();
    
    cy.get('.results-count').should('be.visible');
    cy.get('.results-count').invoke('text').should('match', /result[s]?/).and('not.contain', 'result(es)');
    cy.get('.card').should('have.length.at.least', 1);
    cy.get('.file-name a').first()
      .should('have.attr', 'href')
      .and('include', '?read=');
    cy.get('.file-name a').first().invoke('text').should('not.match', /enxautogen/i);
    cy.get('.card').first().should('not.contain', 'Relevance Score');
    cy.get('.card').first().find('.file-name a').should('be.visible');
  });

  it('filters by Hawkins Books Only', () => {
    cy.get('#filterSelect').should('be.visible');
    cy.get('#filterSelect option').should('have.length', 4);
    
    // Select "Hawkins Books Only"
    cy.get('#filterSelect').select('all-hawkins-books');

    cy.get('#searchInput').type('consciousness');
    cy.get('#searchButton').click();
    
    cy.get('.results-count').should('be.visible');
    cy.get('.card').should('have.length.at.least', 1);

    // Verify no non-Hawkins books appear in results
    cy.get('.file-name').each(($el) => {
      const text = $el.text();
      expect(text).not.to.include('ACIM');
      expect(text).not.to.include('Lamsa');
      expect(text).not.to.include('I_AM_THAT');
      expect(text).not.to.include('Be_as_you_are');
    });
  });

  it('handles "no results found" gracefully', () => {
    cy.get('#searchInput').type('xyzqwe123'); // Unlikely query
    cy.get('#searchButton').click();
    cy.get('.message').should('contain', 'No results found');
  });

  it('copies a readable source name, not the raw filename', () => {
    cy.window().then((win) => {
      cy.stub(win.navigator.clipboard, 'writeText').resolves().as('copied');
    });
    cy.get('#searchInput').type('ego');
    cy.get('#searchButton').click();
    cy.get('.card.hit').first().should('be.visible');
    cy.contains('.card.hit .copy-btn', /^Copy$/).first().click();
    cy.get('@copied').should('have.been.calledOnce');
    cy.get('@copied').its('firstCall.args.0').then((text) => {
      const src = String(text).split('\n').find((l) => l.startsWith('Source: '));
      expect(src, 'copy includes a Source line').to.match(/^Source: /);
      expect(src).not.to.match(/enxautogen/i);
      expect(src).not.to.match(/_/);
    });
  });

  it('shows a source title instead of a relevance score', () => {
    cy.get('#searchInput').type('ego consciousness');
    cy.get('#searchButton').click();
    cy.get('.results-count').should('be.visible');
    cy.get('.card').first().within(() => {
      cy.get('.file-name a').should('be.visible').and('not.contain', 'Source:');
      cy.get('.relevance-score').should('not.exist');
    });
    cy.contains('Relevance Score').should('not.exist');
  });
    
  it('respects "Whole words only" during highlighting', () => {
    cy.get('#searchInput').type('thoughts');
    cy.get('#wholeWords').check();
    cy.get('#searchButton').click();
    
    cy.get('.card').first().within(() => {
        // "thoughts" should be highlighted as a word, but not inside larger words (if any)
        cy.get('mark').each(($el) => {
            cy.wrap($el).invoke('text').should('match', /^thoughts$/i);
        });
    });
  });

  it('narrows to one source from the typeahead', () => {
    cy.get('#sourceList option', { timeout: 10000 }).should('have.length.at.least', 20);
    cy.visit('/se/?q=ego&filter=power_vs_force__the_hidden_de');
    cy.get('#sourceInput').invoke('val').should('match', /power vs force/i);
    cy.get('#filterSelect').should('have.value', 'all');
    cy.get('.results-count').should('be.visible');
    cy.get('.file-name a').should('have.length.at.least', 1);
    cy.get('.file-name a').each(($el) => {
      expect($el.text().toLowerCase()).to.match(/power vs force/);
    });
  });

  it('writes the query into the URL and restores it', () => {
    cy.get('#searchInput').type('healing');
    cy.get('#searchButton').click();
    cy.get('.results-count').should('be.visible');
    cy.location('search').should('include', 'q=healing');

    cy.visit('/se/?q=consciousness&filter=books');
    cy.get('#searchInput').should('have.value', 'consciousness');
    cy.get('#filterSelect').should('have.value', 'books');
    cy.get('.results-count').should('be.visible');
  });

  it('opens a lecture with a way back to search', () => {
    cy.get('#searchInput').type('consciousness');
    cy.get('#searchButton').click();
    cy.get('.file-name a').first()
      .should('have.attr', 'href')
      .and('include', 'q=consciousness')
      .and('include', '#at-');
    cy.get('.file-name a').first().click();
    cy.location('search').should('include', 'read=').and('include', 'q=consciousness');
    cy.location('hash').should('match', /^#at-\d+$/);
    cy.get('.lecture-bar .back-link').should('be.visible').and('contain', 'Back to search');
    cy.get('.lecture-bar .back-link').should('have.attr', 'href').and('include', 'q=consciousness');
    cy.get('.search-container').should('not.be.visible');
    cy.get('.lecture-body #at', { timeout: 15000 }).should('exist').and('have.attr', 'aria-current', 'location');
    cy.get('.lecture-body mark').should('have.length.at.least', 2);
    cy.get('.lecture-nav').should('contain', 'of');
    cy.get('.lecture-hint').should('contain', 'Esc');
    cy.location('hash').then((h1) => {
      cy.get('.lecture-nav button[aria-label="Next match"]').click();
      cy.get('.lecture-body #at').should('exist').and('have.attr', 'aria-current', 'location');
      cy.location('hash').should('match', /^#at-\d+$/).and('not.eq', h1);
    });
    cy.get('body').trigger('keydown', { key: 'Escape' });
    cy.location('search').should('include', 'q=consciousness').and('not.include', 'read=');
    cy.get('#searchInput').should('be.visible').and('have.value', 'consciousness');
  });

  it('highlights only the whole search word in the lecture', () => {
    cy.get('#searchInput').type('ego');
    cy.get('#searchButton').click();
    cy.get('.file-name a').first().click();
    cy.get('.lecture-body mark', { timeout: 15000 }).should('have.length.at.least', 1);
    cy.get('.lecture-body mark').each(($el) => {
      const el = $el[0];
      expect(el.textContent, 'mark is the query').to.match(/^ego$/i);
      const prev = el.previousSibling && el.previousSibling.textContent;
      const next = el.nextSibling && el.nextSibling.textContent;
      if (prev) expect(prev.slice(-1), 'no prefix like egotistical').not.to.match(/\w/);
      if (next) expect(next[0], 'no suffix like egoic').not.to.match(/\w/);
    });
  });

  it('returns to the same place in the results after reading', () => {
    cy.get('#searchInput').type('ego');
    cy.get('#searchButton').click();
    cy.get('.card.hit').should('have.length.at.least', 8);
    cy.get('.card.hit').eq(7).scrollIntoView();
    cy.get('.card.hit').eq(7).find('.file-name a').click();
    cy.get('.lecture-bar .back-link').should('be.visible').click();
    cy.get('.results-count').should('be.visible');
    cy.get('.card.hit').should('have.length.at.least', 8);
    cy.window().its('scrollY').should('be.gt', 200);
  });

  it('opens a book from Only this without a search term', () => {
    cy.get('#sourceList option', { timeout: 10000 }).should('have.length.at.least', 20);
    cy.get('#sourceList option').then(($opts) => {
      const hit = [...$opts].find((o) => /power vs force/i.test(o.value));
      expect(hit, 'Power vs Force is in the typeahead').to.exist;
      cy.get('#sourceInput').invoke('val', hit.value).trigger('input');
    });
    cy.get('#readSource')
      .should('have.attr', 'href')
      .and('include', 'read=')
      .and('include', 'power_vs_force');
    cy.get('#readSource').click();
    cy.location('search').should('include', 'read=').and('not.include', 'q=');
    cy.get('.lecture-bar .back-link').should('be.visible');
    cy.get('.search-container').should('not.be.visible');
    cy.get('.lecture-body', { timeout: 15000 }).should('be.visible');
    cy.contains('h3', 'Power vs. Force').should('be.visible');
    cy.contains('h3', /hidden de/i).should('not.exist');
    cy.get('#lectureFind').should('be.visible').and('not.be.disabled');
  });

  it('finds a word inside an opened book', () => {
    cy.get('#sourceList option', { timeout: 10000 }).should('have.length.at.least', 20);
    cy.get('#sourceList option').then(($opts) => {
      const hit = [...$opts].find((o) => /power vs force/i.test(o.value));
      expect(hit, 'Power vs Force is in the typeahead').to.exist;
      cy.get('#sourceInput').invoke('val', hit.value).trigger('input');
    });
    cy.get('#readSource').click();
    cy.get('.lecture-body', { timeout: 15000 }).should('be.visible');
    cy.get('#lectureFind').should('be.visible').and('not.be.disabled').type('ego');
    cy.get('.lecture-find button[type="submit"]').click();
    cy.location('search').should('include', 'q=ego').and('include', 'read=');
    cy.get('.lecture-body mark', { timeout: 15000 }).should('have.length.at.least', 1);
    cy.get('.lecture-body #at').should('have.attr', 'aria-current', 'location');
    cy.get('#lectureFind').should('have.value', 'ego');
    cy.contains(/matches for "ego"/i).should('be.visible');
    cy.get('.lecture-nav').should('contain', 'of');
  });

  it('jumps to a chapter in an opened book', () => {
    cy.get('#sourceList option', { timeout: 10000 }).should('have.length.at.least', 20);
    cy.get('#sourceList option').then(($opts) => {
      const hit = [...$opts].find((o) => /power vs force/i.test(o.value));
      expect(hit, 'Power vs Force is in the typeahead').to.exist;
      cy.get('#sourceInput').invoke('val', hit.value).trigger('input');
    });
    cy.get('#readSource').click();
    cy.get('.lecture-body', { timeout: 15000 }).should('be.visible');
    cy.get('#lectureChapters').should('be.visible');
    cy.get('#lectureChapters option').should('have.length.at.least', 10);
    cy.get('#lectureChapters option').eq(4).then(($opt) => {
      const off = $opt.val();
      cy.get('#lectureChapters').select(off);
      cy.location('hash').should('eq', '#at-' + off);
    });
    cy.get('.lecture-body #at').should('have.attr', 'aria-current', 'location');
  });

  it('opens a shared quote into the lecture at that passage', () => {
    cy.visit('/se/?read=Worry,_Fear,_and_Anxiety_enxautogen_html#q-alleviating%20human%20suffer-80');
    cy.contains('Shared quote:').should('be.visible');
    cy.contains('alleviating human suffering').should('be.visible');
    cy.get('.search-container').should('not.be.visible');
    cy.get('.lecture-bar .back-link').should('be.visible');
    cy.contains('a', 'Read full lecture')
      .should('have.attr', 'href')
      .and('include', '?read=')
      .and('match', /#at-\d+/);
    cy.contains('a', 'Read full lecture').then(($a) => {
      cy.visit($a.prop('href'));
    });
    cy.location('hash').should('match', /^#at-\d+$/);
    cy.get('.lecture-body #at', { timeout: 15000 }).should('exist')
      .and('have.attr', 'aria-current', 'location')
      .and('contain', 'alleviating human suffering');
    cy.get('.search-container').should('not.be.visible');
  });

  it('steps to the next part of a multi-part lecture', () => {
    cy.visit('/se/?read=Spiritual_Traps_Oct_2005_Part_1_enxautogen_html');
    cy.get('.lecture-body', { timeout: 15000 }).should('be.visible');
    cy.get('.part-nav').should('be.visible').and('contain', 'Part 1 of 3');
    cy.get('.part-nav a').should('have.attr', 'href')
      .and('include', 'read=')
      .and('include', 'Part_2');
    cy.get('.part-nav a').click();
    cy.location('search').should('include', 'Part_2');
    cy.get('.lecture-body', { timeout: 15000 }).should('be.visible');
    cy.get('.part-nav').should('contain', 'Part 2 of 3');
    cy.get('.part-nav a').first().should('have.attr', 'href').and('include', 'Part_1');
    cy.get('.part-nav a').last().should('have.attr', 'href').and('include', 'Part_3');
  });

  it('reflows a run-together book into paragraphs', () => {
    cy.visit('/se/?read=I_AM_THAT');
    cy.get('.lecture-body', { timeout: 20000 }).should('be.visible');
    cy.get('.lecture-body').should('contain', 'Questioner:');
    cy.get('.lecture-body').invoke('text').should((t) => {
      const paras = String(t).split(/\n\n/).filter((p) => p.trim());
      expect(paras.length, 'I AM THAT is not one wall of text').to.be.gt(20);
    });
  });
});
