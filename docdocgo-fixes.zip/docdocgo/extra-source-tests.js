const assert = require('assert');
const path = require('path');
const fs = require('fs');
const { loadExtraSources, loadJsonDataSource, loadBookTexts, EXTRA_KEY_RE, duplicated14GramRatio } = require('./lecture-text');

let passed = 0;
let failed = 0;
function test(name, fn) {
    try { fn(); console.log(`  ✅ ${name}`); passed++; }
    catch (err) { console.log(`  ❌ ${name}`); console.log(`     ${err.message}`); failed++; }
}

console.log('\n--- extra-sources ---');

const extras = loadExtraSources();
const KEY = 'Book_of_Slides_Barret_notes';
const booksPath = path.join(__dirname, 'html', 'merged-book-texts_json_1.js');
const books = (loadJsonDataSource(booksPath, 'the_json_obj_books').the_json_obj_books) || {};

test('extra-sources keys are filename-safe', () => {
    for (const k of Object.keys(extras)) {
        assert.match(k, EXTRA_KEY_RE);
    }
});

test('an unloadable extra-source key fails loudly instead of silently skipping', () => {
    const os = require('os');
    const tmp = fs.mkdtempSync(require('path').join(os.tmpdir(), 'extras-bad-'));
    try {
        fs.writeFileSync(require('path').join(tmp, 'Bad_Key_&_Here.txt'), 'content');
        process.env.EXTRA_SOURCES_DIR = tmp;
        assert.throws(() => loadExtraSources(), /not loadable.*Bad_Key_&_Here/, 'bad-charset key must throw, not silently skip');
    } finally {
        delete process.env.EXTRA_SOURCES_DIR;
        fs.rmSync(tmp, { recursive: true, force: true });
    }
});

test('Book of Slides Barret notes is present and labeled as notes, not official OCR', () => {
    if (!fs.existsSync(path.join(__dirname, 'extra-sources', KEY + '.txt'))) {
        console.log('     (skip — extra-sources/ not mounted)');
        return;
    }
    assert.ok(extras[KEY], 'missing extra source');
    assert.ok(extras[KEY].includes('NOT the official'), extras[KEY].slice(0, 240));
    assert.ok(extras[KEY].split(/\s+/).length > 1000, 'notes too short');
    assert.ok(!/WEBVTT/.test(extras[KEY]));
});

test('extra sources do not overwrite existing book keys', () => {
    for (const k of Object.keys(extras)) {
        assert.ok(!Object.prototype.hasOwnProperty.call(books, k), `extra source collides with book key ${k}`);
    }
});

test('phone-photo OCR is destuttered and not typeset', () => {
    const k = 'Book_of_Slides_phone_ocr';
    if (!fs.existsSync(path.join(__dirname, 'extra-sources', k + '.txt'))) {
        console.log('     (skip — extra-sources/ not mounted)');
        return;
    }
    assert.ok(extras[k], 'missing phone ocr extra source');
    assert.ok(/not typeset/i.test(extras[k].slice(0, 400)), extras[k].slice(0, 200));
    assert.ok(extras[k].split(/\s+/).length > 50000, 'phone ocr too short');
    const love = (extras[k].match(/all I got is love/gi) || []).length;
    assert.ok(love <= 3, 'love-loop remains: ' + love);
    const n403 = (extras[k].match(/\b403\b/g) || []).length;
    assert.ok(n403 < 40, '403-loop remains: ' + n403);
    assert.ok(!/WEBVTT/.test(extras[k]));
});

test('existing book count stays 24', () => {
    assert.strictEqual(Object.keys(books).length, 24);
});

test('DOC-049: discord OCR Map of Consciousness keeps Enlightenment 700–1000 as a row', () => {
    const k = 'Book_of_Slides_discord_ocr';
    if (!fs.existsSync(path.join(__dirname, 'extra-sources', k + '.txt'))) {
        console.log('     (skip — extra-sources/ not mounted)');
        return;
    }
    const text = extras[k];
    assert.ok(text, 'missing discord ocr extra source');
    assert.ok(!/Self-view Is/.test(text), 'header still concatenated with first data row');
    assert.ok(!/Level Enlightenment/.test(text), 'Level column still ate Enlightenment');
    assert.match(text, /\|\s*God-view\s*\|\s*Self-view\s*\|\s*Level\s*\|\s*Log\s*\|\s*Emotion\s*\|\s*Process\s*\|/);
    assert.match(text, /\|\s*Self\s*\|\s*Is\s*\|\s*Enlightenment\s*\|\s*700-1,000\s*\|\s*Ineffable\s*\|\s*Pure Consciousness\s*\|/);
    const peace = text.match(/\|\s*Self\s*\|\s*Perfect\s*\|\s*Peace\s*\|\s*600\s*\|\s*Bliss\s*\|\s*Illumination\s*\|/);
    const enl = text.match(/\|\s*Self\s*\|\s*Is\s*\|\s*Enlightenment\s*\|\s*700-1,000\s*\|\s*Ineffable\s*\|\s*Pure Consciousness\s*\|/);
    assert.ok(peace && enl, 'Peace 600 and Enlightenment 700–1000 rows present');
    assert.ok(enl.index < peace.index, 'Enlightenment 700–1000 must precede Peace 600');
});

test('DOC-059 #97: discord truncated heading, lone Sli, HAWKING', () => {
    const k = 'Book_of_Slides_discord_ocr';
    const text = extras[k];
    assert.ok(text, 'missing discord ocr');
    assert.match(text, /It did not reach/);
    assert.ok(!/It did not reac\b/.test(text), 'truncated reac remains');
    assert.ok(!/^\s*Sli\s*$/m.test(text), 'lone Sli remains');
    assert.ok(!/HAWKING/.test(text), 'HAWKING remains');
    assert.match(text, /DAVID R\. HAWKINS/);
});

test('DOC-059 #97: Barret lite/pertection/Shame smash/hyphens/the I', () => {
    const text = extras[KEY];
    assert.ok(text, 'missing Barret notes');
    assert.ok(!/\byour lite\b/.test(text));
    assert.ok(!/\ball lite\b/.test(text));
    assert.ok(!/\bof lite\b/.test(text));
    assert.ok(!/pertection/.test(text));
    assert.ok(!/will occur it Shame/.test(text));
    assert.ok(!/wit-nessing/.test(text));
    assert.ok(!/omnip-otentiality/.test(text));
    assert.ok(!/posi-tion/.test(text));
    assert.ok(!/positional-ity/.test(text));
    assert.match(text, /Risking your life unnecessarily/);
    assert.match(text, /aware of the perfection/);
    assert.match(text, /will occur\. Shame is banishment/);
    assert.match(text, /If no intervention takes place/);
    assert.match(text, /Realization of the Self as the I/);
    assert.ok(!/and the T/.test(text));
});

test('DOC-059 #97: phone Allen/looksee/Keshma phrase-only', () => {
    const k = 'Book_of_Slides_phone_ocr';
    const text = extras[k];
    assert.ok(text, 'missing phone ocr');
    assert.ok(!/Allen Abduction/.test(text));
    assert.match(text, /Alien Abduction/);
    assert.ok(!/looksee/.test(text));
    assert.match(text, /You told, look, see things revealed even 25 to 30 years later/);
    assert.ok(!/diagnable/.test(text));
    assert.ok(!/explaination/.test(text));
    assert.ok(!/\barmier\b/.test(text));
    assert.ok(!/cmpulsion/.test(text));
    assert.ok(!/Keshma/.test(text));
    assert.ok(!/except though me/.test(text));
    assert.ok(!/The pre-ther populate/.test(text));
    assert.ok(!/Politize the specialness/.test(text));
    assert.match(text, /Lord Krishna/);
    assert.match(text, /except through me/);
    assert.match(text, /The predator populate/);
    assert.match(text, /Politicize the specialness/);
    assert.match(text, /programmable/);
    assert.match(text, /Conditioning depends/);
    // must-survive: not a global Politize/pre-ther rewrite of other words
    assert.match(text, /political world/);
});

test('DOC-056 #85: phone_ocr duplicated 14-grams collapse; unique blocks kept', () => {
    const k = 'Book_of_Slides_phone_ocr';
    const text = extras[k];
    assert.ok(text, 'missing phone ocr');
    const r = duplicated14GramRatio(text);
    assert.ok(r < 0.005, 'phone_ocr 14-gram dup ratio ' + r);
    const words = text.match(/\S+/g) || [];
    assert.ok(words.length > 50000, 'phone ocr too short after dedupe: ' + words.length);
    assert.ok(words.length < 190000, 'phone ocr did not shrink (~16%): ' + words.length);
    assert.match(text, /Alien Abduction/);
    assert.match(text, /Krishna/);
    for (const extra of Object.values(extras)) {
        const er = duplicated14GramRatio(extra);
        assert.ok(er < 0.005, 'extra 14-gram dup ratio ' + er);
    }
});

test('DOC-054: Barret notes hyphen/misspell remainder', () => {
    const text = extras[KEY];
    assert.ok(!/surender-ing/.test(text));
    assert.match(text, /surrendering/);
    assert.ok(!/spiritu-ally/.test(text));
    assert.match(text, /spiritually/);
    assert.ok(!/is caled,/.test(text));
    assert.match(text, /is called, classically, the Purusha/);
    assert.ok(!/theres practically/.test(text));
    assert.match(text, /there's practically nobody/);
});

test('DOC-054: phone OCR remainder (phrase-scoped Thane)', () => {
    const k = 'Book_of_Slides_phone_ocr';
    const text = extras[k];
    assert.ok(!/the affect I am the Way/.test(text));
    assert.match(text, /the effect I am the Way/);
    assert.ok(!/Consciousness Iself/.test(text));
    assert.match(text, /Consciousness Itself/);
    assert.ok(!/I surrender to Thane, O Lord/.test(text));
    assert.match(text, /I surrender to Thee, O Lord/);
    assert.ok(!/\bDvinity\b/.test(text));
    assert.match(text, /Divinity/);
    assert.ok(!/differeent/.test(text));
    assert.match(text, /to become different requires/);
    assert.ok(!/Dohng, The 430/.test(text));
    assert.match(text, /Tao, The 430/);
    assert.ok(!/\bauto-matic\b/.test(text));
    assert.match(text, /automatic consequence of truth/);
    assert.ok(!/thatthe/.test(text));
});

test('DOC-054: Power vs Force C HAPTER / fromthe / Man has', () => {
    const booksDir = path.join(__dirname, 'html');
    const cleaned = loadBookTexts(booksDir).the_json_obj_books;
    const pvf = cleaned.power_vs_force__the_hidden_determinants_of_human_behavior;
    assert.ok(pvf, 'missing power vs force');
    assert.strictEqual((pvf.match(/C HAPTER/g) || []).length, 0);
    assert.ok(!/E LEVEN/.test(pvf));
    assert.match(pvf, /CHAPTER ELEVEN/);
    assert.match(pvf, /Man has freedom of choice/);
    assert.ok(!/\bM an has/.test(pvf));
    assert.ok(!/fromthe/.test(pvf));
    assert.ok(!/bodymidline/.test(pvf));
    assert.match(pvf, /from the attempt/);
    assert.match(pvf, /body midline/);
    const acim = cleaned.ACIM_workbook;
    assert.ok(!/becaus you/.test(acim));
    assert.match(acim, /because you did not make it/);
    const heal = cleaned.healing_and_recovery;
    assert.ok(!/Peacer/.test(heal));
    assert.match(heal, /The Science of Peace/);
    const toc = cleaned.transcending_the_levels_of_consciousness;
    assert.ok(toc, 'missing transcending_the_levels_of_consciousness');
    assert.strictEqual((toc.match(/PLACT/g) || []).length, 0);
    assert.match(toc, /membership of the FACTNet web site/);
    assert.ok(!/\bmembership of PLACT web site\b/.test(toc));
});

console.log(`\nextra-source-tests: ${passed} passed, ${failed} failed`);
if (failed > 0) process.exit(1);
