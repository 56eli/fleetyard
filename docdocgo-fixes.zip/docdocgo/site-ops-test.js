// Request-level proofs for the site/ops issues (nginx/redirect/login/rate-limit):
//   #43 login Back link must not loop to sign-in (history.back, not href="/")
//   #23 no HTTPS->HTTP downgrade: X-Forwarded-Proto drives Secure session cookies
//   #27 /api/docs states the LIVE rate limit + retry guidance (not stale defaults)
//   #63 / DOC-038: HSTS, nosniff, X-Frame-Options, no x-powered-by, SESSION_SECRET fail-fast
//
// Runs in the repo's existing test style (axios + assert, no framework).
// Spawns its own api.js on port 3205.
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const axios = require('axios');
const assert = require('assert');

axios.defaults.httpAgent = new http.Agent({ keepAlive: false });

const TEST_PORT = 3205;
const BASE = `http://127.0.0.1:${TEST_PORT}`;
// Non-default values prove /api/docs reports live config, not hard-coded text.
const MAX = 7;
const WINDOW_MS = 120 * 1000;

let child;

function startServer() {
    const grantsFile = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'docdocgo-site-test-')), 'grants.json');
    child = spawn(process.execPath, ['api.js'], {
        cwd: path.join(__dirname),
        env: {
            ...process.env,
            PORT: String(TEST_PORT),
            GRANTS_FILE: grantsFile,
            AUTH_TEST_MODE: '1',
            RATE_LIMIT_MAX: String(MAX),
            RATE_LIMIT_WINDOW_MS: String(WINDOW_MS)
        },
        stdio: ['ignore', 'pipe', 'pipe']
    });
    child.stderr.on('data', (d) => process.stderr.write(`[child] ${d}`));
}

async function waitForHealth() {
    for (let i = 0; i < 60; i++) {
        try {
            const res = await axios.get(`${BASE}/api/health`, { validateStatus: () => true, timeout: 5000 });
            if (res.status === 200) return;
        } catch (e) { /* not up yet */ }
        await new Promise((r) => setTimeout(r, 1000));
    }
    throw new Error('api did not become ready');
}

async function runTests() {
    console.log('--- Site/Ops Issue Tests ---');
    startServer();
    try {
        await waitForHealth();
        console.log('Target server ready.');

        // #43: Back must use browser history — href="/" 301s to the gated
        // /se/, which bounces logged-out browsers back to /login (loop).
        const login = await axios.get(`${BASE}/login`, { validateStatus: () => true });
        assert.strictEqual(login.status, 200, '/login should be public');
        assert(login.data.includes('history.back()'), 'Back link should use browser history');
        assert(!login.data.includes('href="/"'), 'Back link must not point at / (sign-in loop)');
        console.log('✅ #43 /login Back uses history.back(), no href="/" loop');

        // #23: with X-Forwarded-Proto: https (what nginx now forwards from
        // Cloudflare) the session cookie must be Secure; over plain http
        // (local dev) it must still be set without Secure.
        const httpsLogin = await axios.get(`${BASE}/api/test-login?user_id=91001`, {
            headers: { 'X-Forwarded-Proto': 'https' },
            maxRedirects: 0,
            validateStatus: () => true
        });
        assert.strictEqual(httpsLogin.status, 200, 'test-login should succeed');
        const httpsCookie = (httpsLogin.headers['set-cookie'] || []).join('; ');
        assert(/Secure/i.test(httpsCookie), `https session cookie should be Secure (got ${httpsCookie})`);
        const httpLogin = await axios.get(`${BASE}/api/test-login?user_id=91002`, {
            maxRedirects: 0,
            validateStatus: () => true
        });
        const httpCookie = (httpLogin.headers['set-cookie'] || []).join('; ');
        assert(httpCookie.includes('docdocgo.sid'), 'http session cookie should still be set (local dev)');
        assert(!/Secure/i.test(httpCookie), 'http session cookie must not be Secure');
        console.log('✅ #23 Secure cookie on https proto, plain cookie on http');

        // #27: /api/docs must state the live limit + retry guidance.
        const docs = await axios.get(`${BASE}/api/docs`, { validateStatus: () => true });
        assert.strictEqual(docs.status, 200, '/api/docs should be 200');
        assert(docs.data.rate_limiting.limit.includes(`${MAX} requests per 2 minutes`),
            `/api/docs should state the live limit (got ${docs.data.rate_limiting.limit})`);
        assert(docs.data.rate_limiting.over_limit.includes('retry_after_seconds'),
            '/api/docs should tell clients to wait retry_after_seconds');
        assert(typeof docs.data.rate_limiting.internal_token === 'string'
            && /X-Internal-Token/.test(docs.data.rate_limiting.internal_token),
            '/api/docs should document the Friendbot/internal token exemption');
        console.log('✅ #27 /api/docs states live limits + retry guidance + internal token exemption');

        // #63 / DOC-038: security headers on HTML + API; no Express fingerprint.
        const headerPaths = ['/login', '/api/health'];
        for (const p of headerPaths) {
            const res = await axios.get(`${BASE}${p}`, { validateStatus: () => true });
            const h = res.headers;
            assert.strictEqual(h['x-content-type-options'], 'nosniff', `${p} nosniff`);
            assert.strictEqual(h['x-frame-options'], 'DENY', `${p} frame deny`);
            assert.ok(/max-age=31536000/.test(h['strict-transport-security'] || ''),
                `${p} HSTS (got ${h['strict-transport-security']})`);
            assert.strictEqual(h['x-powered-by'], undefined, `${p} must not send x-powered-by`);
        }
        console.log('✅ #63 nosniff + DENY + HSTS; no x-powered-by');

        const nginx = fs.readFileSync(path.join(__dirname, 'nginx.conf'), 'utf8');
        assert.ok(nginx.includes('Strict-Transport-Security'), 'nginx HSTS');
        assert.ok(nginx.includes('X-Content-Type-Options'), 'nginx nosniff');
        assert.ok(nginx.includes('X-Frame-Options'), 'nginx frame deny');
        console.log('✅ #63 nginx.conf security headers');

        console.log('\n--- All Site/Ops Issue Tests Passed Successfully ---');
    } finally {
        child.kill('SIGTERM');
    }

    // #63: production must refuse a missing SESSION_SECRET (loud startup).
    await new Promise((r) => setTimeout(r, 300));
    const env = { ...process.env, NODE_ENV: 'production', PORT: '3207' };
    delete env.SESSION_SECRET;
    const failChild = spawn(process.execPath, ['-e', "require('./auth')"], {
        cwd: __dirname,
        env,
        stdio: ['ignore', 'pipe', 'pipe']
    });
    const errChunks = [];
    failChild.stderr.on('data', (d) => errChunks.push(d));
    const code = await new Promise((resolve) => failChild.on('exit', resolve));
    const errText = Buffer.concat(errChunks).toString();
    assert.notStrictEqual(code, 0, 'prod without SESSION_SECRET must exit non-zero');
    assert.ok(/SESSION_SECRET must be set/.test(errText), `fail-fast message (got ${errText.slice(0, 400)})`);
    console.log('✅ #63 SESSION_SECRET fail-fast in production');

    // Live stack never set NODE_ENV, so fail-fast never fired. Pin the wiring.
    const compose = fs.readFileSync(path.join(__dirname, 'docker-compose.yml'), 'utf8');
    const apiEnv = compose.slice(compose.indexOf('  api:'), compose.indexOf('  rag:'));
    assert.ok(/NODE_ENV=production/.test(apiEnv), 'docker-compose api must set NODE_ENV=production');
    const dockerfile = fs.readFileSync(path.join(__dirname, 'Dockerfile'), 'utf8');
    const apiStage = dockerfile.slice(dockerfile.indexOf('AS api'));
    assert.ok(/ENV NODE_ENV=production/.test(apiStage), 'Dockerfile api stage must ENV NODE_ENV=production');
    const entry = fs.readFileSync(path.join(__dirname, 'entrypoint.sh'), 'utf8');
    assert.ok(/NODE_ENV=production/.test(entry), 'entrypoint.sh must default NODE_ENV=production');
    console.log('✅ #63 NODE_ENV=production wired in Dockerfile + compose + entrypoint');
}

runTests().catch((err) => {
    console.error('\n❌ Site/Ops Issue Test Suite Failed:');
    console.error(err.message);
    if (err.response) console.error(err.response.status, JSON.stringify(err.response.data).slice(0, 300));
    if (child) child.kill('SIGTERM');
    process.exit(1);
});
