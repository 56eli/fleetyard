'use strict';
const { parentPort, workerData } = require('worker_threads');
const { pattern, flags, texts, matchCap } = workerData;
const docs = [];
let remaining = matchCap;
for (const text of texts) {
    const matches = [];
    if (remaining > 0) {
        const local = new RegExp(pattern, flags);
        let m;
        while ((m = local.exec(text)) !== null) {
            matches.push({ index: m.index, text: m[0] });
            remaining--;
            if (remaining <= 0) break;
            if (m.index === local.lastIndex) local.lastIndex++;
        }
    }
    docs.push(matches);
}
parentPort.postMessage(docs);
