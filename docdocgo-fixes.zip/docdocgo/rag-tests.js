const axios = require('axios');
const assert = require('assert');

const RAG_HOST = process.env.RAG_HOST || '127.0.0.1';
const RAG_PORT = parseInt(process.env.RAG_PORT, 10) || 9432;
const BASE_URL = `http://${RAG_HOST}:${RAG_PORT}`;

async function runTests() {
    console.log('--- Starting RAG Endpoint Tests ---');
    console.log(`Targeting: ${BASE_URL}\n`);

    let passed = 0;
    let failed = 0;

    // --- Health check ---
    try {
        console.log('Test 1: GET /health');
        const res = await axios.get(`${BASE_URL}/health`);
        assert.strictEqual(res.status, 200);
        assert.strictEqual(res.data.status, 'ok');
        console.log('✅ Passed\n');
        passed++;
    } catch (e) {
        console.log(`❌ Failed: ${e.message}\n`);
        failed++;
    }

    // --- Missing query ---
    try {
        console.log('Test 2: POST /search with missing query');
        await axios.post(`${BASE_URL}/search`, {});
        console.log('❌ Failed: Should have returned 400\n');
        failed++;
    } catch (e) {
        assert.strictEqual(e.response.status, 400);
        assert(e.response.data.error.includes('Missing'));
        console.log('✅ Passed\n');
        passed++;
    }

    // --- Basic search ---
    try {
        console.log('Test 3: POST /search with query');
        const res = await axios.post(`${BASE_URL}/search`, {
            query: 'non-duality',
            top_k: 3
        });
        assert.strictEqual(res.status, 200);
        assert(res.data.query === 'non-duality');
        assert(Array.isArray(res.data.results));
        assert(res.data.results.length > 0);
        assert(res.data.total === res.data.results.length);
        console.log(`✅ Passed (found ${res.data.total} results)\n`);
        passed++;
    } catch (e) {
        console.log(`❌ Failed: ${e.message}\n`);
        failed++;
    }

    // --- Top_k limit ---
    try {
        console.log('Test 4: POST /search with top_k=1');
        const res = await axios.post(`${BASE_URL}/search`, {
            query: 'truth',
            top_k: 1
        });
        assert.strictEqual(res.data.total, 1);
        console.log('✅ Passed\n');
        passed++;
    } catch (e) {
        console.log(`❌ Failed: ${e.message}\n`);
        failed++;
    }

    // --- Source filter ---
    try {
        console.log('Test 5: POST /search with sources filter');
        const res = await axios.post(`${BASE_URL}/search`, {
            query: 'truth',
            sources: ['david_r_hawkins.txt']
        });
        assert.strictEqual(res.status, 200);
        // All results should be from the specified source
        for (const r of res.data.results) {
            assert.strictEqual(r.chunk.source, 'david_r_hawkins.txt');
        }
        console.log('✅ Passed\n');
        passed++;
    } catch (e) {
        console.log(`❌ Failed: ${e.message}\n`);
        failed++;
    }

    // --- Non-existent source ---
    try {
        console.log('Test 6: POST /search with non-existent source');
        const res = await axios.post(`${BASE_URL}/search`, {
            query: 'truth',
            sources: ['nonexistent.txt']
        });
        assert.strictEqual(res.status, 200);
        assert.strictEqual(res.data.total, 0);
        console.log('✅ Passed\n');
        passed++;
    } catch (e) {
        console.log(`❌ Failed: ${e.message}\n`);
        failed++;
    }

    // --- Embed endpoint ---
    try {
        console.log('Test 7: POST /embed');
        const res = await axios.post(`${BASE_URL}/embed`, {
            query: 'test embedding'
        });
        assert.strictEqual(res.status, 200);
        assert(Array.isArray(res.data.embedding));
        assert(res.data.dimensions > 0);
        console.log(`✅ Passed (embedding dims: ${res.data.dimensions})\n`);
        passed++;
    } catch (e) {
        console.log(`❌ Failed: ${e.message}\n`);
        failed++;
    }

    // --- Embed missing query ---
    try {
        console.log('Test 8: POST /embed with missing query');
        await axios.post(`${BASE_URL}/embed`, {});
        console.log('❌ Failed: Should have returned 400\n');
        failed++;
    } catch (e) {
        assert.strictEqual(e.response.status, 400);
        console.log('✅ Passed\n');
        passed++;
    }

    // --- Score ordering ---
    try {
        console.log('Test 9: POST /search scores are descending');
        const res = await axios.post(`${BASE_URL}/search`, {
            query: 'duality',
            top_k: 10
        });
        if (res.data.results.length >= 2) {
            for (let i = 0; i < res.data.results.length - 1; i++) {
                assert(res.data.results[i].score >= res.data.results[i + 1].score,
                    'Scores should be in descending order');
            }
        }
        console.log('✅ Passed\n');
        passed++;
    } catch (e) {
        console.log(`❌ Failed: ${e.message}\n`);
        failed++;
    }

    // --- Chunk structure ---
    try {
        console.log('Test 10: POST /search result chunk structure');
        const res = await axios.post(`${BASE_URL}/search`, {
            query: 'awareness',
            top_k: 1
        });
        const chunk = res.data.results[0].chunk;
        assert(chunk.source, 'chunk should have source');
        assert(chunk.text, 'chunk should have text');
        assert(typeof res.data.results[0].score === 'number');
        console.log('✅ Passed\n');
        passed++;
    } catch (e) {
        console.log(`❌ Failed: ${e.message}\n`);
        failed++;
    }

    // --- Context endpoint: missing query ---
    try {
        console.log('Test 11: POST /context with missing query');
        await axios.post(`${BASE_URL}/context`, {});
        console.log('❌ Failed: Should have returned 400\n');
        failed++;
    } catch (e) {
        assert.strictEqual(e.response.status, 400);
        assert(e.response.data.error.includes('Missing'));
        console.log('✅ Passed\n');
        passed++;
    }

    // --- Context endpoint: valid query ---
    try {
        console.log('Test 12: POST /context with valid query');
        const res = await axios.post(`${BASE_URL}/context`, {
            query: 'non-duality',
            top_k: 3
        });
        assert.strictEqual(res.status, 200);
        assert(typeof res.data.context === 'string');
        assert(res.data.context.length > 0);
        assert(typeof res.data.system_instructions === 'string');
        assert(Array.isArray(res.data.chunks));
        assert(res.data.chunks.length > 0);
        assert(res.data.chunks[0].text);
        assert(res.data.chunks[0].source);
        assert(typeof res.data.chunks[0].score === 'number');
        console.log(`✅ Passed (${res.data.chunks.length} chunks)\n`);
        passed++;
    } catch (e) {
        console.log(`❌ Failed: ${e.message}\n`);
        failed++;
    }

    // --- Context endpoint: calibrate mode ---
    try {
        console.log('Test 13: POST /context with calibrate mode');
        const res = await axios.post(`${BASE_URL}/context`, {
            query: 'I feel deep compassion for all beings',
            top_k: 3,
            mode: 'calibrate'
        });
        assert.strictEqual(res.status, 200);
        assert(res.data.system_instructions.includes('Map of Consciousness'));
        assert(res.data.system_instructions.includes('CALIBRATION'));
        console.log('✅ Passed\n');
        passed++;
    } catch (e) {
        console.log(`❌ Failed: ${e.message}\n`);
        failed++;
    }

    // --- Sources endpoint ---
    try {
        console.log('Test 14: GET /sources');
        const res = await axios.get(`${BASE_URL}/sources`);
        assert.strictEqual(res.status, 200);
        assert(Array.isArray(res.data.sources));
        assert(res.data.sources.length > 0);
        console.log(`✅ Passed (${res.data.sources.length} sources)\n`);
        passed++;
    } catch (e) {
        console.log(`❌ Failed: ${e.message}\n`);
        failed++;
    }

    // --- Reranker flag ---
    try {
        console.log('Test 15: POST /search with reranker=false');
        const res = await axios.post(`${BASE_URL}/search`, {
            query: 'truth',
            top_k: 3,
            reranker: false
        });
        assert.strictEqual(res.status, 200);
        assert.strictEqual(res.data.reranked, false);
        console.log('✅ Passed\n');
        passed++;
    } catch (e) {
        console.log(`❌ Failed: ${e.message}\n`);
        failed++;
    }

    // --- Reranker enabled ---
    try {
        console.log('Test 16: POST /search with reranker=true');
        const healthRes = await axios.get(`${BASE_URL}/health`);
        if (!healthRes.data.reranker) {
            console.log('⚠️ Skipped (reranker disabled on server)\n');
            passed++;
        } else {
            const res = await axios.post(`${BASE_URL}/search`, {
                query: 'truth',
                top_k: 3,
                reranker: true
            });
            assert.strictEqual(res.status, 200);
            assert.strictEqual(res.data.reranked, true);
            if (res.data.results.length > 0 && res.data.results[0].rerank_score !== undefined) {
                assert(typeof res.data.results[0].rerank_score === 'number');
            }
            console.log('✅ Passed\n');
            passed++;
        }
    } catch (e) {
        console.log(`❌ Failed: ${e.message}\n`);
        failed++;
    }

    // --- Health shows reranker status ---
    try {
        console.log('Test 17: GET /health shows reranker status');
        const res = await axios.get(`${BASE_URL}/health`);
        assert.strictEqual(res.status, 200);
        assert(typeof res.data.reranker === 'boolean');
        console.log(`✅ Passed (reranker: ${res.data.reranker})\n`);
        passed++;
    } catch (e) {
        console.log(`❌ Failed: ${e.message}\n`);
        failed++;
    }

    // --- Summary ---
    console.log('='.repeat(50));
    console.log(`Results: ${passed} passed, ${failed} failed`);
    console.log('='.repeat(50));

    if (failed > 0) {
        process.exit(1);
    }
}

runTests().catch(e => {
    console.error('Unhandled error:', e.message);
    process.exit(1);
});
