#!/bin/sh
set -e

# DevOps deploy stamp (issue #61).
# Primary: BUILD_SHA (full git sha), optional DEPLOYED_AT (ISO-8601 UTC).
# Alias: DOCDOCGO_GIT_SHA / DOCDOCGO_DEPLOYED_AT if the primary vars are unset.
SHA="${BUILD_SHA:-${DOCDOCGO_GIT_SHA:-}}"
DEPLOYED_AT="${DEPLOYED_AT:-${DOCDOCGO_DEPLOYED_AT:-}}"
VERSION_LABEL="${VERSION_LABEL:-}"

if [ -n "$SHA" ]; then
  SHORT=$(printf '%s' "$SHA" | cut -c1-7)
  if [ -z "$DEPLOYED_AT" ]; then
    DEPLOYED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)
  fi
  if [ -z "$VERSION_LABEL" ]; then
    VERSION_LABEL="$SHORT"
  fi
  tmp=$(mktemp)
  printf '{\n  "sha": "%s",\n  "shortSha": "%s",\n  "deployedAt": "%s",\n  "versionLabel": "%s"\n}\n' \
    "$SHA" "$SHORT" "$DEPLOYED_AT" "$VERSION_LABEL" > "$tmp"
  mv "$tmp" /app/build-info.json

  # Bake shortSha (+ full sha) into public changelog HTML so /changelog is
  # grep-friendly without client-side JS. Placeholders committed as markers.
  if [ -f /app/html/changelog.html ]; then
    sed -i \
      -e "s/__DOCDOCGO_GIT_SHA__/${SHA}/g" \
      -e "s/__DOCDOCGO_SHORT_SHA__/${SHORT}/g" \
      -e "s/__DOCDOCGO_DEPLOYED_AT__/${DEPLOYED_AT}/g" \
      /app/html/changelog.html || true
  fi
fi

# Image/compose is the production runtime. auth.js only fail-fasts
# SESSION_SECRET when NODE_ENV=production — default it here so a
# missing compose env still cannot fall back to DEV_SESSION_SECRET.
if [ -z "${NODE_ENV:-}" ]; then
  export NODE_ENV=production
fi

# Quality gate now runs inside api.js on the corpus it just loaded, so the
# corpus is cleaned once per start instead of twice (was: node quality-check.js
# followed by exec node api.js). Hard failures still abort the container start.
exec node api.js
