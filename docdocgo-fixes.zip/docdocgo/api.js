const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');
const http = require('http');
const rateLimit = require('express-rate-limit');
const crypto = require('crypto');

const app = express();
const port = parseInt(process.env.PORT || '3000', 10);
const HTML_DIR = path.join(__dirname, 'html');

app.disable('x-powered-by');
app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
    next();
});

app.use(cors());
app.use(express.json());

// Discord login + admin-approval gate (see auth.js). Order matters: the
// session middleware and public auth routes must run before the gate, so
// every /api/* route below ends up behind it.
const { execRegexBoundedMany } = require('./search-regex');
const auth = require('./auth');
app.use(auth.sessionMiddleware);
app.use(auth.router);
// No blanket gate on /api/* — internal tools call these endpoints without a
// Discord session. The site UI (/se/) stays gated at nginx via /auth/gate,
// and /admin/* routes enforce admin themselves.
// app.use(auth.gate);

// --- Rate limiting for the public /api/* surface (abuse protection) ---
// The API is unauthenticated, so cap requests per client IP. Limits are
// env-tunable without a rebuild (RATE_LIMIT_WINDOW_MS / RATE_LIMIT_MAX).
// Trust the first hop (nginx) so the client IP from Cloudflare's
// X-Forwarded-For chain is used; nginx appends its peer via
// $proxy_add_x_forwarded_for in nginx.conf.
app.set('trust proxy', 1);
const RATE_LIMIT_WINDOW_MS = parseInt(process.env.RATE_LIMIT_WINDOW_MS || String(2 * 60 * 1000), 10);
const RATE_LIMIT_MAX = parseInt(process.env.RATE_LIMIT_MAX || '100', 10);
// Least-privilege exemption for internal tools (e.g. Friendbot): a request
// that presents the shared secret in the X-Internal-Token header is NOT
// rate-limited. The secret lives in env (INTERNAL_API_TOKEN, never committed).
// Default-deny: when the env var is unset/blank, no internal exemption is
// active and every caller (including loopback / docker network) is
// rate-limited per IP — so public IP abuse protection is never weakened by
// an unset env. Loopback/docker-network skips are deliberately not used:
// Friendbot calls the public URL via Cloudflare, and trust-proxy plus the
// published :12854 port would make a loopback skip spoofable by
// X-Forwarded-For.
const INTERNAL_API_TOKEN = (process.env.INTERNAL_API_TOKEN || '').trim();
function isInternalRequest(req) {
    if (!INTERNAL_API_TOKEN) return false;
    const provided = String(req.get('X-Internal-Token') || '');
    if (!provided) return false;
    const a = Buffer.from(provided);
    const b = Buffer.from(INTERNAL_API_TOKEN);
    if (a.length !== b.length) return false;
    return crypto.timingSafeEqual(a, b);
}
function retryAfterSeconds(req) {
    const reset = req.rateLimit && req.rateLimit.resetTime;
    if (reset instanceof Date) {
        return Math.max(1, Math.ceil((reset.getTime() - Date.now()) / 1000));
    }
    return Math.max(1, Math.ceil(RATE_LIMIT_WINDOW_MS / 1000));
}

const apiLimiter = rateLimit({
    windowMs: RATE_LIMIT_WINDOW_MS,
    limit: RATE_LIMIT_MAX,
    standardHeaders: true,
    legacyHeaders: false,
    // Internal tools present X-Internal-Token (INTERNAL_API_TOKEN) to skip
    // the per-IP limiter. Public callers (no header) stay rate-limited by IP.
    skip: (req) => isInternalRequest(req),
    handler: (req, res, _next, options) => {
        const retry = retryAfterSeconds(req);
        res.set('Retry-After', String(retry));
        res.status(options.statusCode).json({
            error: 'Too many requests, please try again later.',
            message: 'You have reached the request limit for this window. The library is still here — please wait a moment and try again, or use a more specific query.',
            retry_after_seconds: retry,
            limit: RATE_LIMIT_MAX,
            window_ms: RATE_LIMIT_WINDOW_MS,
            hint: 'Health checks at /api/health and /api/health/deps are never throttled. See /api/docs for rate_limiting.',
            docs: '/api/docs'
        });
    }
});
// Mounted after auth.router, so /api/health and /api/test-login (served by
// the auth router above) stay exempt — the liveness probe must never be
// throttled. The /api/health/deps route below is registered here for the
// same reason: health and dependency probes must never be throttled.
app.use('/api', apiLimiter);

// --- RAG availability: probe cache + fast-fail (DOC-002) ---
// The Python RAG service (rag/rag_service.py) is an OPTIONAL deployment,
// parked behind the "rag" profile in docker-compose.yml. When it is not
// running, the RAG proxy endpoints (/api/rag, /api/rag/context,
// /api/calibrate, /api/rag/sources) must fail fast with a self-describing
// 503 JSON body instead of making every caller pay for a DNS/connect
// attempt — and the dependency's state must be observable. This block
// lives above the limiter only so /api/health/deps can be exempt; the
// proxying itself happens further down in the RAG proxy section.
const RAG_HOST = process.env.RAG_HOST || 'rag';
const RAG_PORT = parseInt(process.env.RAG_PORT || '9432', 10);
const MAX_QUERY_LENGTH = parseInt(process.env.MAX_QUERY_LENGTH || '1000', 10);
// How long a probe result is trusted (a down RAG is re-probed at most once
// per TTL) and how long a single probe may take before counting as down.
const RAG_PROBE_TTL_MS = parseInt(process.env.RAG_PROBE_TTL_MS || '30000', 10);
const RAG_PROBE_TIMEOUT_MS = parseInt(process.env.RAG_PROBE_TIMEOUT_MS || '2000', 10);

const ragStatus = { state: 'unknown', error: null, lastChecked: 0 };

// One cheap GET /health against the RAG service. ANY HTTP response (even an
// error status) proves the service is up and listening; only DNS, connect,
// and timeout failures mark it down.
function probeRAG(callback) {
    let settled = false;
    const done = (up, error) => {
        if (settled) return;
        settled = true;
        const previous = ragStatus.state;
        ragStatus.state = up ? 'up' : 'down';
        ragStatus.error = up ? null : (error || 'unreachable');
        ragStatus.lastChecked = Date.now();
        if (previous !== ragStatus.state) {
            logger[up ? 'info' : 'warn'](`[RAG] ${RAG_HOST}:${RAG_PORT} is ${ragStatus.state}${ragStatus.error ? ` (${ragStatus.error})` : ''}`);
        }
        callback(up);
    };
    const req = http.get(
        { hostname: RAG_HOST, port: RAG_PORT, path: '/health', timeout: RAG_PROBE_TIMEOUT_MS },
        (res) => {
            res.resume(); // drain the socket; the body does not matter
            done(true);
        }
    );
    req.on('timeout', () => {
        req.destroy();
        done(false, `no response within ${RAG_PROBE_TIMEOUT_MS}ms`);
    });
    req.on('error', (e) => done(false, e.code || e.message));
}

// Fresh 'up' → proxy straight away; fresh 'down' → immediate 503; stale or
// unknown → probe once (bounded by RAG_PROBE_TIMEOUT_MS), then decide.
function ragGuard(res, proceed) {
    const fresh = Date.now() - ragStatus.lastChecked < RAG_PROBE_TTL_MS;
    if (fresh) {
        return ragStatus.state === 'up' ? proceed() : ragUnavailable(res);
    }
    probeRAG((up) => (up ? proceed() : ragUnavailable(res)));
}

function ragUnavailable(res) {
    res.status(503).json({
        error: 'RAG vector search is not available on this deployment',
        status: 'unavailable',
        hint: 'The optional RAG service (Docker Compose profile "rag") is not running. Keyword and regex search still work via /api/search.',
        docs: '/api/docs',
        dependencies: '/api/health/deps'
    });
}

// Dependency health REPORT — always 200, so it stays useful as a diagnostic
// even while things are broken. Read body.status ('ok' | 'degraded') and
// body.dependencies for detail. Deliberately not a liveness probe:
// /api/health (auth.js) remains the uptime endpoint; a missing OPTIONAL
// dependency must not mark the whole API unhealthy for monitors.
app.get('/api/health/deps', (req, res) => {
    const report = () => res.json({
        status: ragStatus.state === 'up' ? 'ok' : 'degraded',
        dependencies: {
            rag: {
                status: ragStatus.state,
                endpoint: `${RAG_HOST}:${RAG_PORT}`,
                detail: ragStatus.error,
                last_checked: ragStatus.lastChecked ? new Date(ragStatus.lastChecked).toISOString() : null
            }
        }
    });
    if (Date.now() - ragStatus.lastChecked < RAG_PROBE_TTL_MS) return report();
    probeRAG(report);
});


// --- Build identity + public changelog (issue #61) ---
// DevOps stamps build-info.json at deploy (see entrypoint.sh). Env wins over file:
//   DOCDOCGO_GIT_SHA (alias: BUILD_SHA)
//   DOCDOCGO_DEPLOYED_AT (alias: DEPLOYED_AT)
//   VERSION_LABEL (optional)
const BUILD_INFO_PATH = path.join(__dirname, 'build-info.json');
const CHANGELOG_PATH = path.join(__dirname, 'changelog.json');

function loadBuildInfo() {
    const defaults = {
        sha: 'unknown',
        shortSha: 'unknown',
        deployedAt: null,
        versionLabel: 'dev'
    };
    let info = { ...defaults };
    try {
        const raw = JSON.parse(fs.readFileSync(BUILD_INFO_PATH, 'utf8'));
        if (raw && typeof raw === 'object') info = { ...defaults, ...raw };
    } catch (e) {
        // Missing/invalid file is fine in local/dev — env or defaults apply.
    }
    // Primary: BUILD_SHA / DEPLOYED_AT. Alias: DOCDOCGO_GIT_SHA / DOCDOCGO_DEPLOYED_AT.
    const shaEnv = (process.env.BUILD_SHA || process.env.DOCDOCGO_GIT_SHA || '').trim();
    if (shaEnv) {
        info.sha = shaEnv;
        info.shortSha = shaEnv.slice(0, 7);
    } else if (info.sha && info.sha !== 'unknown' && (!info.shortSha || info.shortSha === 'unknown')) {
        info.shortSha = String(info.sha).slice(0, 7);
    }
    const deployedEnv = (process.env.DEPLOYED_AT || process.env.DOCDOCGO_DEPLOYED_AT || '').trim();
    if (deployedEnv) info.deployedAt = deployedEnv;
    if ((process.env.VERSION_LABEL || '').trim()) {
        info.versionLabel = process.env.VERSION_LABEL.trim();
    } else if ((!info.versionLabel || info.versionLabel === 'dev') && info.shortSha && info.shortSha !== 'unknown') {
        info.versionLabel = info.shortSha;
    }
    let packageVersion = '0.0.0';
    try {
        packageVersion = JSON.parse(fs.readFileSync(path.join(__dirname, 'package.json'), 'utf8')).version || packageVersion;
    } catch (e) { /* ignore */ }
    return {
        sha: info.sha,
        shortSha: info.shortSha,
        deployedAt: info.deployedAt,
        versionLabel: info.versionLabel,
        packageVersion
    };
}

function loadChangelogEntries() {
    try {
        const raw = JSON.parse(fs.readFileSync(CHANGELOG_PATH, 'utf8'));
        if (Array.isArray(raw)) return raw;
        if (raw && Array.isArray(raw.entries)) return raw.entries;
    } catch (e) { /* fall through */ }
    return [];
}

/**
 * GET /api/version — public build identity for the changelog page + ops checks.
 */
app.get('/api/version', (req, res) => {
    res.json(loadBuildInfo());
});

/**
 * GET /api/changelog — plain-language entries ({date, title, before, now}).
 */
app.get('/api/changelog', (req, res) => {
    const entries = loadChangelogEntries();
    res.json({ entries });
});


// --- Stop words list (common English words that contribute little to relevance) ---
// Note: "not", "no", "nor" excluded — negation matters in spiritual/teaching content
const STOP_WORDS = new Set([
  'a','an','the','in','on','at','to','for','of','with',
  'by','from','its','this','that','these','those','was','were',
  'been','has','had','does','did','would'
]);

// --- Search time budget ---
// /api/search scans the whole corpus synchronously on the event loop; a
// pathological query (long multi-word, dense regex) can block every other
// request for seconds. Bound the work: stop scanning once the budget is
// exceeded and return a partial result set flagged `truncated: true`.
// Default 2000 ms separates legitimate heavy queries (measured <~1.5 s)
// from pathological ones; env-tunable without a rebuild.
const SEARCH_BUDGET_MS = parseInt(process.env.SEARCH_BUDGET_MS || '2000', 10);

// --- Logger Utility ---
const LOG_LEVEL = process.env.LOG_LEVEL || 'info'; // 'low' or 'verbose'
const logger = {
    info: (...args) => {
        if (LOG_LEVEL === 'low' || LOG_LEVEL === 'verbose' || LOG_LEVEL === 'info') {
            console.log(`[INFO]`, ...args);
        }
    },
    debug: (...args) => {
        if (LOG_LEVEL === 'verbose') {
            console.log(`[DEBUG]`, ...args);
        }
    },
    warn: (...args) => {
        console.error(`[WARN]`, ...args);
    },
    error: (...args) => {
        console.error(`[ERROR]`, ...args);
    }
};

// --- Load Search Data ---
// Load the same pre-processed JSON data sources used by the browser search page.
// These contain text WITHOUT timestamps, matching the browser search experience.
// Loading + cleanup live in lecture-text.js (shared with the quality gate + tests).
let the_json_obj = {};
let the_json_obj_books = {};
const {
    loadLectureTexts, loadBookTexts, loadExtraSources, FILE_KEY_RE, resolveSourceKey,
    NORMALISATION_VERSION, PERIOD_DENSITY_MIN, PERIOD_DENSITY_MAX
} = require('./lecture-text');
const { checkLectures } = require('./quality-check');

let lectureMeta = {};

try {
    // Same path quality-check + overlay-tests use. Overlays live in overlays/<key>.txt
    // and must reach /api/read and /api/search — do not re-implement clean here.
    const loaded = loadLectureTexts(HTML_DIR);
    the_json_obj = loaded.lectures;
    lectureMeta = loaded.lectureMeta || {};
    const bits = [];
    if (loaded.cleanedCount) bits.push(`cleaned ${loaded.cleanedCount}`);
    bits.push(`overlays ${loaded.overlayCount}`);
    if (loaded.rawAsrCount) bits.push(`raw_asr ${loaded.rawAsrCount}`);
    console.log(`Loaded ${loaded.rawCount} lecture entries (no timestamps), ${bits.join(', ')}` +
        ` [norm ${loaded.normalisationVersion || NORMALISATION_VERSION}]`);
    if (loaded.overlayCount !== 0 && loaded.overlayCount !== 230) {
        console.error(`[ERROR] partial ASR overlay set: overlayCount=${loaded.overlayCount} (expected 0 or 230)`);
        process.exit(1);
    }
    // Pre-start quality gate (was entrypoint.sh's separate `node
    // quality-check.js`). Runs on the corpus that was just loaded, so a
    // container start cleans once instead of twice, and still refuses to
    // serve garbage when the runtime html/ mount is bad.
    const qc = checkLectures(the_json_obj);
    console.log(`quality-check: ${qc.keys} lectures loaded`);
    for (const w of qc.softWarnings) console.log(`  [warn] ${w}`);
    if (qc.hardFailures.length) {
        for (const f of qc.hardFailures) console.error(`[ERROR] quality-check: ${f}`);
        console.error(`[ERROR] quality-check: FAIL (${qc.hardFailures.length} hard failure(s))`);
        process.exit(1);
    }
    console.log('quality-check: OK');
} catch (err) {
    console.error('[ERROR] failed to load lectures:', err && err.message ? err.message : err);
    process.exit(1);
}

try {
    // loadBookTexts applies the same load-time hygiene as lectures
    // (==== banners, whitespace artifacts, encoding damage — DOC-010/014/015).
    const bookData = loadBookTexts(HTML_DIR);
    the_json_obj_books = bookData.the_json_obj_books || {};
    const extras = loadExtraSources();
    const collide = Object.keys(extras).filter((k) => Object.prototype.hasOwnProperty.call(the_json_obj_books, k));
    if (collide.length) {
        console.error('[ERROR] extra-sources collide with book keys:', collide.join(', '));
        process.exit(1);
    }
    Object.assign(the_json_obj_books, extras);
    console.log(`Loaded ${Object.keys(the_json_obj_books).length} book entries (no timestamps)` +
        (Object.keys(extras).length ? `, extras ${Object.keys(extras).length}` : ''));
} catch (err) {
    console.error('[ERROR] failed to load books:', err && err.message ? err.message : err);
    process.exit(1);
}

// --- Build Chapter Map for Books ---
// Word → number for all-caps spelled-out chapter markers (e.g. "CHAPTER TWELVE.")
const CHAPTER_NUMBER_WORDS = {
    ONE: 1, TWO: 2, THREE: 3, FOUR: 4, FIVE: 5, SIX: 6, SEVEN: 7, EIGHT: 8, NINE: 9,
    TEN: 10, ELEVEN: 11, TWELVE: 12, THIRTEEN: 13, FOURTEEN: 14, FIFTEEN: 15,
    SIXTEEN: 16, SEVENTEEN: 17, EIGHTEEN: 18, NINETEEN: 19, TWENTY: 20
};

function chapterWordToNumber(word) {
    if (CHAPTER_NUMBER_WORDS[word] !== undefined) return CHAPTER_NUMBER_WORDS[word];
    const hyphen = /^TWENTY-(ONE|TWO|THREE|FOUR|FIVE|SIX|SEVEN|EIGHT|NINE)$/.exec(word);
    return hyphen ? 20 + CHAPTER_NUMBER_WORDS[hyphen[1]] : null;
}

// Pass 1 matches chapter markers at line start (newline-separated books, e.g. "CHAPTER 1: Title").
const LINE_START_CHAPTER_RE = /^\s*CHAPTER\s+(\d+)(?:[:\.\-]\s*(.+?))?\s*$/i;
// Pass 2 matches mid-line chapter markers in run-together books (whole text on one line),
// e.g. "...  Chapter 2: Title  ..." or "...CHAPTER TWELVE. Title...". The \b word boundary
// keeps lowercase cross-references like "chapter nine" or "chapter of a series" from matching.
// The separator after the chapter number is either a colon/period (e.g. "Chapter 2: Title")
// or at least two spaces (e.g. "CHAPTER 1   The nature of the Self" in Be_as_you_are).
const MID_LINE_CHAPTER_RE = /\b(?:Chapter\s+(\d+)|CHAPTER\s+((?:\d+)|([A-Z]+(?:-[A-Z]+)?)))\s*(?:[:.]\s+|\s{2,})([^.!?\n]*)/g;

const bookChapterMap = {};
for (const [key, text] of Object.entries(the_json_obj_books)) {
    bookChapterMap[key] = relocateTocChapters(text, parseChapters(text), key);
}
// DOC-020: satsang_june_2010 gets Gloria session chapters. Do not scan every
// lecture — other Satsang_Series_* keys have hymn "Gloria" hits that are not
// session boundaries.
{
    const key = 'satsang_june_2010';
    if (the_json_obj[key] && !(bookChapterMap[key] && bookChapterMap[key].length)) {
        const chapters = relocateTocChapters(the_json_obj[key], parseChapters(the_json_obj[key]), key);
        if (chapters.length) bookChapterMap[key] = chapters;
    }
}
console.log(`Built chapter map: ${Object.values(bookChapterMap).reduce((s, c) => s + c.length, 0)} chapters across ${Object.keys(bookChapterMap).length} books`);

// --- Load Source Config ---
// Metadata about which sources belong to which categories (hawkins-books, non-hawkins-books, lectures).
// This is the single source of truth for filter categories.
let sourceConfig = { categories: { hawkinsBooks: [], nonHawkinsBooks: [], lectureSeries: [] }, displayNames: {}, filterOptions: {}, kinds: {}, variants: {}, incomplete_series: {} };
try {
    const configPath = path.join(__dirname, 'source-config.json');
    if (fs.existsSync(configPath)) {
        sourceConfig = JSON.parse(fs.readFileSync(configPath, 'utf8'));
        console.log(`Loaded source config: ${sourceConfig.categories.hawkinsBooks.length} Hawkins books, ${sourceConfig.categories.nonHawkinsBooks.length} other books, ${sourceConfig.categories.lectureSeries.length} lecture series`);
    } else {
        // Fallback: derive from data keys if config missing
        const allBookKeys = Object.keys(the_json_obj_books);
        const knownNonHawkins = new Set(['ACIM_workbook', 'Be_as_you_are', 'I_AM_THAT', 'Lamsa_bible']);
        sourceConfig.categories.hawkinsBooks = allBookKeys.filter(k => !knownNonHawkins.has(k));
        sourceConfig.categories.nonHawkinsBooks = allBookKeys.filter(k => knownNonHawkins.has(k));
        sourceConfig.categories.lectureSeries = Object.keys(the_json_obj);
        console.log('source-config.json not found, using derived categories (consider creating source-config.json for better management)');
    }
} catch (err) {
    console.error('Failed to load source-config.json:', err.message);
}

// --- Catalogue metadata: kinds, variants, series (DOC-021/022/031/032/034/035) ---
// source-config.json declares an explicit kind per corpus key plus variant
// links and known-incomplete series. Search filters derive from kinds — never
// from title presence (DOC-034). Corpus keys are read-only data, so series
// grouping normalises punctuation/suffix in code instead of renaming files
// (DOC-031/032): one series id per work, whatever the suffix or commas.
const KIND_BOOKS = new Set(['hawkins_book', 'reference', 'slides_ocr']); // filter=books
const KIND_HAWKINS_BOOKS = new Set(['hawkins_book', 'slides_ocr']); // filter=all-hawkins-books
const catalogueKinds = sourceConfig.kinds || {};
const catalogueVariants = sourceConfig.variants || {};
const incompleteSeries = sourceConfig.incomplete_series || {};
const useKindFilters = Object.keys(catalogueKinds).length > 0;

// Canonical series id: strip the pipeline suffix, drop every non-alphanumeric
// (commas/underscores/case), then drop a trailing PartN marker. Parts 1-2
// `Dialogue,_Questions,_and_Answers_...` and part 3 `Dialogue_Questions_...`
// land on one id; suffix-less files group with suffixed siblings.
function seriesId(key) {
    let s = String(key).replace(/_enxautogen_html$/i, '').replace(/\.txt$/i, '');
    s = s.toLowerCase().replace(/[^a-z0-9]/g, '');
    return s.replace(/part\d+$/, '');
}

// Forward variant links from config plus reverse `linked_by` (derived, so the
// two directions cannot drift). Keys with no relations get no entry.
function variantInfo(key) {
    const fwd = catalogueVariants[key];
    const linkedBy = Object.keys(catalogueVariants).filter((k) => {
        const v = catalogueVariants[k];
        return v.variant_of === key
            || (Array.isArray(v.same_session_as) && v.same_session_as.includes(key))
            || v.source_lecture_of === key;
    }).sort();
    if (!fwd && !linkedBy.length) return undefined;
    const out = { ...(fwd || {}) };
    if (linkedBy.length) out.linked_by = linkedBy;
    return out;
}

// Group id for search-result variant grouping: variants collapse onto their
// canonical target, intentional parallels onto their named group, hubs onto
// themselves. healing_and_recovery has only reverse links, so it hubs too.
function variantGroupId(key) {
    const v = catalogueVariants[key];
    if (v && v.variant_of) return v.variant_of;
    if (v && v.variant_group) return `group:${v.variant_group}`;
    if (v || variantInfo(key)) return key;
    return null;
}

// Fail fast on catalogue drift (same convention as the extra-source key
// collide check): every corpus key needs a kind, every variant target and
// every incomplete_series present-part must exist, every flagged-missing
// part must stay absent. A new unmanaged document breaks startup loudly
// instead of silently falling back to filename display (DOC-035).
{
    const corpusKeys = new Set([...Object.keys(the_json_obj), ...Object.keys(the_json_obj_books)]);
    const problems = [];
    if (useKindFilters) {
        for (const k of corpusKeys) if (!catalogueKinds[k]) problems.push(`no kind: ${k}`);
        for (const k of Object.keys(catalogueKinds)) if (!corpusKeys.has(k)) problems.push(`kind for unknown key: ${k}`);
    }
    for (const [k, v] of Object.entries(catalogueVariants)) {
        if (!corpusKeys.has(k)) problems.push(`variant for unknown key: ${k}`);
        for (const t of [...(v.same_session_as || []), v.variant_of, v.source_lecture_of].filter(Boolean)) {
            if (!corpusKeys.has(t)) problems.push(`variant target missing: ${k} -> ${t}`);
        }
    }
    for (const [sid, spec] of Object.entries(incompleteSeries)) {
        for (const p of spec.present || []) if (!corpusKeys.has(p)) problems.push(`incomplete_series ${sid}: present part absent: ${p}`);
        for (const m of spec.missing || []) {
            if (corpusKeys.has(m) || corpusKeys.has(`${m}_enxautogen_html`)) problems.push(`incomplete_series ${sid}: flagged-missing part present: ${m}`);
        }
    }
    if (problems.length) {
        console.error(`[ERROR] catalogue metadata drift (${problems.length}):\n  ` + problems.join('\n  '));
        process.exit(1);
    }
    console.log(`Loaded catalogue metadata: ${Object.keys(catalogueKinds).length} kinds, ${Object.keys(catalogueVariants).length} variant-linked keys, ${Object.keys(incompleteSeries).length} incomplete series`);
}

// DOC-030 / GoluGit #28: every corpus key gets a human title. Explicit
// source-config displayNames win; otherwise derive from the filename
// (strip _enxautogen_html, parse Title_Mon_YYYY_Part_N, else humanize).
const TITLE_MONTHS = new Set(['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']);
const TITLE_SMALL = new Set(['a','an','and','as','at','but','by','for','in','of','on','or','the','to','vs','vs.']);

function titleCaseWords(s) {
    return String(s).split(/\s+/).filter(Boolean).map((w, i) => {
        const lower = w.toLowerCase();
        if (i > 0 && TITLE_SMALL.has(lower)) return lower;
        // Keep short all-caps tokens (I, AM) and roman-ish volume markers.
        if (/^(?:[IVXLCDM]+|AM|OK)$/i.test(w) && w === w.toUpperCase()) return w.toUpperCase();
        if (/^vs\.?$/i.test(w)) return 'vs.';
        // Hyphenated compounds (Self-Healing) title-case each side; 's stays on the stem.
        return w.split('-').map((part) => {
            const p = part.toLowerCase();
            if (!p) return part;
            return p.charAt(0).toUpperCase() + p.slice(1);
        }).join('-');
    }).join(' ');
}

function humanizeSlug(slug) {
    // DOC-048: filename _s_ between tokens is a possessive, not a letter S.
    // CamelCase inner caps (SelfHealing) are hyphenated compounds, not one smashed word.
    const marked = String(slug)
        .replace(/([A-Za-z0-9])_s_(?=[A-Za-z0-9])/gi, "$1's_")
        .replace(/([a-z])([A-Z])/g, '$1-$2');
    return titleCaseWords(marked.replace(/_/g, ' ').replace(/\s+/g, ' ').trim());
}

function deriveDisplayName(key) {
    let base = String(key).replace(/_enxautogen_html$/i, '').replace(/\.txt$/i, '');
    // satsang_june_2010 (lowercase month word)
    let m = base.match(/^satsang_([a-z]+)_(\d{4})$/i);
    if (m) {
        const mon = m[1].charAt(0).toUpperCase() + m[1].slice(1).toLowerCase();
        return `Satsang (${mon} ${m[2]})`;
    }
    // Title_Mon_YYYY[_Part_N]
    m = base.match(/^(.+)_([A-Z][a-z]{2})_(\d{4})(?:_Part_(\d+))?$/);
    if (m && TITLE_MONTHS.has(m[2])) {
        const part = m[4] ? `, Part ${m[4]}` : '';
        return `${humanizeSlug(m[1])} (${m[2]} ${m[3]})${part}`;
    }
    // Title_Part_N (no date)
    m = base.match(/^(.+)_Part_(\d+)$/i);
    if (m) return `${humanizeSlug(m[1])}, Part ${m[2]}`;
    return humanizeSlug(base);
}

function displayName(key) {
    const explicit = sourceConfig.displayNames && sourceConfig.displayNames[key];
    if (explicit) return explicit;
    return deriveDisplayName(key);
}

// Named filter taxonomy from source-config.json filterOptions (DOC-009).
// Exact source keys (books + lectures) remain valid filter values too.
function declaredNamedFilters() {
    const fromConfig = sourceConfig.filterOptions && Object.keys(sourceConfig.filterOptions);
    return (fromConfig && fromConfig.length)
        ? fromConfig
        : ['all', 'books', 'all-hawkins-books', 'lectures'];
}

function isKnownSourceKey(key) {
    const resolved = resolveSourceKey(key);
    return Object.prototype.hasOwnProperty.call(the_json_obj, resolved)
        || Object.prototype.hasOwnProperty.call(the_json_obj_books, resolved);
}

/**
 * Root /api endpoint providing documentation and health status
 */
app.get('/api', (req, res) => {
    res.json({
        name: "DocDocGo API",
        status: "Online",
        message: "Gloria in Excelsis Deo! Use the endpoints below to explore the library.",
        documentation: {
            endpoints: [
                {
                    path: "/api/files",
                    description: "List all available document paths.",
                    method: "GET"
                },
                {
                    path: "/api/read/<path>",
                    description: "Retrieve full HTML content for a specific document.",
                    method: "GET"
                },
                {
                    path: "/api/search?q=<query>",
                    description: "Search all documents with advanced options.",
                    parameters: ["q", "context", "contextChars", "groupDistance", "max", "limit", "filter", "case", "caseSensitive", "whole", "wholeWords", "regex", "useRegex", "page"],
                    method: "GET"
                }
            ],
            example_search: "/api/search?q=Love&case=true&limit=5",
            rate_limiting: `${RATE_LIMIT_MAX} requests per ${RATE_LIMIT_WINDOW_MS / 60000} minutes per IP (env-tunable via RATE_LIMIT_MAX / RATE_LIMIT_WINDOW_MS). Over-limit returns a gracious 429 (error + retry_after_seconds + hint) with RateLimit-* and Retry-After. Clients: wait retry_after_seconds, then retry with backoff; space out bulk queries. /api/health is exempt. Internal tools (e.g. Friendbot) are exempt when they send the X-Internal-Token header matching INTERNAL_API_TOKEN (env, never committed; exemption inactive when unset).`
        }
    });
});

/**
 * List files/directories recursively
 */
function walk(dir) {
    let results = [];
    const list = fs.readdirSync(dir);
    list.forEach(file => {
        const filePath = path.join(dir, file);
        const stat = fs.statSync(filePath);
        if (stat && stat.isDirectory()) {
            results = results.concat(walk(filePath));
        } else {
            if (file.endsWith('.html') || file.endsWith('.js')) {
                results.push(path.relative(HTML_DIR, filePath));
            }
        }
    });
    return results;
}

/**
 * Escape regex special characters
 */
function escapeRegExp(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// --- Typographic folding + Unicode word boundaries (DOC-006/007/008) ---
// Books use curly typography (’ “ ” —), auto-transcripts use straight
// (' " -). The corpus is read-only (see AGENTS.md), so variants fold at
// MATCH time: every pattern built from user input accepts both forms, and
// a query typed with either variant finds both. escapeRegExp leaves
// ' " - untouched (they are not regex metacharacters), so folding safely
// runs on the escaped pattern. Folding must map EVERY variant to the full
// class, in both directions: a query typed with the curly form (isn’t)
// has to find the straight form (isn't) just as much as the other way
// around.
function foldEscaped(pattern) {
    return pattern
        .replace(/[''’‘]/g, "[''’‘]")   // straight + typographic apostrophes / single quotes
        .replace(/[""“”]/g, '[""“”]')   // straight + typographic double quotes
        .replace(/[—–-]/g, '[—–-]');    // hyphen + en dash + em dash
}

// ASCII-only \b cannot bound non-ASCII tokens: \bé\b can never match, and
// \bcafé\b misses "café,". These lookarounds are Unicode-aware and are
// exactly equivalent to \b...\b for pure-ASCII tokens. Requires the 'u'
// flag on the compiled regex.
function wrapWholeWord(pattern) {
    return `(?<![\\p{L}\\p{N}_])${pattern}(?![\\p{L}\\p{N}_])`;
}

// Whole-word wrapping is meaningless for tokens with no letters or digits
// at all (" and — must match every occurrence, not "standalone" ones), and
// for a single non-ASCII letter (é) a standalone whole-word hit is never
// what is wanted — users searching these want occurrences.
function needsWordWrap(token) {
    if (!/[\p{L}\p{N}]/u.test(token)) return false;
    if (token.length === 1 && /[^\x00-\x7F]/.test(token)) return false;
    // Digit-bearing tokens (timestamps/IDs like 20241228) are often glued to
    // more alphanumerics via underscore (20241228_143016). Unicode-aware \b
    // equivalents still treat _ as a word char, so wrap never fires. Skip
    // wrapping for those tokens so default wholeWords=true still finds them
    // (DOC-005 / GoluGit #6).
    if (/\d/.test(token)) return false;
    return true;
}

// Literal-mode matcher for one keyword token: escaped, folded, and
// word-wrapped per the wholeWords option.
function tokenPattern(token, wholeWords) {
    let pattern = foldEscaped(escapeRegExp(token));
    if (wholeWords && needsWordWrap(token)) pattern = wrapWholeWord(pattern);
    return pattern;
}

// Matcher for an exact phrase: escaped, folded, whitespace-normalised (a
// line break in the corpus still matches a space in the query), and
// word-wrapped only when both edges are word characters.
function phrasePattern(phrase, wholeWords) {
    const trimmed = phrase.trim();
    let pattern = foldEscaped(escapeRegExp(trimmed).replace(/\s+/g, '\\s+'));
    if (wholeWords && /^[\p{L}\p{N}]/u.test(trimmed) && /[\p{L}\p{N}]$/u.test(trimmed)) {
        pattern = wrapWholeWord(pattern);
    }
    return pattern;
}

// Extract balanced double-quoted spans (straight or curly delimiters) from
// a query. Returns { phrases, remainder } or null when there is no complete
// pair — a lone " then stays a literal search character (DOC-007).
function extractQuotedPhrases(q) {
    const phrases = [];
    let remainder = '';
    let last = 0;
    const re = /["“]([^"”]+)["”]/g;
    let m;
    while ((m = re.exec(q)) !== null) {
        phrases.push(m[1]);
        remainder += q.slice(last, m.index);
        last = re.lastIndex;
    }
    if (phrases.length === 0) return null;
    const nonEmpty = phrases.filter((p) => p.trim() !== '');
    if (nonEmpty.length === 0) return null;
    remainder += q.slice(last);
    return { phrases: nonEmpty, remainder };
}

/**
 * Mulberry32 - a fast, high-quality seeded PRNG.
 * @param {number} seed - Integer seed.
 * @returns {function} PRNG function returning [0, 1).
 */
function mulberry32(seed) {
    return function() {
        seed |= 0;
        seed = seed + 0x6D2B79F5 | 0;
        let t = Math.imul(seed ^ seed >>> 15, 1 | seed);
        t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
        return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
}

/**
 * Hash a string to a 32-bit integer.
 * @param {string} str - Input string.
 * @returns {number} Hash value.
 */
function hashString(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
        const char = str.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash |= 0;
    }
    return hash;
}

/**
 * Fisher-Yates shuffle with seeded PRNG.
 * @param {Array} array - Array to shuffle.
 * @param {number} seed - Seed for deterministic shuffling.
 * @returns {Array} New shuffled array (original not mutated).
 */
function seededShuffle(array, seed) {
    const rng = mulberry32(seed);
    const arr = array.slice();
    for (let i = arr.length - 1; i > 0; i--) {
        const j = Math.floor(rng() * (i + 1));
        [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
}

// --- Chapter Parsing Functions ---
function parseChapters(text) {
    if (!text) return [];
    const lines = text.split('\n');
    const lineOffset = [];
    let offset = 0;
    for (let i = 0; i < lines.length; i++) {
        lineOffset.push(offset);
        offset += lines[i].length + 1; // +1 for newline
    }

    // Pass 1: line-start markers (existing behavior, other books rely on it)
    const chapters = [];
    for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        const chapterMatch = line.match(LINE_START_CHAPTER_RE);
        if (chapterMatch) {
            const num = parseInt(chapterMatch[1], 10);
            let title = chapterMatch[2] ? chapterMatch[2].trim() : null;
            // If no title on same line, take the next non-blank line (Healing and
            // Recovery: "CHAPTER 1\n\nA Map of Consciousness").
            if (!title) {
                for (let j = i + 1; j < Math.min(i + 4, lines.length); j++) {
                    const nextLine = lines[j].trim();
                    if (!nextLine) continue;
                    if (/^CHAPTER\s+\d+/i.test(nextLine)) break;
                    if (/[.!?;:]\s*$/.test(nextLine)) break;
                    if (nextLine.length > 120) break;
                    title = nextLine;
                    break;
                }
            }
            chapters.push({
                number: num,
                title: title,
                offset: lineOffset[i]
            });
        }
    }
    // Books that parse via line-start keep their exact previous behavior.
    if (chapters.length > 0) return chapters;

    // Pass 2: run-together books keep their whole text on one line, so chapter markers
    // appear mid-line. Their character offset is line start + position within the line,
    // matching the raw-content offsets the search engine indexes by.
    for (let i = 0; i < lines.length; i++) {
        for (const m of lines[i].matchAll(MID_LINE_CHAPTER_RE)) {
            let number;
            if (m[1] !== undefined) {
                number = parseInt(m[1], 10);
            } else if (m[3] !== undefined) {
                number = chapterWordToNumber(m[3]);
            } else {
                number = parseInt(m[2], 10);
            }
            if (!Number.isInteger(number) || number <= 0) continue;
            let title = m[4] ? m[4].trim() : null;
            if (title) {
                // Strip trailing section numerals / calibration values ("Intro to Miracles  I", "... 986")
                title = title.replace(/\s+[IVXLC]+$/, '').replace(/\s+\d[\d,]*$/, '');
                // Reject cross-references and citations: "(See ... Chapter 6.)" or "Chapter 13: Explanations, p. 265"
                if (title.includes(')') || /,\s*p{1,2}\.?\s*\d*$/.test(title)) continue;
            }
            // For Be_as_you_are style (CHAPTER 1   Title   Content...), the title
            // capture may include body text after the real title. Trim at the first
            // multi-space gap followed by a capital letter (body-sentence start).
            if (title) {
                const bodyBreak = title.search(/\s{2,}[A-Z]/);
                if (bodyBreak >= 0) title = title.substring(0, bodyBreak).trim();
            }
            chapters.push({ number, title: title || null, offset: lineOffset[i] + m.index });
        }
        // Pass 3: I_AM_THAT uses numbered dialogues (1. Title   Questioner:) without
        // the word "Chapter". Match digits-period-space, then a title with no embedded
        // digits (rejects TOC entries that contain other dialogue numbers).
        if (chapters.length === 0) {
            const I_AM_THAT_DIALOGUE_RE = /(\d+)\.\s+([^\d]+?)\s{2,}(?=Questioner:)/g;
            for (const m of lines[i].matchAll(I_AM_THAT_DIALOGUE_RE)) {
                const num = parseInt(m[1], 10);
                if (!Number.isInteger(num) || num <= 0) continue;
                const title = m[2].trim();
                chapters.push({ number: num, title: title || null, offset: lineOffset[i] + m.index });
            }
        }
    }
    return chapters;
}

function findChapter(chapters, offset) {
    if (!chapters || chapters.length === 0) return null;
    // If offset is before first chapter, it's preface/front matter
    if (offset < chapters[0].offset) return null;
    let lo = 0, hi = chapters.length - 1;
    while (lo <= hi) {
        const mid = (lo + hi) >> 1;
        if (offset < chapters[mid].offset) {
            hi = mid - 1;
        } else if (mid + 1 < chapters.length && offset >= chapters[mid + 1].offset) {
            lo = mid + 1;
        } else {
            return { number: chapters[mid].number, title: chapters[mid].title };
        }
    }
    return { number: chapters[chapters.length - 1].number, title: chapters[chapters.length - 1].title };
}

function getChapterLabel(fileName, offset) {
    const info = findChapter(bookChapterMap[fileName] || [], offset);
    if (!info) return null;
    return info.title ? `Chapter ${info.number}: ${info.title}` : `Chapter ${info.number}`;
}

function documentHasChapters(fileName) {
    const chapters = bookChapterMap[fileName];
    return Array.isArray(chapters) && chapters.length > 0;
}

// DOC-045: one result object for every search_mode. match_count is per-group
// (keyword: unique query words; phrase/regex: 1). chapter is present whenever
// the document has parsed chapters (null for front matter).
// DOC-044: doc_match_count is this document's total in the same search
// (same basis as total_matches), not "this group matched once".
// DOC-041: title and kind come from the already-loaded displayNames/kinds
// maps (same as /api/files) — O(1), no join, no rescan.
function decorateSearchHit(m, docMatchCounts) {
    const totals = docMatchCounts || Object.create(null);
    const hit = {
        path: m.path,
        title: displayName(m.path),
        kind: catalogueKinds[m.path],
        offset: m.offset,
        match_text: m.match_text,
        snippet: m.snippet,
        score: m.score,
        proximity: m.proximity,
        match_count: Number.isInteger(m.match_count) ? m.match_count : 1,
        doc_match_count: totals[m.path] || 0
    };
    if (documentHasChapters(m.path)) {
        hit.chapter = getChapterLabel(m.path, m.offset) || null;
    }
    return hit;
}

// Pass 1 often matches the printed Contents page (Power vs Force, Letting Go).
// Those offsets sit in a tiny window at the front, so search labels and jumps
// would all land on the TOC. If that happens, snap to body headings instead.
function chapterSpan(chapters) {
    return chapters.length ? chapters[chapters.length - 1].offset - chapters[0].offset : 0;
}

function nextLineTitle(text, from) {
    const m = text.slice(from).match(/^\s+([^\n]+)/);
    return m ? m[1].trim() : null;
}

function parseSpacedChapters(text) {
    // OCR'd "CHAPTER ONE" came through as "C HAPTER O NE". After DOC-054
    // the served text is "CHAPTER ELEVEN" / "CHAPTER TWENTY-ONE".
    const chapters = [];
    const seen = new Set();
    const add = (m, word) => {
        const number = chapterWordToNumber(String(word).replace(/ /g, ''));
        if (!Number.isInteger(number) || number <= 0) return;
        if (seen.has(m.index)) return;
        seen.add(m.index);
        chapters.push({ number, title: nextLineTitle(text, m.index + m[0].length), offset: m.index });
    };
    for (const m of text.matchAll(/C HAPTER\s+([A-Z]+(?:[ -]+[A-Z]+)*)/g)) add(m, m[1]);
    for (const m of text.matchAll(/\bCHAPTER\s+([A-Z]+(?:-[A-Z]+)?)\b/g)) add(m, m[1]);
    chapters.sort((a, b) => a.offset - b.offset);
    return chapters;
}

function parseSplitLineChapters(text) {
    // Letting Go: "CHAPTER\n\n5\n\nGRIEF"
    const chapters = [];
    for (const m of text.matchAll(/^CHAPTER\s*\n+(\d+)\s*$/gm)) {
        const number = parseInt(m[1], 10);
        if (!Number.isInteger(number) || number <= 0) continue;
        chapters.push({ number, title: nextLineTitle(text, m.index + m[0].length), offset: m.index });
    }
    return chapters;
}

function parseDateChapters(text) {
    // Daily Reflections / Along the Path: "January 1" lines.
    const months = 'January|February|March|April|May|June|July|August|September|October|November|December';
    const re = new RegExp('^(' + months + ')\\s+(\\d{1,2})\\s*$', 'gm');
    const chapters = [];
    let n = 0;
    for (const m of text.matchAll(re)) {
        n += 1;
        chapters.push({ number: n, title: `${m[1]} ${m[2]}`, offset: m.index });
    }
    return chapters;
}

function isAllCapsTitleLine(t) {
    if (!t || t.length < 2 || t.length > 40) return false;
    const letters = t.replace(/[^A-Za-z]/g, '');
    if (letters.length < 2) return false;
    return letters === letters.toUpperCase();
}

function parseNumberedContemplationChapters(text) {
    // Dissolving the Ego: "1\n\nNATURE OF THE "EGO"" (ALL-CAPS title, maybe wrapped).
    const lines = text.split('\n');
    const lineOffset = [];
    let offset = 0;
    for (let i = 0; i < lines.length; i++) {
        lineOffset.push(offset);
        offset += lines[i].length + 1;
    }
    const chapters = [];
    for (let i = 0; i < lines.length; i++) {
        const num = lines[i].trim();
        if (!/^\d{1,2}$/.test(num)) continue;
        const n = parseInt(num, 10);
        if (n < 1 || n > 40) continue;
        const titleParts = [];
        for (let j = i + 1; j < Math.min(i + 6, lines.length); j++) {
            const t = lines[j].trim();
            if (!t) continue;
            if (isAllCapsTitleLine(t)) {
                titleParts.push(t.replace(/["“”']/g, ''));
                continue;
            }
            break;
        }
        if (!titleParts.length) continue;
        if (chapters.length && n <= chapters[chapters.length - 1].number) continue;
        chapters.push({ number: n, title: titleParts.join(' '), offset: lineOffset[i] });
    }
    return chapters;
}

function parseGloriaSessions(text) {
    // Session boundaries for satsang_june_2010: "Gloria in Excelsis" openings.
    // Require ≥5k chars between hits so hymn repeats (Volume VIII) are not sessions.
    const MIN_GAP = 5000;
    const chapters = [];
    let n = 0;
    let last = -MIN_GAP;
    for (const m of text.matchAll(/Gloria in Excelsis/gi)) {
        if (m.index - last < MIN_GAP) continue;
        n += 1;
        last = m.index;
        chapters.push({ number: n, title: `Session ${n}`, offset: m.index });
    }
    return chapters;
}

function parseTocPartChapters(text) {
    // The Ego Is Not the Real You: PART I/II/III only in the TOC — place
    // evenly across the body after INTRODUCTION (no body PART markers).
    const head = text.slice(0, 8000);
    const parts = [...head.matchAll(/^PART\s+([IVXLC]+):\s*(.+)$/gim)];
    if (parts.length < 2) return [];
    const intro = text.search(/^INTRODUCTION\s*$/im);
    const bodyStart = intro >= 0 ? intro : (parts[parts.length - 1].index + parts[parts.length - 1][0].length);
    // TOC also lists Bibliography/About — search only in the back half.
    const back = text.slice(Math.floor(text.length / 2));
    const backHit = back.search(/^(?:BIBLIOGRAPHY|ABOUT THE AUTHOR)\s*$/im);
    let bodyEnd = backHit >= 0 ? Math.floor(text.length / 2) + backHit : text.length;
    if (bodyEnd < bodyStart + 20000) bodyEnd = text.length;
    const span = Math.max(1, bodyEnd - bodyStart);
    return parts.map((p, i) => ({
        number: i + 1,
        title: p[2].trim(),
        offset: Math.floor(bodyStart + (span * i) / parts.length)
    }));
}

function relocateTocChapters(text, chapters, key) {
    if (!text) return chapters || [];
    const minSpan = Math.max(20000, text.length * 0.05);
    if (chapters.length && chapterSpan(chapters) >= minSpan) return chapters;
    let best = chapters || [];
    const candidates = [
        parseSpacedChapters(text),
        parseSplitLineChapters(text),
        parseDateChapters(text),
        parseNumberedContemplationChapters(text),
        parseTocPartChapters(text)
    ];
    if (key === 'satsang_june_2010') candidates.push(parseGloriaSessions(text));
    for (const cand of candidates) {
        if (cand.length >= 2 && chapterSpan(cand) > Math.max(minSpan, chapterSpan(best))) best = cand;
        if (cand.length >= 10 && chapterSpan(cand) > chapterSpan(best)) best = cand;
    }
    return best;
}

// --- API Documentation for LLMs ---
app.get('/api/docs', (req, res) => {
    res.json({
        service: "DocDocGo API",
        version: "1.0.0",
        description: "API for searching and reading the DocDocGo library (Spirituality, Non-duality, Consciousness).",
        endpoints: {
            "/api/search": {
                method: "GET",
                description: "Search the library using multi-word ranked search, exact phrases, or regex.",
                parameters: {
                    "q": "Required. The search query (min 3 characters; shorter queries are treated as empty EXCEPT when they contain punctuation or non-ASCII characters — \", é, — are legitimate searches). Double quotes delimit exact phrases: q=\"Heal Your Life\" searches for the literal phrase (whitespace-flexible, stop words honoured) and total_matches counts phrase occurrences. Quoted phrases can be combined with keywords (\"Heal Your Life\" grief) — results then group around occurrences of every quoted phrase. Matched literally as plain text — HTML-like queries (e.g. `<script>`) are not stripped or interpreted. Typographic variants fold at match time: ’↔', “”↔\", —/–↔-, so don't finds don’t.",
                    "limit": "Optional. Number of results, integer 1-1000 (default: 100). Alias: max. Values outside 1-1000 return 400.",
                    "page": "Optional. Page number (default: 1). Values below 1 normalize to 1; pages past the last page return empty results. An offset query parameter is not supported and returns 400 — paginate with page and limit.",
                    "context": "Optional. Snippet padding chars on each side of the match anchor (default: 300). Alias: contextChars. Does NOT control multi-word grouping.",
                    "groupDistance": "Optional. Max gap between consecutive word hits in one group (default: 250). Alias: group. Independent of context.",
                    "filter": "Optional. Source filter from source-config.json filterOptions (default 'all'), or an exact source key from /api/files. Unknown values return 400 listing valid named filters.",
                    "caseSensitive": "Optional. If 'true', case-sensitive. Alias: case=true.",
                    "wholeWords": "Optional. If 'false', allow partial words (default true). Alias: whole=false. Word boundaries are Unicode-aware (é, naïve bound correctly); pure punctuation tokens (\", —) always match every occurrence. Digit-bearing tokens (timestamps/IDs) skip whole-word boundaries under the default so they still match when glued to more alphanumerics via underscore (Unicode boundaries treat _ as a word char).",
                    "useRegex": "Optional. If 'true', treat q as regex (quotes in q are pattern characters, not phrase delimiters). Alias: regex=true. Patterns run off-thread and abort when SEARCH_BUDGET_MS is exceeded (truncated: true) so nested-quantifier ReDoS cannot stall the event loop."
                },
                behavior: "Multi-word hits group by groupDistance; each snippet is centered on the exact (folded, whitespace-flexible) phrase when present, else the densest keyword cluster. context only pads that anchor. Score = match_count * 3 + log(1 + doc_groups) / 10 + proximity bonus (unique query words dominate; per-doc frequency ranks single-keyword ties; a 1-word group never outranks a 2-word group). Tier shuffle only among near-equal scores after density/path tie-breaks. Pagination is deterministic. All-stopword queries return 0 matches with ignored_terms naming the dropped words. Invalid filter values return 400 with valid_filters. The offset query parameter returns 400 (use page).",
                results: {
                    schema: "One object shape for every search_mode. Always present: path, title, kind, offset, match_text, snippet, score, proximity, match_count, doc_match_count. title is the same human name as /api/files names[path]; kind is the declared catalogue kind (same as /api/files kinds[path]). chapter is included when that document has parsed chapters (keyword/phrase/regex alike; null for front matter before chapter 1) and omitted for lectures and chapter-less sources. The response also lists doc_counts: every matching document's {path, doc_match_count}, sorted by volume, so a client can rank documents from one response without paging.",
                    title: "Human document title from the already-loaded names map (source-config displayNames, else derived). Non-empty; no /api/files join required.",
                    kind: "Declared catalogue kind for this path (hawkins_book, reference, slides_ocr, lecture, …). Same map as /api/files kinds.",
                    match_count: "This match-group only — not the document total. Keyword mode: unique query words matched in this group. Phrase and regex modes: 1 (this occurrence).",
                    doc_match_count: "This document's total in the same search, on the same basis as total_matches (keyword-groups, phrase-occurrences, or regex-matches). Equals GET /api/search?filter=<path> total_matches when the scan is not truncated."
                },
                example: "/api/search?q=meditation&limit=5"
            },
            "/api/files": {
                method: "GET",
                description: "List all document filenames in the library. names maps every key to a human title (source-config displayNames overrides, else derived from the filename — DOC-030). kinds is the declared kind per key (DOC-034); series the canonical series id, suffix/punctuation-insensitive (DOC-031/032); variants the duplicate/derivation links with reverse linked_by (DOC-021/035); incomplete_series the known gaps (DOC-033). transcript_normalisation lists lecture keys tagged raw_asr (period density below the DOC-018 band) plus the normalisation version, and starts_abruptly for lectures whose body opens mid-clause (DOC-053).",
                example: "/api/files"
            },
            "/api/read/:filename": {
                method: "GET",
                description: "Read the full content of a specific document. title is the human name when one is configured. kind is the declared catalogue kind, series the canonical series id, variants the duplicate/derivation links (DOC-021/032/034/035). Books include a chapters array ({number, title, offset}) when headings were found. Lectures also include normalisationVersion, periodDensity, and transcriptTag (normal | raw_asr); raw_asr lectures include word-count chunks for non-sentence chunking. startsAbruptly is true when the served body opens mid-clause (Part N is not a clean cut — DOC-053).",
                example: "/api/read/Worry,_Fear,_and_Anxiety_enxautogen_html"
            },
            "/api/rag": {
                method: "POST",
                description: "RAG endpoint — returns relevant book excerpts using vector similarity search (embedding-based). Requires the optional RAG service (Docker Compose profile \"rag\"); when it is not running, the RAG endpoints return 503 JSON with a hint instead of hanging or proxying a dead connection. Related proxies with the same availability: POST /api/rag/context (LLM context block), POST /api/calibrate (Map-of-Consciousness calibration context), GET /api/rag/sources.",
                body: {
                    query: "Required. The search query.",
                    sources: "Optional. Array of source filenames to filter (e.g. ['Book1.txt']). Non-arrays or non-string entries return 400.",
                    top_k: "Optional. Number of results to return (default: 8). Must be an integer 1-100, else 400."
                },
                response: {
                    query: "The query string",
                    results: [{ chunk: { source: "example-source.txt", text: "chunk text..." }, score: "relevance score" }],
                    total: "Number of results"
                },
                example: '{"query": "What is non-duality?", "top_k": 5}'
            },
            "/api/health/deps": {
                method: "GET",
                description: "Dependency health report — always 200 (it is a report, not a liveness probe; /api/health remains the uptime endpoint, and a missing optional dependency does not mark the API unhealthy). body.status is 'ok' or 'degraded'; body.dependencies.rag describes the vector-search service: status ('up' | 'down' | 'unknown'), endpoint, detail (last error), last_checked. Never rate limited.",
                example: "/api/health/deps"
            },
            "/api/version": {
                method: "GET",
                description: "Public build identity for the end-user changelog. Returns sha, shortSha, deployedAt, versionLabel, and packageVersion. Prefers env BUILD_SHA / DEPLOYED_AT (aliases DOCDOCGO_GIT_SHA / DOCDOCGO_DEPLOYED_AT) over committed build-info.json.",
                example: "/api/version"
            },
            "/api/changelog": {
                method: "GET",
                description: "Plain-language changelog entries for non-technical readers. Each entry has date, title, before, and now.",
                example: "/api/changelog"
            }
        },
        rate_limiting: {
            limit: `${RATE_LIMIT_MAX} requests per ${RATE_LIMIT_WINDOW_MS / 60000} minutes per client IP (live values; env-tunable via RATE_LIMIT_MAX and RATE_LIMIT_WINDOW_MS)`,
            over_limit: "HTTP 429 JSON: error, message, retry_after_seconds, limit, window_ms, hint, docs. RateLimit-* and Retry-After headers set. Clients: wait retry_after_seconds before retrying (back off on repeats) and space out bulk queries.",
            exempt: "/api/health, /api/health/deps",
            internal_token: "Least-privilege exemption for internal tools (e.g. Friendbot): send header X-Internal-Token with the value of env INTERNAL_API_TOKEN to skip the per-IP limiter (constant-time compared, never committed, never echoed). When INTERNAL_API_TOKEN is unset, no internal exemption is active — every caller is rate-limited per IP, so public IP abuse protection is never weakened by an unset env. Loopback and docker-network sources are not exempt on their own."
        },
        notes: {
            html_queries: "Queries are matched literally as plain text. HTML-like queries (e.g. `<script>`) are not stripped or sanitized — the corpus contains no HTML markup, so such queries return 0 matches. Results are always plain text.",
            validation: "q must be a single string (duplicate params return 400); limit must be an integer 1-1000 (else 400); useRegex=true with an invalid pattern returns 400; page values below 1 normalize to 1; an offset parameter returns 400 (paginate with page and limit).",
            counting: "What total_matches counts is stated by count_basis in every response: 'keyword-groups' (default multi-word mode: proximity windows over word hits — one result per group, so a query like 'This is Audible' reports thousands of groups), 'phrase-occurrences' (quoted-phrase mode: actual occurrences of the literal phrase), or 'regex-matches'. Multi-word keyword responses also carry phrase_match_count — how often the exact phrase (folded, whitespace-flexible) actually occurs. truncated:true means the 20,000-result cap or the time budget stopped the scan early. Each result carries match_count (this group only: query words, or 1 in phrase/regex) and doc_match_count (this document's total in the same search). doc_counts lists every matching document with that total so ranking does not require paging.",
            errors: "Unknown /api/* paths return 404 JSON {error, path, docs}. Known /api paths hit with the wrong method return 405 JSON with an Allow header listing the verbs the route accepts. These never use Express's HTML error page."
        },
        docs: "/api/docs"
    });
});

/**
 * GET /api/files - List all documents
 */
app.get('/api/files', (req, res) => {
    const allFiles = [...new Set([
        ...Object.keys(the_json_obj),
        ...Object.keys(the_json_obj_books)
    ])];
    const names = {};
    for (const f of allFiles) {
        const n = displayName(f);
        if (n) names[f] = n;
    }
    const rawAsr = [];
    const startsAbruptly = [];
    for (const [k, meta] of Object.entries(lectureMeta)) {
        if (meta && meta.transcriptTag === 'raw_asr') rawAsr.push(k);
        if (meta && meta.startsAbruptly) startsAbruptly.push(k);
    }
    rawAsr.sort();
    startsAbruptly.sort();
    // Catalogue metadata (DOC-021/031/032/034/035): kinds, canonical series
    // ids, variant links (with derived reverse `linked_by`), incomplete series.
    const series = {};
    for (const f of allFiles) series[f] = seriesId(f);
    const variants = {};
    for (const f of allFiles) {
        const v = variantInfo(f);
        if (v) variants[f] = v;
    }
    res.json({
        files: allFiles,
        names,
        count: allFiles.length,
        kinds: catalogueKinds,
        series,
        variants,
        incomplete_series: incompleteSeries,
        transcript_normalisation: {
            version: NORMALISATION_VERSION,
            period_density_band: [PERIOD_DENSITY_MIN, PERIOD_DENSITY_MAX],
            raw_asr_count: rawAsr.length,
            raw_asr: rawAsr,
            starts_abruptly: startsAbruptly
        },
        docs: "/api/docs"
    });
});

/**
 * GET /api/read/:filename - Get content of a specific file
 */
app.get('/api/read/:fileName', (req, res) => {
    const fileName = req.params.fileName;

    // Security check: shared corpus-key charset — FILE_KEY_RE in lecture-text.js
    // (alphanumeric, underscore, comma, hyphen, '&'; the six legacy '&' titles
    // are the reason '&' is allowed). Also used by /api/quote below.
    if (!FILE_KEY_RE.test(fileName)) {
        return res.status(400).json({
            error: 'Invalid filename format',
            docs: "/api/docs"
        });
    }

    const resolvedName = resolveSourceKey(fileName);
    const content = the_json_obj[resolvedName] || the_json_obj_books[fileName] || the_json_obj_books[resolvedName];
    if (content) {
        const body = {
            path: resolvedName,
            title: displayName(resolvedName) || displayName(fileName) || undefined,
            content,
            chapters: bookChapterMap[resolvedName] || bookChapterMap[fileName] || [],
            // Catalogue metadata (DOC-032/034/035): declared kind, canonical
            // series id, variant links for this document. Prefer resolvedName
            // so DOC-032 lecture-key aliases still surface catalogue fields.
            kind: catalogueKinds[resolvedName] || catalogueKinds[fileName] || undefined,
            series: seriesId(resolvedName),
            variants: variantInfo(resolvedName) || variantInfo(fileName),
            docs: "/api/docs"
        };
        // DOC-018: lecture transcripts carry normalisation metadata. raw_asr
        // lectures also expose word-count chunks (no sentence punctuation).
        const meta = lectureMeta[resolvedName] || lectureMeta[fileName];
        if (meta) {
            body.normalisationVersion = meta.normalisationVersion;
            body.periodDensity = meta.periodDensity;
            body.transcriptTag = meta.transcriptTag;
            if (meta.startsAbruptly) body.startsAbruptly = true;
            if (meta.transcriptTag === 'raw_asr') {
                body.chunkWordSize = meta.chunkWordSize;
                body.chunks = meta.chunks;
            }
        }
        res.json(body);
    } else {
        res.status(404).json({
            error: 'File not found',
            docs: "/api/docs"
        });
    }
});

/**
 * GET /api/quote/:fileName?p=<prefix>&n=<len> — resolve a shareable quote link.
 *
 * No database: the anchor is derived from the text itself. A quote link is
 *   /se/?read=<path>#q-<prefix>-<len>
 * where <prefix> is the first ~24 chars of the whitespace-collapsed lowercase
 * quote and <len> is its normalized length. This endpoint re-derives the quote
 * by locating the prefix in the served text (same overlays + hotwords as
 * /api/read), so links keep working after minor corpus edits: the prefix is
 * retried at 4-char shorter lengths before giving up.
 *
 * Returns the resolved quote in original casing plus surrounding context.
 */
function normalizeWithMap(s) {
    const norm = [];
    const map = [];
    let prevSpace = false;
    for (let i = 0; i < s.length; i++) {
        const c = s[i];
        if (/\s/.test(c)) {
            if (!prevSpace) {
                norm.push(' ');
                map.push(i);
                prevSpace = true;
            }
        } else {
            norm.push(c.toLowerCase());
            map.push(i);
            prevSpace = false;
        }
    }
    return { norm: norm.join(''), map };
}

app.get('/api/quote/:fileName', (req, res) => {
    const fileName = req.params.fileName;
    // Same shared corpus-key charset as /api/read (FILE_KEY_RE, lecture-text.js).
    if (!FILE_KEY_RE.test(fileName)) {
        return res.status(400).json({ error: 'Invalid filename format', docs: '/api/docs' });
    }
    const resolvedName = resolveSourceKey(fileName);
    const content = the_json_obj[resolvedName] || the_json_obj_books[fileName] || the_json_obj_books[resolvedName];
    if (!content) {
        return res.status(404).json({ error: 'File not found', docs: '/api/docs' });
    }
    const prefixRaw = String(req.query.p || '');
    const nRaw = req.query.n === undefined ? '' : String(req.query.n);
    if (prefixRaw.length < 4) {
        return res.status(400).json({ error: 'missing or too-short quote prefix (?p= at least 4 chars)', docs: '/api/docs' });
    }
    let n = null;
    if (nRaw !== '') {
        n = parseInt(nRaw, 10);
        if (!Number.isFinite(n) || n < 4 || n > 40000) {
            return res.status(400).json({ error: 'bad quote length (?n= must be 4..40000)', docs: '/api/docs' });
        }
    }
    const { norm, map } = normalizeWithMap(content);
    let idx = -1;
    for (let plen = prefixRaw.length; plen >= 4; plen -= 4) {
        idx = norm.indexOf(prefixRaw.slice(0, plen));
        if (idx !== -1) {
            break;
        }
    }
    if (idx === -1) {
        return res.status(404).json({ error: 'quote not found in this text', path: fileName, docs: '/api/docs' });
    }
    const origStart = map[idx];
    let origEnd;
    if (n === null) {
        origEnd = content.length;
    } else {
        const lastNormIdx = Math.min(map.length - 1, idx + n - 1);
        origEnd = Math.min(content.length, map[lastNormIdx] + 1);
    }
    const quote = content.slice(origStart, origEnd);
    const CONTEXT = 160;
    const before = content.slice(Math.max(0, origStart - CONTEXT), origStart);
    const after = content.slice(origEnd, Math.min(content.length, origEnd + CONTEXT));
    res.json({
        path: fileName,
        quote,
        index: origStart,
        length: origEnd - origStart,
        before,
        after,
        docs: '/api/docs'
    });
});

/**
 * Keyword-mode relevance (DOC-043). Unique query words dominate; a 1-word
 * group can never outrank a 2-word group. Per-doc frequency breaks the
 * single-keyword all-score-3 tie. Proximity is a damped remainder.
 *
 *   score = matchCount * 3 + log(1 + docGroups) / 10 + proximityBonus
 *
 * proximityBonus is 0.5 for an exact phrase of all query words inside the
 * group span, else 0.4 * (1 - min(span, 2000) / 2000).
 */
function keywordRelevanceScore(matchCount, proximity, isExactPhrase, docGroups) {
    const freqBonus = Math.log1p(docGroups) / 10;
    const proximityBonus = isExactPhrase
        ? 0.5
        : Math.max(0, 0.4 * (1.0 - (Math.min(proximity, 2000) / 2000)));
    return parseFloat((matchCount * 3 + freqBonus + proximityBonus).toFixed(4));
}

function compareKeywordMatches(a, b, shuffleIndex) {
    if (Math.abs(b.score - a.score) > 0.001) return b.score - a.score;
    const ag = a.docGroups || 0;
    const bg = b.docGroups || 0;
    if (bg !== ag) return bg - ag;
    if (a.proximity !== b.proximity) return a.proximity - b.proximity;
    const pathCmp = a.path.localeCompare(b.path);
    if (pathCmp) return pathCmp;
    if (a.offset !== b.offset) return a.offset - b.offset;
    if (shuffleIndex) {
        return (shuffleIndex.get(a.path + ':' + a.offset) || 0)
            - (shuffleIndex.get(b.path + ':' + b.offset) || 0);
    }
    return 0;
}

/**
 * GET /api/search - Search with relevance scoring + tier-based shuffling
 *
 * Scoring formula (keyword mode, DOC-043):
 *   score = match_count * 3 + log(1 + doc_groups) / 10 + proximity_bonus
 *
 * - match_count: unique query words in the group (dominates frequency/proximity)
 * - doc_groups: keyword-groups in that document (frequency; breaks single-word ties)
 * - proximity_bonus: 0.5 exact phrase of all query words, else damped by span
 *
 * Stop words (common English words) are filtered out of the matching regex
 * to prevent high-frequency words like "the" from diluting results.
 * Results are grouped into tiers by score, then shuffled within a tier only
 * after docGroups/path/offset tie-breaks (near-equal scores, deterministic).
 */
app.get('/api/search', async (req, res) => {
    const rawQuery = req.query.q;
    if (!rawQuery) {
        return res.status(400).json({
            error: 'Missing query parameter "q"',
            docs: "/api/docs"
        });
    }
    if (typeof rawQuery !== 'string') {
        // Duplicate params (?q=a&q=b) arrive as an array, nested (?q[x]=y) as an
        // object; neither is searchable. Reject instead of crashing on .replace.
        return res.status(400).json({
            error: 'Parameter "q" must be a single string',
            docs: "/api/docs"
        });
    }

    // Keep the query exactly as the client sent it. A global comma strip here
    // used to corrupt regex quantifier ranges (a{2,3} compiled as a{23}) and
    // character classes, and made the echoed query differ from what was typed.
    // Literal (non-regex) mode splits tokens on whitespace AND commas below, so
    // keyword matching and stop-word filtering keep their previous behavior,
    // while exact-phrase detection now honors commas in real text.
    const query = rawQuery;

    // Aliases: camelCase (docs) and short names both accepted.
    const contextRaw = req.query.context ?? req.query.contextChars;
    const contextChars = Math.max(0, parseInt(contextRaw, 10) || 300);
    const limitRaw = req.query.limit ?? req.query.max;
    let maxResults = 100;
    if (limitRaw !== undefined) {
        const parsedLimit = parseInt(limitRaw, 10);
        if (!Number.isInteger(parsedLimit) || parsedLimit < 1 || parsedLimit > 1000) {
            return res.status(400).json({
                error: 'Parameter "limit" must be an integer between 1 and 1000',
                docs: "/api/docs"
            });
        }
        maxResults = parsedLimit;
    }
    if (Object.prototype.hasOwnProperty.call(req.query, 'offset')) {
        // DOC-045: offset is not a pagination param (page + limit are).
        // Reject instead of silently ignoring — unknown filter values already 400.
        return res.status(400).json({
            error: 'Parameter "offset" is not supported; use "page" and "limit" to paginate',
            docs: '/api/docs'
        });
    }
    const filter = req.query.filter || 'all';
    const caseSensitive = String(req.query.caseSensitive ?? req.query.case ?? 'false') === 'true';
    const wholeWords = String(req.query.wholeWords ?? req.query.whole ?? 'true') !== 'false';
    const useRegex = String(req.query.useRegex ?? req.query.regex ?? 'false') === 'true';
    // DOC-009: reject unknown filters before short-query / stopword early
    // returns, so typos never look like an empty library (filter-before-short-gate).
    {
        const namedFilters = declaredNamedFilters();
        if (!namedFilters.includes(filter) && !isKnownSourceKey(filter)) {
            return res.status(400).json({
                error: `Invalid filter '${filter}'`,
                valid_filters: namedFilters,
                hint: 'Use a named filter from valid_filters, or an exact source key from /api/files',
                docs: '/api/docs'
            });
        }
    }
    // Normalize page: 0, negatives, and non-numbers all become page 1. Large
    // valid pages stay as-is and simply return empty results past the last page.
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    // groupDistance is independent of context padding (large context must not chain distant hits).
    const groupDistanceRaw = parseInt(req.query.groupDistance ?? req.query.group, 10);
    const groupDistance = Number.isFinite(groupDistanceRaw) && groupDistanceRaw > 0
        ? groupDistanceRaw
        : 250;

    if (useRegex) {
        // Validate the pattern up front: an invalid regex previously fell
        // through to the outer catch and surfaced as a 500 (or was silently
        // masked by the min-length early return below).
        try {
            new RegExp(query, 'g');
        } catch (e) {
            return res.status(400).json({
                error: 'Invalid regular expression: ' + e.message,
                docs: "/api/docs"
            });
        }
    }

    if (query.trim().length < 3) {
        // Min-length gate: 1-2 character queries are noise-prone and stay
        // empty — EXCEPT when the query contains punctuation or non-ASCII
        // characters (", é, —, ’): those are legitimate targeted searches
        // that were silently swallowed before (DOC-007). Note: regex
        // patterns containing a literal " were never mangled — a bare "
        // only failed this gate (\x22 passed it).
        const shortQuery = query.trim();
        if (!/[^\sA-Za-z0-9]/.test(shortQuery)) {
            // DOC-004: short stopword-only queries (q=of, q=to) should still
            // name the ignored terms instead of looking like an empty library.
            const shortWords = shortQuery.match(/\d[\d,]*\d|\d|[^\s,]+/g) || [];
            const shortAllStop = shortWords.length > 0
                && shortWords.every((w) => STOP_WORDS.has(w.toLowerCase()));
            const ignoredTerms = shortAllStop
                ? [...new Set(shortWords.map((w) => w.toLowerCase()))]
                : null;
            return res.json({
                query,
                search_mode: useRegex ? 'regex' : 'keywords',
                count_basis: useRegex ? 'regex-matches' : 'keyword-groups',
                total_matches: 0,
                files_count: 0,
                page,
                limit: maxResults,
                total_pages: 0,
                options: { contextChars, groupDistance, maxResults, filter, caseSensitive, wholeWords, useRegex },
                ...(ignoredTerms && {
                    ignored_terms: ignoredTerms,
                    notice: `All query terms were ignored as stop words: ${ignoredTerms.join(', ')}. Add a content word to search.`
                }),
                results: [],
                doc_counts: [],
                docs: "/api/docs"
            });
        }
    }

    logger.info(`[SEARCH] Query: "${query}", filter: ${filter}, limit: ${maxResults}`);

    try {
        let allMatches = [];
        let searchData = {};
        const searchStart = Date.now();
        let truncated = false;
        const truncationReasons = [];
        const markTruncated = (reason) => {
            truncated = true;
            if (!truncationReasons.includes(reason)) truncationReasons.push(reason);
        };
        // How total_matches is counted for this response (DOC-006): phrase
        // occurrences, keyword proximity-groups, or raw regex matches.
        let searchMode = useRegex ? 'regex' : 'keywords';
        // Phrase reporting (DOC-006), filled in by the keyword branch below:
        // parsed quoted phrases echoed on hybrid responses, plus the
        // exact-phrase occurrence count that keeps keyword-group totals
        // honest.
        let phrasesEcho = null;
        let countReferencePhrase = false;
        let phraseMatchCount = 0;
        let phraseCountCapped = false;
        let phraseCountPartial = false;
        // Time-budget check shared by both scan modes. Sets `truncated` only
        // when the budget is actually exceeded (short-circuit keeps normal
        // results un-touched).
        const overBudget = () => {
            if (Date.now() - searchStart > SEARCH_BUDGET_MS) {
                markTruncated(`the ${SEARCH_BUDGET_MS}ms time budget`);
                return true;
            }
            return false;
        };

        // Determine what to search - same logic as all-merged-books-serch.html
        // Named filters come from source-config.json filterOptions (DOC-009).
        const namedFilters = declaredNamedFilters();
        if (filter === 'all') {
            Object.assign(searchData, the_json_obj, the_json_obj_books);
        } else if (filter === 'books') {
            // DOC-034: membership derives from declared kinds, never title presence.
            if (useKindFilters) {
                for (const [key, kind] of Object.entries(catalogueKinds)) {
                    if (KIND_BOOKS.has(kind) && the_json_obj_books[key]) searchData[key] = the_json_obj_books[key];
                }
            } else searchData = { ...the_json_obj_books };
        } else if (filter === 'all-hawkins-books') {
            // Hawkins books from declared kinds (includes Book of Slides per DOC-009 owner decision)
            if (useKindFilters) {
                for (const [key, kind] of Object.entries(catalogueKinds)) {
                    if (KIND_HAWKINS_BOOKS.has(kind) && the_json_obj_books[key]) searchData[key] = the_json_obj_books[key];
                }
            } else for (const key of sourceConfig.categories.hawkinsBooks) {
                if (the_json_obj_books[key]) searchData[key] = the_json_obj_books[key];
            }
        } else if (filter === 'lectures') {
            if (useKindFilters) {
                for (const [key, kind] of Object.entries(catalogueKinds)) {
                    if (!KIND_BOOKS.has(kind) && the_json_obj[key]) searchData[key] = the_json_obj[key];
                }
            } else searchData = { ...the_json_obj };
        } else if (isKnownSourceKey(filter)) {
            const resolvedFilter = resolveSourceKey(filter);
            if (the_json_obj[resolvedFilter]) searchData[resolvedFilter] = the_json_obj[resolvedFilter];
            if (the_json_obj_books[filter]) searchData[filter] = the_json_obj_books[filter];
            if (the_json_obj_books[resolvedFilter]) searchData[resolvedFilter] = the_json_obj_books[resolvedFilter];
        } else {
            // Unknown named filter / typo — 400 with the declared taxonomy (DOC-009).
            // Exact source keys remain valid; only values outside both lists error.
            return res.status(400).json({
                error: `Invalid filter '${filter}'`,
                valid_filters: namedFilters,
                hint: 'Use a named filter from valid_filters, or an exact source key from /api/files',
                docs: '/api/docs'
            });
        }

        const flags = caseSensitive ? 'g' : 'gi';
        // Literal-mode patterns are generated (escaped + folded + \p{...}
        // lookarounds), so they can and must use the 'u' flag. User-supplied
        // regex patterns keep the plain flags — 'u' would change their
        // semantics and reject valid patterns.
        const literalFlags = caseSensitive ? 'gu' : 'giu';
        const literalTestFlags = caseSensitive ? 'u' : 'iu';

        if (useRegex) {
            // DOC-040: user regex runs in ONE worker for the whole corpus so
            // nested-quantifier ReDoS cannot pin the event loop, and a cheap
            // pattern (q=") is not killed by per-file worker spawn cost.
            const regexEntries = Object.entries(searchData);
            const remaining = SEARCH_BUDGET_MS - (Date.now() - searchStart);
            const bounded = await execRegexBoundedMany(
                query, flags, regexEntries.map(([, content]) => content), remaining, 20000
            );
            if (bounded.timedOut) {
                markTruncated(`the ${SEARCH_BUDGET_MS}ms time budget`);
            } else {
                for (let i = 0; i < regexEntries.length; i++) {
                    const [fileName, content] = regexEntries[i];
                    const hits = (bounded.docs && bounded.docs[i]) || [];
                    for (const match of hits) {
                        const start = Math.max(0, match.index - contextChars);
                        const end = Math.min(content.length, match.index + match.text.length + contextChars);
                        const snippet = content.substring(start, end);
                        const chapterTitle = getChapterLabel(fileName, match.index);
                        allMatches.push({
                            path: fileName,
                            offset: match.index,
                            match_text: [match.text],
                            snippet: `${start > 0 ? '...' : ''}${snippet.replace(/\s+/g, ' ')}${end < content.length ? '...' : ''}`,
                            score: 1,
                            proximity: match.text.length,
                            ...(chapterTitle && { chapter: chapterTitle })
                        });
                        if (allMatches.length >= 20000) { markTruncated('the 20,000-result cap'); break; }
                    }
                    if (allMatches.length >= 20000) break;
                }
            }
        } else if (extractQuotedPhrases(query) && extractQuotedPhrases(query).phrases.length === 1 && extractQuotedPhrases(query).remainder.trim() === '') {
            // --- Phrase mode (DOC-006) ---
            // A query that is exactly one balanced double-quoted span
            // ("Heal Your Life", “This is Audible”) searches for the literal
            // phrase: folded, whitespace-flexible, word-wrapped per
            // wholeWords — and total_matches counts PHRASE OCCURRENCES, not
            // keyword groups. Stop words inside the phrase are honoured (it
            // is a literal string match). Results keep natural corpus order.
            const phrase = extractQuotedPhrases(query).phrases[0];
            const phraseRegex = new RegExp(phrasePattern(phrase, wholeWords), literalFlags);
            logger.debug(`[SEARCH] Phrase search: "${phrase}"`);
            Object.entries(searchData).forEach(([fileName, content]) => {
                if (allMatches.length >= 20000) { markTruncated('the 20,000-result cap'); return; }
                if (overBudget()) return;
                let match;
                while ((match = phraseRegex.exec(content)) !== null) {
                    if (overBudget()) break;
                    const start = Math.max(0, match.index - contextChars);
                    const end = Math.min(content.length, match.index + match[0].length + contextChars);
                    const snippet = content.substring(start, end);
                    const chapterTitle = getChapterLabel(fileName, match.index);
                    allMatches.push({
                        path: fileName,
                        offset: match.index,
                        match_text: [match[0]],
                        snippet: `${start > 0 ? '...' : ''}${snippet.replace(/\s+/g, ' ')}${end < content.length ? '...' : ''}`,
                        score: 1,
                        proximity: match[0].length,
                        ...(chapterTitle && { chapter: chapterTitle })
                    });
                    if (allMatches.length >= 20000) { markTruncated('the 20,000-result cap'); break; }
                    if (match.index === phraseRegex.lastIndex) phraseRegex.lastIndex++;
                }
            });
            searchMode = 'phrase';
        } else {
            // Keyword mode (possibly hybrid: quoted phrases + keywords).
            // Balanced double-quoted spans act as required exact phrases
            // (DOC-006); a lone " stays a literal search character.
            const quoted = extractQuotedPhrases(query);
            const phrases = quoted ? quoted.phrases : [];
            const tokenSource = quoted ? quoted.remainder : query;

            // Tokenize for keyword matching: whitespace and commas separate
            // tokens (keyword matching stays comma-blind, and comma-attached
            // stop words like "the," are still recognized) — EXCEPT a comma
            // flanked by digits, which stays inside the token so formatted
            // numbers ("1,000", "100,000") search as one unit instead of
            // exploding into junk tokens ("1" + "000").
            const allWords = tokenSource.match(/\d[\d,]*\d|\d|[^\s,]+/g) || [];
            if (allWords.length === 0 && phrases.length === 0) {
                return res.json({
                    query,
                    search_mode: 'keywords',
                    count_basis: 'keyword-groups',
                    total_matches: 0,
                    files_count: 0,
                    page,
                    limit: maxResults,
                    total_pages: 0,
                    options: { contextChars, groupDistance, maxResults, filter, caseSensitive, wholeWords, useRegex },
                    results: [],
                    doc_counts: [],
                    docs: "/api/docs"
                });
            }

            // Filter out stop words from matching (but keep for exact phrase detection).
            // All-stop-word queries used to fall back to scanning "the"/"for" across
            // the corpus; that is just noise and burns the search budget.
            // Quoted phrases bypass the stop-word filter — they are literal
            // strings, and "This is Audible" must match "This is Audible".
            const stopWordFilter = (w) => !STOP_WORDS.has(w.toLowerCase());
            const matchWords = allWords.filter(stopWordFilter);
            if (matchWords.length === 0 && phrases.length === 0) {
                // DOC-004: all tokens were stop words — name them so clients
                // don't read this as an empty library.
                const ignoredTerms = [...new Set(allWords.map((w) => w.toLowerCase()))];
                return res.json({
                    query,
                    search_mode: 'keywords',
                    count_basis: 'keyword-groups',
                    total_matches: 0,
                    files_count: 0,
                    page,
                    limit: maxResults,
                    total_pages: 0,
                    options: { contextChars, groupDistance, maxResults, filter, caseSensitive, wholeWords, useRegex },
                    ignored_terms: ignoredTerms,
                    notice: `All query terms were ignored as stop words: ${ignoredTerms.join(', ')}. Add a content word to search.`,
                    results: [],
                    doc_counts: [],
                    docs: "/api/docs"
                });
            }

            // Per-token matchers: escaped, typographically folded (’↔', “”↔",
            // —/–↔-), and Unicode-aware whole-word wrapped (DOC-007/008).
            const wordRegexes = matchWords.map(w => new RegExp(tokenPattern(w, wholeWords), literalTestFlags));
            // Stateless .test versions for doc selection; global versions
            // for occurrence scanning (a non-global exec loops forever on
            // the same first match).
            const phraseRegexes = phrases.map(p => new RegExp(phrasePattern(p, wholeWords), literalTestFlags));
            const phraseGlobalRegexes = phrases.map(p => new RegExp(phrasePattern(p, wholeWords), literalFlags));

            logger.debug(`[SEARCH] Ranked multi-word search with words: [${matchWords.join(', ')}]${phrases.length ? ` + phrases: [${phrases.map(p => `"${p}"`).join(', ')}]` : ''}`);

            // Keyword occurrences are scanned per-token below (with wordIdx tags).
            // Do not build a combined RegExp('') — empty matchWords (hybrid whose
            // remainder is all stopwords, e.g. "Heal Your Life" the) would match
            // the empty string at every index.

            // Reference phrase for anchoring, the exact-phrase score bonus,
            // and the phrase_match_count report (DOC-006): the first quoted
            // phrase when quotes are present, otherwise the trimmed query.
            const referencePhrase = phrases.length ? phrases[0] : query.trim();
            const referencePattern = phrasePattern(referencePhrase, wholeWords);
            const referenceRegex = new RegExp(referencePattern, literalFlags);
            const anchorRegex = new RegExp(referencePattern, literalTestFlags);
            // Report the exact-phrase count whenever the reference phrase
            // spans multiple tokens — that is where keyword-group counts
            // mislead ("This is Audible" → 20,023 groups vs a handful of
            // actual phrase occurrences).
            const referenceTokens = referencePhrase.match(/\S+/g) || [];
            countReferencePhrase = referenceTokens.length >= 2;
            phrasesEcho = phrases.length ? phrases : null;

            // Group documents by score (number of unique words matched).
            // A doc containing the phrase necessarily contains one of its
            // words, so phrase-only qualification cannot miss docs here.
            // The exact-phrase count (DOC-006) is ALSO computed here, over
            // the complete set of matched docs, BEFORE result collection:
            // the 20,000-result cap skips remaining docs during snippet
            // collection, and that must not undercount the phrase total.
            const matchedDocs = [];
            Object.entries(searchData).forEach(([fileName, content]) => {
                if (overBudget()) {
                    if (countReferencePhrase) phraseCountPartial = true;
                    return; // time budget: stop collecting docs
                }
                const matchedWords = matchWords.filter((w, i) => wordRegexes[i].test(content));
                const hasPhrase = phraseRegexes.some(re => re.test(content));
                // Hybrid (phrases + keywords): doc must contain every quoted phrase
                // AND every unquoted keyword. Phrase-only / keyword-only stay OR.
                const hybrid = phrases.length > 0 && matchWords.length > 0;
                const hasAllPhrases = !phrases.length || phraseRegexes.every(re => re.test(content));
                const hasAllKeywords = !matchWords.length || matchedWords.length === matchWords.length;
                const docOk = hybrid
                    ? (hasAllPhrases && hasAllKeywords)
                    : (matchedWords.length > 0 || hasPhrase);
                if (docOk) {
                    matchedDocs.push({ fileName, content, docMatchedWords: matchedWords });
                    if (countReferencePhrase && !phraseCountCapped && !phraseCountPartial) {
                        while (referenceRegex.exec(content) !== null) {
                            phraseMatchCount++;
                            if (phraseMatchCount >= 20000) { phraseCountCapped = true; break; }
                            if (overBudget()) { phraseCountPartial = true; break; }
                        }
                    }
                }
            });

            // Find all snippets in matched documents and group matches that are close to each other
            matchedDocs.forEach(doc => {
                if (allMatches.length >= 20000) { markTruncated('the 20,000-result cap'); return; }
                if (overBudget()) return; // time budget

                let docMatches = [];
                let match;
                // Scan per-keyword with GLOBAL flags so we can tag wordIdx
                // (hybrid group filter needs phrase AND each keyword in the group).
                matchWords.forEach((w, wi) => {
                    const re = new RegExp(tokenPattern(w, wholeWords), literalFlags);
                    while ((match = re.exec(doc.content)) !== null) {
                        if (overBudget()) break;
                        docMatches.push({
                            word: match[0],
                            offset: match.index,
                            wordIdx: wi
                        });
                        if (match.index === re.lastIndex) re.lastIndex++;
                    }
                });

                // Phrase occurrences join the same proximity grouping, tagged
                // with their phrase index so groups can be filtered below.
                // Must scan with the GLOBAL regexes — a non-global exec
                // returns the same first match forever.
                phrases.forEach((p, pi) => {
                    const pre = phraseGlobalRegexes[pi];
                    while ((match = pre.exec(doc.content)) !== null) {
                        if (overBudget()) break;
                        docMatches.push({ word: match[0], offset: match.index, phraseIdx: pi });
                        if (match.index === pre.lastIndex) pre.lastIndex++;
                    }
                });
                docMatches.sort((a, b) => a.offset - b.offset);

                // Group by groupDistance (NOT contextChars). context only pads the anchor.
                const groups = [];
                if (docMatches.length > 0) {
                    let currentGroup = [docMatches[0]];
                    for (let i = 1; i < docMatches.length; i++) {
                        const m = docMatches[i];
                        const prevM = docMatches[i - 1];
                        if (m.offset - (prevM.offset + prevM.word.length) < groupDistance) {
                            currentGroup.push(m);
                        } else {
                            groups.push(currentGroup);
                            currentGroup = [m];
                        }
                    }
                    groups.push(currentGroup);
                }

                // Phrase queries: group must contain every quoted phrase.
                // Hybrid: also every unquoted keyword (do not change keyword-only).
                const hybridMode = phrases.length > 0 && matchWords.length > 0;
                const qualifiedGroups = groups.filter(g => {
                    if (phrases.length && !phrases.every((_p, pi) => g.some(m => m.phraseIdx === pi))) return false;
                    if (hybridMode && !matchWords.every((_w, wi) => g.some(m => m.wordIdx === wi))) return false;
                    return true;
                });

                const docGroups = qualifiedGroups.length;

                // Center each snippet on exact phrase or densest keyword cluster in the group
                qualifiedGroups.forEach(group => {
                    const firstMatch = group[0];
                    const lastMatch = group[group.length - 1];
                    const groupStart = firstMatch.offset;
                    const groupEnd = lastMatch.offset + lastMatch.word.length;

                    let anchorStart = groupStart;
                    let anchorEnd = groupEnd;
                    const searchLo = Math.max(0, groupStart - Math.max(contextChars, 500));
                    const searchHi = Math.min(doc.content.length, groupEnd + Math.max(contextChars, 500));
                    const region = doc.content.slice(searchLo, searchHi);
                    // Folded, whitespace-flexible phrase anchor (was a plain
                    // toLowerCase().indexOf of the raw query — blind to ’/-
                    // variants, line breaks, and the caseSensitive option).
                    const phraseAt = anchorRegex.exec(region);
                    if (phraseAt) {
                        anchorStart = searchLo + phraseAt.index;
                        anchorEnd = anchorStart + phraseAt[0].length;
                    } else {
                        let best = null;
                        for (let i = 0; i < group.length; i++) {
                            const seen = new Set();
                            for (let j = i; j < group.length; j++) {
                                seen.add(group[j].word.toLowerCase());
                                const s = group[i].offset;
                                const e = group[j].offset + group[j].word.length;
                                const span = Math.max(1, e - s);
                                const score = seen.size * 1e9 - span;
                                if (!best || score > best.score) best = { score, start: s, end: e };
                                if (seen.size >= matchWords.length && span > 800) break;
                            }
                        }
                        if (best) {
                            anchorStart = best.start;
                            anchorEnd = best.end;
                        }
                    }

                    const start = Math.max(0, anchorStart - contextChars);
                    const end = Math.min(doc.content.length, anchorEnd + contextChars);
                    const snippetRaw = doc.content.substring(start, end);
                    const snippet = snippetRaw.replace(/\s+/g, ' ');
                    const uniqueWordsInSnippet = [...new Set(group.map(m => m.word.toLowerCase()))];
                    const matchCount = uniqueWordsInSnippet.length;

                    let proximity = Math.max(0, anchorEnd - anchorStart);
                    // Exact-phrase bonus only when the group itself holds every
                    // query word as a contiguous phrase — padded snippet context
                    // used to promote 1-word groups to score 3.0 (DOC-043).
                    const groupSlice = doc.content.slice(groupStart, groupEnd);
                    const isFullMatch = matchWords.length <= 1
                        || matchWords.every((_w, wi) => group.some(m => m.wordIdx === wi));
                    const isExactPhrase = isFullMatch && (
                        matchWords.length <= 1 || anchorRegex.test(groupSlice)
                    );
                    const relevanceScore = keywordRelevanceScore(
                        matchCount, proximity, isExactPhrase, docGroups
                    );

                    const chapterTitle = getChapterLabel(doc.fileName, anchorStart);
                    allMatches.push({
                        path: doc.fileName,
                        offset: anchorStart,
                        match_text: uniqueWordsInSnippet,
                        snippet: `${start > 0 ? '...' : ''}${snippet}${end < doc.content.length ? '...' : ''}`,
                        score: relevanceScore,
                        match_count: matchCount,
                        proximity,
                        docGroups,
                        ...(chapterTitle && { chapter: chapterTitle })
                    });
                });
            });

            // Sort by score descending before tier grouping
            allMatches.sort((a, b) => compareKeywordMatches(a, b));

            // Group into tiers by score (within 0.01 of each other)
            const tierGroups = [];
            if (allMatches.length > 0) {
                let currentTier = [allMatches[0]];
                for (let i = 1; i < allMatches.length; i++) {
                    const m = allMatches[i];
                    const prevM = allMatches[i - 1];
                    if (Math.abs(m.score - prevM.score) < 0.01) {
                        currentTier.push(m);
                    } else {
                        tierGroups.push(currentTier);
                        currentTier = [m];
                    }
                }
                tierGroups.push(currentTier);
            }

            // Shuffle within each tier using seeded PRNG for variety.
            // Score and proximity ordering is preserved; only ties are shuffled.
            // Seed excludes pagination params to ensure deterministic ordering across pages.
            const seedParams = { q: query, context: contextChars, groupDistance, filter, case: caseSensitive, whole: wholeWords, regex: useRegex };
            const shuffleSeed = hashString(JSON.stringify(seedParams));
            allMatches = [];
            for (const tier of tierGroups) {
                const shuffled = seededShuffle(tier, shuffleSeed);
                // Score and density first; seeded order is last-resort only.
                const sortOrder = new Map(shuffled.map((m, i) => [m.path + ':' + m.offset, i]));
                shuffled.sort((a, b) => compareKeywordMatches(a, b, sortOrder));
                allMatches.push(...shuffled);
            }
        }

        logger.info(`[SEARCH] Total matches found: ${allMatches.length}`);

        // Integrity check: verify sort order
        let sortIntegrity = { violations: 0, corrected: false };
        if (allMatches.length > 0) {
            for (let i = 1; i < allMatches.length; i++) {
                if (allMatches[i].score > allMatches[i - 1].score + 0.001) {
                    sortIntegrity.violations++;
                    logger.debug(`[SEARCH] Sort order violated at index ${i}: ${allMatches[i].score} > ${allMatches[i - 1].score}`);
                }
            }
        }

        // Auto-correct sort order if violations detected
        if (sortIntegrity.violations > 0) {
            logger.debug(`[SEARCH] ${sortIntegrity.violations} sort violations detected, re-sorting results`);
            allMatches.sort((a, b) => compareKeywordMatches(a, b));
            sortIntegrity.corrected = true;
        }

        // Pagination: slice after final sort (deterministic - no overlap between pages)
        const startIndex = (page - 1) * maxResults;
        const endIndex = startIndex + maxResults;
        // DOC-044: per-document totals over the whole scan (same basis as
        // total_matches), not the current page and not match_count.
        const docMatchCounts = Object.create(null);
        for (const m of allMatches) {
            docMatchCounts[m.path] = (docMatchCounts[m.path] || 0) + 1;
        }
        const doc_counts = Object.keys(docMatchCounts)
            .map((path) => ({ path, doc_match_count: docMatchCounts[path] }))
            .sort((a, b) => b.doc_match_count - a.doc_match_count || (a.path < b.path ? -1 : a.path > b.path ? 1 : 0));
        const paginatedResults = allMatches.slice(startIndex, endIndex).map((m) => decorateSearchHit(m, docMatchCounts));

        // DOC-021: group variant sources shown on this page under their
        // canonical target (or named parallel group), so the same session /
        // work no longer ranks as unrelated hits. Singleton canonicals are
        // dropped; a lone variant still points at its canonical target.
        const variantGroups = {};
        for (const m of paginatedResults) {
            const gid = variantGroupId(m.path);
            if (!gid) continue;
            variantGroups[gid] = variantGroups[gid] || [];
            if (!variantGroups[gid].includes(m.path)) variantGroups[gid].push(m.path);
        }
        for (const [gid, paths] of Object.entries(variantGroups)) {
            if (paths.length === 1) {
                const v = catalogueVariants[paths[0]];
                if (!(v && v.variant_of)) delete variantGroups[gid];
            }
        }

        res.json({
            query,
            search_mode: searchMode,
            count_basis: searchMode === 'regex' ? 'regex-matches' : (searchMode === 'phrase' ? 'phrase-occurrences' : 'keyword-groups'),
            total_matches: allMatches.length,
            files_count: doc_counts.length,
            page,
            limit: maxResults,
            total_pages: Math.ceil(allMatches.length / maxResults),
            options: { contextChars, groupDistance, maxResults, filter, caseSensitive, wholeWords, useRegex },
            results: paginatedResults,
            doc_counts,
            ...(Object.keys(variantGroups).length && { variant_groups: variantGroups }),
            ...(phrasesEcho && { phrases: phrasesEcho }),
            ...(countReferencePhrase && {
                phrase_match_count: phraseMatchCount,
                ...(phraseCountCapped && { phrase_match_count_capped: true }),
                ...(phraseCountPartial && { phrase_match_count_partial: true })
            }),
            ...(LOG_LEVEL === 'verbose' && { sort_integrity: sortIntegrity }),
            ...(truncated && { truncated: true, notice: `Search stopped early (${truncationReasons.join(' and ')}); results are partial. Use a more specific query.` }),
            docs: "/api/docs"
        });
    } catch (err) {
        res.status(500).json({ error: 'Search failed: ' + err.message });
    }
});

// --- RAG Microservice Proxy ---
// The Python RAG service (rag/rag_service.py) runs on a separate port.
// This endpoint proxies requests to it. Configuration (RAG_HOST/RAG_PORT),
// the availability cache and ragGuard() live near the top of the file,
// before the /api rate limiter, so /api/health/deps can be exempt.

// Connection-level failures mean the dependency itself is unreachable: mark
// it down so subsequent requests fast-fail (503) until the next probe,
// instead of every caller repeating the same dead connect attempt.
const RAG_UNREACHABLE_CODES = /ENOTFOUND|ECONNREFUSED|ETIMEDOUT|EAI_AGAIN/;
function markRAGDown(reason) {
    ragStatus.state = 'down';
    ragStatus.error = reason;
    ragStatus.lastChecked = Date.now();
}

function proxyToRAG(ragPath, payload, res, { timeout = 60000 } = {}) {
    const bodyStr = JSON.stringify(payload);
    const proxyReq = http.request({
        hostname: RAG_HOST,
        port: RAG_PORT,
        path: ragPath,
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(bodyStr)
        },
        timeout
    }, (proxyRes) => {
        let body = '';
        proxyRes.on('data', (chunk) => { body += chunk; });
        proxyRes.on('end', () => {
            try {
                const result = JSON.parse(body);
                res.status(proxyRes.statusCode).json(result);
            } catch (e) {
                res.status(502).json({ error: 'RAG service returned invalid JSON', dependencies: '/api/health/deps' });
            }
        });
    });

    proxyReq.on('error', (e) => {
        logger.error(`[RAG] Proxy error on ${ragPath}: ${e.message}`);
        if (RAG_UNREACHABLE_CODES.test(e.code || e.message)) markRAGDown(e.code || e.message);
        res.status(502).json({
            error: 'RAG service unavailable',
            details: e.message,
            hint: 'The RAG service dropped this request mid-flight; it was reachable moments ago. Check /api/health/deps.',
            dependencies: '/api/health/deps'
        });
    });

    proxyReq.on('timeout', () => {
        proxyReq.destroy();
        res.status(504).json({ error: 'RAG service timed out', dependencies: '/api/health/deps' });
    });

    proxyReq.write(bodyStr);
    proxyReq.end();
}

function proxyGetFromRAG(ragPath, res, { timeout = 10000 } = {}) {
    const proxyReq = http.request({
        hostname: RAG_HOST,
        port: RAG_PORT,
        path: ragPath,
        method: 'GET',
        timeout
    }, (proxyRes) => {
        let body = '';
        proxyRes.on('data', (chunk) => { body += chunk; });
        proxyRes.on('end', () => {
            try {
                const result = JSON.parse(body);
                res.status(proxyRes.statusCode).json(result);
            } catch (e) {
                res.status(502).json({ error: 'RAG service returned invalid JSON', dependencies: '/api/health/deps' });
            }
        });
    });

    proxyReq.on('error', (e) => {
        logger.error(`[RAG] Proxy error on ${ragPath}: ${e.message}`);
        if (RAG_UNREACHABLE_CODES.test(e.code || e.message)) markRAGDown(e.code || e.message);
        res.status(502).json({
            error: 'RAG service unavailable',
            details: e.message,
            dependencies: '/api/health/deps'
        });
    });

    // The `timeout` option alone does NOT abort a request — without this
    // handler a silent RAG would hang the proxy (and the caller) forever.
    proxyReq.on('timeout', () => {
        proxyReq.destroy();
        res.status(504).json({ error: 'RAG service timed out', dependencies: '/api/health/deps' });
    });

    proxyReq.end();
}

app.post('/api/rag', (req, res) => {
    const { query, sources, top_k } = req.body;

    if (!query) {
        return res.status(400).json({ error: "Missing 'query' field" });
    }
    if (typeof query !== 'string') {
        return res.status(400).json({ error: "'query' must be a string" });
    }
    if (query.length > MAX_QUERY_LENGTH) {
        return res.status(400).json({ error: `Query too long (max ${MAX_QUERY_LENGTH} characters)` });
    }
    if (sources !== undefined && sources !== null && (!Array.isArray(sources) || !sources.every((s) => typeof s === 'string'))) {
        return res.status(400).json({ error: "'sources' must be an array of source filenames" });
    }
    if (top_k !== undefined && top_k !== null && (!Number.isInteger(top_k) || top_k < 1 || top_k > 100)) {
        return res.status(400).json({ error: "'top_k' must be an integer between 1 and 100" });
    }

    const payload = {
        query,
        sources: sources || null,
        top_k: top_k || 8
    };

    logger.info(`[RAG] Query: "${query.substring(0, 100)}", sources: ${sources ? sources.join(', ') : 'all'}, top_k: ${top_k || 8}`);
    ragGuard(res, () => proxyToRAG('/search', payload, res));
});

// --- RAG Context Proxy ---
// Returns context block + system instructions for LLM generation
app.post('/api/rag/context', (req, res) => {
    const { query, sources, top_k, mode } = req.body;

    if (!query) {
        return res.status(400).json({ error: "Missing 'query' field" });
    }
    if (typeof query !== 'string') {
        return res.status(400).json({ error: "'query' must be a string" });
    }
    if (query.length > MAX_QUERY_LENGTH) {
        return res.status(400).json({ error: `Query too long (max ${MAX_QUERY_LENGTH} characters)` });
    }
    if (sources !== undefined && sources !== null && (!Array.isArray(sources) || !sources.every((s) => typeof s === 'string'))) {
        return res.status(400).json({ error: "'sources' must be an array of source filenames" });
    }
    if (top_k !== undefined && top_k !== null && (!Number.isInteger(top_k) || top_k < 1 || top_k > 100)) {
        return res.status(400).json({ error: "'top_k' must be an integer between 1 and 100" });
    }

    const payload = {
        query,
        sources: sources || null,
        top_k: top_k || 5,
        mode: mode || "default"
    };

    logger.info(`[RAG Context] Query: "${query.substring(0, 100)}", mode: ${mode || 'default'}`);
    ragGuard(res, () => proxyToRAG('/context', payload, res));
});

// --- Calibrate Endpoint ---
// Calibrate text against the Map of Consciousness using RAG context
app.post('/api/calibrate', (req, res) => {
    const { text } = req.body;

    if (!text) {
        return res.status(400).json({ error: "Missing 'text' field" });
    }
    if (typeof text !== 'string') {
        return res.status(400).json({ error: "'text' must be a string" });
    }
    if (text.length > MAX_QUERY_LENGTH) {
        return res.status(400).json({ error: `Text too long (max ${MAX_QUERY_LENGTH} characters)` });
    }

    logger.info(`[Calibrate] Text: "${text.substring(0, 100)}..."`);

    ragGuard(res, () => {
        const contextPayload = {
            query: text,
            top_k: 5,
            mode: "calibrate"
        };

        const bodyStr = JSON.stringify(contextPayload);
        const contextReq = http.request({
            hostname: RAG_HOST,
            port: RAG_PORT,
            path: '/context',
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(bodyStr)
            },
            timeout: 60000
        }, (contextRes) => {
            let body = '';
            contextRes.on('data', (chunk) => { body += chunk; });
            contextRes.on('end', () => {
                try {
                    const contextResult = JSON.parse(body);
                    res.status(contextRes.statusCode).json({
                        text: text,
                        calibration_context: contextResult,
                        system_instructions: contextResult.system_instructions,
                        message: "Use the context and system instructions to calibrate the text."
                    });
                } catch (e) {
                    res.status(502).json({ error: 'RAG service returned invalid JSON', dependencies: '/api/health/deps' });
                }
            });
        });

        contextReq.on('error', (e) => {
            logger.error(`[Calibrate] RAG error: ${e.message}`);
            if (RAG_UNREACHABLE_CODES.test(e.code || e.message)) markRAGDown(e.code || e.message);
            res.status(502).json({ error: 'RAG service unavailable', details: e.message, dependencies: '/api/health/deps' });
        });

        contextReq.on('timeout', () => {
            contextReq.destroy();
            res.status(504).json({ error: 'RAG service timed out', dependencies: '/api/health/deps' });
        });

        contextReq.write(bodyStr);
        contextReq.end();
    });
});

// --- RAG Sources Proxy ---
app.get('/api/rag/sources', (req, res) => {
    ragGuard(res, () => proxyGetFromRAG('/sources', res));
});

// DOC-042: JSON 404/405 for unmatched /api/* instead of Express HTML
// ("Cannot GET /api/rag"). CORS preflight OPTIONS is already finished by
// cors() above — leave those 204s alone.
const API_ROUTE_METHODS = [
    { re: /^\/api$/, methods: ['GET', 'HEAD'] },
    { re: /^\/api\/health$/, methods: ['GET', 'HEAD'] },
    { re: /^\/api\/health\/deps$/, methods: ['GET', 'HEAD'] },
    { re: /^\/api\/test-login$/, methods: ['GET', 'HEAD'] },
    { re: /^\/api\/version$/, methods: ['GET', 'HEAD'] },
    { re: /^\/api\/changelog$/, methods: ['GET', 'HEAD'] },
    { re: /^\/api\/docs$/, methods: ['GET', 'HEAD'] },
    { re: /^\/api\/files$/, methods: ['GET', 'HEAD'] },
    { re: /^\/api\/search$/, methods: ['GET', 'HEAD'] },
    { re: /^\/api\/read\/[^/]+$/, methods: ['GET', 'HEAD'] },
    { re: /^\/api\/quote\/[^/]+$/, methods: ['GET', 'HEAD'] },
    { re: /^\/api\/rag\/sources$/, methods: ['GET', 'HEAD'] },
    { re: /^\/api\/rag$/, methods: ['POST'] },
    { re: /^\/api\/rag\/context$/, methods: ['POST'] },
    { re: /^\/api\/calibrate$/, methods: ['POST'] }
];

app.use((req, res, next) => {
    if (!req.path.startsWith('/api')) return next();
    if (req.method === 'OPTIONS') return next();
    const route = API_ROUTE_METHODS.find((r) => r.re.test(req.path));
    if (route) {
        res.set('Allow', route.methods.join(', '));
        return res.status(405).json({
            error: 'Method not allowed',
            method: req.method,
            path: req.path,
            allow: route.methods,
            docs: '/api/docs'
        });
    }
    return res.status(404).json({
        error: 'Not found',
        path: req.path,
        docs: '/api/docs'
    });
});

if (require.main === module) {
    const server = app.listen(port, () => {
        logger.info(`DocDocGo API listening at http://localhost:${port}`);
        logger.info(`RAG proxy → ${RAG_HOST}:${RAG_PORT}`);
        // Warm the availability cache so the first RAG request does not pay
        // the probe latency, and log the dependency state at boot. The probe
        // is async and bounded (RAG_PROBE_TIMEOUT_MS); it never blocks listen.
        probeRAG(() => {});
    });

    // Graceful shutdown
    function shutdown(signal) {
        console.log(`\n${signal} signal received: closing HTTP server`);
        server.close(() => {
            console.log('HTTP server closed gracefully');
            process.exit(0);
        });

        // Force shutdown if it takes longer than 5 seconds
        setTimeout(() => {
            console.error('Could not close connections in time, forcefully shutting down');
            process.exit(1);
        }, 5000).unref();
    }

    process.on('SIGTERM', () => shutdown('SIGTERM'));
    process.on('SIGINT', () => shutdown('SIGINT'));
}

module.exports = { parseChapters, findChapter, relocateTocChapters, parseDateChapters, parseNumberedContemplationChapters, parseGloriaSessions, parseTocPartChapters };
