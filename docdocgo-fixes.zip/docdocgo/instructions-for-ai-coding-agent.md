# Requests and Instructions for AI LLM Coding Agent to Follow


## Main Issue & Technical Requirements and features or bug fixes , to focus on now
relevance score is not higher for exact matches ? eg when i search for "ignore all thoughts" first is ` When letting go, ignore all thoughts. Focus on the feeling itself, not on the thoughts. Thoughts are endl` 

it has relevance score of 3 but next result with text 
`will ignore what goes on in mind—ignore the thoughts but allow the experience of the energy field—the mind will say, “Well, I’m experiencing grief.” That is a label, so we will say that all thoughts are `  also as a relevance score of 3 ? i thought you would sort by relevance score ? 

since we rank the snippets where query words are closer to each other higher, that should increase their relevance score right ? relevance and rank go hand in hand right ? can we merge relevance and rank into one score ?  if not please provide reasons why not , please see  the principles 

### later not now 


- implement AI=True AI= False  for get requests 
if user query does not have any results 
use ollama.lak.nz to think of related search keywords and to search and generate a response 

random_results 


## old issues/ feature that are fixed/implemeted now make sure there is no regression , add updates if related, eg upddate related tests , docs 
if user has enabled Whole words only in html  , then user searches for "ignore all thoughts" the 2nd result matches words with all in them example allow and automatically . yes all is in them but Whole words only has been selected. so it should not match all in allow etc 

the current version is good 
there has been a regression , where html no longer shows source , please fix 

also add new test : query "ignore all thoughts" should return perfect match as top result , 
rank higher the results where query words are closer., this adds another criteria for ranking 

- speed up build by caching node_modules seems api container and cypress container is using the same one package.json ? please share the cache some how be it docker cache or what  please check 

need to install tooling for cypress , please create a docker container for it , you must not run node or npx , npm on host , run these inside docker contaienrs only , update makefile and docker compose file as well so that 
there is a new profile for cypress , meaning default make up must not start the cypress contianer 

suggest improvements for all-merged-books-serch.html based on recent improvements to api, 

Switch to API-Backend Search: Currently, the page performs search locally in the browser. Switching to fetch('/api/search') would help enable the new Ranked Snippets, Multi-word AND logic, and Randomization we just built.
- Multi-term Highlighting: Since the API now returns match_text as an array, the UI can highlight all matched words in a snippet simultaneously, providing much better context.
- Display Relevance Scores: We should now  show the match score (e.g., "Matched 4/5 words") on each result card to help users find the most pertinent content.
Min-Length Enforcement: Align the UI with the API's 4-character minimum rule for better consistency and performance.
- Dynamic Data Loading: Instead of loading huge .js data files into the browser, we should use the API to fetch only what's needed.
please go ahead and implement these changes in all-merged-books-serch.html

- make it use the API while keeping the existing look and feel, or improving if easy.
- Most important - cypress tests - update them to reflect the changes, add more cypress tests so we can be sure UI is working as expected. thanks

default limit = 100 if request does not specify limit


http://localhost:12854/api/search?q=lose%20person%20now%20major%20never

should return top result for a paragraph that has this 

we need to improve ranking so that 

match_text is array and has most keywords matched 	

many times AI llms make guesses to query this api , please add some endpoint that returns docs on how to use this api that llms can read and make get request to , focus on search api , provide details on what all flags, filter etc  are availabe to use , provide examples , with each response please return the "docs": "/api/docs" 

- when human does make up , sometimes expectation is less logs , sometimes expectatiton is more logs 

please add / update makefiile commands to include make up-low-logs

and make up-verbose-logs
what this means is add some args  to cli commands that make the actuall logging reduced or increased , so may need to edit api.js as well 


Test 3: GET /search?q=here is a wonderful t-shirt
✅ Success: Search works and returns clean snippets. Found 1000 matches.
this is ok , we need 50 more tests , please make more extensive tests for the search api , query = dfsdf must not return results 
query = "tesla car " must return results about car and Nicholas tesla  
query = " how to be happy" must return results
query = "peace self clumsy" must return most relevant results 
query = a -> no results , minimum 4 chars pls 
query the -> no results minimum 4 chars pls 



-  people make api calls to DocDocGo API request: like GET https://docdocgo.lak.nz/api/search?q=nondual gratitude present moment acceptance&limit=5 

this returns no results 

we need to update the search feature 

please make git commits as you make changes , these gommits must be well thought out and ready for release 

please make sure that results are random example if get request is limit n where n is a number  and there are more than n  results  please choose random results so that api returns different results each time for the same api request , if possible , random results for same api search call for query call when possible is a feature we need. 



- improve search 



## testing : 
dont mock , test againt actual docdocgo.lak.nz api or curl to localhost based on docker compose file
	make sure to use 	docker compose run --rm for tests  in Makefile


    please make sure any tests you want to run are well written and human should also be able to run them with a cli command easily 


## version control 
make good commits after you are sure you have done a good job. after all is tested and verifed , this commit should be ready for release 

**Requirements:**
*   **Testing:** Run tests and see what the issue is. All tests must still pass. 
*   **Environment:** Remember to use **Docker** and `make test`. Do **not** run Python on the host.
*   **Features:** 
    *   You may need to add a feature flag.
*   **Quality Assurance:** 
    *   Make sure tests are thorough and provide real feedback (not just pass/fail). 
    *   Tests are meant to provide a "yes/no" before releasing the software to production.
*   **Workflow:** 
    *   Read this file again and again to check for any feedback from my side. I will update this file with feedback, and you should re-read it and update the code accordingly. 
    *   I can provide guidance and information that you may not know.

---


## General Instructions for Code Changes

### Core Practices
  always use docker if there is a docker compose file , if not make one and user docker , run most commands in docker contaners  for the service 
*   **Logging:** Add debug and verbose logging. Logging helps us understand what is happening and helps debug issues, make it easy to run tests with verbose logging. makefile must have 2 versions of make test command one with verbose logging swoing and other quiet .
*   **Modularity:** Make the code more modular so we can easily add new features and remove old ones without breaking the code.
*   **Decoupling:** Make the logic less dependent on Telegram.

### Essential Design Principles
*   **DRY (Don’t Repeat Yourself):** Avoid logic duplication to prevent "maintenance nightmares" where a single bug must be fixed in multiple places.
*   **KISS (Keep It Simple, Stupid):** Prioritize clarity over cleverness; the simplest solution that works is usually the most maintainable.
*   **YAGNI (You Aren't Gonna Need It):** Only build features needed today, rather than over-engineering for hypothetical future requirements.
*   **SOLID Principles:** 
    *   Single Responsibility
    *   Open/Closed
    *   Liskov Substitution
    *   Interface Segregation
    *   Dependency Inversion
*   **Meaningful Naming:** Use descriptive names for variables and functions (e.g., `daysSinceLastUpdate` instead of `d`) to make code self-documenting.
*   **Small, Focused Functions:** Functions should handle a single responsibility and typically fit on one screen without scrolling (roughly 20–30 lines).
*   **Single Responsibility Principle (SRP):** Each module or class should have only one reason to change.
*   **Commenting "Why," Not "What":** Code should explain *what* is happening; comments should be reserved for explaining complex business rules or the reasoning behind non-obvious decisions.
*   **Automated Testing:** Maintain a robust suite of unit, integration, and system tests. Use Test-Driven Development (TDD) to ensure reliability from the start.
*   **Progressive Delivery:** Use feature flags to selectively enable new functionality for a subset of users, reducing the risk of large-scale failures.

### Documentation & Maintenance
*   **Maintain Up-to-Date Docs:** Keep high-level architecture, API endpoints, and setup guides current.
*   **Boy Scout Rule:** Always leave code slightly better than you found it—rename a confusing variable or delete dead code whenever you touch a file.
*   **Observability:** Use monitoring and logging to gain real-time visibility into system health and performance.