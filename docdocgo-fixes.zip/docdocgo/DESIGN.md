# DESIGN.md — DocDocGo Architecture & Design

> High-level design document explaining what this codebase does, how it's structured, and the key design decisions.

---

## What is DocDocGo?

DocDocGo is a **spiritual knowledge base search engine** for the teachings of Dr. David R. Hawkins, a renowned teacher of non-duality, consciousness, and spiritual enlightenment. The platform provides:

1. **Full-text search** across ~20 books and ~200+ transcribed lectures
2. **RAG (Retrieval-Augmented Generation)** semantic vector search with reranking
3. **API endpoints** for programmatic access (used by AI agents, LLM tools, etc.)
4. **Browser-based search UI** with relevance-ranked results, highlighting, and export

## System Architecture

```
┌─────────────────────────────────────────────────────────┐
│                      Client (Browser)                    │
│  all-merged-books-serch.html  (main search page)        │
│  rag-test.html                 (RAG test UI)            │
└─────────────┬───────────────────────────────────────────┘
              │ port 12853
              ▼
┌─────────────────────────────────────────────────────────┐
│                   nginx:alpine (Reverse Proxy)           │
│  • Serves static HTML/JS files from ./html               │
│  • Proxies /api/* → api:3000                             │
│  • Index: all-merged-books-serch.html                    │
└─────────────┬───────────────────────────────────────────┘
              │ /api/*
              ▼
┌─────────────────────────────────────────────────────────┐
│              api (Node.js 18 + Express)                  │
│  • Loads ~30MB of text data into memory at startup       │
│  • /api/search  — Full-text search with ranking          │
│  • /api/files   — List all documents                     │
│  • /api/read/*  — Read full document content             │
│  • /api/rag     — Proxy to RAG service                   │
│  • /api/calibrate — Consciousness calibration            │
│  • Relevance-ranked, multi-word AND with proximity bonus │
│  • Seeded pseudo-random shuffling for result variety     │
└─────────────┬───────────────────────────────────────────┘
              │ port 9432
              ▼
┌─────────────────────────────────────────────────────────┐
│            rag (Python 3.12 + Flask)                     │
│  • /ask         — Vector search + rerank                 │
│  • /calibrate   — Consciousness calibration endpoint     │
│  • /health      — Health check                           │
│  • Embedding: nomic-embed-text-v1.5 (137M params)       │
│  • Reranker: Ettin cross-encoder (68M params)           │
│  • Vector DB: Chroma (persistent on Docker volume)       │
│  • Chunking: tiktoken-based (256 token chunks)           │
└─────────────────────────────────────────────────────────┘
```

### Docker Compose Services

| Service | Image | Port | Role |
|---------|-------|------|------|
| `nginx` | nginx:alpine | 12853→80 | Static files + reverse proxy |
| `api` | Node 18 Alpine | 12854→3000 | Search API |
| `rag` | Python 3.12 Slim | 9432→9432 | RAG vector search |
| `rag-populate` | Python 3.12 Slim | — | One-shot vector DB ingestion |
| `cypress` | Cypress | — | E2E browser tests (test profile) |

## Data Layer

### Data Files

```
html/
├── merged-book-texts_json_1.js        ← 14MB — Book texts as JS object
├── 0-all-merged-no-timestamps_json.js ← 15MB — Lecture transcriptions as JS object
├── all-merged-books-serch.html        ← Main search page (API-backed)
├── all-books-and-lectures-search.html ← Alternative search (local data)
├── all-merged-no-timestamps-serch.html← Lectures-only search (local data)
└── rag-test.html                      ← RAG test UI

txt-files/
└── david_r_hawkins.txt                ← Raw text for RAG vector DB

source-config.json                     ← Source metadata & categories
```

### Why JS Files Instead of JSON?

The data files use `const the_json_obj = { ... }` format (JavaScript objects) rather than raw JSON for two reasons:
1. **Template literals** — Multi-line strings with backtick syntax (`\``) avoid JSON escaping issues
2. **Browser compatibility** — Can be loaded directly as `<script>` tags in the browser-based search pages

### Why Not a Database?

The current ~14-15MB of text data is loaded entirely into memory at startup. This is a deliberate tradeoff:

| Approach | Pros | Cons |
|----------|------|------|
| **In-memory JS objects** (current) | Zero query latency, simple code, no DB dependency | RAM usage (~30MB), slow startup, can't incrementally update |
| **SQLite + FTS5** | Smaller RAM footprint, fast startup, incremental updates, FTS5 full-text search | Added dependency, data migration needed |
| **Elasticsearch** | Best search quality, horizontal scaling | Complex ops, overkill for the data size |
| **PostgreSQL + pg_trgm** | Good search, ACID | Complex setup, overkill |

**Recommendation:** For data beyond ~50MB, **SQLite with FTS5** is the sweet spot — it provides full-text search, fast startup, minimal memory, and is a single file. The data could be ingested at build time.

Current status: ~14MB JSON → ~30MB in Node memory. Totally fine for now.

## Search Engine Design

### Multi-word Search Algorithm

1. **Query parsing**: Split query into words, remove stop words
2. **For each document in the filter scope**:
   - Test each query word against the document
   - If ANY query word is missing → skip document (AND logic)
   - Build a combined regex of all matched words
3. **Proximity scoring**: Words closer together get a small damped bonus (never enough to invert unique-word ranking)
4. **Document frequency**: `log(1 + keyword-groups in that doc)` breaks single-keyword ties so denser sources rank first (DOC-043)
5. **Tier-based ranking**: Results grouped into tiers by score
6. **Seeded shuffling**: Within a tier, after density/path/offset tie-breaks, remaining ties are deterministically shuffled

### Scoring Formula

```
Score = match_count × 3 + log(1 + doc_groups) / 10 + proximity_bonus
```

- **match_count**: How many unique query words matched in the group (dominates)
- **doc_groups**: Keyword-groups in that document (frequency)
- **proximity_bonus**: 0.5 if the full query is a contiguous phrase inside the group, else damped by span

### Stop Words

Common English words (the, and, is, was, etc.) are excluded from matching to prevent dilution. "not", "no", "nor" are intentionally preserved since negation is critical in spiritual teachings.

### Sort Integrity

The API automatically validates sort order and corrects violations. Under verbose logging, sort integrity details are included in the response.

## RAG Pipeline

The RAG (Retrieval-Augmented Generation) system uses a **retrieve-then-rerank** architecture:

```
User Query
    │
    ▼
┌─────────────────────┐
│ 1. Embed query      │  nomic-embed-text-v1.5
│    (137M params)     │
└─────────┬───────────┘
          ▼
┌─────────────────────┐
│ 2. Cosine similarity │  Chroma vector DB
│    Retrieve top-12    │
└─────────┬───────────┘
          ▼
┌─────────────────────┐
│ 3. Cross-encoder     │  Ettin reranker (68M)
│    Rerank to top-5    │
└─────────┬───────────┘
          ▼
┌─────────────────────┐
│ 4. Context assembly  │  System prompt + chunks
│    for LLM            │
└─────────────────────┘
```

### Key RAG Configurations

| Parameter | Default | Description |
|-----------|---------|-------------|
| `TOP_K_RETRIEVAL` | 12 | Candidates from vector search |
| `TOP_K_RERANK` | 5 | Final results after reranking |
| `ENABLE_RERANKER` | false (prod) | Toggle cross-encoder |

## Filter System Design

### Source Config (`source-config.json`)

This is the single source of truth for source categorization:

```json
{
  "categories": {
    "hawkinsBooks": ["along_the_path...", "letting_go...", ...],
    "nonHawkinsBooks": ["ACIM_workbook", "Lamsa_bible", ...],
    "lectureSeries": ["A_Map_of_Consciousness...", ...]
  }
}
```

### Filter Resolution Logic

```
filter param → action
─────────────────────────────────
"all"           → the_json_obj + the_json_obj_books
"books"         → the_json_obj_books (all books)
"all-hawkins-books" → hawkinsBooks keys from source config
"lectures"      → the_json_obj (all lectures)
"<specific>"    → lookup single key in both data sets
```

## API Design

### Key Design Decisions

1. **Always include `docs: "/api/docs"` in responses** — LLMs and tools can discover API usage
2. **4-character minimum for queries** — prevents single-letter/short word spam that would match everything
3. **Default limit = 100** — balanced between responsiveness and completeness
4. **Seeded randomness** — same query+params always produces same order, but variety exists across tiers
5. **RESTful design** — GET for reads, POST for RAG (since it has a body)

### Endpoints

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/api` | GET | API overview & docs |
| `/api/docs` | GET | Detailed parameter documentation |
| `/api/files` | GET | List all document paths |
| `/api/read/:filename` | GET | Read full document content |
| `/api/search` | GET | Full-text search |
| `/api/rag` | POST | RAG vector search |
| `/api/rag/context` | POST | RAG with LLM-ready context |
| `/api/calibrate` | POST | Consciousness calibration |
| `/api/rag/sources` | GET | List RAG-available sources |

## Frontend Architecture

### Three Search Pages

| Page | Data Source | Features |
|------|------------|----------|
| `all-merged-books-serch.html` | API (fetch) | Full features: relevance scores, multi-word highlight, pagination, export |
| `all-books-and-lectures-search.html` | Local JS data | Can search offline, but loads ~29MB in browser |
| `all-merged-no-timestamps-serch.html` | Local JS data | Lectures only, simplified UI |

### Main Page (`all-merged-books-serch.html`)

This is the primary search interface:
- **Nginx serves it as the index page** (defined in `nginx.conf`)
- **Uses the API** via `fetch('/api/search?...')` — does NOT load the large data files
- **Dynamically populates filter dropdown** from `/api/files`
- **Displays relevance scores** on each result card
- **Multi-word highlighting** from the API's `match_text` array
- **Pagination** (100 results per page)
- **Export** results as text file

## Testing Strategy

### Test Layers

```
┌─────────────────────────┐
│   Cypress E2E (Browser)  │  search.cy.js
├─────────────────────────┤
│   API Integration Tests  │  e2e-test.js
├─────────────────────────┤
│   Extended API Tests     │  extended-tests.js  (87+ cases)
├─────────────────────────┤
│   RAG Tests              │  rag-tests.js, rag-tests-docker.sh
├─────────────────────────┤
│   Parser Unit Tests      │  test-parser.js
└─────────────────────────┘
```

### Testing Principles

1. **No mocking** — all tests run against the actual running Docker stack
2. **Docker-native** — tests run inside containers (`docker compose run --rm`)
3. **Single command** — each test suite is runnable with one CLI command
4. **CI pipeline** — GitLab CI runs lint → test → build stages

## Development Workflow

### Making Changes

1. **Read `IMPORTANT-NOTES-FOR-AI-AGENTS.md` first**
2. Branch from `main`
3. Make changes following DRY, KISS principles
4. Run tests: `make test`
5. Create PR

### Key Commands

```bash
make up              # Start full stack
make test            # Run all tests
make lint            # ESLint
make cypress         # Run Cypress tests
make ci              # CI simulation
make rag-populate    # Populate vector DB
```

## Future Considerations

### Database Migration (when data grows)

If data grows beyond ~50MB:
- **SQLite + FTS5** would replace the in-memory JS object approach
- `source-config.json` already separates metadata from content — this makes migration easier
- FTS5 would handle stop words, proximity scoring, and ranking natively
- The API could be updated to query SQLite instead of scanning in-memory

### Performance

Current search performance:
- 14MB of book text + 15MB of lectures → ~30MB in Node memory
- Full scan per search request
- Search time: typically < 500ms for the full dataset
- RAG: ~2-5 seconds per query (embedding + reranking)

### Scaling

For much larger datasets:
1. Migrate to SQLite FTS5 for text search
2. Keep Chroma for semantic search (it's designed for this)
3. Add caching layer (Redis) for repeated queries
4. Consider pre-computing embeddings for all chunks (offline)
