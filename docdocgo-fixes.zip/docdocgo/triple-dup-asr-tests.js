const assert = require('assert');
const {
    collapseConsecutiveTripleDuplicates,
    applyOverlayText,
    readOverlay
} = require('./lecture-text');

let passed = 0;
let failed = 0;
function test(name, fn) {
    try {
        fn();
        console.log(`  ✅ ${name}`);
        passed++;
    } catch (err) {
        console.log(`  ❌ ${name}`);
        console.log(`     ${err.message}`);
        failed++;
    }
}

console.log('\n--- GoluGit #146 consecutive triple-duplicate ASR ---');

function consecutiveCopies(text, needle) {
    const esc = needle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    return new RegExp(`(?:${esc}[,.!?]*\\s*){3,}`, 'i').test(text);
}

test('3+ word phrase ×3 collapses to one utterance', () => {
    const s = collapseConsecutiveTripleDuplicates(
        'Does it come out of here? Does it come out of here? Does it come out of here? Does it mean action?'
    );
    assert.strictEqual((s.match(/come out of here/gi) || []).length, 1, s);
    assert.match(s, /Does it mean action/);
});

test('hyphenated spider question ×3 collapses', () => {
    const phrase = 'Why the overdone-ness of the web spider?';
    const s = collapseConsecutiveTripleDuplicates((phrase + ' ').repeat(3) + 'Why the extreme of it?');
    assert.strictEqual((s.match(/overdone-ness of the web spider/gi) || []).length, 1, s);
    assert.match(s, /Why the extreme of it/);
});

test('3-word no-punct stutter collapses', () => {
    const s = collapseConsecutiveTripleDuplicates(
        'absorb it by sure familiarity by sure familiarity by sure familiarity so constantly'
    );
    assert.strictEqual((s.match(/by sure familiarity/gi) || []).length, 1, s);
    assert.match(s, /so constantly/);
});

test('comma vs period watch-my-fingers still collapses', () => {
    const s = collapseConsecutiveTripleDuplicates(
        'I tell you, watch my fingers, watch my fingers, watch my fingers. Sleep.'
    );
    assert.strictEqual((s.match(/watch my fingers/gi) || []).length, 1, s);
    assert.match(s, /Sleep/);
});

test('rhetorical A/B/C near-repeat is not identical and stays', () => {
    const raw = 'out of nothingness, this is nothingness, arises A. Out of nothingness arises B. Out of nothingness arises C.';
    const s = collapseConsecutiveTripleDuplicates(raw);
    assert.match(s, /arises A/);
    assert.match(s, /arises B/);
    assert.match(s, /arises C/);
    assert.strictEqual((s.match(/out of nothingness/gi) || []).length, 3, s);
});

test('2-word hypnosis cadence wake up ×3 is not collapsed here', () => {
    const raw = 'Sleep, peace, sleep, peace, sleep. Wake up, wake up, wake up. OK.';
    const s = collapseConsecutiveTripleDuplicates(raw);
    assert.ok((s.match(/wake up/gi) || []).length >= 3, s);
});

test('DOC-055 Mung? call-and-response ×14 is not a phrase stutter', () => {
    const raw = Array(14).fill('Mung?').join(' ');
    const s = collapseConsecutiveTripleDuplicates(raw);
    assert.ok((s.match(/Mung\?/g) || []).length >= 12, s);
});

const KEYS = {
    causality: 'Causality_The_Ego_s_Foundation_Jan_2002_Part_1_enxautogen_html',
    emotions: 'Emotions_and_Sensations_Apr_2004_Part_3_enxautogen_html',
    ident: 'Identification_and_Illusion_Aug_2004_Part_3_enxautogen_html',
    pos1: 'Perception_and_Positionality_Jun_2004_Part_1_enxautogen_html',
    pos2: 'Perception_and_Positionality_Jun_2004_Part_2_enxautogen_html',
    essence: 'Perception_vs_Essence_Apr_2006_Part_1',
    duality: 'Positionality_and_Duality_Transcending_the_Opposites_Apr_2002_Part_1_enxautogen_html',
    thought: 'Thought_and_Ideation_Feb_2004_Part_2_enxautogen_html',
    qualities: 'Most_Valuable_Qualities_for_a_Spiritual_Seeker_May_2011_Part_2_enxautogen_html'
};

function servedOverlay(key) {
    const ov = readOverlay(key);
    assert.ok(ov, `overlay missing ${key}`);
    return applyOverlayText(ov);
}

test('overlay: Causality P1 spider question is one utterance', () => {
    const t = servedOverlay(KEYS.causality);
    assert.ok(!consecutiveCopies(t, 'Why the overdone-ness of the web spider'), t);
    assert.match(t, /overdone-ness of the web spider/);
});

test("overlay: Emotions P3 it's not discriminatory is one utterance", () => {
    const t = servedOverlay(KEYS.emotions);
    assert.ok(!consecutiveCopies(t, "it's not discriminatory"), t);
    assert.match(t, /not discriminatory/);
});

test("overlay: Identification P3 What's the question ×3 gone", () => {
    const t = servedOverlay(KEYS.ident);
    assert.ok(!consecutiveCopies(t, "What's the question"), t);
    assert.match(t, /What's the question/);
});

test('overlay: Positionality P1 A/B/C nothingness kept (not a stutter)', () => {
    const t = servedOverlay(KEYS.pos1);
    assert.match(t, /arises A/);
    assert.match(t, /Out of nothingness arises B/);
    assert.match(t, /Out of nothingness arises C/);
});

test('overlay: Positionality P2 come out of here is one utterance', () => {
    const t = servedOverlay(KEYS.pos2);
    assert.ok(!consecutiveCopies(t, 'Does it come out of here'), t);
    assert.match(t, /come out of here/);
});

test('overlay: Perception vs Essence P1 by sure familiarity is one utterance', () => {
    const t = servedOverlay(KEYS.essence);
    assert.ok(!consecutiveCopies(t, 'by sure familiarity'), t);
    assert.match(t, /by sure familiarity/);
});

test('overlay: Duality P1 God creates this is one utterance', () => {
    const t = servedOverlay(KEYS.duality);
    assert.ok(!consecutiveCopies(t, 'God creates this'), t);
    assert.match(t, /God creates this/);
});

test('overlay: Thought P2 watch my fingers is one utterance', () => {
    const t = servedOverlay(KEYS.thought);
    assert.ok(!consecutiveCopies(t, 'watch my fingers'), t);
    assert.match(t, /watch my fingers/);
});

test('overlay: Qualities P2 Anybody not satisfied with who you are is one utterance', () => {
    const t = servedOverlay(KEYS.qualities);
    assert.ok(!consecutiveCopies(t, 'Anybody not satisfied with who you are'), t);
    assert.match(t, /Anybody not satisfied with who you are/);
    assert.match(t, /who or what they are at this moment/);
});

console.log(`\n#146 tests: ${passed} passed, ${failed} failed`);
if (failed) process.exit(1);
