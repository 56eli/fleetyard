// Catalogue metadata E2E tests (GoluGit catalogue issues).
// Spawns its own api.js (port 3223), axios + assert.
//
//   DOC-030 #28 titles      -> every /api/files entry has a name; none ends
//                              _enxautogen_html (also pinned in api-bugs-test)
//   DOC-022 #23 ACIM label  -> displayName says Combined Original Edition,
//                              not bare "Workbook"
//   DOC-031 #29 suffix      -> all 11 remaining suffix-less lecture files share their
//                              series id with suffixed siblings (Dialogue Part_3
//                              was canonicalized by DOC-032 / #58 onto the
//                              _enxautogen_html key, so it is no longer in this set)
//   DOC-032 #30 Dec 2003    -> all three Dialogue parts share one series id;
//                              no other punctuation-split series exist
//   DOC-033 #31 gaps        -> the 4 missing parts + Volume VI are absent
//                              from /api/files AND flagged in incomplete_series
//   DOC-034 #32 kinds       -> every file has a declared kind; filters derive
//                              from kinds with legacy membership intact
//                              (books 27 / lectures 280 / hawkins 23)
//   DOC-021 #22 variants    -> satsang pair linked both ways, canonical set;
//                              16 health lectures -> healing_and_recovery;
//                              3 slides share one variant_group;
//                              search emits variant_groups for the pair
//   DOC-035 #33 satsang     -> satsang_june_2010 titled, chaptered,
//                              kind satsang, variant-linked
//   DOC-048 #81 possessives -> _s_ between tokens is 's (Ego's / Today's);
//                              SelfHealing keeps its hyphen (Self-Healing)
const { spawn } = require('child_process');
const path = require('path');
const axios = require('axios');
const assert = require('assert');

const TEST_PORT = 3223;
const BASE = `http://127.0.0.1:${TEST_PORT}`;

let child;

function startServer() {
    child = spawn(process.execPath, ['api.js'], {
        cwd: path.join(__dirname),
        env: { ...process.env, PORT: String(TEST_PORT), RATE_LIMIT_MAX: '1000' },
        stdio: ['ignore', 'pipe', 'pipe']
    });
    child.stderr.on('data', (d) => process.stderr.write(`[child] ${d}`));
}

async function waitForHealth() {
    for (let i = 0; i < 60; i++) {
        try {
            const res = await axios.get(`${BASE}/api/health`, { validateStatus: () => true, timeout: 5000 });
            if (res.status === 200) return;
        } catch (e) { /* not up yet */ }
        await new Promise((r) => setTimeout(r, 1000));
    }
    throw new Error('api did not become ready');
}

async function main() {
    console.log('--- Catalogue E2E Tests ---');
    startServer();
    try {
        await waitForHealth();
        const files = (await axios.get(`${BASE}/api/files`)).data;
        const { files: list, names, kinds, series, variants, incomplete_series } = files;
        assert.strictEqual(list.length, 307, 'corpus is 307 documents');

        // DOC-030 #28: every document titled, no pipeline suffix leaks.
        assert.strictEqual(Object.keys(names).length, list.length, 'names cover every file');
        for (const f of list) assert.ok(names[f] && names[f].trim(), `untitled: ${f}`);
        assert.ok(!Object.values(names).some((n) => n.endsWith('_enxautogen_html')), 'title ends in _enxautogen_html');
        console.log(`✅ DOC-030: all ${list.length} documents titled, no suffix leakage`);

        // DOC-022 #23: ACIM relabelled to what the file holds.
        assert.match(names.ACIM_workbook, /Combined Original Edition/, 'ACIM label must name the Combined Original Edition');
        assert.match(names.ACIM_workbook, /Text.*Workbook.*Manual/, 'ACIM label must list Text, Workbook, Manual');
        console.log(`✅ DOC-022: ACIM_workbook → "${names.ACIM_workbook}"`);

        // DOC-031 #29 + DOC-032 #30: canonical series ids.
        const dec = list.filter((f) => /Dialogue/i.test(f) && /Dec_2003/.test(f));
        assert.strictEqual(dec.length, 3, 'Dec 2003 Dialogue has 3 parts');
        assert.strictEqual(new Set(dec.map((f) => series[f])).size, 1, 'Dec 2003 parts share one series');
        const noSuffix = list.filter((f) => !f.endsWith('_enxautogen_html') && /_Part_\d+$/.test(f));
        assert.strictEqual(noSuffix.length, 11, `expected the 11 suffix-less files, got ${noSuffix.length}`);
        for (const f of noSuffix) {
            const sibs = list.filter((g) => g !== f && series[g] === series[f] && g.endsWith('_enxautogen_html'));
            assert.ok(sibs.length, `suffix-less ${f} groups with no suffixed sibling`);
        }
        // No other punctuation-split series: every multi-part series id holds
        // parts whose titles agree once commas are ignored.
        const bySeries = {};
        for (const f of list) (bySeries[series[f]] = bySeries[series[f]] || []).push(f);
        const split = Object.entries(bySeries).filter(([, fs]) => {
            const titles = new Set(fs.map((f) => names[f].replace(/, Part \d+$/, '').replace(/,/g, '')));
            return fs.length > 1 && titles.size > 1 && !/^satsang/.test(fs[0]);
        });
        assert.deepStrictEqual(split.map(([s]) => s), [], `punctuation-split series remain: ${JSON.stringify(split)}`);
        console.log('✅ DOC-031/032: 11 suffix-less files grouped; Dec 2003 one series; no other splits');

        // DOC-033 #31: genuine gaps absent AND flagged (coverage report in CI).
        const gaps = ['areviewoftheworksep2006', 'thoughtandideationfeb2004', 'theegoandtheselfdec2004', 'lovesep2011'];
        for (const sid of gaps) {
            const spec = incomplete_series[sid];
            assert.ok(spec && spec.missing.length, `${sid} flagged incomplete`);
            for (const m of spec.missing) {
                assert.ok(!list.includes(m) && !list.includes(`${m}_enxautogen_html`), `flagged-missing part present: ${m}`);
            }
            for (const p of spec.present) assert.ok(list.includes(p), `present part absent: ${p}`);
        }
        assert.ok(!list.some((f) => f.startsWith('Volume_VI_')), 'Volume VI present?');
        assert.ok(incomplete_series.volume_collection, 'volume collection flagged');
        console.log('✅ DOC-033: 4 missing parts + Volume VI absent and flagged incomplete');

        // DOC-034 #32: declared kinds drive the filters.
        assert.strictEqual(Object.keys(kinds).length, list.length, 'kinds cover every file');
        const kindOf = (k) => kinds[k];
        const books = list.filter((f) => ['hawkins_book', 'reference', 'slides_ocr'].includes(kindOf(f)));
        const lectures = list.filter((f) => !['hawkins_book', 'reference', 'slides_ocr'].includes(kindOf(f)));
        assert.strictEqual(books.length, 27, 'books = 27');
        assert.strictEqual(lectures.length, 280, 'lectures = 280');
        // Every path served under a named filter carries a matching kind.
        const expectKind = {
            books: (k) => ['hawkins_book', 'reference', 'slides_ocr'].includes(k),
            lectures: (k) => !['hawkins_book', 'reference', 'slides_ocr'].includes(k),
            'all-hawkins-books': (k) => ['hawkins_book', 'slides_ocr'].includes(k)
        };
        for (const [f, ok] of Object.entries(expectKind)) {
            const first = await axios.get(`${BASE}/api/search?q=${encodeURIComponent('consciousness')}&filter=${f}&limit=1000`);
            for (let p = 1; p <= first.data.total_pages; p++) {
                const rp = p === 1 ? first : await axios.get(`${BASE}/api/search?q=${encodeURIComponent('consciousness')}&filter=${f}&limit=1000&page=${p}`);
                for (const m of rp.data.results) assert.ok(ok(kinds[m.path]), `filter=${f} served ${m.path} (kind ${kinds[m.path]})`);
            }
        }
        const hawkinsKinds = new Set(list.filter((f) => ['hawkins_book', 'slides_ocr'].includes(kindOf(f))));
        assert.strictEqual(hawkinsKinds.size, 23, 'hawkins kinds = 23');
        assert.strictEqual(new Set([...books, ...lectures]).size, 307, 'kinds partition the library');
        console.log('✅ DOC-034: kinds partition 27/280; hawkins 23; filters derive from kinds');

        // DOC-021 #22: variant links, both directions.
        const sat = variants.satsang_june_2010;
        assert.ok(sat && sat.canonical, 'satsang_june_2010 canonical');
        assert.deepStrictEqual(sat.same_session_as, ['Satsang_Series_Volume_IX_Part_1_enxautogen_html']);
        assert.deepStrictEqual(variants.Satsang_Series_Volume_IX_Part_1_enxautogen_html.variant_of, 'satsang_june_2010');
        assert.ok(sat.linked_by.includes('Satsang_Series_Volume_IX_Part_1_enxautogen_html'), 'reverse link derived');
        const lectures16 = Object.entries(variants).filter(([, v]) => v.source_lecture_of === 'healing_and_recovery');
        assert.strictEqual(lectures16.length, 16, '16 health lectures link to Healing and Recovery');
        assert.strictEqual(variants.healing_and_recovery.linked_by.length, 16, 'reverse: book linked from 16');
        const slides = Object.entries(variants).filter(([, v]) => v.variant_group === 'book_of_slides');
        assert.strictEqual(slides.length, 3, '3 slides share one variant group');
        const vg = await axios.get(`${BASE}/api/search?q=${encodeURIComponent('Gloria in Excelsis')}&limit=100`);
        assert.ok(vg.data.variant_groups && vg.data.variant_groups.satsang_june_2010, 'search groups the satsang pair');
        assert.ok(vg.data.variant_groups.satsang_june_2010.includes('satsang_june_2010'), 'group holds the canonical');
        console.log('✅ DOC-021: satsang pair + 16 health links + slides group; search variant_groups emitted');

        // DOC-035 #33: the unmanaged document is managed.
        assert.strictEqual(kinds.satsang_june_2010, 'satsang', 'satsang kind');
        assert.ok(names.satsang_june_2010 && !/satsang_june_2010/.test(names.satsang_june_2010), 'satsang titled');
        const satRead = (await axios.get(`${BASE}/api/read/satsang_june_2010`)).data;
        assert.ok(satRead.chapters && satRead.chapters.length > 0, 'satsang chaptered');
        assert.strictEqual(satRead.kind, 'satsang', '/api/read carries kind');
        assert.ok(satRead.series, '/api/read carries series');
        assert.ok(satRead.variants && satRead.variants.canonical, '/api/read carries variants');
        console.log(`✅ DOC-035: satsang_june_2010 titled ("${names.satsang_june_2010}"), ${satRead.chapters.length} chapters, kind+series+variants`);

        // DOC-053 #90: mid-clause part openings are flagged so the UI does not
        // imply a clean Part N. Data files stay read-only; flag, don't recut.
        const abruptKeys = [
            'Dialogue,_Questions,_and_Answers_Dec_2003_Part_2_enxautogen_html',
            'Enlightenment_Aug_2003_Part_2_enxautogen_html',
            'God_Transcendent_and_Immanent_Nov_2002_Part_1_enxautogen_html',
            'Positionality_and_Duality_Transcending_the_Opposites_Apr_2002_Part_3_enxautogen_html'
        ];
        assert.ok(Array.isArray(files.transcript_normalisation.starts_abruptly), 'starts_abruptly list');
        for (const abruptKey of abruptKeys) {
            const abruptRead = (await axios.get(`${BASE}/api/read/${encodeURIComponent(abruptKey)}`)).data;
            assert.strictEqual(abruptRead.startsAbruptly, true, `${abruptKey} mid-clause opening must be flagged`);
            assert.ok(files.transcript_normalisation.starts_abruptly.includes(abruptKey), `files list missing ${abruptKey}`);
        }
        console.log(`✅ DOC-053: startsAbruptly on /api/read + /api/files (${files.transcript_normalisation.starts_abruptly.length} flagged)`);

        // DOC-048 #81: filename _s_ is a possessive, not a bare letter S.
        const egoKeys = list.filter((f) => /Ego_s_Foundation/.test(f));
        const todayKeys = list.filter((f) => /Today_s_World/.test(f));
        assert.strictEqual(egoKeys.length, 3, 'Ego\'s Foundation has 3 parts');
        assert.strictEqual(todayKeys.length, 3, 'Today\'s World has 3 parts');
        for (const f of egoKeys) {
            assert.match(names[f], /Ego['’]s Foundation/, `${f} name should keep possessive Ego's, got ${names[f]}`);
            assert.doesNotMatch(names[f], /\bS\b/, `${f} must not title-case _s_ as a bare S`);
            const read = (await axios.get(`${BASE}/api/read/${encodeURIComponent(f)}`)).data;
            assert.match(read.title, /Ego['’]s Foundation/, `/api/read.title for ${f}`);
        }
        for (const f of todayKeys) {
            assert.match(names[f], /Today['’]s World/, `${f} name should keep possessive Today's, got ${names[f]}`);
            assert.doesNotMatch(names[f], /\bS\b/, `${f} must not title-case _s_ as a bare S`);
        }
        const strippedPossessive = Object.entries(names).filter(([, n]) => /\bS\b/.test(n));
        assert.deepStrictEqual(strippedPossessive, [], `stripped possessives remain: ${JSON.stringify(strippedPossessive)}`);
        const healKey = 'Illness_and_SelfHealing_enxautogen_html';
        assert.ok(list.includes(healKey), 'SelfHealing lecture present');
        assert.match(names[healKey], /Self-Healing/, `SelfHealing should keep the hyphen, got ${names[healKey]}`);
        const healRead = (await axios.get(`${BASE}/api/read/${encodeURIComponent(healKey)}`)).data;
        assert.match(healRead.title, /Self-Healing/, '/api/read.title Self-Healing');
        console.log('✅ DOC-048: Ego\'s / Today\'s possessives; Self-Healing hyphen; no bare-S titles');

        // DOC-060 #98: Jan 2011 Q&A is cut mid-story; Mar 2011 continues it.
        const janQa = 'Question_Answer_Session_Jan_2011_enxautogen_html';
        const marQa = 'Question_Answer_Session_Mar_2011_enxautogen_html';
        const julQa = 'Question_Answer_Session_Jul_2011_enxautogen_html';
        assert.ok(list.includes(janQa) && list.includes(marQa), 'Jan/Mar 2011 Q&A present');
        const janVar = variants[janQa];
        const marVar = variants[marQa];
        assert.ok(janVar && marVar, 'Jan/Mar must have variant entries');
        assert.deepStrictEqual(janVar.same_session_as, [marQa]);
        assert.deepStrictEqual(marVar.same_session_as, [janQa]);
        assert.strictEqual(janVar.variant_group, 'q_and_a_2011_jan_mar');
        assert.strictEqual(marVar.variant_group, 'q_and_a_2011_jan_mar');
        assert.ok(janVar.linked_by.includes(marQa), 'Mar reverse-links Jan');
        assert.ok(marVar.linked_by.includes(janQa), 'Jan reverse-links Mar');
        const janRead = (await axios.get(`${BASE}/api/read/${encodeURIComponent(janQa)}`)).data;
        const marRead = (await axios.get(`${BASE}/api/read/${encodeURIComponent(marQa)}`)).data;
        assert.ok(janRead.variants && janRead.variants.same_session_as.includes(marQa), '/api/read Jan links Mar');
        assert.ok(marRead.variants && marRead.variants.same_session_as.includes(janQa), '/api/read Mar links Jan');
        assert.match(marRead.content.slice(0, 80), /And she got evicted/i, 'Mar still opens at the eviction (not recut)');
        if (list.includes(julQa)) {
            assert.ok(!variants[julQa] || variants[julQa].variant_group !== 'q_and_a_2011_jan_mar', 'Jul 2011 is a different question');
        }
        const qaSearch = await axios.get(`${BASE}/api/search?q=${encodeURIComponent('got evicted')}&limit=50`);
        const qaGroup = qaSearch.data.variant_groups && qaSearch.data.variant_groups['group:q_and_a_2011_jan_mar'];
        if (qaGroup) {
            assert.ok(qaGroup.includes(janQa) || qaGroup.includes(marQa), 'search groups the Jan/Mar continuation');
        }

        const sid = await axios.get(`${BASE}/api/search?q=Siddhona&limit=20`);
        assert.strictEqual(sid.status, 200);
        assert.strictEqual(sid.data.total_matches, 0, 'Siddhona ASR miss must be gone');
        const sed = await axios.get(`${BASE}/api/search?q=Sedona&filter=${encodeURIComponent('Satsang_Series_Volume_I_Part_1_enxautogen_html')}&limit=5`);
        assert.ok(sed.data.total_matches > 0, 'Sedona remains in Volume I Part 1');
        console.log('✅ DOC-060: Jan↔Mar 2011 Q&A linked; Siddhona→Sedona');

        console.log('\nAll catalogue tests passed 🎉');
    } finally {
        child.kill();
    }
}

main().catch((err) => {
    console.error(`\n❌ catalogue test failed: ${err.message}`);
    try { child.kill(); } catch (e) { /* already dead */ }
    process.exit(1);
});
