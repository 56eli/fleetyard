# IMPORTANT NOTES FOR AI AGENTS

> This file contains critical project knowledge for any AI coding agent working on this codebase.
> **Read this first before making any changes.**

---

## Quick Reference

| Thing | Location |
|-------|----------|
| Main HTML page (served by nginx) | `html/all-merged-books-serch.html` |
| Nginx config (sets index page) | `nginx.conf` |
| API server (Node.js/Express) | `api.js` |
| RAG microservice (Python/Flask) | `rag/rag_service.py` |
| Vector DB population | `rag/populate.py` |
| Ettin reranker | `rag/reranker.py` |
| Docker Compose (full stack) | `docker-compose.yml` |
| Makefile (dev commands) | `Makefile` |
| Source metadata/config | `source-config.json` |
| E2E tests (Cypress) | `cypress/e2e/search.cy.js` |
| API tests (Node.js) | `e2e-test.js`, `extended-tests.js` |
| RAG tests | `rag-tests.js`, `rag-tests-docker.sh` |

## Architecture Summary

```
Browser ──► nginx (port 12853) ──► static HTML/JS (search pages)
                        └────────► /api/* ──► api.js (port 12854)
                                                   └────► rag (port 9432) Python Flask
```

- **nginx.conf** defines the main index page as `all-merged-books-serch.html`
- nginx reverse-proxies `/api/` to the Node.js Express API on `api:3000` (Docker internal)
- The API loads two large JS data files at startup into memory, converts them to JSON objects
- Search is performed IN-MEMORY by the Node API (not SQL, not Elasticsearch)

## Data Files

| File | Size | Variable | Content |
|------|------|----------|---------|
| `html/merged-book-texts_json_1.js` | ~14MB | `the_json_obj_books` | All books (24 entries: 20 Hawkins + 4 non-Hawkins) |
| `html/0-all-merged-no-timestamps_json.js` | ~15MB | `the_json_obj` | All lecture transcriptions |
| `txt-files/david_r_hawkins.txt` | varies | — | Raw text for RAG vector DB |

### Book Categories

**Hawkins Books (20):**
- along_the_path_to_enlightenmen, daily_reflections_from_dr_dav, discovery_of_the_presence_of_g, dissolving_the_ego_realizing_, healing_and_recovery, I_reality_and_subj, in_the_world_but_not_of_it__t, letting_go__the_pathway_of_sur, power_vs_force__the_hidden_de, reality_spirituality_and_mode, success_is_for_you, the_ego_is_not_the_real_you__w, the_evolution_of_consciousness, the_eye_of_the_i__from_which_n, the_highest_level_of_enlighten, the_map_of_consciousness_expla, the_path_to_spiritual_advancem, the_wisdom_of_dr_david_r_haw, transcending_the_levels_of_con, truth_vs_falsehood

**Non-Hawkins Books (4):**
- `ACIM_workbook` — A Course in Miracles Workbook
- `Be_as_you_are` — Be As You Are (Ramana Maharshi)
- `I_AM_THAT` — I AM THAT (Nisargadatta Maharaj)
- `Lamsa_bible` — Lamsa Bible

**Source metadata is managed in `source-config.json`** — this is the SINGLE SOURCE OF TRUTH for which books belong to which category. When adding or removing a book, update this file.

## How to Add a New Source

1. Add the text content as a key in the appropriate data file (`merged-book-texts_json_1.js` or `0-all-merged-no-timestamps_json.js`)
2. Add the key to the appropriate category in `source-config.json`
3. Optionally add a display name in `source-config.json`
4. Restart the API (`make up` or `docker compose restart api`)

## How Search Works

1. User types query on `all-merged-books-serch.html`
2. HTML sends `fetch('/api/search?q=...&filter=...&limit=...')`
3. `api.js` receives request, loads the filter-specific data
4. For non-regex queries: splits query into words, filters stop words, creates word-level regexes
5. Matches against all documents in the selected filter scope
6. Scores results by: `(match_count + proximity_bonus) × exact_phrase_multiplier`
7. Results are tier-grouped, shuffled within tiers using seeded PRNG
8. Paginated and returned as JSON

### Available Filters

| Filter Value | Description |
|-------------|-------------|
| `all` | All sources (books + lectures) |
| `books` | All books (including non-Hawkins) |
| `all-hawkins-books` | Only Dr. Hawkins authored books |
| `lectures` | All lecture transcriptions |
| `<specific-key>` | A specific book or lecture by its data key |

## Running the Project

```bash
# Start full stack (nginx + api + rag)
make up

# Start with low logging
make up-log-low

# Start with verbose logging
make up-log-verbose

# Run all tests
make test

# Run just Cypress E2E tests
make cypress

# Populate vector DB
make rag-populate
```

## Testing Rules

- Always use Docker (`docker compose run --rm ...`) for testing
- Never run `npm`, `npx`, `python`, or `node` on the host
- Test against the running Docker stack, not mocks
- Tests must be runnable with a single CLI command

## Key Gotchas

1. **The main page is defined in `nginx.conf`** — if you create a new search page, update `nginx.conf` to point to it
2. **Data files are large (~14-15MB each)** — the API loads them fully into memory at startup. If you add a lot of content, consider database migration
3. **3 different search pages exist** — `all-merged-books-serch.html` (API-based, main), `all-books-and-lectures-search.html` (local data), `all-merged-no-timestamps-serch.html` (lectures only). Changes to filter logic must be synced across all relevant pages
4. **`source-config.json` is the category authority** — both `api.js` and local-data pages derive their filter behavior from the categories listed here. Non-Hawkins books are hardcoded as a fallback in `api.js` if config is missing
5. **Docker service names** are internal DNS: `api:3000`, `nginx:80`, `rag:9432`
6. **The `nginx.conf` uses Docker's internal DNS resolver** (`127.0.0.11`) for the proxy_pass to api

## Git Workflow

- Branch from `main`
- Make atomic, well-tested commits
- PR to merge
- References: `https://gitlab.com/laknz/docdocgo`
