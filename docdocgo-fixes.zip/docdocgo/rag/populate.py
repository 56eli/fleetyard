"""
Populate vector-db from txt-files using token-based chunking.

Uses tiktoken (cl100k_base) for precise token counting with 500-token
chunks and 100-token overlap, matching good-rag's ingestion pipeline.
"""

import json
import os
import sys
from pathlib import Path

import re

import numpy as np
import tiktoken

TXT_DIR = os.environ.get("TXT_DIR", "/app/txt-files")
VECTOR_DB_DIR = os.environ.get("VECTOR_DB_DIR", "/app/vector-db")
CHUNK_SIZE_TOKENS = int(os.environ.get("CHUNK_SIZE_TOKENS", "500"))
CHUNK_OVERLAP_TOKENS = int(os.environ.get("CHUNK_OVERLAP_TOKENS", "100"))
EMBEDDING_MODEL = os.environ.get("EMBEDDING_MODEL", "nomic-ai/nomic-embed-text-v1.5")
ENCODING_NAME = "cl100k_base"
BATCH_SIZE = 32


def get_encoding():
    return tiktoken.get_encoding(ENCODING_NAME)


def _extract_js_text(content: str) -> str:
    """If content is a JS wrapper (const the_... = {"k": `...`}), extract the backtick strings."""
    if content.lstrip().startswith("const"):
        parts = re.findall(r"`([^`]*)`", content, re.DOTALL)
        if parts:
            return "\n\n".join(parts)
    return content


def _correct_lecture_text(text: str) -> str:
    # Hawkins ASR hotwords — deterministic, lecture-only (no NLP)
    # Mirrors correctLectureText() in pipeline/correct-lecture-text.js + api.js; keep in sync.
    # Order matters: specific -> generic.
    text = re.sub(r'\beagle\b', lambda m: 'Ego' if m.group(0)[0] == 'E' else ('EGO' if m.group(0).isupper() else 'ego'), text, flags=re.IGNORECASE)
    text = re.sub(r'\ba\s+tractor\s+fields?\b', 'attractor field', text, flags=re.IGNORECASE)
    text = re.sub(r'\btractor\s+fields?\b', 'attractor field', text, flags=re.IGNORECASE)
    text = re.sub(r'\battractive\s+fields?\b', 'attractor field', text, flags=re.IGNORECASE)
    text = re.sub(r'\battractor\s+fuels?\b', 'attractor field', text, flags=re.IGNORECASE)
    text = re.sub(r'Gloria\s+in\s+Excelsior\s+Steel', 'Gloria in Excelsis Deo', text, flags=re.IGNORECASE)
    text = re.sub(r'Korean\s+Excelsior\s+Steel', 'Gloria in Excelsis Deo', text, flags=re.IGNORECASE)
    text = re.sub(r'\bExcelsior\s+Steel\b', 'Excelsis Deo', text, flags=re.IGNORECASE)
    # DOC-061: Gloria in Excelsis Deo ASR variants beyond Steel.
    text = re.sub(
        r"Gloria and Excelsior God beat the guy didn't know it's and on Earth Goodwill to men",
        'Gloria in Excelsis Deo. Peace on Earth, goodwill to men',
        text,
        flags=re.IGNORECASE,
    )
    text = re.sub(r"Gloria and Excelsior that fries you(?: you)?['’]re", "Gloria in Excelsis Deo. If you're", text, flags=re.IGNORECASE)
    text = re.sub(r'Gloria in Excelsior Praise', 'Gloria in Excelsis Deo. Praise', text, flags=re.IGNORECASE)
    text = re.sub(r'Gloria and Excelsior Studio', 'Gloria in Excelsis Deo', text, flags=re.IGNORECASE)
    text = re.sub(r'where to God in the highest', 'Glory to God in the highest', text, flags=re.IGNORECASE)
    text = re.sub(r'Maria in excelsious deal', 'Gloria in Excelsis Deo', text, flags=re.IGNORECASE)
    text = re.sub(r'glory in excelsious deal', 'Gloria in Excelsis Deo', text, flags=re.IGNORECASE)
    text = re.sub(r"glorian\s+excelsior(?:['’]?s)?\s+deal", 'Gloria in Excelsis Deo', text, flags=re.IGNORECASE)
    text = re.sub(r"Gloria and excelsior['’]?s deal", 'Gloria in Excelsis Deo', text, flags=re.IGNORECASE)
    text = re.sub(r"\ban\s+Excelsior['’]?s\s+deal\b", 'Gloria in Excelsis Deo', text, flags=re.IGNORECASE)
    text = re.sub(r"\bExcelsior['’]?s\s+deal\b", 'Gloria in Excelsis Deo', text, flags=re.IGNORECASE)
    text = re.sub(r'\bexcelsious\s+diaw\b', 'Excelsis Deo', text, flags=re.IGNORECASE)
    text = re.sub(r'\bexcelsious\s+deal\b', 'Gloria in Excelsis Deo', text, flags=re.IGNORECASE)
    text = re.sub(r'\bexcelsious\b', 'excelsis', text, flags=re.IGNORECASE)
    text = re.sub(r'\bglor(?:ia|y)\s+and\s+Excelsior\b', 'Gloria in Excelsis Deo', text, flags=re.IGNORECASE)
    text = re.sub(r'Gloria\s+and\s+Excelsior\b', 'Gloria in Excelsis Deo', text, flags=re.IGNORECASE)
    text = re.sub(r'Gloria\s+in\s+Excelsior\b', 'Gloria in Excelsis Deo', text, flags=re.IGNORECASE)
    text = re.sub(r"Gloria in Excelsis Deo that fries you(?: you)?['’]re", "Gloria in Excelsis Deo. If you're", text, flags=re.IGNORECASE)
    text = re.sub(r'\b5:40\b', '540', text)
    text = re.sub(r'\bRomana\b', 'Ramana', text)
    text = re.sub(r'\bRamona\b', 'Ramana', text)
    text = re.sub(r'\bRamada\b', 'Ramana', text)
    text = re.sub(r'\bMr\.\s*Godadamara\b', 'Nisargadatta Maharaj', text, flags=re.IGNORECASE)
    text = re.sub(r'Godada\s*Maharaj', 'Nisargadatta Maharaj', text, flags=re.IGNORECASE)
    text = re.sub(r'Godada\w*', 'Nisargadatta', text, flags=re.IGNORECASE)
    text = re.sub(r'\bClomagnum\b', 'Cro-Magnon', text, flags=re.IGNORECASE)
    text = re.sub(r'\binfill man\b', 'Neanderthal man', text, flags=re.IGNORECASE)
    text = re.sub(r'\bKill-Town Man\b', 'Neanderthal man', text, flags=re.IGNORECASE)
    text = re.sub(r'\bKilton man\b', 'Neanderthal man', text, flags=re.IGNORECASE)
    text = re.sub(r'\bAustralopis(?:\s+Popis)?\b', 'Australopithecus', text, flags=re.IGNORECASE)
    text = re.sub(r'\bAustralopopis\b', 'Australopithecus', text, flags=re.IGNORECASE)
    text = re.sub(r'\bnon-integers\b', 'non-integrous', text, flags=re.IGNORECASE)
    text = re.sub(r'\bnon-integrists\b', 'non-integrous', text, flags=re.IGNORECASE)
    text = re.sub(r'\bintegrists\b', 'integrous', text, flags=re.IGNORECASE)
    text = re.sub(r'\bDo you just said\b', 'Did you just say', text, flags=re.IGNORECASE)
    text = re.sub(r"\bthat which is Caesar\b(?!'s)", "that which is Caesar's", text, flags=re.IGNORECASE)
    text = re.sub(r'\binlet that rode\b', 'intellectual road', text, flags=re.IGNORECASE)
    text = re.sub(r'Homo erectus,\s*Antho,\s*Australopithecus', 'Homo erectus, Australopithecus', text, flags=re.IGNORECASE)
    text = re.sub(r'\bachieve the cities\b', 'achieve the siddhis', text, flags=re.IGNORECASE)
    text = re.sub(r'\ba certain city\b', 'a certain siddhi', text, flags=re.IGNORECASE)
    # DOC-047: health-lecture opening ASR homophones (phrase-scoped).
    text = re.sub(r'\bHawkins position for\b', 'Hawkins practice for', text, flags=re.IGNORECASE)
    text = re.sub(r'\bform of secretary and group therapy\b', 'form of individual and group therapy', text, flags=re.IGNORECASE)
    text = re.sub(r'\bmysterious conference\b', 'mysterious conditions', text, flags=re.IGNORECASE)
    # DOC-050: health-lecture stock intro ASR (phrase-scoped glossary).
    text = re.sub(r'\bcycle analysis\b', 'psychoanalysis', text, flags=re.IGNORECASE)
    text = re.sub(r"\bI'm gonna psychiatrist\b", "I've been a psychiatrist", text, flags=re.IGNORECASE)
    text = re.sub(r'\bgonna psychiatrist\b', 'been a psychiatrist', text, flags=re.IGNORECASE)
    text = re.sub(r'\bpsychothermicology\b', 'psychopharmacology', text, flags=re.IGNORECASE)
    text = re.sub(r'\bpsychoanalist\b', 'psychoanalyst', text, flags=re.IGNORECASE)
    text = re.sub(r'\bof specialized\b', 'I specialized', text, flags=re.IGNORECASE)
    text = re.sub(r'\bphysician in the psychiatrist\b', 'physician and psychiatrist', text, flags=re.IGNORECASE)
    text = re.sub(r"\bDid you're the research and\b", 'I did research in', text, flags=re.IGNORECASE)
    text = re.sub(r"\bDid you're the research\b", 'I did research in', text, flags=re.IGNORECASE)
    text = re.sub(r'\bthe second analyst\b', 'psychoanalyst', text, flags=re.IGNORECASE)
    text = re.sub(r"\byou I'm Dr\b", "I'm Dr", text, flags=re.IGNORECASE)
    text = re.sub(r'\ba psychoanalysis\b', 'psychoanalysis', text, flags=re.IGNORECASE)
    text = re.sub(r'\bbeen as a psychiatrist\b', 'been a psychiatrist', text, flags=re.IGNORECASE)
    text = re.sub(r'\bDr\. Dave Hawkins\b', 'Dr. David Hawkins', text, flags=re.IGNORECASE)
    text = re.sub(r"\bIn today's talk is going to be\b", "Today's talk is going to be", text, flags=re.IGNORECASE)
    text = re.sub(
        r'\bresearcher and the relationship between nutrition and the relationship to alcoholism\b',
        'researcher into the relationship between nutrition and alcoholism',
        text,
        flags=re.IGNORECASE,
    )
    text = re.sub(
        r'\bfields of psychoanalysis psychopharmacology Psychotherapy group therapy\b',
        'fields of psychoanalysis, psychopharmacology, psychotherapy, group therapy',
        text,
        flags=re.IGNORECASE,
    )
    # DOC-051 / #88: proper-name ASR (phrase-scoped).
    text = re.sub(r'\bair fat\b', 'Arafat', text, flags=re.IGNORECASE)
    text = re.sub(r'\blaboratory retrievers\b', 'Labrador retrievers', text, flags=re.IGNORECASE)
    text = re.sub(r'\bCatholics Diocese\b', 'Catholic Diocese', text, flags=re.IGNORECASE)
    text = re.sub(r"\bMingu['’]s Mountain\b", 'Mingus Mountain', text, flags=re.IGNORECASE)
    text = re.sub(r"\bunderstand Campbell's\b", 'understand camels', text, flags=re.IGNORECASE)
    # DOC-062 / #100: Volume I-V / Verification lecture ASR (phrase-scoped).
    text = re.sub(r'\bpower versus Forest(?:er)?\b', 'power versus Force', text, flags=re.IGNORECASE)
    text = re.sub(r'\bor here election like this\b', 'or hear a lecture like this', text, flags=re.IGNORECASE)
    text = re.sub(r'\bshark Cathedrals?\b', 'Chartres Cathedral', text, flags=re.IGNORECASE)
    text = re.sub(r'\b503 genuine Flexin so all forms symbolic of their symbolic these to do this and itself is 540\b', '[inaudible] itself is 540', text, flags=re.IGNORECASE)
    text = re.sub(r'\bthe agreeing chin the background\b', 'the echoing in the background', text, flags=re.IGNORECASE)
    text = re.sub(r'\bgoing to ohmaster\b', 'going to a master', text, flags=re.IGNORECASE)
    text = re.sub(r'\benergy dingo\b', 'energy field', text, flags=re.IGNORECASE)
    text = re.sub(r'\ba very famous Butler\b', 'a very famous author', text, flags=re.IGNORECASE)
    text = re.sub(r'\bthird must stay\b', 'third-month stay', text, flags=re.IGNORECASE)
    text = re.sub(r'\binterdication\b', 'inner dictation', text, flags=re.IGNORECASE)
    text = re.sub(r'\bif David our Hawkins\b', 'Dr. David R. Hawkins', text, flags=re.IGNORECASE)
    text = re.sub(r"Dr\. David Hawkins Tay reung['’]s son Keck tosa\.?", 'Dr. David R. Hawkins.', text, flags=re.IGNORECASE)
    text = re.sub(r"Tay reung['’]s son Keck tosa\.?", '', text, flags=re.IGNORECASE)
    text = re.sub(r'\bDavid our Hawkins\b', 'David R. Hawkins', text, flags=re.IGNORECASE)
    # #142: Integris / integers / inlet / Forester (not a global Forest rewrite).
    text = re.sub(r'\bthe integers\b', 'the integrity', text, flags=re.IGNORECASE)
    text = re.sub(r'\bintegers\b', 'integrous', text, flags=re.IGNORECASE)
    text = re.sub(r'\bIntegris\b', 'integrous', text, flags=re.IGNORECASE)
    def _inlet(m):
        return 'Intellect' if m.group(0)[0] == 'I' else 'intellect'
    text = re.sub(r'\binlet\b', _inlet, text, flags=re.IGNORECASE)
    text = re.sub(r'\bForester intimidation\b', 'force or intimidation', text, flags=re.IGNORECASE)
    text = re.sub(r'\bart on Forest\b', 'Ardennes Forest', text, flags=re.IGNORECASE)
    text = re.sub(r'\byard and Forest\b', 'Ardennes Forest', text, flags=re.IGNORECASE)
    text = re.sub(r'^(\s*)it here (?=[A-Z])', r'\1', text, flags=re.IGNORECASE)
    text = re.sub(r'^(\s*)here (?=What\b)', r'\1', text, flags=re.IGNORECASE)
    text = re.sub(r'^(\s*)here take my word', r'\1Take my word', text, flags=re.IGNORECASE)
    # #145: Verification Part 1 opening thanks + Darwin ASR (phrase-scoped).
    text = re.sub(r'Thank you very much for school\.?\s*(?:here\s+)?Yeah,\s*yeah\.\s*here\s*', 'Thank you very much. ', text, flags=re.IGNORECASE)
    text = re.sub(r'Thank you very much for school', 'Thank you very much', text, flags=re.IGNORECASE)
    text = re.sub(r"Darwin['’]s\s+Love\s+Revolution", "Darwin's evolution", text, flags=re.IGNORECASE)
    text = re.sub(r'\b(\w+)\s+\1\b', lambda m: m.group(1), text, flags=re.IGNORECASE)
    return text


def _clean_lecture_text(text: str) -> str:
    # Mirror cleanLectureText() in api.js — strip leftover WEBVTT headers and
    # isolated WebVTT cue numbers (\n\d\n) that polluted txt-files/lect.txt.
    # Do NOT apply to books.txt (calibration numbers like "655" would be deleted).
    # Also reflows WEBVTT cue shards (avg 42-char mid-sentence fragments) into
    # readable paragraph lines so RAG chunks aren't shard-sized.
    text = re.sub(r"\bWEBVTT\b\s*", "", text)
    text = re.sub(r"\n\s*\d{1,3}\s*\n", "\n", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    paras = re.split(r"\n{2,}", text)
    reflowed = []
    for para in paras:
        lines = [l.strip() for l in para.split("\n") if l.strip()]
        if len(lines) <= 1:
            reflowed.append("\n".join(lines))
            continue
        out, buf = [], lines[0]
        for nxt in lines[1:]:
            if buf.startswith("====") or nxt.startswith("===="):
                out.append(buf); buf = nxt; continue
            if re.search(r'[.!?:"\u2014\u2013]$', buf):
                out.append(buf); buf = nxt
            elif len(buf) > 550:
                out.append(buf); buf = nxt
            else:
                buf = buf + " " + nxt
        out.append(buf)
        reflowed.append("\n".join(out))
    text = "\n\n".join(reflowed)
    # Legacy Health lecture has a 20k run-on — break oversize lines at ". " sentence boundaries.
    # Python re forbids variable-width look-behind, so use a \b(\w+) capture + callback
    # instead of the JS (?<!\b(?:Dr|...|[A-Z])) pattern. Skips abbreviations + single initials.
    _ABBREVS = {"Dr", "Mr", "Mrs", "Ms", "Prof", "St", "Sr", "Jr", "vs", "etc"}
    _SENT_RE = re.compile(r"\b(\w+)\.\s+(?=[A-Z\"'\u201C])")
    def _split_line(line: str) -> str:
        if len(line) <= 700:
            return line
        def _repl(m):
            w = m.group(1)
            if w in _ABBREVS or (len(w) == 1 and w.isupper()):
                return m.group(0)
            return w + ".\n"
        return _SENT_RE.sub(_repl, line).strip()
    text = "\n".join(_split_line(l) for l in text.split("\n"))
    text = _correct_lecture_text(text)
    return text


def chunk_text(text, source_filename, encoding):
    """Split text into overlapping token-based chunks."""
    tokens = encoding.encode(text)
    chunks = []
    start = 0
    chunk_id = 0

    while start < len(tokens):
        end = min(start + CHUNK_SIZE_TOKENS, len(tokens))
        chunk_tokens = tokens[start:end]
        chunk_text_str = encoding.decode(chunk_tokens)
        chunks.append({
            "id": chunk_id,
            "source": source_filename,
            "text": chunk_text_str,
            "token_count": len(chunk_tokens),
        })
        chunk_id += 1
        start += CHUNK_SIZE_TOKENS - CHUNK_OVERLAP_TOKENS

    return chunks


def main():
    os.makedirs(VECTOR_DB_DIR, exist_ok=True)
    encoding = get_encoding()

    txt_files = sorted(f for f in os.listdir(TXT_DIR) if f.endswith(".txt"))
    if not txt_files:
        print("No .txt files found in", TXT_DIR)
        sys.exit(1)

    print(f"Loading {len(txt_files)} text file(s)…")

    all_chunks = []
    for filename in txt_files:
        filepath = os.path.join(TXT_DIR, filename)
        with open(filepath, "r", encoding="utf-8") as f:
            content = f.read()
        content = _extract_js_text(content)
        if filename == "lect.txt":
            content = _clean_lecture_text(content)
        file_chunks = chunk_text(content, filename, encoding)
        all_chunks.extend(file_chunks)
        print(f"  {filename}: {len(file_chunks)} chunks")

    if not all_chunks:
        print("No chunks generated.")
        sys.exit(1)

    total = len(all_chunks)
    print(f"\nTotal chunks: {total}")

    print("Loading embedding model…")
    from sentence_transformers import SentenceTransformer
    import logging
    logging.getLogger("sentence_transformers").setLevel(logging.WARNING)
    model = SentenceTransformer(EMBEDDING_MODEL, trust_remote_code=True)

    texts = ["search_document: " + chunk["text"] for chunk in all_chunks]
    print(f"Computing embeddings (batch_size={BATCH_SIZE})…")
    embeddings = model.encode(texts, batch_size=BATCH_SIZE, show_progress_bar=True)
    embeddings_np = np.array(embeddings, dtype=np.float32)

    chunks_path = os.path.join(VECTOR_DB_DIR, "chunks.json")
    embeddings_path = os.path.join(VECTOR_DB_DIR, "embeddings.npy")

    with open(chunks_path, "w", encoding="utf-8") as f:
        json.dump(all_chunks, f, ensure_ascii=False)
    np.save(embeddings_path, embeddings_np)

    print(f"\nDone! Saved {total} chunks.")
    print(f"  chunks.json:   {chunks_path} ({os.path.getsize(chunks_path) / 1024 / 1024:.1f} MB)")
    print(f"  embeddings.npy: {embeddings_path} ({os.path.getsize(embeddings_path) / 1024 / 1024:.1f} MB)")
    print(f"  Embedding dimensions: {embeddings_np.shape[1]}")


if __name__ == "__main__":
    main()
