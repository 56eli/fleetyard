#!/usr/bin/env python3
"""Tests for the docdocgo CLI."""

import subprocess
import sys
import json

VECTOR_DB = "/app/vector-db"
CLI = ["python", "-m", "rag.cli"]


def run(*args):
    result = subprocess.run(
        CLI + ["--vector-db", VECTOR_DB] + list(args),
        capture_output=True, text=True, timeout=30
    )
    return result


def test_no_command():
    result = run()
    assert result.returncode == 1
    assert "usage" in result.stdout.lower() or "usage" in result.stderr.lower()
    print("✅ test_no_command passed")


def test_search():
    result = run("search", "non-duality")
    assert result.returncode == 0
    assert "results" in result.stdout
    assert "Score:" in result.stdout
    print("✅ test_search passed")


def test_search_top_k():
    result = run("search", "truth", "-n", "2")
    assert result.returncode == 0
    assert "Score:" in result.stdout
    print("✅ test_search_top_k passed")


def test_ask():
    result = run("ask", "What is consciousness?")
    assert result.returncode == 0
    assert "QUERY:" in result.stdout
    assert "SYSTEM INSTRUCTIONS" in result.stdout
    assert "CONTEXT BLOCK" in result.stdout
    print("✅ test_ask passed")


def test_calibrate():
    result = run("calibrate", "I feel deep compassion for all beings")
    assert result.returncode == 0
    assert "TEXT:" in result.stdout
    assert "CALIBRATION INSTRUCTIONS" in result.stdout
    assert "Map of Consciousness" in result.stdout
    print("✅ test_calibrate passed")


def test_sources():
    result = run("sources")
    assert result.returncode == 0
    assert "Available sources:" in result.stdout
    assert "david_r_hawkins.txt" in result.stdout
    print("✅ test_sources passed")


def test_search_no_results():
    result = run("search", "xyznonexistent12345")
    assert result.returncode == 0
    assert "No results found" in result.stdout or "Score:" in result.stdout
    print("✅ test_search_no_results passed")


if __name__ == "__main__":
    tests = [
        test_no_command,
        test_search,
        test_search_top_k,
        test_ask,
        test_calibrate,
        test_sources,
        test_search_no_results,
    ]
    passed = 0
    failed = 0
    for t in tests:
        try:
            t()
            passed += 1
        except Exception as e:
            print(f"❌ {t.__name__} failed: {e}")
            failed += 1

    print(f"\n{'='*40}")
    print(f"Results: {passed} passed, {failed} failed")
    print(f"{'='*40}")

    if failed > 0:
        sys.exit(1)
