#!/bin/bash
set -euo pipefail

VECTOR_DB_DIR="${VECTOR_DB_DIR:-/app/vector-db}"
mkdir -p "$VECTOR_DB_DIR"

# ── Download models on first run (cached in volume) ────────
MODEL_CACHE="${TRANSFORMERS_CACHE:-/root/.cache/huggingface}"

if [ ! -d "$MODEL_CACHE/hub/models--nomic-ai--nomic-embed-text-v1.5" ]; then
    echo "Downloading embedding model (~400 MB, first run only)…"
    python -c "
from sentence_transformers import SentenceTransformer
SentenceTransformer('nomic-ai/nomic-embed-text-v1.5', trust_remote_code=True)
print('Embedding model ready.')
"
fi

if [ ! -d "$MODEL_CACHE/hub/models--cross-encoder--ettin-reranker-68m-v1" ]; then
    echo "Downloading reranker model (~1.3 GB, first run only)…"
    python -c "
from sentence_transformers import CrossEncoder
CrossEncoder('cross-encoder/ettin-reranker-68m-v1')
print('Reranker model ready.')
"
fi

# ── Start the service ──────────────────────────────────────
exec python -m rag.rag_service \
    --host "${RAG_HOST:-0.0.0.0}" \
    --port "${RAG_PORT:-9432}" \
    --vector-db "$VECTOR_DB_DIR"
