"""
RAG microservice for docdocgo.
Thin Flask wrapper around the core RAG engine.

Usage:
    python rag_service.py --host 0.0.0.0 --port 9432 --vector-db /path/to/vector-db
"""

import argparse
import logging
import os
import signal
import sys

from flask import Flask, request, jsonify

from .core import RAGEngine, SYSTEM_INSTRUCTIONS, CALIBRATE_SYSTEM_INSTRUCTIONS

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger(__name__)

app = Flask(__name__)

def _handle_shutdown(signum, frame):
    logger.info("Received signal %s, shutting down gracefully...", signum)
    # Raise SystemExit so Flask's werkzeug server can clean up
    raise SystemExit(0)

signal.signal(signal.SIGTERM, _handle_shutdown)
signal.signal(signal.SIGINT, _handle_shutdown)

# Config from env
ENABLE_RERANKER = os.environ.get("ENABLE_RERANKER", "true").lower() == "true"
TOP_K_RETRIEVAL = int(os.environ.get("TOP_K_RETRIEVAL", "12"))
TOP_K_RERANK = int(os.environ.get("TOP_K_RERANK", "5"))
VECTOR_DB_DIR = os.environ.get("VECTOR_DB_DIR", "/app/vector-db")

# Global engine instance
engine = RAGEngine(
    vector_db_dir=VECTOR_DB_DIR,
    enable_reranker=ENABLE_RERANKER,
    top_k_retrieval=TOP_K_RETRIEVAL,
    top_k_rerank=TOP_K_RERANK,
)


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "loaded": engine.loaded, "reranker": engine.enable_reranker})


@app.route("/system-instructions", methods=["GET"])
def system_instructions():
    mode = request.args.get("mode", "default")
    instructions = CALIBRATE_SYSTEM_INSTRUCTIONS if mode == "calibrate" else SYSTEM_INSTRUCTIONS
    return jsonify({"instructions": instructions})


@app.route("/embed", methods=["POST"])
def embed():
    data = request.get_json(silent=True) or {}
    query = data.get("query", "")
    if not query or not isinstance(query, str):
        return jsonify({"error": "Missing or invalid 'query' field"}), 400
    if not engine.loaded:
        return jsonify({"error": "Vector database not loaded"}), 503

    from core import embed_query
    embedding = embed_query(query)
    return jsonify({"query": query, "embedding": embedding.tolist(), "dimensions": len(embedding)})


@app.route("/search", methods=["POST"])
def search():
    data = request.get_json(silent=True) or {}
    query = data.get("query", "")
    if not query or not isinstance(query, str):
        return jsonify({"error": "Missing or invalid 'query' field"}), 400
    if not engine.loaded:
        return jsonify({"error": "Vector database not loaded"}), 503

    sources = data.get("sources", None)
    top_k = min(max(int(data.get("top_k", engine.top_k_rerank)), 1), 50)
    use_reranker = data.get("reranker", engine.enable_reranker)

    if use_reranker and engine.enable_reranker:
        results = engine.retrieve(query, sources, top_k)
    else:
        results = engine.search(query, sources, top_k)

    return jsonify({
        "query": query,
        "results": results,
        "total": len(results),
        "reranked": use_reranker and engine.enable_reranker,
    })


@app.route("/context", methods=["POST"])
def context():
    data = request.get_json(silent=True) or {}
    query = data.get("query", "")
    if not query or not isinstance(query, str):
        return jsonify({"error": "Missing or invalid 'query' field"}), 400
    if not engine.loaded:
        return jsonify({"error": "Vector database not loaded"}), 503

    sources = data.get("sources", None)
    top_k = min(max(int(data.get("top_k", engine.top_k_rerank)), 1), 50)
    mode = data.get("mode", "default")

    result = engine.build_context(query, sources, top_k, mode)
    return jsonify(result)


@app.route("/sources", methods=["GET"])
def sources():
    return jsonify({"sources": engine.sources()})


def init():
    engine.load()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="RAG microservice for docdocgo")
    parser.add_argument("--host", default="0.0.0.0", help="Host to bind")
    parser.add_argument("--port", type=int, default=9432, help="Port to listen on")
    parser.add_argument("--vector-db", type=str, default=None, help="Path to vector-db directory")
    parser.add_argument("--workers", type=int, default=1, help="Gunicorn workers")
    args = parser.parse_args()

    if args.vector_db:
        engine.vector_db_dir = args.vector_db

    init()

    if args.workers > 1:
        from gunicorn.app.base import BaseApplication

        class StandaloneApplication(BaseApplication):
            def __init__(self, app, options=None):
                self.options = options or {}
                self.application = app
                super().__init__()

            def load_config(self):
                for key, value in self.options.items():
                    if key in self.cfg.settings and value is not None:
                        self.cfg.set(key.lower(), value)

            def load(self):
                return self.application

        options = {
            "bind": f"{args.host}:{args.port}",
            "workers": args.workers,
            "timeout": 30,
            "graceful_timeout": 5,
        }
        StandaloneApplication(app, options).run()
    else:
        app.run(host=args.host, port=args.port)
