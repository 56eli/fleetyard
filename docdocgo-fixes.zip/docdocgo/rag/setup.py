from setuptools import setup, find_packages

setup(
    name="docdocgo-rag",
    version="1.0.0",
    packages=find_packages(),
    install_requires=[
        "flask>=3.0.0",
        "numpy>=2.0.0",
        "sentence-transformers>=4.0.0",
        "einops",
        "tiktoken",
    ],
    entry_points={
        "console_scripts": [
            "docdocgo=rag.cli:main",
        ],
    },
)
