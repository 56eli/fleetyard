#!/bin/bash
# Start the RAG microservice for docdocgo
# Usage: ./rag/start.sh [--host 0.0.0.0] [--port 9432] [--vector-db /path/to/vector-db]

cd "$(dirname "$0")/.."

if [ ! -f rag/venv/bin/python3 ]; then
    echo "Setting up Python venv..."
    python3 -m venv rag/venv
    pip install -r rag/requirements.txt
fi

exec rag/venv/bin/python3 rag/rag_service.py "$@"
