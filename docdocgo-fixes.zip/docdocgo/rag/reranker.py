"""
Ettin cross-encoder reranker for docdocgo RAG pipeline.

Uses cross-encoder/ettin-reranker-68m-v1 for retrieve-then-rerank.
Detects CUDA availability and selects appropriate attention implementation.
"""

import logging
import os

logger = logging.getLogger(__name__)

_model = None
RERANKER_MODEL = os.environ.get(
    "RERANKER_MODEL", "cross-encoder/ettin-reranker-68m-v1"
)


def _has_cuda() -> bool:
    try:
        import torch
        return torch.cuda.is_available()
    except ImportError:
        return False


def get_reranker():
    """Lazy-load the Ettin reranker model with device-aware config."""
    global _model
    if _model is None:
        logging.getLogger("sentence_transformers").setLevel(logging.WARNING)
        from sentence_transformers import CrossEncoder

        model_kwargs = {}
        if _has_cuda():
            model_kwargs["dtype"] = "bfloat16"
            model_kwargs["attn_implementation"] = "flash_attention_2"
            logger.info("Loading reranker with CUDA + Flash Attention 2")
        else:
            logger.info("Loading reranker on CPU (no Flash Attention)")

        _model = CrossEncoder(RERANKER_MODEL, model_kwargs=model_kwargs)
        logger.info(f"Loaded reranker: {RERANKER_MODEL}")
    return _model


def rerank(query: str, results: list, top_k: int = 5) -> list:
    """
    Rerank retrieval results using the Ettin cross-encoder.

    Args:
        query: The user's search query
        results: List of dicts with "chunk" and "score" keys from initial retrieval
        top_k: Number of results to return after reranking

    Returns:
        Reranked list of results with updated scores
    """
    if not results:
        return results

    model = get_reranker()

    pairs = [(query, r["chunk"]["text"]) for r in results]
    rerank_scores = model.predict(pairs)

    for i, score in enumerate(rerank_scores):
        results[i]["rerank_score"] = float(score)

    results.sort(key=lambda x: x.get("rerank_score", x["score"]), reverse=True)

    return results[:top_k]
