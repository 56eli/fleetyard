#!/usr/bin/env python3
"""
docdocgo CLI — Search, ask, and calibrate from the command line.

Usage:
    docdocgo search "non-duality"
    docdocgo ask "What is the nature of consciousness?"
    docdocgo calibrate "I feel deep compassion for all beings"
    docdocgo sources
"""

import argparse
import json
import os
import sys
from pathlib import Path

# Add rag/ to path so we can import core
RAG_DIR = Path(__file__).parent
sys.path.insert(0, str(RAG_DIR))

from rag.core import RAGEngine


def get_engine(vector_db: str = None) -> RAGEngine:
    """Create and load a RAG engine instance."""
    db_dir = vector_db or os.environ.get("VECTOR_DB_DIR", "/app/vector-db")

    # Try common local paths
    if not Path(db_dir).exists():
        candidates = [
            Path(__file__).parent.parent / "vector-db",
            Path.cwd() / "vector-db",
            Path.home() / "code" / "docdocgo" / "vector-db",
        ]
        for c in candidates:
            if (c / "chunks.json").exists():
                db_dir = str(c)
                break

    engine = RAGEngine(db_dir, enable_reranker=False, top_k_retrieval=8, top_k_rerank=5)
    if not engine.load():
        print(f"Error: Could not load vector database from {db_dir}", file=sys.stderr)
        print("Set VECTOR_DB_DIR or pass --vector-db", file=sys.stderr)
        sys.exit(1)
    return engine


def cmd_search(args):
    engine = get_engine(args.vector_db)
    results = engine.search(args.query, top_k=args.top_k)

    if not results:
        print("No results found.")
        return

    for i, r in enumerate(results):
        score = r["score"]
        source = r["chunk"].get("source", "unknown")
        text = r["chunk"]["text"][:200].replace("\n", " ")
        print(f"\n[{i+1}] Score: {score:.4f} | Source: {source}")
        print(f"    {text}...")

    print(f"\n({len(results)} results)")


def cmd_ask(args):
    engine = get_engine(args.vector_db)
    ctx = engine.build_context(args.query, top_k=args.top_k, mode="default")

    print("=" * 60)
    print("QUERY:", ctx["query"])
    print("=" * 60)

    if not ctx["chunks"]:
        print("\nNo relevant excerpts found.")
        return

    print(f"\nFound {len(ctx['chunks'])} relevant excerpts:\n")
    for i, chunk in enumerate(ctx["chunks"]):
        print(f"[Excerpt {i+1}] Score: {chunk['score']:.4f} | {chunk['source']}")
        print(f"  {chunk['text'][:300].replace(chr(10), ' ')}...")
        print()

    print("-" * 60)
    print("SYSTEM INSTRUCTIONS (send to LLM with the context above):")
    print("-" * 60)
    print(ctx["system_instructions"][:500] + "...")
    print()
    print("CONTEXT BLOCK (copy this to your LLM):")
    print("-" * 60)
    print(ctx["context"][:1000] + ("..." if len(ctx["context"]) > 1000 else ""))


def cmd_calibrate(args):
    engine = get_engine(args.vector_db)
    ctx = engine.build_context(args.text, top_k=args.top_k, mode="calibrate")

    print("=" * 60)
    print("TEXT:", args.text)
    print("=" * 60)

    if not ctx["chunks"]:
        print("\nNo relevant excerpts found.")
        return

    print(f"\nFound {len(ctx['chunks'])} related excerpts:\n")
    for i, chunk in enumerate(ctx["chunks"]):
        print(f"[{i+1}] Score: {chunk['score']:.4f} | {chunk['source']}")
        print(f"  {chunk['text'][:300].replace(chr(10), ' ')}...")
        print()

    print("-" * 60)
    print("CALIBRATION INSTRUCTIONS:")
    print("-" * 60)
    print(ctx["system_instructions"])
    print()
    print("CONTEXT BLOCK:")
    print("-" * 60)
    print(ctx["context"][:1500] + ("..." if len(ctx["context"]) > 1500 else ""))


def cmd_sources(args):
    engine = get_engine(args.vector_db)
    sources = engine.sources()
    if sources:
        print("Available sources:")
        for s in sources:
            print(f"  - {s}")
    else:
        print("No sources found.")


def main():
    parser = argparse.ArgumentParser(
        prog="docdocgo",
        description="DocDocGo CLI — Search, ask, and calibrate from the command line",
    )
    parser.add_argument("--vector-db", help="Path to vector-db directory")

    sub = parser.add_subparsers(dest="command", help="Command to run")

    # search
    p_search = sub.add_parser("search", help="Vector search for relevant chunks")
    p_search.add_argument("query", help="Search query")
    p_search.add_argument("-n", "--top-k", type=int, default=5, help="Number of results")
    p_search.set_defaults(func=cmd_search)

    # ask
    p_ask = sub.add_parser("ask", help="Build LLM context for a question")
    p_ask.add_argument("query", help="Your question")
    p_ask.add_argument("-n", "--top-k", type=int, default=5, help="Number of excerpts")
    p_ask.set_defaults(func=cmd_ask)

    # calibrate
    p_cal = sub.add_parser("calibrate", help="Calibrate text against Map of Consciousness")
    p_cal.add_argument("text", help="Text to calibrate")
    p_cal.add_argument("-n", "--top-k", type=int, default=5, help="Number of excerpts")
    p_cal.set_defaults(func=cmd_calibrate)

    # sources
    p_sources = sub.add_parser("sources", help="List available source files")
    p_sources.set_defaults(func=cmd_sources)

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(1)

    args.func(args)


if __name__ == "__main__":
    main()
