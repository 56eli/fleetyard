"""
docdocgo RAG core module.

Reusable RAG engine: embed, search, rerank, build context.
Can be used by the Flask API, CLI, or imported as a library.
"""

import json
import logging
import os
from pathlib import Path

import numpy as np

logger = logging.getLogger(__name__)

# ──────────────────────────────────────────────
# System instructions
# ──────────────────────────────────────────────

SYSTEM_INSTRUCTIONS = """
You are a helpful assistant that answers questions using only the provided book excerpts. Adhere strictly to the following guidelines:

1. SOURCE CONSTRAINT: Answer questions using only the information directly stated in the provided book excerpts. Do not use external knowledge or make assumptions.

2. CONVERSATIONAL GREETINGS: If the user greets you or says "thank you," respond politely and briefly remind them that you are here to answer questions based on the provided books and say "Gloria in Excelsis Deo" after your response.

3. UNRELATED QUESTIONS: If the user asks a question that is completely unrelated to the content of the books, respond with: "I can only answer questions based on the provided books. Here is a brief summary of what the books cover:" followed by a short, 2-3 sentence summary of the excerpts.

4. MISSING INFORMATION: If the question is related to the book's topics but the specific answer cannot be found in the text, respond exactly with: "I could not find the answer in the provided books." Do not ask the user for clarification unless their question is highly ambiguous but clearly related to the text.

5. QUOTING AND ATTRIBUTION (EXTREMELY IMPORTANT):
   - When answering, integrate exact quotes from the text to support your response.
   - Present these quotes naturally within your explanation so the answer is easy to read.
   - Do not mention internal labels such as "Excerpt 1", "Content Block", or "Document A". Refer to the source material simply as "the books" or "the text."
"""

CALIBRATE_SYSTEM_INSTRUCTIONS = """
You are a consciousness calibration expert trained in David R. Hawkins' Map of Consciousness.

Your task: Analyze the user's text and calibrate it on the Map of Consciousness scale (1-1000).

## Scale Reference
- 20 Shame: Self-hatred, worthlessness, desire to not exist
- 30 Guilt: Self-blame, remorse, desire for punishment
- 50 Apathy: Hopelessness, resignation, giving up
- 75 Grief: Deep sadness, loss, mourning
- 100 Fear: Anxiety, worry, dread, being scared
- 125 Desire: Wanting, craving, needing, obsession
- 150 Anger: Hatred, fury, resentment, desire for revenge
- 175 Pride: Superiority, arrogance, ego inflation, contempt
- 200 Courage: Hopefulness, willingness to try, optimism, "I can handle this"
- 250 Neutrality: Flexibility, equanimity, "it doesn't matter much"
- 310 Willingness: Productivity, cooperation, wanting to help and contribute
- 350 Acceptance: Understanding, forgiveness, inner peace, compassion
- 400 Reason: Logic, analysis, pursuit of truth, intellectual understanding
- 500 Love: Unconditional love, compassion for all, service to others, benevolence
- 540 Joy: Gratitude, bliss, serenity, "every moment is a gift"
- 600 Peace: Oneness, transcendence, non-dual perception, unity

## Rules
- Below 200 = life-draining (ego-driven, fear-based, weakness)
- 200 = critical threshold between weakness and strength
- 200-500 = life-supporting (growing awareness, personal responsibility)
- 500+ = transcendent (selfless, universal love, unity consciousness)
- Scale is logarithmic: differences between higher levels are exponentially greater

## Response Format
Respond in EXACTLY this format, nothing else:

CALIBRATION: <number>
LABEL: <level name>
CONFIDENCE: <0.0-1.0>
REASONING: <1-2 sentence explanation>
"""

# ──────────────────────────────────────────────
# Vector DB
# ──────────────────────────────────────────────

_model = None
EMBEDDING_MODEL = os.environ.get("EMBEDDING_MODEL", "nomic-ai/nomic-embed-text-v1.5")


def load_vector_db(vector_db_dir: str) -> tuple:
    """Load chunks and embeddings from disk."""
    chunks_path = os.path.join(vector_db_dir, "chunks.json")
    embeddings_path = os.path.join(vector_db_dir, "embeddings.npy")

    if not os.path.exists(chunks_path) or not os.path.exists(embeddings_path):
        return None, None

    with open(chunks_path, "r", encoding="utf-8") as f:
        chunks = json.load(f)

    embeddings = np.load(embeddings_path)
    return chunks, embeddings


def get_embed_model():
    global _model
    if _model is None:
        logging.getLogger("sentence_transformers").setLevel(logging.WARNING)
        from sentence_transformers import SentenceTransformer
        _model = SentenceTransformer(EMBEDDING_MODEL, trust_remote_code=True)
    return _model


def embed_query(query_text: str) -> np.ndarray:
    """Embed a query string."""
    model = get_embed_model()
    embedding = model.encode("search_query: " + query_text)
    return np.array(embedding, dtype=np.float32)


def cosine_similarity(query_vec: np.ndarray, embeddings_matrix: np.ndarray) -> np.ndarray:
    """Compute cosine similarity between query and all embeddings."""
    query_norm = query_vec / (np.linalg.norm(query_vec) + 1e-10)
    norms = np.linalg.norm(embeddings_matrix, axis=1, keepdims=True) + 1e-10
    embeddings_normed = embeddings_matrix / norms
    return embeddings_normed @ query_norm


# ──────────────────────────────────────────────
# RAG Engine
# ──────────────────────────────────────────────

class RAGEngine:
    """Reusable RAG engine. Load once, query many times."""

    def __init__(self, vector_db_dir: str, enable_reranker: bool = True,
                 top_k_retrieval: int = 12, top_k_rerank: int = 5):
        self.vector_db_dir = vector_db_dir
        self.enable_reranker = enable_reranker
        self.top_k_retrieval = top_k_retrieval
        self.top_k_rerank = top_k_rerank
        self.chunks = None
        self.embeddings = None
        self.loaded = False

    def load(self):
        """Load vector database into memory."""
        self.chunks, self.embeddings = load_vector_db(self.vector_db_dir)
        if self.chunks is not None:
            self.loaded = True
            logger.info(f"Loaded {len(self.chunks)} chunks, {self.embeddings.shape} embeddings")
        else:
            logger.warning("Vector database not found")
        return self.loaded

    def search(self, query: str, sources: list = None, top_k: int = None) -> list:
        """Retrieve top-k chunks by cosine similarity."""
        if not self.loaded:
            return []

        top_k = top_k or self.top_k_retrieval

        if sources:
            indices = [i for i, c in enumerate(self.chunks) if c.get("source") in sources]
            if not indices:
                return []
            filtered_chunks = [self.chunks[i] for i in indices]
            filtered_embeddings = self.embeddings[indices]
        else:
            filtered_chunks = self.chunks
            filtered_embeddings = self.embeddings

        query_vec = embed_query(query)
        similarities = cosine_similarity(query_vec, filtered_embeddings)
        top_indices = np.argsort(similarities)[::-1][:top_k]

        return [
            {"chunk": filtered_chunks[idx], "score": float(similarities[idx])}
            for idx in top_indices
        ]

    def rerank(self, query: str, results: list, top_k: int = None) -> list:
        """Rerank results using Ettin cross-encoder."""
        if not self.enable_reranker or not results:
            return results[: (top_k or self.top_k_rerank)]

        try:
            from .reranker import rerank as ettin_rerank
            reranked = ettin_rerank(query, results, top_k or self.top_k_rerank)

            for i, r in enumerate(reranked):
                cosine = r.get("score", 0)
                rerank = r.get("rerank_score", 0)
                logger.debug(f"Rerank [{i+1}] cosine={cosine:.4f} -> rerank={rerank:.4f} | {r['chunk'].get('source', '')}")

            return reranked
        except Exception as e:
            logger.warning(f"Reranker failed: {e}")
            return results[: (top_k or self.top_k_rerank)]

    def retrieve(self, query: str, sources: list = None, top_k: int = None) -> list:
        """Full retrieve-then-rerank pipeline."""
        results = self.search(query, sources, self.top_k_retrieval)
        return self.rerank(query, results, top_k or self.top_k_rerank)

    def build_context(self, query: str, sources: list = None, top_k: int = None,
                      mode: str = "default") -> dict:
        """Build LLM-ready context from retrieved chunks."""
        results = self.retrieve(query, sources, top_k)

        context_parts = []
        for i, result in enumerate(results):
            chunk_text = result["chunk"]["text"]
            score = result.get("rerank_score", result["score"])
            context_parts.append(f"[Excerpt {i+1} (relevance: {score:.2f})]:\n{chunk_text}")

        context_block = "\n\n".join(context_parts)

        if mode == "calibrate":
            instructions = CALIBRATE_SYSTEM_INSTRUCTIONS
        else:
            instructions = SYSTEM_INSTRUCTIONS

        return {
            "query": query,
            "context": context_block,
            "system_instructions": instructions,
            "chunks": [
                {
                    "text": r["chunk"]["text"],
                    "source": r["chunk"].get("source", ""),
                    "score": r.get("rerank_score", r["score"]),
                }
                for r in results
            ],
        }

    def sources(self) -> list:
        """List available source files."""
        if not self.loaded:
            return []
        return sorted(set(c.get("source", "") for c in self.chunks))
