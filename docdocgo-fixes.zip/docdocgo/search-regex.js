'use strict';
const { Worker } = require('worker_threads');
const path = require('path');

/**
 * Run a user regex off the event loop. Terminate the worker when budgetMs
 * elapses so a nested-quantifier ReDoS cannot stall the API process.
 *
 * One worker per call — pass every document in `texts` so a corpus scan does
 * not pay worker-spawn + structured-clone cost per file (that blew
 * SEARCH_BUDGET_MS after 1–2 docs on q=").
 */
function execRegexBoundedMany(pattern, flags, texts, budgetMs, matchCap = 20000) {
    const timeout = Math.max(1, Number(budgetMs) || 1);
    const cap = Math.max(1, matchCap);
    const list = Array.isArray(texts) ? texts : [texts];
    return new Promise((resolve) => {
        const worker = new Worker(path.join(__dirname, 'search-regex-worker.js'), {
            workerData: { pattern, flags, texts: list, matchCap: cap }
        });
        let settled = false;
        const finish = (result) => {
            if (settled) return;
            settled = true;
            clearTimeout(timer);
            resolve(result);
        };
        const timer = setTimeout(() => {
            worker.terminate().then(() => finish({ timedOut: true, docs: [] }));
        }, timeout);
        worker.on('message', (docs) => {
            worker.terminate();
            finish({ timedOut: false, docs });
        });
        worker.on('error', () => {
            finish({ timedOut: true, docs: [] });
        });
        worker.on('exit', (code) => {
            if (!settled && code !== 0) finish({ timedOut: true, docs: [] });
        });
    });
}

function execRegexBounded(pattern, flags, text, budgetMs, matchCap = 20000) {
    return execRegexBoundedMany(pattern, flags, [text], budgetMs, matchCap).then((r) => ({
        timedOut: r.timedOut,
        matches: (r.docs && r.docs[0]) || []
    }));
}

module.exports = { execRegexBounded, execRegexBoundedMany };
