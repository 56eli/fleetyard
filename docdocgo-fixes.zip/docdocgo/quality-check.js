// Transcription-quality gate for the lecture corpus.
//
// HARD checks (exit 1 on failure — block docker build / container start):
//   - lecture data loads and every lecture is non-empty after cleanup
//   - no residual WEBVTT headers, no "-->" cue timestamps, no isolated
//     WebVTT cue-number lines (the cleanup regex removes ^\n\d{1,3}\n$)
//
// SOFT checks (report-only, never block): fragment-y lectures (low median
// line length, high short-line ratio), surviving run-on lines, lecture count
// drift vs the corpus pin.
//
// Soft issues are warnings, not failures, because ASR hallucinations like
// "We do not worship life. We worship death." cannot be fixed deterministically
// — a flaky hard gate would take prod down, which is worse than serving an
// imperfect transcript.
//
// Usage:
//   node quality-check.js           human report; exit 1 iff any HARD failure
//   node quality-check.js --json    same, machine-readable summary on stdout
//
// Called from: Dockerfile (build gate), api.js (pre-start gate),
// quality-tests.js (npm test regression pins).

const path = require('path');
const { loadLectureTexts, identicalTokenRunCensus, DOC055_KEEP_RUN_TOKEN } = require('./lecture-text');

const HTML_DIR = path.join(__dirname, 'html');
// Corpus pin: number of lecture keys in 0-all-merged-no-timestamps_json.js.
// Drift is a warning, not a failure — lectures get added legitimately.
const EXPECTED_LECTURES = 280;

// Soft-threshold tuning (measured on the corpus on 2026-08):
//   - Health (worst legacy run-on) now ~140 avg chars after splitting
//   - Spiritual_Traps_Oct_2005_Part_2 is fragment-y: median 54, 6.3% short lines
const SOFT_MEDIAN_MIN = 40;     // median line length below this => fragment shards
const SOFT_SHORT_RATIO_MAX = 0.20; // lines <12 chars as fraction of all lines
const SOFT_MAX_LINE = 900;      // a surviving line above this => runaway run-on

function metrics(text) {
    const lines = text.split('\n').filter(l => l.length > 0);
    const lens = lines.map(l => l.length).sort((a, b) => a - b);
    const median = lens.length ? lens[Math.floor(lens.length / 2)] : 0;
    const short = lens.filter(l => l < 12).length;
    const max = lens.length ? lens[lens.length - 1] : 0;
    return { lines: lines.length, median, shortRatio: lines.length ? short / lines.length : 0, max };
}

function checkLectures(lectures) {
    const keys = Object.keys(lectures);
    const hardFailures = [];
    const softWarnings = [];
    const byLecture = {};

    for (const k of keys) {
        const text = lectures[k];
        if (!text || text.trim().length === 0) {
            hardFailures.push(`${k}: empty after cleanup`);
            continue;
        }
        const m = metrics(text);
        byLecture[k] = m;
        if (/WEBVTT/.test(text)) hardFailures.push(`${k}: residual WEBVTT header`);
        if (/-->/.test(text)) hardFailures.push(`${k}: residual "-->" timestamp`);
        const cueLines = text.split('\n').filter(l => /^\d{1,3}$/.test(l.trim()));
        if (cueLines.length) hardFailures.push(`${k}: ${cueLines.length} isolated WebVTT cue-number line(s)`);
        if (m.median < SOFT_MEDIAN_MIN) softWarnings.push(`${k}: fragment-y (median ${m.median} chars)`);
        if (m.shortRatio > SOFT_SHORT_RATIO_MAX) softWarnings.push(`${k}: ${(m.shortRatio * 100).toFixed(1)}% lines <12 chars`);
        if (m.max > SOFT_MAX_LINE) softWarnings.push(`${k}: run-on line of ${m.max} chars`);
        const runs = identicalTokenRunCensus(text, 12);
        for (const r of runs) {
            if (DOC055_KEEP_RUN_TOKEN.has(String(r.token).toLowerCase())) continue;
            softWarnings.push(`${k}: identical-token run ${r.token} x${r.n}`);
        }
    }

    if (keys.length === 0) hardFailures.push('no lecture keys loaded');
    if (keys.length !== EXPECTED_LECTURES) softWarnings.push(`lecture count ${keys.length} != corpus pin ${EXPECTED_LECTURES} (update EXPECTED_LECTURES if intended)`);

    return { keys: keys.length, hardFailures, softWarnings, byLecture };
}

function checkAll() {
    const { lectures, rawCount } = loadLectureTexts(HTML_DIR);
    return Object.assign(checkLectures(lectures), { rawCount });
}

function main() {
    const asJson = process.argv.includes('--json');
    const report = checkAll();
    if (asJson) {
        console.log(JSON.stringify({
            lectures: report.keys,
            hardFailures: report.hardFailures,
            softWarnings: report.softWarnings,
            hardPass: report.hardFailures.length === 0
        }, null, 2));
    } else {
        console.log(`quality-check: ${report.keys} lectures loaded`);
        for (const w of report.softWarnings) console.log(`  [warn] ${w}`);
        if (report.hardFailures.length) {
            for (const f of report.hardFailures) console.log(`  [FAIL] ${f}`);
            console.log(`quality-check: FAIL (${report.hardFailures.length} hard failure(s))`);
            process.exit(1);
        }
        console.log('quality-check: OK');
    }
}

module.exports = { checkAll, checkLectures, metrics, EXPECTED_LECTURES };

if (require.main === module) main();
