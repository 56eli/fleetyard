// hawkins-lecture-fixes.js — deterministic ASR hotword correction for Hawkins lectures (browser)
// Mirrors pipeline/correct-lecture-text.js (whitebox-iac) and api.js cleanLectureText tail.
// Loaded after 0-all-merged-no-timestamps_json.js so it can patch window.the_json_obj in place.
// ponytail: regex only, no deps, order matters (specific -> generic)
(function () {
  function correctLectureText(text) {
    return text
      .replace(/\beagle\b/gi, function (m) { return m[0] === 'E' ? 'Ego' : m === m.toUpperCase() ? 'EGO' : 'ego'; })
      .replace(/\ba\s+tractor\s+fields?\b/gi, 'attractor field')
      .replace(/\btractor\s+fields?\b/gi, 'attractor field')
      .replace(/\battractive\s+fields?\b/gi, 'attractor field')
      .replace(/\battractor\s+fuels?\b/gi, 'attractor field')
      .replace(/Gloria\s+in\s+Excelsior\s+Steel/gi, 'Gloria in Excelsis Deo')
      .replace(/Korean\s+Excelsior\s+Steel/gi, 'Gloria in Excelsis Deo')
      .replace(/\bExcelsior\s+Steel\b/gi, 'Excelsis Deo')
      .replace(/Gloria and Excelsior God beat the guy didn't know it's and on Earth Goodwill to men/gi, 'Gloria in Excelsis Deo. Peace on Earth, goodwill to men')
      .replace(/Gloria and Excelsior that fries you(?: you)?['’]re/gi, "Gloria in Excelsis Deo. If you're")
      .replace(/Gloria in Excelsior Praise/gi, 'Gloria in Excelsis Deo. Praise')
      .replace(/Gloria and Excelsior Studio/gi, 'Gloria in Excelsis Deo')
      .replace(/where to God in the highest/gi, 'Glory to God in the highest')
      .replace(/Maria in excelsious deal/gi, 'Gloria in Excelsis Deo')
      .replace(/glory in excelsious deal/gi, 'Gloria in Excelsis Deo')
      .replace(/glorian\s+excelsior(?:['’]?s)?\s+deal/gi, 'Gloria in Excelsis Deo')
      .replace(/Gloria and excelsior['’]?s deal/gi, 'Gloria in Excelsis Deo')
      .replace(/\ban\s+Excelsior['’]?s\s+deal\b/gi, 'Gloria in Excelsis Deo')
      .replace(/\bExcelsior['’]?s\s+deal\b/gi, 'Gloria in Excelsis Deo')
      .replace(/\bexcelsious\s+diaw\b/gi, 'Excelsis Deo')
      .replace(/\bexcelsious\s+deal\b/gi, 'Gloria in Excelsis Deo')
      .replace(/\bexcelsious\b/gi, 'excelsis')
      .replace(/\bglor(?:ia|y)\s+and\s+Excelsior\b/gi, 'Gloria in Excelsis Deo')
      .replace(/Gloria\s+and\s+Excelsior\b/gi, 'Gloria in Excelsis Deo')
      .replace(/Gloria\s+in\s+Excelsior\b/gi, 'Gloria in Excelsis Deo')
      .replace(/Gloria in Excelsis Deo that fries you(?: you)?['’]re/gi, "Gloria in Excelsis Deo. If you're")
      .replace(/\b5:40\b/g, '540')
      .replace(/\bRomana\b/g, 'Ramana')
      .replace(/\bRamona\b/g, 'Ramana')
      .replace(/\bRamada\b/g, 'Ramana')
      .replace(/\bMr\.\s*Godadamara\b/gi, 'Nisargadatta Maharaj')
      .replace(/Godada\s*Maharaj/gi, 'Nisargadatta Maharaj')
      .replace(/Godada\w*/gi, 'Nisargadatta')
      .replace(/\bClomagnum\b/gi, 'Cro-Magnon')
      .replace(/\binfill man\b/gi, 'Neanderthal man')
      .replace(/\bKill-Town Man\b/gi, 'Neanderthal man')
      .replace(/\bKilton man\b/gi, 'Neanderthal man')
      .replace(/\bAustralopis(?:\s+Popis)?\b/gi, 'Australopithecus')
      .replace(/\bAustralopopis\b/gi, 'Australopithecus')
      .replace(/\bnon-integers\b/gi, 'non-integrous')
      .replace(/\bnon-integrists\b/gi, 'non-integrous')
      .replace(/\bintegrists\b/gi, 'integrous')
      .replace(/\bDo you just said\b/gi, 'Did you just say')
      .replace(/\bthat which is Caesar\b(?!'s)/gi, "that which is Caesar's")
      .replace(/\binlet that rode\b/gi, 'intellectual road')
      .replace(/Homo erectus,\s*Antho,\s*Australopithecus/gi, 'Homo erectus, Australopithecus')
      .replace(/\bachieve the cities\b/gi, 'achieve the siddhis')
      .replace(/\ba certain city\b/gi, 'a certain siddhi')
      .replace(/\bHawkins position for\b/gi, 'Hawkins practice for')
      .replace(/\bform of secretary and group therapy\b/gi, 'form of individual and group therapy')
      .replace(/\bmysterious conference\b/gi, 'mysterious conditions')
      .replace(/\bcycle analysis\b/gi, 'psychoanalysis')
      .replace(/\bI'm gonna psychiatrist\b/gi, "I've been a psychiatrist")
      .replace(/\bgonna psychiatrist\b/gi, 'been a psychiatrist')
      .replace(/\bpsychothermicology\b/gi, 'psychopharmacology')
      .replace(/\bpsychoanalist\b/gi, 'psychoanalyst')
      .replace(/\bof specialized\b/gi, 'I specialized')
      .replace(/\bphysician in the psychiatrist\b/gi, 'physician and psychiatrist')
      .replace(/\bDid you're the research and\b/gi, 'I did research in')
      .replace(/\bDid you're the research\b/gi, 'I did research in')
      .replace(/\bthe second analyst\b/gi, 'psychoanalyst')
      .replace(/\byou I'm Dr\b/gi, "I'm Dr")
      .replace(/\ba psychoanalysis\b/gi, 'psychoanalysis')
      .replace(/\bbeen as a psychiatrist\b/gi, 'been a psychiatrist')
      .replace(/\bDr\. Dave Hawkins\b/gi, 'Dr. David Hawkins')
      .replace(/\bIn today's talk is going to be\b/gi, "Today's talk is going to be")
      .replace(/\bresearcher and the relationship between nutrition and the relationship to alcoholism\b/gi, 'researcher into the relationship between nutrition and alcoholism')
      .replace(/\bfields of psychoanalysis psychopharmacology Psychotherapy group therapy\b/gi, 'fields of psychoanalysis, psychopharmacology, psychotherapy, group therapy')
      .replace(/\bair fat\b/gi, 'Arafat')
      .replace(/\blaboratory retrievers\b/gi, 'Labrador retrievers')
      .replace(/\bCatholics Diocese\b/gi, 'Catholic Diocese')
      .replace(/\bMingu['’]s Mountain\b/gi, 'Mingus Mountain')
      .replace(/\bunderstand Campbell's\b/gi, 'understand camels')
      .replace(/\bpower versus Forest(?:er)?\b/gi, 'power versus Force')
      .replace(/\bor here election like this\b/gi, 'or hear a lecture like this')
      .replace(/\bshark Cathedrals?\b/gi, 'Chartres Cathedral')
      .replace(/\b503 genuine Flexin so all forms symbolic of their symbolic these to do this and itself is 540\b/gi, '[inaudible] itself is 540')
      .replace(/\bthe agreeing chin the background\b/gi, 'the echoing in the background')
      .replace(/\bgoing to ohmaster\b/gi, 'going to a master')
      .replace(/\benergy dingo\b/gi, 'energy field')
      .replace(/\ba very famous Butler\b/gi, 'a very famous author')
      .replace(/\bthird must stay\b/gi, 'third-month stay')
      .replace(/\binterdication\b/gi, 'inner dictation')
      .replace(/\bif David our Hawkins\b/gi, 'Dr. David R. Hawkins')
      .replace(/Dr\. David Hawkins Tay reung['’]s son Keck tosa\.?/gi, 'Dr. David R. Hawkins.')
      .replace(/Tay reung['’]s son Keck tosa\.?/gi, '')
      .replace(/\bDavid our Hawkins\b/gi, 'David R. Hawkins')
      .replace(/\bthe integers\b/gi, 'the integrity')
      .replace(/\bintegers\b/gi, 'integrous')
      .replace(/\bIntegris\b/gi, 'integrous')
      .replace(/\binlet\b/gi, function (m) { return m[0] === 'I' ? 'Intellect' : 'intellect'; })
      .replace(/\bForester intimidation\b/gi, 'force or intimidation')
      .replace(/\bart on Forest\b/gi, 'Ardennes Forest')
      .replace(/\byard and Forest\b/gi, 'Ardennes Forest')
      .replace(/^(\s*)it here (?=[A-Z])/i, '$1')
      .replace(/^(\s*)here (?=What\b)/i, '$1')
      .replace(/^(\s*)here take my word/i, '$1Take my word')
      .replace(/Thank you very much for school\.?\s*(?:here\s+)?Yeah,\s*yeah\.\s*here\s*/gi, 'Thank you very much. ')
      .replace(/Thank you very much for school/gi, 'Thank you very much')
      .replace(/Darwin['’]s\s+Love\s+Revolution/gi, "Darwin's evolution")
      .replace(/\b(\w+)\s+\1\b/gi, function (m, w) { return w; });
  }
  function cleanLectureText(text) {
    return text.replace(/\bWEBVTT\b\s*/g, '').replace(/\n\s*\d{1,3}\s*\n/g, '\n').replace(/\n{3,}/g, '\n\n');
  }
  // Patch in place — mutates values, not the const binding itself
  try {
    if (typeof the_json_obj !== 'undefined') {
      var n = 0;
      for (var k in the_json_obj) {
        if (!Object.prototype.hasOwnProperty.call(the_json_obj, k)) continue;
        var before = the_json_obj[k];
        var cleaned = cleanLectureText(before);
        // reflow is heavy; for browser we keep it cheap: clean + hotwords only
        // (api.js does full reflow server-side; browser search works on shard text fine)
        var fixed = correctLectureText(cleaned);
        if (fixed !== before) { the_json_obj[k] = fixed; n++; }
      }
      if (typeof console !== 'undefined' && console.log) console.log('[hawkins-fixes] patched ' + n + '/' + Object.keys(the_json_obj).length + ' lectures');
    }
  } catch (e) {
    if (typeof console !== 'undefined' && console.error) console.error('[hawkins-fixes] failed', e);
  }
  if (typeof window !== 'undefined') window.hawkinsCorrectLectureText = correctLectureText;
})();
