// Pins DOC-037 / #62: production deploy runbook + smoke battery live in-repo.
// Does not talk to prod or docker — asserts the scripts exist and cover the
// issue's done-when checklist so a missing reload or a `compose down` cannot
// silently land.
const fs = require('fs');
const path = require('path');
const assert = require('assert');

const ROOT = __dirname;
const DEPLOY = path.join(ROOT, 'scripts', 'deploy.sh');
const SMOKE = path.join(ROOT, 'scripts', 'smoke-test.sh');

function read(p) {
    assert.ok(fs.existsSync(p), `missing ${path.relative(ROOT, p)}`);
    const st = fs.statSync(p);
    assert.ok((st.mode & 0o111) !== 0, `${path.relative(ROOT, p)} must be executable`);
    return fs.readFileSync(p, 'utf8');
}

console.log('--- Deploy/smoke script pins (DOC-037 / #62) ---');

const deploy = read(DEPLOY);
const smoke = read(SMOKE);

assert.ok(/^#!\/usr\/bin\/env bash/m.test(deploy), 'deploy.sh shebang must be bash (dash rejects pipefail)');
assert.ok(/^#!\/usr\/bin\/env bash/m.test(smoke), 'smoke-test.sh shebang must be bash (dash rejects pipefail)');
assert.ok(/set -euo pipefail/.test(deploy), 'deploy.sh must be strict (set -euo pipefail)');
assert.ok(/set -euo pipefail/.test(smoke), 'smoke-test.sh must be strict (set -euo pipefail)');
assert.ok(/process\.argv\[2\]/.test(smoke), 'json_field must read the field name from argv[2] (node -e puts [eval] at argv[1])');

// Never tear down a running stack (test.sh already burned prod once).
assert.ok(!/\bdocker compose down\b/.test(deploy), 'deploy.sh must never docker compose down');
assert.ok(!/\bdocker compose down\b/.test(smoke), 'smoke-test.sh must never docker compose down');
assert.ok(!/AUTH_TEST_MODE=1/.test(deploy), 'deploy.sh must never enable AUTH_TEST_MODE');

// Recreate API, then reload nginx — never one without the other.
const apiIdx = deploy.search(/docker compose up -d --build api/);
const nginxIdx = deploy.search(/nginx -s reload/);
assert.ok(apiIdx !== -1, 'deploy.sh must recreate/rebuild the API container');
assert.ok(nginxIdx !== -1, 'deploy.sh must nginx -s reload');
assert.ok(apiIdx < nginxIdx, 'deploy.sh must rebuild API before reloading nginx');

assert.ok(/Loaded catalogue metadata: 307 kinds/.test(deploy),
    'deploy.sh must assert the catalogue drift log line');
assert.ok(/smoke-test\.sh/.test(deploy), 'deploy.sh must run the smoke battery');
assert.ok(!/\bsh\s+["'][^"']*smoke-test\.sh/.test(deploy)
    && !/\bsh\s+\$ROOT\/scripts\/smoke-test\.sh/.test(deploy),
    'deploy.sh must not invoke smoke-test.sh via sh (Ubuntu sh=dash ignores bash shebang)');
assert.ok(/\bbash\s+"\$ROOT\/scripts\/smoke-test\.sh"/.test(deploy),
    'deploy.sh must invoke smoke via bash so the shebang is not ignored');
assert.ok(/gitlab/.test(deploy), 'deploy.sh must push/sync the gitlab mirror (best-effort)');

assert.ok(/\/api\/health/.test(smoke), 'smoke: /api/health');
assert.ok(/\/api\/files/.test(smoke), 'smoke: /api/files');
assert.ok(/307/.test(smoke), 'smoke: files count ≥ 307');
assert.ok(/\bkinds\b/.test(smoke), 'smoke: kinds present');
assert.ok(/q====|q=%3D%3D%3D%3D/.test(smoke), 'smoke: q==== → 0');
assert.ok(/letting_go__the_pathway_of_surrender/.test(smoke), 'smoke: new-name read');
assert.ok(/letting_go__the_pathway_of_sur/.test(smoke), 'smoke: legacy alias read');
assert.ok(/Caf[eé]|Caf%C3%A9/.test(smoke), 'smoke: q=Café');
assert.ok(/truth_vs_falsehood/.test(smoke), 'smoke: Café hits truth_vs_falsehood');
assert.ok(/https/.test(smoke) && /redirect|Location|redirect_url/i.test(smoke),
    'smoke: https-only redirect chain');
assert.ok(/history\.back\(\)/.test(smoke), 'smoke: /login contains history.back()');

console.log('✅ #62 scripts/deploy.sh + scripts/smoke-test.sh cover the runbook');
