// Discord OAuth2 login + admin-approval gate for DocDocGo.
//
// Ported from hawkins-tv (tv/discord_auth.py, tv/auth_views.py,
// tv/access.py, tv/middleware.py — Django) to Express. Same contract:
//
//   /login            login page with "Login with Discord" button
//   /login/discord    start OAuth flow (state kept in session)
//   /callback         exchange code -> fetch user -> upsert grant -> session
//   /logout           clear session, back to /login
//   /auth/gate        nginx auth_request probe: 200 granted, 401 otherwise
//   /auth/entry       internal target for nginx's 401 error_page: redirects
//                     to /login (no session) or shows the pending page
//   /api/test-login   e2e-test session setter (403 unless AUTH_TEST_MODE=1)
//   /admin/grants     grant list + toggle (Discord login + is_admin required)
//
// The grants file (JSON, persisted on a docker volume) is the single
// source of truth for who may use the site. Every gated request checks
// it, so an admin toggle takes effect on the next request — same as
// hawkins-tv's AccessGrant row.
//
// The gate is only active when Discord OAuth is configured (all three
// DISCORD_* env vars set). Without them the site stays open, matching
// the pre-auth behavior that local dev and the CI test stack rely on.
const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const axios = require('axios');
const session = require('express-session');

const DISCORD_AUTHORIZE_URL = 'https://discord.com/oauth2/authorize';
const DISCORD_TOKEN_URL = 'https://discord.com/api/oauth2/token';
const DISCORD_USER_URL = 'https://discord.com/api/users/@me';
const DISCORD_SCOPES = 'identify';

const SESSION_MAX_AGE = 60 * 60 * 24 * 7; // 1 week, matching hawkins-tv

// Captain's own Discord id — seeded granted + admin so the site owner is
// never locked out (mirrors hawkins-tv tv/migrations/0012_seed_captain_access.py).
const CAPTAIN_DISCORD_USER_ID = process.env.CAPTAIN_DISCORD_ID || '1298076640043073548';
const GRANTS_FILE = process.env.GRANTS_FILE || path.join(__dirname, 'grants', 'grants.json');
const AUTH_TEST_MODE = process.env.AUTH_TEST_MODE === '1';
const DEV_SESSION_SECRET = 'docdocgo-dev-secret-change-me';

function sessionSecret() {
    const fromEnv = process.env.SESSION_SECRET;
    if (process.env.NODE_ENV === 'production' && !fromEnv) {
        throw new Error('SESSION_SECRET must be set when NODE_ENV=production');
    }
    return fromEnv || DEV_SESSION_SECRET;
}

function isConfigured() {
    return Boolean(process.env.DISCORD_CLIENT_ID && process.env.DISCORD_CLIENT_SECRET && process.env.DISCORD_REDIRECT_URI);
}

function logger() {
    // Keep auth logs on the same [LOG] prefix the app uses.
    return { error: (...args) => console.error('[ERROR]', ...args), info: (...args) => console.log('[INFO]', ...args) };
}

// --- Grants store (JSON file = source of truth) -------------------------
let grants = null;

function loadGrants() {
    if (grants) return grants;
    grants = { users: {} };
    try {
        if (fs.existsSync(GRANTS_FILE)) {
            const parsed = JSON.parse(fs.readFileSync(GRANTS_FILE, 'utf8'));
            if (parsed && parsed.users) grants = parsed;
        }
    } catch (err) {
        logger().error(`[AUTH] failed to load ${GRANTS_FILE}: ${err.message}`);
    }
    seedCaptain();
    return grants;
}

function saveGrants() {
    fs.mkdirSync(path.dirname(GRANTS_FILE), { recursive: true });
    const tmp = `${GRANTS_FILE}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(grants, null, 2));
    fs.renameSync(tmp, GRANTS_FILE); // atomic on POSIX
}

function seedCaptain() {
    const user = grants.users[CAPTAIN_DISCORD_USER_ID];
    if (user) {
        if (user.granted && user.is_admin) return;
        user.granted = true;
        user.is_admin = true;
    } else {
        grants.users[CAPTAIN_DISCORD_USER_ID] = {
            discord_user_id: CAPTAIN_DISCORD_USER_ID,
            name: 'Captain',
            avatar: '',
            granted: true,
            is_admin: true,
            last_login: null,
            created_at: new Date().toISOString()
        };
    }
    saveGrants();
}

function hasGrant(discordUserId) {
    if (!discordUserId) return false;
    return Boolean(loadGrants().users[String(discordUserId)] && loadGrants().users[String(discordUserId)].granted);
}

function isAdmin(discordUserId) {
    if (!discordUserId) return false;
    return Boolean(loadGrants().users[String(discordUserId)] && loadGrants().users[String(discordUserId)].is_admin);
}

function avatarUrl(userData) {
    const uid = String(userData.id || '');
    const hash = userData.avatar || '';
    if (!uid || !hash) return '';
    return `https://cdn.discordapp.com/avatars/${uid}/${hash}.png?size=64`;
}

function upsertGrant(userData) {
    const uid = String(userData.id || '');
    if (!uid) return;
    const users = loadGrants().users;
    const now = new Date().toISOString();
    const name = userData.global_name || userData.username || '?';
    if (users[uid]) {
        users[uid].name = name;
        if (userData.avatar) users[uid].avatar = avatarUrl(userData);
        users[uid].last_login = now;
    } else {
        // Default is NO access; the captain (seeded) or an admin must grant.
        users[uid] = {
            discord_user_id: uid,
            name,
            avatar: avatarUrl(userData),
            granted: false,
            is_admin: false,
            last_login: now,
            created_at: now
        };
    }
    saveGrants();
}

// --- Discord OAuth2 (axios, same endpoints as hawkins-tv) ----------------
async function exchangeCodeForToken(code) {
    const params = new URLSearchParams({
        client_id: process.env.DISCORD_CLIENT_ID,
        client_secret: process.env.DISCORD_CLIENT_SECRET,
        grant_type: 'authorization_code',
        code,
        redirect_uri: process.env.DISCORD_REDIRECT_URI
    });
    const resp = await axios.post(DISCORD_TOKEN_URL, params.toString(), {
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        timeout: 10000
    });
    return resp.data;
}

async function fetchDiscordUser(token) {
    const resp = await axios.get(DISCORD_USER_URL, {
        headers: { Authorization: `Bearer ${token.access_token}` },
        timeout: 10000
    });
    return resp.data;
}

// --- Session --------------------------------------------------------------
// ponytail: MemoryStore — one container, handful of users. Restarts drop
// sessions (users re-login; grants survive on the volume). Swap to a
// persistent store only if multi-instance or restart-login hurts.
const sessionMiddleware = session({
    name: 'docdocgo.sid',
    secret: sessionSecret(),
    resave: false,
    saveUninitialized: false,
    cookie: { httpOnly: true, sameSite: 'lax', maxAge: SESSION_MAX_AGE, secure: 'auto' }
    // 'auto' needs req.protocol: nginx forwards the client scheme as
    // X-Forwarded-Proto (Cloudflare's value, else $scheme) so Express sees
    // https on the TLS-fronted site and http on local dev.
});

// --- Helpers ---------------------------------------------------------------
function safeNext(next) {
    if (typeof next === 'string' && next.startsWith('/') && !next.startsWith('//')) return next;
    return '/';
}

function sessionUser(req) {
    const data = req.session && req.session.user;
    return data && typeof data === 'object' ? data : null;
}

function statesMatch(expected, actual) {
    const a = Buffer.from(expected || '');
    const b = Buffer.from(actual || '');
    return a.length === b.length && crypto.timingSafeEqual(a, b);
}

// --- Pages (inline HTML — no static asset pipeline in this app) ------------
const STYLE = `<style>
    body{font-family:system-ui,-apple-system,sans-serif;background:#1e1f22;color:#dbdee1;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0}
    .card{background:#2b2d31;border-radius:12px;padding:40px;max-width:380px;width:90%;text-align:center;box-shadow:0 4px 20px rgba(0,0,0,.4)}
    .brand{font-size:42px;margin-bottom:8px}
    h1{margin:0 0 6px;font-size:22px}
    .subtitle{margin:0 0 24px;color:#b5bac1;font-size:14px}
    .btn-discord{display:flex;align-items:center;justify-content:center;gap:10px;background:#5865f2;color:#fff;text-decoration:none;padding:12px 20px;border-radius:8px;font-weight:600;margin-bottom:16px}
    .btn-discord:hover{background:#4752c4}
    .btn-discord svg{width:20px;height:20px;flex:none}
    .btn-muted{background:#4e5058;font-weight:400;font-size:14px}
    .btn-muted:hover{background:#3f4149}
    .error{background:#5a2d2d;color:#ffb3b3;border-radius:8px;padding:10px 14px;font-size:13px;margin-bottom:16px}
    .hint{color:#949ba4;font-size:13px}
    table{width:100%;border-collapse:collapse;margin:16px 0}
    th,td{padding:8px 10px;text-align:left;border-bottom:1px solid #3f4149;font-size:14px}
    img.avatar{width:28px;height:28px;border-radius:50%}
    .badge{display:inline-block;padding:2px 8px;border-radius:10px;font-size:12px}
    .badge-yes{background:#1f5e36;color:#8ef0b0}.badge-no{background:#5a2d2d;color:#ffb3b3}
    button{background:#5865f2;color:#fff;border:none;border-radius:6px;padding:6px 12px;cursor:pointer}
</style>`;

function loginPage(oauthConfigured, error, next) {
    const btn = oauthConfigured
        ? `<a class="btn-discord" href="/login/discord?next=${encodeURIComponent(next)}">
             <svg fill="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.873-.894.077.077 0 0 1-.008-.128c.126-.093.252-.19.372-.287a.075.075 0 0 1 .077-.011c3.92 1.793 8.18 1.793 12.061 0a.073.073 0 0 1 .078.009c.12.099.246.195.373.289a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.894.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.156-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.156 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.156-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.156 2.418z"></path></svg>
             Login with Discord
           </a>
           <p class="hint">Sign in with your Discord account to access the library.</p>`
        : `<div class="error">Discord login is not configured yet.</div>
           <p class="hint">Set <code>DISCORD_CLIENT_ID</code>, <code>DISCORD_CLIENT_SECRET</code> and <code>DISCORD_REDIRECT_URI</code> in the environment to enable login.</p>`;
    const errorHtml = error ? `<div class="error">${String(error).replace(/[<>&]/g, '')}</div>` : '';
    // Back uses browser history, not href="/": "/" 301s to the gated /se/,
    // which bounces logged-out browsers straight back to /login (loop).
    return `<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Sign in — DocDocGo</title>${STYLE}</head>
<body><div class="card"><div class="brand">🔍</div><h1>DocDocGo</h1><p class="subtitle">Sign in to search the Hawkins library.</p>
${errorHtml}${btn}<a class="btn-discord btn-muted" href="#" onclick="history.back();return false;">Back</a></div></body></html>`;
}

function pendingPage(username) {
    return `<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Access pending — DocDocGo</title>${STYLE}</head>
<body><div class="card"><div class="brand">⏳</div><h1>Access pending</h1>
<p class="subtitle">Hi <strong>${String(username || '').replace(/[<>&]/g, '')}</strong> — you're signed in, but your access hasn't been granted yet.</p>
<div class="error">DocDocGo is invite-only. Ask the site owner to grant your Discord account access, then refresh this page. You'll get the search library as soon as they do.</div>
<a class="btn-discord btn-muted" href="/logout">Sign out</a></div></body></html>`;
}

function adminPage(users) {
    const rows = users.map((u) => `<tr>
        <td>${u.avatar ? `<img class="avatar" src="${u.avatar}" alt="">` : '—'}</td>
        <td>${String(u.name || '?').replace(/[<>&]/g, '')}</td>
        <td>${String(u.discord_user_id).replace(/[<>&]/g, '')}</td>
        <td>${u.last_login ? String(u.last_login).slice(0, 16).replace('T', ' ') : 'never'}</td>
        <td><span class="badge ${u.granted ? 'badge-yes' : 'badge-no'}">${u.granted ? 'granted' : 'pending'}</span>${u.is_admin ? ' <span class="badge badge-yes">admin</span>' : ''}</td>
        <td><form method="POST" action="/admin/grants/${String(u.discord_user_id).replace(/[^0-9]/g, '')}/toggle"><button type="submit">${u.granted ? 'Revoke' : 'Grant'}</button></form></td>
    </tr>`).join('');
    return `<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Access grants — DocDocGo</title>${STYLE}</head>
<body style="display:block"><div class="card" style="max-width:720px;margin:40px auto;text-align:left"><div class="brand" style="text-align:center">🔐</div><h1 style="text-align:center">Access grants</h1>
<p class="hint" style="text-align:center">The Discord login recorded above; toggle <em>granted</em> to allow access. Takes effect on their next request.</p>
<table><tr><th></th><th>Name</th><th>Discord ID</th><th>Last login</th><th>Status</th><th></th></tr>${rows}</table>
<p style="text-align:center"><a class="btn-discord btn-muted" href="/logout" style="text-decoration:none">Sign out</a> · <a class="btn-discord btn-muted" href="/se/" style="text-decoration:none">Open site</a></p>
</div></body></html>`;
}

// --- Router (mounted before the gate; these routes stay reachable) ----------
const router = express.Router();

// Liveness probe for uptime monitors — deliberately unauthenticated, same
// as hawkins-tv's /health. Registered before the gate.
router.get('/api/health', (req, res) => {
    res.json({ status: 'ok' });
});

router.get(['/login', '/login/'], (req, res) => {
    res.send(loginPage(isConfigured(), req.query.error, safeNext(req.query.next)));
});

router.get('/login/discord', (req, res) => {
    if (!isConfigured()) {
        return res.redirect(`/login?error=${encodeURIComponent('Discord OAuth is not configured')}`);
    }
    const state = crypto.randomBytes(24).toString('base64url');
    req.session.oauth_state = state;
    req.session.next_url = safeNext(req.query.next);
    const params = new URLSearchParams({
        client_id: process.env.DISCORD_CLIENT_ID,
        redirect_uri: process.env.DISCORD_REDIRECT_URI,
        response_type: 'code',
        scope: DISCORD_SCOPES,
        state
    });
    res.redirect(`${DISCORD_AUTHORIZE_URL}?${params.toString()}`);
});

router.get(['/callback', '/callback/'], async (req, res) => {
    const next = safeNext(req.session.next_url);
    const { error, code, state } = req.query;
    if (error) return res.redirect(`/login?error=${encodeURIComponent(error)}`);
    if (!code || !state) return res.redirect(`/login?error=${encodeURIComponent('missing code or state')}`);
    // State doubles as the CSRF token for the OAuth flow itself.
    if (!statesMatch(req.session.oauth_state, state)) {
        return res.redirect(`/login?error=${encodeURIComponent('invalid state — try again')}`);
    }
    delete req.session.oauth_state;
    try {
        const token = await exchangeCodeForToken(code);
        const userData = await fetchDiscordUser(token);
        upsertGrant(userData);
        req.session.user = {
            user_id: String(userData.id),
            username: userData.global_name || userData.username || '?'
        };
        res.redirect(next);
    } catch (err) {
        logger().error(`[AUTH] Discord callback failed: ${err.message}`);
        res.redirect(`/login?error=${encodeURIComponent('authentication failed')}`);
    }
});

router.get(['/logout', '/logout/'], (req, res) => {
    req.session.destroy(() => res.redirect('/login'));
});

// Current-user probe so the search page can show an admin link.
// 200 with {is_admin} when a session exists; 401 when not logged in.
router.get('/auth/me', (req, res) => {
    const user = sessionUser(req);
    if (!user) return res.status(401).json({ error: 'not logged in' });
    const grants = loadGrants();
    const row = grants.users[String(user.user_id)];
    res.json({
        user_id: user.user_id,
        username: user.username,
        is_admin: Boolean(row && row.is_admin),
    });
});

// nginx auth_request probe for /se/: 200 granted (or site open), 401 else.
router.get('/auth/gate', (req, res) => {
    // Login required no matter what — even when Discord OAuth not configured, gate the UI
    const user = sessionUser(req);
    if (user && hasGrant(user.user_id)) return res.sendStatus(200);
    res.sendStatus(401);
});

// Internal target for nginx's error_page after a 401 on /se/. The browser
// never navigates here directly; it gets the login redirect or the pending
// page depending on whether a session exists.
router.get('/auth/entry', (req, res) => {
    const next = safeNext(req.get('x-original-uri') || '/');
    const user = sessionUser(req);
    if (!user) return res.redirect(`/login?next=${encodeURIComponent(next)}`);
    if (!hasGrant(user.user_id)) return res.status(403).send(pendingPage(user.username));
    res.redirect(next);
});

// e2e test session setter — mirrors hawkins-tv's DEBUG-only /api/test-login/.
router.get('/api/test-login', (req, res) => {
    if (!AUTH_TEST_MODE) return res.status(403).json({ error: 'test login disabled' });
    const uid = String(req.query.user_id || '');
    if (!uid) return res.status(400).json({ error: 'user_id required' });
    const users = loadGrants().users;
    if (!users[uid]) {
        users[uid] = {
            discord_user_id: uid,
            name: `Test ${uid}`,
            avatar: '',
            granted: false,
            is_admin: false,
            last_login: new Date().toISOString(),
            created_at: new Date().toISOString()
        };
        saveGrants();
    }
    req.session.user = { user_id: uid, username: users[uid].name };
    res.json({ ok: true, user_id: uid, granted: users[uid].granted, is_admin: users[uid].is_admin });
});

function requireAdmin(req, res, next) {
    const user = sessionUser(req);
    if (!user) return res.redirect(`/login?next=${encodeURIComponent(req.originalUrl)}`);
    if (!isAdmin(user.user_id)) {
        return res.status(403).send('<!DOCTYPE html><html><head><meta charset="UTF-8"><title>403</title></head><body style="font-family:system-ui;background:#1e1f22;color:#dbdee1;padding:60px;text-align:center"><h1>403</h1><p>This page is for the site owner only.</p><p><a href="/se/" style="color:#5865f2">Back to the library</a></p></body></html>');
    }
    next();
}

router.get('/admin/grants', requireAdmin, (req, res) => {
    const users = Object.values(loadGrants().users).sort((a, b) => {
        if (a.is_admin !== b.is_admin) return a.is_admin ? -1 : 1;
        if (b.granted !== a.granted) return b.granted ? 1 : -1;
        return String(b.last_login || '').localeCompare(String(a.last_login || ''));
    });
    res.send(adminPage(users));
});

router.post('/admin/grants/:id/toggle', requireAdmin, (req, res) => {
    const user = loadGrants().users[req.params.id];
    if (!user) return res.status(404).json({ error: 'unknown user' });
    user.granted = !user.granted;
    saveGrants();
    res.redirect('/admin/grants');
});

// --- Gate (mounted after the router; applies to everything else) ------------
// Only /api/* reaches this in practice (nginx serves /se/ static through the
// /auth/gate probe). Ungranted sessions get 401 JSON on data paths, exactly
// like hawkins-tv's DATA_PREFIXES.
function gate(req, res, next) {
    // Login required for UI (/se) no matter what; /api stays open for agents (docdocgo-axi, friendbot)
    if (req.path.startsWith('/api/')) return next();
    const user = sessionUser(req);
    if (user && hasGrant(user.user_id)) return next();
    return res.redirect(`/login?next=${encodeURIComponent(req.originalUrl)}`);
}

module.exports = {
    sessionMiddleware,
    router,
    gate,
    isConfigured,
    hasGrant,
    isAdmin,
    loadGrants,
    upsertGrant,
    sessionSecret,
    CAPTAIN_DISCORD_USER_ID,
    GRANTS_FILE
};
