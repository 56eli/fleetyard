// DOC-040 / GoluGit #68: useRegex must not pin the event loop on a
// pathological pattern. Prove a nested-quantifier ReDoS cannot stall
// past the budget — worker-interrupt, not a production corpus scan.
'use strict';
const assert = require('assert');
const { execRegexBounded } = require('./search-regex');

async function main() {
    // No terminal 'b': nested quantifiers backtrack exponentially.
    const pattern = '(a+)+b';
    const text = 'a'.repeat(28);
    const budgetMs = 80;
    const ticks = [];
    const iv = setInterval(() => ticks.push(Date.now()), 15);
    const t0 = Date.now();
    const result = await execRegexBounded(pattern, 'g', text, budgetMs, 10);
    const elapsed = Date.now() - t0;
    clearInterval(iv);

    assert(result.timedOut === true, `pathological regex must time out (got ${JSON.stringify(result)})`);
    assert.deepStrictEqual(result.matches, [], 'timed-out scan returns no matches');
    assert(elapsed < budgetMs + 400, `must return within budget+slack (elapsed ${elapsed}ms, budget ${budgetMs}ms)`);
    assert(ticks.length >= 1, `event loop must keep ticking during the bounded regex (ticks=${ticks.length}, elapsed=${elapsed})`);
    console.log(`✅ DOC-040: nested-quantifier ReDoS timed out in ${elapsed}ms; event loop ticks=${ticks.length}`);

    // Harmless regex still matches.
    const ok = await execRegexBounded('bliss', 'gi', 'find bliss here', 500, 10);
    assert.strictEqual(ok.timedOut, false);
    assert.strictEqual(ok.matches.length, 1);
    assert.strictEqual(ok.matches[0].text, 'bliss');
    console.log('✅ DOC-040: ordinary regex still matches');
}

main().catch((err) => {
    console.error(err);
    process.exit(1);
});
