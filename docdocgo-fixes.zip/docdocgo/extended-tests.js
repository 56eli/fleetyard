const axios = require('axios');
const assert = require('assert');
const { spawn } = require('child_process');
const path = require('path');

// Spawns its own api.js on a dedicated port so it never collides with other
// services squatting 3000 (e.g. the local GoluGit instance on this host).
const TEST_PORT = 3204;
const BASE_URL = process.env.API_URL || `http://127.0.0.1:${TEST_PORT}/api`;

let child;

function startServer() {
    child = spawn(process.execPath, ['api.js'], {
        cwd: path.join(__dirname),
        env: { ...process.env, PORT: String(TEST_PORT) },
        stdio: ['ignore', 'pipe', 'pipe']
    });
    child.stderr.on('data', (d) => process.stderr.write(`[child] ${d}`));
}

async function waitForHealth() {
    for (let i = 0; i < 60; i++) {
        try {
            const res = await axios.get(`${BASE_URL}/health`, { validateStatus: () => true, timeout: 5000 });
            if (res.status === 200) return;
        } catch (e) { /* not up yet */ }
        await new Promise((r) => setTimeout(r, 1000));
    }
    throw new Error('api did not become ready');
}

const testCases = [
    { q: 'a', expectedMin: 0, expectedMax: 0, description: 'Single char should return 0 results' },
    { q: 'the', expectedMin: 0, expectedMax: 0, description: 'Stop-word-only query returns 0 results' },
    { q: 'dfsdf', expectedMin: 0, expectedMax: 0, description: 'Random gibberish should return 0 results' },
    { q: 'tesla car', expectedMin: 1, description: 'Should find results for Tesla or car' },
    { q: 'how to be happy', expectedMin: 1, description: 'Common phrase should return results' },
    { q: 'peace self clumsy', expectedMin: 1, description: 'Multi-word search should return relevant results' },
    { q: 'nondual gratitude present moment acceptance', expectedMin: 1, description: 'Original problematic query' },
    { q: 'Love', expectedMin: 10, description: 'Common word' },
    { q: 'Spirit', expectedMin: 10, description: 'Spiritual context' },
    { q: 'Consciousness', expectedMin: 10, description: 'Core topic' },
    { q: 'Map of Consciousness', expectedMin: 1, description: 'Specific phrase' },
    { q: 'David Hawkins', expectedMin: 1, description: 'Author name' },
    { q: 'spiritual', expectedMin: 10, description: 'Common term' },
    { q: 'existence', expectedMin: 5, description: 'Common term' },
    { q: 'reality', expectedMin: 10, description: 'Common term' },
    { q: 'ego', expectedMin: 1, description: '3-char query is searchable (min-3 gate)' },
    { q: 'mind', expectedMin: 10, description: 'Common term' },
    { q: 'body', expectedMin: 5, description: 'Common term' },
    { q: 'healing', expectedMin: 5, description: 'Common term' },
    { q: 'truth', expectedMin: 10, description: 'Common term' },
    { q: 'false', expectedMin: 5, description: 'Common term' },
    { q: 'enlightenment', expectedMin: 5, description: 'Common term' },
    { q: 'duality', expectedMin: 3, description: 'Common term' },
    { q: 'non-duality', expectedMin: 1, description: 'Common term' },
    { q: 'meditation', expectedMin: 1, description: 'Common term' },
    { q: 'prayer', expectedMin: 1, description: 'Common term' },
    { q: 'god', expectedMin: 1, description: '3-char query is searchable (min-3 gate)' },
    { q: 'religion', expectedMin: 3, description: 'Common term' },
    { q: 'science', expectedMin: 1, description: 'Common term' },
    { q: 'random_query_xyz_123', expectedMin: 0, expectedMax: 0, description: 'Unique random phrase' },
    { q: 'random_query_abc_456', expectedMin: 0, expectedMax: 0, description: 'Unique random phrase' },
    { q: 'random_query_789_ghi', expectedMin: 0, expectedMax: 0, description: 'Unique random phrase' },

    { q: 'fear', expectedMin: 5, description: 'Emotion' },
    { q: 'anger', expectedMin: 5, description: 'Emotion' },
    { q: 'guilt', expectedMin: 3, description: 'Emotion' },
    { q: 'apathy', expectedMin: 2, description: 'Level' },
    { q: 'courage', expectedMin: 5, description: 'Level' },
    { q: 'willingness', expectedMin: 3, description: 'Level' },
    { q: 'acceptance', expectedMin: 5, description: 'Level' },
    { q: 'reason', expectedMin: 5, description: 'Level' },
    { q: 'joy', expectedMin: 1, description: '3-char query is searchable (min-3 gate)' },
    { q: 'peace', expectedMin: 5, description: 'Level' },
    { q: 'silence', expectedMin: 1, description: 'Common term' },
    { q: 'awareness', expectedMin: 5, description: 'Common term' },
    { q: 'presence', expectedMin: 5, description: 'Common term' },
    { q: 'infinite', expectedMin: 1, description: 'Common term' },
    { q: 'eternal', expectedMin: 1, description: 'Common term' },
    { q: 'absolute', expectedMin: 1, description: 'Common term' },
    { q: 'wisdom', expectedMin: 1, description: 'Common term' },
    { q: 'compassion', expectedMin: 1, description: 'Common term' },
    { q: 'forgiveness', expectedMin: 1, description: 'Common term' },
    { q: 'humility', expectedMin: 1, description: 'Common term' },
    { q: 'surrender', expectedMin: 5, description: 'Common term' },
    { q: 'devotion', expectedMin: 1, description: 'Common term' },
    { q: 'grace', expectedMin: 1, description: 'Common term' },
    { q: 'blessing', expectedMin: 1, description: 'Common term' },
    { q: 'ignore all thoughts', expectedMin: 1, topMatchContainsWords: ['ignore', 'all', 'thoughts'], expectedMinScore: 4.0, description: 'Keyword group: top hit has every query word and score > 4' },
    { q: 'ignore thoughts', expectedMin: 1, topMatchContains: 'ignore thoughts', expectedMinScore: 3.0, description: 'Exact phrase match' },
    { q: 'letting go', expectedMin: 1, topMatchContains: 'letting go', expectedMinScore: 3.0, description: 'Exact phrase match' },
    { q: 'accumulated pressure', expectedMin: 1, topMatchContains: 'accumulated pressure', description: 'Exact phrase match' },
    { q: 'feeling label', expectedMin: 1, description: 'Proximity ranking test' },
    { q: 'mind thoughts Useful', expectedMin: 1, description: 'Multi-word AND logic' },
    { q: 'healing techniques rapid', expectedMin: 1, description: 'Multi-word AND logic' },

    // Whole Word Tests
    { q: 'thoughts', whole: true, expectedMin: 1, description: 'Whole word "thoughts" should return results' },
    { q: 'allow', whole: true, expectedMin: 1, description: 'Whole word "allow" should return results' },

    // Case Sensitivity Tests
    { q: 'LOVE', expectedMin: 1, description: 'Case-insensitive search' },
    { q: 'love', expectedMin: 1, description: 'Case-insensitive search' },

    // Pagination & Limits
    { q: 'consciousness', limit: 50, expectedLimit: 50, description: 'Custom limit' },
    { q: 'consciousness', limit: 5, page: 2, expectedLimit: 5, description: 'Pagination' },

    // Diverse Topics
    { q: 'San Francisco', expectedMin: 1, description: 'Proper nouns' },
    { q: 'orthopedist', expectedMin: 1, description: 'Specific medical term' },
    { q: 'park bench', expectedMin: 1, description: 'Common objects' },
    { q: 'San Francisco ankle', expectedMin: 1, description: 'Combined distant terms' },
    { q: 'park bench twisting', expectedMin: 1, description: 'Combined terms' },

    // Empty/Malformed
    { q: '    ', expectedMin: 0, expectedMax: 0, description: 'Whitespace only' },
    { q: '!!!!', expectedMin: 0, expectedMax: 0, description: 'Special chars only' },

    // === TDD: Whole Word Bug Fix ===
    // Issue: 'all' as whole word should NOT match 'allow', 'automatically', etc.
    {
        q: 'all',
        whole: true,
        limit: 10,
        description: 'Whole word "all" should NOT match inside "allow" or "automatically"',
        topMatchShouldNotContain: 'allow' // match_text should never be "allow"
    },
    {
        q: 'all',
        whole: true,
        limit: 10,
        description: 'Whole word "all" should NOT match "automatically"',
        noMatchSubstring: 'autom' // snippet should not contain "automatically"
    },
    // Two-word query with whole word: 'ignore all thoughts' whole word
    {
        q: 'ignore all thoughts',
        whole: true,
        limit: 5,
        description: 'Whole word "ignore all thoughts" should match exact words only',
        expectedMin: 1
    },

    // === TDD: Relevance Ranking Improvements ===
    // Issue: exact phrase match should outrank non-exact proximity
    {
        q: 'ignore all thoughts',
        limit: 5,
        description: 'Exact phrase match should have highest score',
        topScoreMin: 3.9
    },
    {
        q: 'ignore all thoughts',
        limit: 10,
        description: 'Results sorted descending by score',
        isSortedDescending: true
    },

    // === TDD: Pagination ===
    {
        q: 'consciousness',
        limit: 5,
        page: 1,
        description: 'Page 1 returns first 5 results',
        pageResultCount: 5
    },
    {
        q: 'consciousness',
        limit: 5,
        page: 2,
        description: 'Page 2 returns 5 results with different offsets',
        pageResultCount: 5
    },

    // === TDD: Pagination no overlap ===
    {
        q: 'love',
        limit: 100,
        page: 1,
        description: 'Page 1 and page 2 have zero overlap (path:offset)',
        noOverlapWithPage: 2
    },

    // === TDD: Deterministic results ===
    {
        q: 'consciousness',
        limit: 3,
        description: 'Same query with same params returns identical results (deterministic)',
        shouldBeDeterministic: true
    },

    // === TDD: Source in response ===
    {
        q: 'meditation',
        limit: 1,
        description: 'Results should include source info in match_text',
        hasMatchTextArray: true
    },

    // === TDD: Sort Integrity ===
    {
        q: 'consciousness',
        limit: 20,
        description: 'Results should always be sorted by score descending (sort integrity check)',
        isSortedDescending: true
    },
    {
        q: 'healing',
        limit: 15,
        description: 'Healing results should be sorted by score',
        isSortedDescending: true
    },
    // Filter-specific tests
    {
        q: 'consciousness',
        filter: 'all-hawkins-books',
        limit: 5,
        expectedMin: 100,
        description: 'all-hawkins-books filter returns Hawkins books only'
    },
    {
        q: 'consciousness',
        filter: 'books',
        limit: 5,
        expectedMin: 100,
        description: 'books filter returns all books (including non-Hawkins)'
    },
    {
        q: 'Lord',
        filter: 'all-hawkins-books',
        limit: 5,
        expectedMin: 1,
        description: 'all-hawkins-books excludes Lamsa Bible (searched Lord)'
    },
    {
        q: 'Lord',
        filter: 'books',
        limit: 5,
        expectedMin: 1,
        description: 'books filter includes Lamsa Bible (searched Lord)'
    },
    {
        q: 'consciousness',
        filter: 'lectures',
        limit: 5,
        expectedMin: 100,
        description: 'lectures filter returns lectures only'
    },
    {
        q: 'meditation',
        filter: 'all-hawkins-books',
        limit: 5,
        expectedMin: 1,
        description: 'all-hawkins-books works with different query'
    }
];

async function runExtendedTests() {
    console.log(`--- Starting ${testCases.length} Extended API Tests ---`);
    console.log(`Targeting: ${BASE_URL}\n`);

    let passedCount = 0;
    let failedCount = 0;

    // Track page 1 results for overlap check
    const page1ResultPaths = new Set();

    for (let i = 0; i < testCases.length; i++) {
        const tc = testCases[i];
        process.stdout.write(`Test ${i + 1}/${testCases.length}: "${tc.q}" ... `);

        try {
            const params = { q: tc.q };
            if (tc.limit) params.limit = tc.limit;
            else if (tc.expectedLimit === undefined) params.limit = 10;

            if (tc.page) params.page = tc.page;
            if (tc.whole) params.whole = 'true';
            if (tc.filter) params.filter = tc.filter;

            const res = await axios.get(`${BASE_URL}/search`, { params });
            const count = res.data.total_matches;
            const limit = res.data.limit;

            let passed = true;
            let failReason = '';

            // Basic count checks
            if (tc.expectedMin !== undefined && count < tc.expectedMin) {
                passed = false;
                failReason = `Found ${count}, expected min ${tc.expectedMin}`;
            }
            if (tc.expectedMax !== undefined && count > tc.expectedMax) {
                passed = false;
                failReason = `Found ${count}, expected max ${tc.expectedMax}`;
            }
            if (tc.expectedLimit !== undefined && limit !== tc.expectedLimit) {
                passed = false;
                failReason = `limit=${limit}, expected ${tc.expectedLimit}`;
            }

            // Result-specific checks (only if we have results)
            if (res.data.results.length > 0) {
                const first = res.data.results[0];
                const results = res.data.results;

                // match_text should be an array
                if (tc.hasMatchTextArray && !Array.isArray(first.match_text)) {
                    passed = false;
                    failReason = 'match_text is not an array';
                }

                // Top match should contain substring in snippet
                if (tc.topMatchContains && !first.snippet.toLowerCase().includes(tc.topMatchContains.toLowerCase())) {
                    passed = false;
                    failReason = `Snippet doesn't contain "${tc.topMatchContains}"`;
                }

                // Top match should contain every query word in match_text
                if (tc.topMatchContainsWords) {
                    const matchText = (first.match_text || []).map((w) => String(w).toLowerCase());
                    const missing = tc.topMatchContainsWords.filter((w) => !matchText.includes(String(w).toLowerCase()));
                    if (missing.length) {
                        passed = false;
                        failReason = `match_text [${matchText.join(', ')}] missing ${missing.join(', ')}`;
                    }
                }

                // Top match score minimum
                if (tc.topScoreMin && first.score < tc.topScoreMin) {
                    passed = false;
                    failReason = `Score ${first.score} < ${tc.topScoreMin}`;
                }

                // Top match score minimum (legacy field name)
                if (tc.expectedMinScore && first.score < tc.expectedMinScore) {
                    passed = false;
                    failReason = `Score ${first.score} < ${tc.expectedMinScore}`;
                }

                // Whole word: top match_text should NOT contain substring
                if (tc.topMatchShouldNotContain) {
                    const matchTextStr = first.match_text.join(' ');
                    if (matchTextStr.toLowerCase().includes(tc.topMatchShouldNotContain.toLowerCase())) {
                        passed = false;
                        failReason = `match_text "${matchTextStr}" contains "${tc.topMatchShouldNotContain}"`;
                    }
                }

                // Whole word: snippet should NOT contain substring
                if (tc.noMatchSubstring && first.snippet.toLowerCase().includes(tc.noMatchSubstring.toLowerCase())) {
                    passed = false;
                    failReason = `Snippet contains "${tc.noMatchSubstring}" (whole word violation)`;
                }

                // Sorted descending by score
                if (tc.isSortedDescending) {
                    for (let j = 1; j < results.length; j++) {
                        if (results[j].score > results[j - 1].score) {
                            passed = false;
                            failReason = `Not sorted: result[${j}].score=${results[j].score} > result[${j-1}].score=${results[j-1].score}`;
                            break;
                        }
                    }
                }

                // Page result count check
                if (tc.pageResultCount && results.length !== tc.pageResultCount) {
                    passed = false;
                    failReason = `Page returned ${results.length} results, expected ${tc.pageResultCount}`;
                }

                // No-overlap check: fetch the specified page and compare path:offset IDs
                if (tc.noOverlapWithPage) {
                    const otherRes = await axios.get(`${BASE_URL}/search`, { params: { q: tc.q, limit: tc.limit || 100, page: tc.noOverlapWithPage } });
                    const currentIds = new Set(results.map(r => `${r.path}:${r.offset}`));
                    const otherIds = otherRes.data.results.map(r => `${r.path}:${r.offset}`);
                    const overlap = otherIds.filter(id => currentIds.has(id));
                    if (overlap.length > 0) {
                        passed = false;
                        failReason = `Pagination overlap: ${overlap.length} results appear on both page ${tc.page || 1} and page ${tc.noOverlapWithPage}`;
                    }
                }

                // Track page 1 paths for overlap check
                if (tc.shouldNotOverlapWithPage1) {
                    // This is page 2 - check against page 1
                    for (const r of results) {
                        if (page1ResultPaths.has(r.path)) {
                            passed = false;
                            failReason = `Overlap detected: path "${r.path}" found in both page 1 and page 2`;
                            break;
                        }
                    }
                }
            }

            // Deterministic check: same query + params should return identical results
            if (tc.shouldBeDeterministic) {
                const resultsPerCall = tc.limit || 10;
                const responses = [];
                for (let k = 0; k < 3; k++) {
                    const rr = await axios.get(`${BASE_URL}/search`, { params: { q: tc.q, limit: resultsPerCall } });
                    responses.push(rr.data.results.map(r => ({ path: r.path, score: r.score, offset: r.offset })));
                }
                const allSame = responses.every(r => JSON.stringify(r) === JSON.stringify(responses[0]));
                if (!allSame) {
                    passed = false;
                    failReason = `Same query returned different results across 3 calls (expected deterministic)`;
                }
            }

            if (passed) {
                const scoreInfo = res.data.results.length > 0 ? `, top score: ${res.data.results[0].score}` : '';
                console.log(`✅ OK (${count} matches${scoreInfo})`);

                // Store page 1 paths for later overlap check
                if (res.data.page === 1) {
                    for (const r of res.data.results) {
                        page1ResultPaths.add(r.path);
                    }
                }
                passedCount++;
            } else {
                console.log(`❌ FAIL — ${failReason}`);
                failedCount++;
            }
        } catch (error) {
            if (tc.expectedMax === 0 && error.response && error.response.status === 400) {
                console.log(`✅ OK (Correctly rejected with 400)`);
                passedCount++;
            } else {
                console.log(`❌ ERROR: ${error.message} ${error.response ? JSON.stringify(error.response.data) : ''}`);
                failedCount++;
            }
        }
    }


    console.log(`\n--- Extended Test Summary ---`);
    console.log(`Total: ${testCases.length}`);
    console.log(`Passed: ${passedCount}`);
    console.log(`Failed: ${failedCount}`);
    if (failedCount > 0) {
        child.kill('SIGTERM');
        process.exit(1);
    }
}

async function main() {
    startServer();
    try {
        await waitForHealth();
        await runExtendedTests();
    } finally {
        child.kill('SIGTERM');
    }
}

main();
