// End-to-end tests for the Discord-login + admin-approval gate (auth.js).
//
// Runs in the repo's existing test style (axios + assert, no framework).
// The regular e2e-test.js runs against an unconfigured server where the
// gate is off; this suite spawns its own api.js with Discord OAuth env
// vars set, so the gate is active, and exercises the whole flow:
//
//   no session          -> /api/* stays open (no blanket gate), /se/ (auth/gate) 401,
//                          /auth/entry redirects to /login
//   captain test login  -> granted (seeded) -> /auth/gate 200
//   unknown test login  -> pending -> /auth/entry 403 page
//   captain toggles     -> grant applies on the next request
//   non-admin cannot    -> toggle is 403
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const axios = require('axios');
const assert = require('assert');

const TEST_PORT = 3199;
const BASE = `http://127.0.0.1:${TEST_PORT}`;
const API = `${BASE}/api`;
// Same id as the captain seed (mirrors hawkins-tv's migration).
const CAPTAIN_ID = '1298076640043073548';
const OTHER_ID = '999888777666555444';

let child;
let cookie = '';

function captureCookie(res) {
    const sc = res.headers['set-cookie'];
    if (sc) cookie = sc.map((c) => c.split(';')[0]).join('; ');
}

async function request(method, url, opts = {}) {
    const headers = { ...(opts.headers || {}) };
    if (cookie) headers.Cookie = cookie;
    try {
        const res = await axios.request({
            method,
            url,
            headers,
            maxRedirects: 0,
            validateStatus: () => true,
            timeout: 15000,
            ...opts.axios
        });
        captureCookie(res);
        return res;
    } catch (err) {
        console.error(`Request failed: ${method} ${url}`, err.message);
        throw err;
    }
}

function get(url, opts) { return request('GET', url, opts); }
function post(url, opts) { return request('POST', url, opts); }

function startServer() {
    const grantsFile = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'docdocgo-auth-test-')), 'grants.json');
    child = spawn(process.execPath, ['api.js'], {
        cwd: path.join(__dirname),
        env: {
            ...process.env,
            PORT: String(TEST_PORT),
            GRANTS_FILE: grantsFile,
            AUTH_TEST_MODE: '1',
            DISCORD_CLIENT_ID: 'test-client-id',
            DISCORD_CLIENT_SECRET: 'test-client-secret',
            DISCORD_REDIRECT_URI: `${BASE}/callback`
        },
        stdio: ['ignore', 'pipe', 'pipe']
    });
    child.stderr.on('data', (d) => process.stderr.write(`[child] ${d}`));
}

async function waitForHealth() {
    for (let i = 0; i < 60; i++) {
        try {
            const res = await get(`${API}/health`);
            if (res.status === 200) return;
        } catch (e) { /* not up yet */ }
        await new Promise((r) => setTimeout(r, 1000));
    }
    throw new Error('api did not become ready');
}

function loginAs(uid) {
    return get(`${API}/test-login?user_id=${encodeURIComponent(uid)}`);
}

async function runTests() {
    console.log('--- Auth gate E2E Tests ---');
    startServer();
    try {
        await waitForHealth();
        console.log('Target server ready.');

        // 1. No blanket gate on /api/* (reverted: internal tools use it without
        //    a Discord session — abuse protection is rate limiting instead).
        //    The nginx auth_request probe still enforces access to /se/.
        const noAuthFiles = await get(`${API}/files`);
        assert.strictEqual(noAuthFiles.status, 200, 'no-session /api/files should stay open');
        assert(noAuthFiles.data.count > 0, 'files list should be non-empty');
        const noAuthGate = await get(`${BASE}/auth/gate`);
        assert.strictEqual(noAuthGate.status, 401, 'no-session /auth/gate should be 401');
        console.log('✅ unauthenticated /api/* → 200 (open), /auth/gate → 401');

        // 2. Public pages stay public.
        const login = await get(`${BASE}/login`);
        assert.strictEqual(login.status, 200, '/login should be public');
        assert(login.data.includes('Login with Discord'), 'login page should render the Discord button');
        const health = await get(`${API}/health`);
        assert.strictEqual(health.status, 200, '/api/health should stay public');
        console.log('✅ /login and /api/health stay public');

        // 3. No session: nginx-style /auth/entry redirects to /login with next.
        const entry = await get(`${BASE}/auth/entry`, { headers: { 'X-Original-URI': '/se/' } });
        assert.strictEqual(entry.status, 302, '/auth/entry should redirect to login');
        assert(entry.headers.location.startsWith('/login?next='), `redirect to login with next (got ${entry.headers.location})`);
        console.log('✅ /auth/entry redirects unauthenticated /se/ to /login?next=...');

        // 4. test-login locks itself down: 403 without AUTH_TEST_MODE.
        //    (The main e2e-test.js checks this against the unconfigured server.)

        // 5. Captain (seeded granted + admin) gets in.
        await loginAs(CAPTAIN_ID);
        const captainFiles = await get(`${API}/files`);
        assert.strictEqual(captainFiles.status, 200, 'captain should reach /api/files');
        assert(captainFiles.data.count > 0, 'files list should be non-empty');
        const captainGate = await get(`${BASE}/auth/gate`);
        assert.strictEqual(captainGate.status, 200, 'captain /auth/gate should be 200');
        console.log('✅ captain (seeded grant) → /api/* 200, /auth/gate 200');

        // 6. Unknown user: logged in but pending. The API stays open to them
        //    (no gate on /api/*); only /se/ (via /auth/entry) blocks pending users.
        const otherLogin = await loginAs(OTHER_ID);
        assert.strictEqual(otherLogin.status, 200, 'test-login should succeed');
        assert.strictEqual(otherLogin.data.granted, false, 'unknown user should start ungranted');
        const otherFiles = await get(`${API}/files`);
        assert.strictEqual(otherFiles.status, 200, 'pending user /api/files stays open');
        const otherEntry = await get(`${BASE}/auth/entry`, { headers: { 'X-Original-URI': '/se/' } });
        assert.strictEqual(otherEntry.status, 403, 'pending user /auth/entry should be 403');
        assert(otherEntry.data.includes('Access pending'), 'pending page should render');
        console.log('✅ pending user → /api/* stays open, /auth/entry 403 pending page');

        // 7. Pending user cannot toggle grants (not admin).
        const nonAdminToggle = await post(`${BASE}/admin/grants/${CAPTAIN_ID}/toggle`);
        assert.strictEqual(nonAdminToggle.status, 403, 'non-admin toggle should be 403');
        console.log('✅ non-admin toggle → 403');

        // 8. Captain (admin) grants the pending user; takes effect next request.
        await loginAs(CAPTAIN_ID);
        const toggle = await post(`${BASE}/admin/grants/${OTHER_ID}/toggle`);
        assert.strictEqual(toggle.status, 302, 'admin toggle should redirect (PRG)');
        await loginAs(OTHER_ID);
        const grantedFiles = await get(`${API}/files`);
        assert.strictEqual(grantedFiles.status, 200, 'granted user should reach /api/files');
        console.log('✅ admin toggle grants on next request');

        // 9. Revoke applies to the gate (which no longer covers /api/*); the
        //    pending user still reaches the open API but stays blocked on /se/.
        await loginAs(CAPTAIN_ID);
        await post(`${BASE}/admin/grants/${OTHER_ID}/toggle`);
        await loginAs(OTHER_ID);
        const revokedFiles = await get(`${API}/files`);
        assert.strictEqual(revokedFiles.status, 200, 'revoked user /api/files stays open');
        const revokedGate = await get(`${BASE}/auth/gate`);
        assert.strictEqual(revokedGate.status, 401, 'revoked user /auth/gate should be 401 again');
        console.log('✅ revoke applies on next request (/auth/gate 401, /api open)');

        console.log('\n--- All Auth Gate Tests Passed Successfully ---');
    } finally {
        child.kill('SIGTERM');
    }
}

runTests().catch((err) => {
    console.error('\n❌ Auth Gate Test Suite Failed:');
    console.error(err.message);
    if (err.response) console.error(err.response.status, JSON.stringify(err.response.data).slice(0, 300));
    child.kill('SIGTERM');
    process.exit(1);
});
