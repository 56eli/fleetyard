#!/bin/sh
# ─── DocDocGo End-to-End Test Script ───────────────────────────
# Starts the app stack via Docker Compose, waits for readiness,
# exercises key API endpoints, then cleans up.
#
# Usage: bash test.sh
#   --no-teardown  Skip docker compose down at the end
#   --ci           CI mode: less verbose, exit code only
#
# IMPORTANT: only tears the stack down if THIS script started it. If the
# stack was already running (e.g. prod), it is left exactly as found.
# ───────────────────────────────────────────────────────────────

set -u

NO_TEARDOWN=false
CI_MODE=false
for arg in "$@"; do
  case "$arg" in
    --no-teardown) NO_TEARDOWN=true ;;
    --ci) CI_MODE=true ;;
  esac
done

# Was the stack already up before we touched it? If so, never tear it down.
STACK_WAS_RUNNING=false
if docker compose ps --status running -q 2>/dev/null | grep -q .; then
  STACK_WAS_RUNNING=true
fi

PASS=0
FAIL=0
BASE_API="http://localhost:12854/api"

pass() {
  PASS=$((PASS+1))
  [ "$CI_MODE" = false ] && echo "  PASS  $1"
}

fail() {
  FAIL=$((FAIL+1))
  echo "  FAIL  $1"
}

ok_or_fail() {
  code="$1"
  desc="$2"
  if [ "$code" -eq 200 ] || [ "$code" -eq 301 ] || [ "$code" -eq 302 ]; then
    pass "$desc (${code})"
  else
    fail "$desc (${code})"
  fi
}

# ── 1. Build & Start ─────────────────────────────────────────
echo "=== DocDocGo E2E Tests ==="
echo ""
echo "--- Building and starting services ---"

docker compose build api > /dev/null 2>&1
docker compose up -d > /dev/null 2>&1

# ── 2. Wait for API health ───────────────────────────────────
echo "--- Waiting for API to be ready ---"
API_READY=false
for i in $(seq 1 30); do
  if curl -sf "${BASE_API}/health" >/dev/null 2>&1; then
    API_READY=true
    break
  fi
  sleep 2
done

if [ "$API_READY" = "true" ]; then
  pass "API health check"
else
  fail "API health check (timeout)"
  echo "--- Cleaning up ---"
  docker compose logs api
  if [ "$STACK_WAS_RUNNING" = false ] && [ "$NO_TEARDOWN" = false ]; then
    docker compose down > /dev/null 2>&1
  fi
  exit 1
fi

# ── 3. Endpoint Tests ────────────────────────────────────────
echo "--- Testing API endpoints ---"

# GET /api – root documentation endpoint
STATUS=$(curl -s -o /dev/null -w '%{http_code}' "${BASE_API}/")
ok_or_fail "$STATUS" "Root API endpoint (GET /api/)"

# GET /api/health
STATUS=$(curl -s -o /dev/null -w '%{http_code}' "${BASE_API}/health")
ok_or_fail "$STATUS" "Health endpoint (GET /api/health)"

# GET /api/files
FILES_RESP=$(curl -s "${BASE_API}/files")
FILES_COUNT=$(echo "$FILES_RESP" | grep -o '"count":[0-9]*' | grep -o '[0-9]*')
if [ -n "$FILES_COUNT" ] && [ "$FILES_COUNT" -gt 0 ]; then
  pass "GET /api/files returns ${FILES_COUNT} files"
else
  fail "GET /api/files returns files"
fi

# GET /api/read/<first_file>
FIRST_FILE=$(echo "$FILES_RESP" | sed 's/.*"files":\["\([^"]*\)".*/\1/')
if [ -n "$FIRST_FILE" ]; then
  STATUS=$(curl -s -o /dev/null -w '%{http_code}' "${BASE_API}/read/${FIRST_FILE}")
  ok_or_fail "$STATUS" "Read first file (GET /api/read/${FIRST_FILE})"
else
  fail "Read first file (no files found)"
fi

# GET /api/read/nonexistent → 404
STATUS=$(curl -s -o /dev/null -w '%{http_code}' "${BASE_API}/read/nonexistent_file")
if [ "$STATUS" = "404" ]; then
  pass "GET /api/read/nonexistent → 404"
else
  fail "GET /api/read/nonexistent → 404 (got ${STATUS})"
fi

# Path traversal security → 400 or 404
STATUS=$(curl -s -o /dev/null -w '%{http_code}' "${BASE_API}/read/../../api.js")
if [ "$STATUS" = "400" ] || [ "$STATUS" = "404" ]; then
  pass "Path traversal blocked (${STATUS})"
else
  fail "Path traversal blocked (got ${STATUS})"
fi

# ── 4. Search Tests ──────────────────────────────────────────
echo "--- Testing search functionality ---"

# Search for 'love' → should return results
SEARCH_RESP=$(curl -s "${BASE_API}/search?q=love&limit=5")
SEARCH_COUNT=$(echo "$SEARCH_RESP" | grep -o '"total_matches":[0-9]*' | grep -o '[0-9]*')
if [ -n "$SEARCH_COUNT" ] && [ "$SEARCH_COUNT" -gt 0 ]; then
  pass "Search 'love' finds ${SEARCH_COUNT} matches"
else
  fail "Search 'love' returns results"
fi

# Search for short query → 0 results
SEARCH2=$(curl -s "${BASE_API}/search?q=ab&limit=5")
SEARCH2_COUNT=$(echo "$SEARCH2" | grep -o '"total_matches":[0-9]*' | grep -o '[0-9]*')
if [ -n "$SEARCH2_COUNT" ] && [ "$SEARCH2_COUNT" -eq 0 ]; then
  pass "Short query 'ab' returns 0 results"
else
  fail "Short query 'ab' returns 0 results (got ${SEARCH2_COUNT})"
fi

# Search headers include Content-Type: application/json
CONTENT_TYPE=$(curl -s -o /dev/null -w '%{content_type}' "${BASE_API}/search?q=love&limit=1")
if echo "$CONTENT_TYPE" | grep -qi "application/json"; then
  pass "Search response is JSON"
else
  fail "Search response is JSON (got ${CONTENT_TYPE})"
fi

# Search with pagination: page 1 and page 2 should differ
PAGE1=$(curl -s "${BASE_API}/search?q=consciousness&limit=3&page=1")
PAGE2=$(curl -s "${BASE_API}/search?q=consciousness&limit=3&page=2")
P1_RESULTS=$(echo "$PAGE1" | grep -o '"offset":[0-9]*' | head -3)
P2_RESULTS=$(echo "$PAGE2" | grep -o '"offset":[0-9]*' | head -3)
if [ "$P1_RESULTS" != "$P2_RESULTS" ]; then
  pass "Pagination returns different results"
else
  fail "Pagination returns different results (pages appear identical)"
fi

# ── 5. API docs endpoint ─────────────────────────────────────
DOCS_RESP=$(curl -s "${BASE_API}/docs")
DOCS_STATUS=$(echo "$DOCS_RESP" | grep -o '"service":"[^"]*"' | grep -o '"DocDocGo API"')
if [ -n "$DOCS_STATUS" ]; then
  pass "API docs endpoint"
else
  fail "API docs endpoint"
fi

# ── Summary ──────────────────────────────────────────────────
echo ""
echo "========================================"
echo "  Results: ${PASS} passed, ${FAIL} failed"
echo "========================================"

# ── 6. Cleanup ──────────────────────────────────────────────
echo "--- Cleaning up ---"
if [ "$NO_TEARDOWN" = true ]; then
  echo "Skipping teardown (--no-teardown)."
elif [ "$STACK_WAS_RUNNING" = true ]; then
  echo "Stack was already running before tests — leaving it untouched."
else
  docker compose down > /dev/null 2>&1
  echo "Services stopped."
fi

if [ "$FAIL" -gt 0 ]; then
  exit 1
fi
exit 0
