## Bug Report

### Describe the bug
A clear and concise description of what the bug is.

### To Reproduce
Steps to reproduce the behavior:
1. Go to '...'
2. Click on '...'
3. Scroll to '...'
4. See error

### Expected behavior
A clear and concise description of what you expected to happen.

### Screenshots / Logs
If applicable, add screenshots or log output to help explain the problem.

### Environment
- **Deployment:** [e.g. production at docdocgo.lak.nz, local Docker]
- **Browser / Client:** [e.g. Chrome 120, curl, api client]
- **Query / Endpoint:** [e.g. `/api/search?q=love`]

### Additional context
Add any other context about the problem here.

/label ~bug
