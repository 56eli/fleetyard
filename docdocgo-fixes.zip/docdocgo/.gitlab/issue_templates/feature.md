## Feature Request

### Problem statement
What problem does this feature solve? Describe the use case clearly.

### Proposed solution
A clear and concise description of what you want to happen.

### Alternatives considered
Describe any alternative solutions or features you have considered.

### Implementation notes
- **Affected components:** [e.g. api.js, rag/rag_service.py, HTML UI]
- **API changes:** [e.g. new endpoint, new query parameter]
- **Dependencies:** [e.g. new npm package, new Python package]

### Testing considerations
How should this feature be tested? Include edge cases.

### Additional context
Add any other context, mockups, or examples here.

/label ~feature
