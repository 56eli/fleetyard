// E2E test for the /api/* rate limiter (api.js + express-rate-limit).
//
// Runs in the repo's existing test style (axios + assert, no framework).
// Spawns its own api.js with a tiny RATE_LIMIT_MAX, then verifies:
//
//   /api/*          -> 200 up to the cap, 429 once the cap is hit,
//                      RateLimit-* headers present
//   /api/health     -> exempt (served by the auth router, never throttled)
//   public IP       -> still 429 (issue #91: do not disable the public limiter)
//   Friendbot path  -> X-Internal-Token matching INTERNAL_API_TOKEN is not 429
const { spawn } = require('child_process');
const fs = require('fs');
const http = require('http');
const path = require('path');
const axios = require('axios');
const assert = require('assert');

axios.defaults.httpAgent = new http.Agent({ keepAlive: false });

const TEST_PORT = 3201;
const TEST_PORT_NOENV = 3202;
const BASE = `http://127.0.0.1:${TEST_PORT}`;
const BASE_NOENV = `http://127.0.0.1:${TEST_PORT_NOENV}`;
// Deliberately tiny so the test doesn't need to hammer the server.
const MAX = 3;
// Shared secret for the least-privilege internal exemption (test-only value).
const INTERNAL_TOKEN = 'test-internal-token-3201';
const PUBLIC_IP = '203.0.113.50';

let child;

function startServer(port = TEST_PORT, extraEnv = {}) {
    const env = {
        ...process.env,
        PORT: String(port),
        RATE_LIMIT_MAX: String(MAX),
        RATE_LIMIT_WINDOW_MS: String(60 * 1000),
        ...extraEnv
    };
    // Default-deny must not inherit a host INTERNAL_API_TOKEN.
    if (!extraEnv.INTERNAL_API_TOKEN) delete env.INTERNAL_API_TOKEN;
    child = spawn(process.execPath, ['api.js'], {
        cwd: path.join(__dirname),
        env,
        stdio: ['ignore', 'pipe', 'pipe']
    });
    child.stderr.on('data', (d) => process.stderr.write(`[child] ${d}`));
}

async function waitForHealth(base = BASE) {
    for (let i = 0; i < 60; i++) {
        try {
            const res = await axios.get(`${base}/api/health`, { validateStatus: () => true, timeout: 5000 });
            if (res.status === 200) return;
        } catch (e) { /* not up yet */ }
        await new Promise((r) => setTimeout(r, 1000));
    }
    throw new Error('api did not become ready');
}

async function runTests() {
    console.log('--- Rate Limit E2E Tests ---');
    const apiSrc = fs.readFileSync(path.join(__dirname, 'api.js'), 'utf8');
    assert.ok(/RATE_LIMIT_WINDOW_MS \|\| String\(2 \* 60 \* 1000\)/.test(apiSrc),
        'api.js default window must be 2 minutes');
    assert.ok(/RATE_LIMIT_MAX \|\| '100'/.test(apiSrc),
        'api.js default max must be 100');
    assert.ok(/skip:\s*\(req\)\s*=>\s*isInternalRequest\(req\)/.test(apiSrc),
        'internal X-Internal-Token skip must stay');
    const compose = fs.readFileSync(path.join(__dirname, 'docker-compose.yml'), 'utf8');
    assert.ok(compose.includes('RATE_LIMIT_WINDOW_MS=${RATE_LIMIT_WINDOW_MS:-120000}'),
        'compose default window must be 120000');
    assert.ok(compose.includes('RATE_LIMIT_MAX=${RATE_LIMIT_MAX:-100}'),
        'compose default max must be 100');
    console.log('✅ #134 default limiter is 100 requests / 2 minutes per IP (skip intact)');

    startServer(TEST_PORT, { INTERNAL_API_TOKEN: INTERNAL_TOKEN });
    try {
        await waitForHealth();
        console.log('Target server ready.');

        // 1. /api/health is exempt from the limiter: hammer it past the cap.
        for (let i = 0; i < MAX + 3; i++) {
            const health = await axios.get(`${BASE}/api/health`, { validateStatus: () => true });
            assert.strictEqual(health.status, 200, `/api/health should never 429 (attempt ${i + 1})`);
        }
        console.log(`✅ /api/health stays 200 past the ${MAX}/min cap (exempt)`);

        // 2. /api/files is limited: MAX requests 200, then 429.
        let last;
        for (let i = 0; i < MAX; i++) {
            last = await axios.get(`${BASE}/api/files`, { validateStatus: () => true });
            assert.strictEqual(last.status, 200, `/api/files should be 200 (attempt ${i + 1})`);
        }
        const limited = await axios.get(`${BASE}/api/files`, { validateStatus: () => true });
        assert.strictEqual(limited.status, 429, 'over-cap request should be 429');
        assert.strictEqual(limited.data.error, 'Too many requests, please try again later.', '429 body should keep stable error string');
        assert(typeof limited.data.message === 'string' && limited.data.message.length > 20, '429 should include a gracious message');
        assert(Number.isInteger(limited.data.retry_after_seconds) && limited.data.retry_after_seconds >= 1, '429 should say how long to wait');
        assert.strictEqual(limited.data.limit, MAX, '429 should echo the limit');
        assert.strictEqual(limited.data.docs, '/api/docs', '429 should point at docs');
        assert.strictEqual(Number(limited.headers['ratelimit-limit']), MAX, 'RateLimit-Limit header should be present');
        assert.strictEqual(Number(limited.headers['ratelimit-remaining']), 0, 'RateLimit-Remaining header should be 0');
        assert(limited.headers['retry-after'], 'Retry-After header should be set');
        console.log(`✅ /api/files → ${MAX}x 200 then gracious 429 with retry_after_seconds + headers`);

        // 3. Other /api/* routes share the same bucket.
        const docs = await axios.get(`${BASE}/api/docs`, { validateStatus: () => true });
        assert.strictEqual(docs.status, 429, '/api/docs should share the same client bucket');
        console.log('✅ /api/docs shares the bucket (429)');

        // 4. A simulated public IP (X-Forwarded-For; trust proxy 1) has its
        // own bucket and still 429s when exhausted — the public limiter is
        // not disabled (issue #91 constraint).
        const pubHeaders = { 'X-Forwarded-For': PUBLIC_IP };
        for (let i = 0; i < MAX; i++) {
            const r = await axios.get(`${BASE}/api/files`, {
                validateStatus: () => true,
                headers: pubHeaders
            });
            assert.strictEqual(r.status, 200, `public IP /api/files should be 200 (attempt ${i + 1})`);
        }
        const publicLimited = await axios.get(`${BASE}/api/files`, {
            validateStatus: () => true,
            headers: pubHeaders
        });
        assert.strictEqual(publicLimited.status, 429, 'exhausted public IP must still 429');
        console.log(`✅ public IP ${PUBLIC_IP} still 429 after ${MAX} requests (limiter intact)`);

        // 5. Least-privilege internal exemption (Issue #91): a request carrying
        // the shared X-Internal-Token header is NOT rate-limited, even though
        // the same client IP bucket is already exhausted above. The public path
        // (no header) stays 429 — the limiter is skipped only for the secret.
        const internal = await axios.get(`${BASE}/api/files`, {
            validateStatus: () => true,
            headers: { 'X-Internal-Token': INTERNAL_TOKEN }
        });
        assert.strictEqual(internal.status, 200, 'X-Internal-Token request should bypass the limiter (not 429)');
        const docsOk = await axios.get(`${BASE}/api/docs`, {
            validateStatus: () => true,
            headers: { 'X-Internal-Token': INTERNAL_TOKEN }
        });
        assert.strictEqual(docsOk.status, 200, 'token path /api/docs should be 200');
        assert(typeof docsOk.data.rate_limiting.internal_token === 'string'
            && /X-Internal-Token/.test(docsOk.data.rate_limiting.internal_token),
            '/api/docs should document the internal token exemption');
        assert(/INTERNAL_API_TOKEN/.test(docsOk.data.rate_limiting.internal_token),
            '/api/docs internal_token should name the env var');
        console.log('✅ X-Internal-Token (Friendbot) path not 429; /api/docs documents it');

        // 6. A WRONG internal token still gets limited — the exemption is not a
        // blanket bypass; only the exact shared secret is honoured.
        const wrong = await axios.get(`${BASE}/api/files`, {
            validateStatus: () => true,
            headers: { 'X-Internal-Token': 'definitely-not-the-secret' }
        });
        assert.strictEqual(wrong.status, 429, 'a wrong X-Internal-Token should still be rate-limited');
        console.log('✅ wrong X-Internal-Token still 429 (least-privilege: exact secret only)');

        // 7. Default-deny is the security floor of the exemption: when the env
        // var is UNSET, the exemption must NOT silently activate. Restart the
        // server with no INTERNAL_API_TOKEN, exhaust the bucket, then send a
        // request carrying a *matching* X-Internal-Token — it must still be
        // 429. This proves the "public still 429 (any IP, incl. loopback)"
        // guarantee holds even if an operator forgets to set the env.
        child.kill('SIGTERM');
        startServer(TEST_PORT_NOENV);
        await waitForHealth(BASE_NOENV);
        console.log('Default-deny server (no INTERNAL_API_TOKEN) ready.');
        for (let i = 0; i < MAX; i++) {
            const r = await axios.get(`${BASE_NOENV}/api/files`, { validateStatus: () => true });
            assert.strictEqual(r.status, 200, `no-env /api/files should be 200 (attempt ${i + 1})`);
        }
        const noenv = await axios.get(`${BASE_NOENV}/api/files`, {
            validateStatus: () => true,
            headers: { 'X-Internal-Token': INTERNAL_TOKEN }
        });
        assert.strictEqual(noenv.status, 429, 'default-deny: a *matching* X-Internal-Token must still 429 when INTERNAL_API_TOKEN is unset');
        console.log('✅ default-deny: matching X-Internal-Token still 429 when INTERNAL_API_TOKEN is unset');

        console.log('\n--- All Rate Limit Tests Passed Successfully ---');
    } finally {
        child.kill('SIGTERM');
    }
}

runTests().catch((err) => {
    console.error('\n❌ Rate Limit Test Suite Failed:');
    console.error(err.message);
    if (err.response) console.error(err.response.status, JSON.stringify(err.response.data).slice(0, 300));
    child.kill('SIGTERM');
    process.exit(1);
});
