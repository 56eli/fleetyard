# DocDocGo — Handoff

State of the project, what changed recently, and what is still open. Last updated 2026-08-17 21:50 NZST.

## Current (2026-08-17 evening)

- Branch **asr-overlay-batch20**. Prod pin **80** (`e2adfa6`, Oct 2007 Creation + Apr 2007 Relativism).
- Quote links live: `GET /api/quote/:fileName?p=&n=` + search UI Link button (`ead8e25`, `2496fc0`).
- Ship path: VPS `ship-overlays.sh` (this repo) + NAS `/home/ls/hawkins-batch20/ship-next-overlays.sh`. Tests gate every ship. api-only deploy. Never AUTH_TEST_MODE, never compose down.
- ASR engine on NAS/whitebox: 80 overlays live; 82 slugs / 231 keys mapped (almost all monthly lectures + volumes + clean archival bundles). In flight: aug-2007 → jun/jul/nov-2007 → jan/jun/nov-2008.
- Leftover unmapped lecture keys (share media with already-overlaid talks, or no file): Alcoholism, Depression, Health, Stress, satsang_june_2010.
- GitLab fork still not synced.

## Where things live

- **Production**: `https://docdocgo.lak.nz` — docker compose stack running on THIS box.
  - `nginx` → host port 12853 (TLS terminates at Cloudflare; nginx proxies /se/ + /api/)
  - `api` → host port 12854 (`api.js`, Express)
  - `rag` container is REMOVED (see "RAG disabled" below)
- **Code**: `main` branch. Two remotes:
  - `origin` = local GoluGit/Forgejo at `127.0.0.1:3000` (localhost-only, repo is PRIVATE, token embedded in remote URL — don't print it). This is the only remote we can push to right now.
  - `gitlab` = `git@gitlab.com:lakshaynz/docdocgo` — the CI host. Direct pushes are blocked (`@admin3612` has read-only rights on the project), but **SSH push-create works**, so the fork `gitlab.com/admin3612/docdocgo` exists and `main` is synced there. MR to upstream is pending (see Open items).
- Port **3000 is GoluGit, NOT the API**. All test files spawn their own server on dedicated ports (3199, 3201–3204). Never point tests at `localhost:3000`.

## Recent work (all on main, all deployed to prod + pushed to origin)

1. **Lecture text cleanup merged** (fm/docdocgo-parser-29): `cleanLectureText()` strips WEBVTT headers/cue numbers, reflows ~42-char shards into sentences, splits run-on lines, applies Hawkins ASR hotword fixes (eagle→ego, tractor fields→attractor field, Romana→Ramana, etc.). 3-pass `parseChapters()` now also handles I_AM_THAT dialogues + Be_as_you_are. Data files stay read-only; all fixes in code. Effect: Health lecture went 2825 → 427 readable lines.
2. **Test infra fixed**: `e2e-test.js`/`extended-tests.js` were hitting `localhost:3000` (GoluGit). Now every test self-spawns the API on its own port. Full suite green: `npm test` + `npm run test:extended` (94) + Cypress 7/7.
3. **Cypress** now runs against an isolated stack (`cypress-compose.yml`, project `docdocgo-cypress`) so prod containers are untouched; specs log in via `/api/test-login` and visit the real gated `/se/` path.
4. **RAG disabled**: rag + rag-populate parked behind `profiles: ["rag"]`; api no longer `depends_on` it; `/api/rag*` proxies fail gracefully. Volumes kept. Re-enable steps at bottom.
5. **Memory caps** (VPS OOM protection, cgroup-kill): api 1g, nginx 256m, rag 4g, cypress 2g + 512m shm.
6. **CI rewritten** (`.gitlab-ci.yml`): RAG steps removed from test/cypress jobs, `AUTH_TEST_MODE=1` only in the cypress job, builds only the api image. **Not yet run** (see GitLab blocker).
7. **Transcription-quality gate** (`quality-check.js`): hard checks (residual WEBVTT/`-->`/cue digits, empty lectures) FAIL docker build (`RUN node quality-check.js`) and the container pre-start (`api.js` runs `checkLectures()` on the corpus it just loaded, before listen). Soft metrics (median line length, short-line ratio, run-ons, count vs `EXPECTED_LECTURES=280`) are warn-only — a flaky hard gate would take prod down. `quality-tests.js` (runs in `npm test`) pins corpus-wide hard checks + `Spiritual_Traps_Oct_2005_Part_2` reflow bounds.
8. **test.sh footgun fixed**: plain `./test.sh` used to run `docker compose down` at the end — it killed the live prod stack once (502 on the site). Now it snapshots `docker compose ps --status running` before `up -d` and only tears down a stack it started itself. `--no-teardown` still forces skip.

## Open items

1. **GitLab MR is open but unmerged** — the highest-priority loose end.
   - Direct pushes to `gitlab.com/lakshaynz/docdocgo` are rejected (`@admin3612` read-only). But `git push git@gitlab.com:admin3612/docdocgo.git main` works — the fork now exists with `main` at `e4c291d`, matching GoluGit.
   - **To land main on gitlab.com**: open the MR from the fork → upstream. One click: `https://gitlab.com/lakshaynz/docdocgo/-/compare/main...admin3612:main` → "Create merge request" (source `admin3612:main`, target `lakshaynz/docdocgo:main`). Merging also lets the rewritten pipeline actually run.
   - `glab`/API is NOT available: the PAT in `~/.config/glab-cli/config.yml` and the OAuth2 refresh token are both dead (401 / `invalid_grant`). No other GitLab token exists on this box. If a fresh PAT with `api` scope is provided, fork→push→MR can be fully automated via glab.
2. **Prod-drift guard (not built)**: script comparing repo HEAD's `api.js` hash vs the running container's — catches "prod running old code" before it bites. Small, safe, self-contained.
3. **User's test cases**: owner is sending the queries/behaviors they care about — pin them into `extended-tests.js` / `quality-tests.js`.
4. **Quality follow-ups** (soft findings, non-blocking): ~20 lectures have run-on lines >900 chars the splitter misses (worst: `Dialogue_Questions_and_Answers_Dec_2003_Part_3` at 2546); most `_Part_3` lectures are fragment-y (median ~36 chars). Candidate reflow improvements.
5. **`Spiritual_Traps_Oct_2005_Part_2` content**: passes all structural gates but the ASR text itself is garbage ("We do not worship life. We worship death."). Code/regex can't fix it — needs source re-transcription or manual edits.
6. **Housekeeping**: 3 pre-existing lint warnings (`walk` unused in api.js, trailing comma in auth.js, unused `assert` in extended-tests.js).

## Ops notes / sharp edges

- `AUTH_TEST_MODE=1` must NEVER be set on the production api — it lets anyone mint a session via `/api/test-login`. Prod verified 403.
- `/se/` is gated (nginx `auth_request` → `/auth/gate`); `/api/*` is deliberately open + rate-limited (100 req/15min/IP, env-tunable). Gate e2e: `auth-e2e-test.js`.
- Discord auth lives in `auth.js`; grants in the `docdocgo-grants` docker volume; captain seeded from `CAPTAIN_DISCORD_ID`. `SESSION_SECRET` must be set in prod.
- Lecture cleanup hotwords are mirrored in THREE places — `lecture-text.js` (server, shared with quality gate), `rag/populate.py`, `html/hawkins-lecture-fixes.js` (browser). Keep in sync (specific → generic). JS duplicate-collapse is first-match only; Python collapses all.
- Deployment recipe used: `docker compose up -d --build api` (nginx unchanged) → `./test.sh` (now safe against live stack) → curl the PUBLIC url (`https://docdocgo.lak.nz/api/health`, a search, a `/api/read`, `/se/` status) — always verify the public URL, not just `127.0.0.1:12854`.
- RAG re-enable: `docker compose --profile populate run --rm rag-populate` → `docker compose --profile rag up -d rag` → drop the profile gates → restore rag steps in `.gitlab-ci.yml`.

## Useful commands

- Full suite (docker only, supported): `make test` (or `make test-ci`). Bare-host `npm test` is a debugging convenience, not supported.
- Cypress (isolated): `docker compose -p docdocgo-cypress -f cypress-compose.yml up -d --build nginx api` then `docker compose -p docdocgo-cypress -f cypress-compose.yml run --rm cypress`
- Quality gate: `node quality-check.js` (human) / `node quality-check.js --json` / `node quality-tests.js`
- Lint: `npm run lint`
- Live endpoint checks: `./test.sh` (leaves a pre-existing stack alone)
