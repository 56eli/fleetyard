const assert = require('assert');

const { checkAll, metrics } = require('./quality-check');
const { loadLectureTexts } = require('./lecture-text');
const path = require('path');

let passed = 0;
let failed = 0;

function test(name, fn) {
    try {
        fn();
        console.log(`  ✅ ${name}`);
        passed++;
    } catch (err) {
        console.log(`  ❌ ${name}`);
        console.log(`     ${err.message}`);
        failed++;
    }
}

// ============================================================
// Transcription-quality regression tests (whole corpus)
// ============================================================
console.log('\n--- lecture transcription quality (corpus-wide) ---');

const report = checkAll();

test('all hard checks pass (no WEBVTT / --> / isolated cue numbers, no empty lectures)', () => {
    assert.deepStrictEqual(report.hardFailures, []);
});

test('DOC-046 reflow does not isolate calibration numbers as cue lines', () => {
    const lectures = loadLectureTexts(path.join(__dirname, 'html')).lectures;
    for (const k of [
        'Karma_and_the_Afterlife_Oct_2002_Part_3_enxautogen_html',
        'Intention_May_2005_Part_3_enxautogen_html'
    ]) {
        const t = lectures[k];
        assert.ok(t, `missing ${k}`);
        assert.deepStrictEqual(t.split('\n').filter(l => /^\d{1,3}$/.test(l.trim())), [], k);
        if (k.startsWith('Karma')) assert.match(t, /\b445\b/);
        if (k.startsWith('Intention')) assert.match(t, /\b70\b/);
    }
});

test(`lecture count matches corpus pin (${report.keys} == ${report.rawCount} loaded)`, () => {
    assert.strictEqual(report.keys, report.rawCount);
    assert.ok(report.keys >= 200, `only ${report.keys} lectures loaded`);
});

// ============================================================
// Spiritual_Traps_Oct_2005_Part_2 — known bad transcription
// Pin its post-cleanup shape so the reflow can't silently regress it.
// ============================================================
console.log('\n--- Spiritual_Traps_Oct_2005_Part_2 regression pins ---');

const OCT2005 = 'Spiritual_Traps_Oct_2005_Part_2_enxautogen_html';
const target = report.byLecture[OCT2005];

test(`${OCT2005} exists in the corpus`, () => {
    assert.ok(target, `lecture key not found in corpus`);
});

test(`${OCT2005} is structurally clean (no WEBVTT / --> / isolated cue digits)`, () => {
    const cleaned = loadLectureTexts(path.join(__dirname, 'html')).lectures[OCT2005];
    assert.ok(cleaned, 'cleaned text missing');
    assert.ok(!/WEBVTT/.test(cleaned), 'residual WEBVTT header');
    assert.ok(!/-->/.test(cleaned), 'residual "-->" timestamp');
    assert.deepStrictEqual(cleaned.split('\n').filter(l => /^\d{1,3}$/.test(l.trim())), []);
});

test(`${OCT2005} reflow stays readable (median line length 40-120, short-line ratio < 20%)`, () => {
    assert.ok(target.median >= 40, `median ${target.median} too low — shards survived`);
    assert.ok(target.median <= 120, `median ${target.median} too high — lines not split`);
    assert.ok(target.shortRatio < 0.20, `short-line ratio ${(target.shortRatio * 100).toFixed(1)}% too high`);
});

test(`${OCT2005} line count stays within reflow bounds (700-1000)`, () => {
    assert.ok(target.lines >= 700 && target.lines <= 1000, `lines=${target.lines} out of bounds`);
});

test('metrics() computes median/shortRatio/max correctly', () => {
    const m = metrics('aaa bbb ccc ddd\nshort\n');
    assert.strictEqual(m.lines, 2);
    assert.strictEqual(m.shortRatio, 0.5);
    assert.strictEqual(m.median, 15);
});

console.log(`\nquality-tests: ${passed} passed, ${failed} failed`);
if (failed > 0) process.exit(1);
