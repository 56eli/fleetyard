#!/bin/bash
# ship-overlays.sh [commit-message]
#
# One-command DocDocGo ship pipeline — run on the VPS from ~/code/docdocgo.
#   gates  -> bump overlay pins (api.js + overlay-tests.js) if needed
#   -> npm test + extended -> commit + push (asr-overlay-batch20)
#   -> docker compose up -d --build api (api-only) -> verify public URL
#
# Safety: never touches nginx, never sets AUTH_TEST_MODE, never `docker compose
# down`. Tests gate every ship ("tests before any ship"). No-op when there is
# nothing new to commit.
set -euo pipefail
cd "$(dirname "$0")"

BRANCH=$(git rev-parse --abbrev-ref HEAD)
echo "[ship] branch: $BRANCH"
if [ "$BRANCH" != "asr-overlay-batch20" ]; then
    echo "[ship] WARN: expected asr-overlay-batch20 (grok pattern); continuing anyway"
fi

COUNT=$(node -e "const {loadLectureTexts}=require('./lecture-text');console.log(loadLectureTexts('html').overlayCount)")
PIN_API=$(grep -oE 'loaded\.overlayCount !== [0-9]+' api.js | grep -oE '[0-9]+$' | head -1)
PIN_TESTS=$(grep -oE 'n === 0 \|\| n === [0-9]+' overlay-tests.js | grep -oE '[0-9]+$' | head -1)
echo "[ship] overlayCount=$COUNT pins: api=$PIN_API tests=$PIN_TESTS"

echo "[ship] quality gate..."
node quality-check.js || { echo "[ship] FAIL: quality gate"; exit 1; }

if [ "$COUNT" != "${PIN_API:-}" ] || [ "$COUNT" != "${PIN_TESTS:-}" ]; then
    echo "[ship] bumping pins $PIN_API/$PIN_TESTS -> $COUNT"
    node -e '
const fs = require("fs");
const cnt = process.argv[1];
for (const f of ["api.js", "overlay-tests.js"]) {
    let s = fs.readFileSync(f, "utf8");
    const out = s
        .replace(/(loaded\.overlayCount !== 0 && loaded\.overlayCount !== )\d+/, `$1${cnt}`)
        .replace(/\(expected 0 or \d+\)/, `(expected 0 or ${cnt})`)
        .replace(/(n === 0 \|\| n === )\d+/, `$1${cnt}`)
        .replace(/(0 or )\d+( \(full batch\))/, `$1${cnt}$2`);
    if (out !== s) fs.writeFileSync(f, out);
}' "$COUNT"
fi

echo "[ship] npm test..."
npm test || { echo "[ship] FAIL: npm test"; exit 1; }
echo "[ship] npm run test:extended..."
npm run test:extended || { echo "[ship] FAIL: extended tests"; exit 1; }

MSG="${1:-feat: ship re-ASR overlays (auto via ship-overlays.sh)}"
git add api.js overlay-tests.js overlays/ quote-tests.js package.json html/all-merged-books-serch.html html/0-all-merged-no-timestamps_json.js quality-check.js
if git diff --cached --quiet; then
    echo "[ship] nothing new to commit"
else
    git commit -m "$MSG"
    git push origin asr-overlay-batch20
fi

echo "[ship] deploying api-only..."
docker compose up -d --build api 2>&1 | tail -3
sleep 4
echo "[ship] verify:"
curl -s https://docdocgo.lak.nz/api/health; echo
docker compose logs api 2>&1 | grep -E "Loaded .*overlays" | tail -1
echo "[ship] DONE — expect overlayCount=$COUNT in the log line above"
