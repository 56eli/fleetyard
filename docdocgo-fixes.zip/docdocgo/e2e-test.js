const axios = require('axios');
const assert = require('assert');
const { spawn } = require('child_process');
const path = require('path');

// Spawns its own api.js on a dedicated port so it never collides with other
// services squatting 3000 (e.g. the local GoluGit instance on this host).
const TEST_PORT = 3203;
const BASE_URL = process.env.API_URL || `http://127.0.0.1:${TEST_PORT}/api`;

let child;

function startServer() {
    child = spawn(process.execPath, ['api.js'], {
        cwd: path.join(__dirname),
        env: { ...process.env, PORT: String(TEST_PORT) },
        stdio: ['ignore', 'pipe', 'pipe']
    });
    child.stderr.on('data', (d) => process.stderr.write(`[child] ${d}`));
}

async function waitForHealth() {
    for (let i = 0; i < 60; i++) {
        try {
            const res = await axios.get(`${BASE_URL}/health`, { validateStatus: () => true, timeout: 5000 });
            if (res.status === 200) return;
        } catch (e) { /* not up yet */ }
        await new Promise((r) => setTimeout(r, 1000));
    }
    throw new Error('api did not become ready');
}

async function runTests() {
    console.log('--- Starting End-to-End API Tests ---');
    console.log(`Targeting: ${BASE_URL}`);
    startServer();

    try {
        await waitForHealth();
        // Test 1: List Files
        console.log('\nTest 1: GET /files');
        const listRes = await axios.get(`${BASE_URL}/files`);
        assert.strictEqual(listRes.status, 200, 'Status should be 200');
        assert(Array.isArray(listRes.data.files), 'Response.files should be an array');
        assert(listRes.data.count > 0, 'File count should be > 0');
        assert.strictEqual(listRes.data.docs, '/api/docs', 'Should include docs link');
        assert.strictEqual(listRes.data.names.power_vs_force__the_hidden_determinants_of_human_behavior, 'Power vs. Force');
        assert.strictEqual(listRes.data.names.I_AM_THAT, 'I AM THAT (Nisargadatta Maharaj)');
        assert.ok(!Object.values(listRes.data.names).some((n) => /hidden de/i.test(n)), 'titles must not be truncated keys');
        console.log(`✅ Success: Found ${listRes.data.count} files.`);

        // Test 2: Read specific file
        const testFile = listRes.data.files[0];
        console.log(`\nTest 2: GET /read/${testFile}`);
        const readRes = await axios.get(`${BASE_URL}/read/${encodeURIComponent(testFile)}`);
        assert.strictEqual(readRes.status, 200, 'Status should be 200');
        assert.strictEqual(readRes.data.path, testFile, 'Path in response should match requested path');
        assert(typeof readRes.data.content === 'string', 'Content should be a string');
        assert(Array.isArray(readRes.data.chapters), 'chapters should be an array');
        assert.strictEqual(readRes.data.docs, '/api/docs', 'Should include docs link');
        console.log('✅ Success: File content retrieved.');

        console.log('\nTest 2d: GET /read/power_vs_force__the_hidden_de returns body chapters');
        const pvfRes = await axios.get(`${BASE_URL}/read/power_vs_force__the_hidden_de`);
        assert.strictEqual(pvfRes.status, 200);
        assert.strictEqual(pvfRes.data.title, 'Power vs. Force');
        assert(pvfRes.data.chapters.length >= 20, 'Power vs Force should have relocated body chapters');
        assert.ok(pvfRes.data.chapters[0].offset > 20000, 'first chapter must not be the Contents page');
        assert.ok(pvfRes.data.chapters.at(-1).offset > 300000, 'last chapter should sit late in the book');
        console.log('✅ Success: Power vs Force chapters land in the body.');

        // Test 2b: production load path must apply overlays (this is what overlay-tests
        // calling loadLectureTexts directly cannot catch).
        const fs = require('fs');
        const overlayKey = 'Alignment_Apr_2005_Part_2_enxautogen_html';
        const overlayPath = path.join(__dirname, 'overlays', overlayKey + '.txt');
        if (fs.existsSync(overlayPath)) {
            console.log(`\nTest 2b: GET /read/${overlayKey} matches overlay file`);
            const { applyOverlayText } = require('./lecture-text');
            const ov = applyOverlayText(fs.readFileSync(overlayPath, 'utf8').trim());
            const overRes = await axios.get(`${BASE_URL}/read/${encodeURIComponent(overlayKey)}`);
            assert.strictEqual(overRes.status, 200, 'overlay read should be 200');
            assert.strictEqual(overRes.data.content, ov, 'api.js must serve applyOverlayText(overlay)');
            const controlKey = 'A_Map_of_Consciousness_enxautogen_html';
            assert.ok(!fs.existsSync(path.join(__dirname, 'overlays', controlKey + '.txt')), 'control must not have overlay');
            const controlRes = await axios.get(`${BASE_URL}/read/${encodeURIComponent(controlKey)}`);
            assert.strictEqual(controlRes.status, 200);
            assert.notStrictEqual(controlRes.data.content, ov);
            assert.ok(!controlRes.data.content.startsWith('Below 200, others'), 'control lecture must stay original');
            console.log('✅ Success: overlay served on /api/read; control unchanged.');
        } else {
            console.log('Test 2b: skip (overlays/ not present)');
        }

        const extraKey = 'Book_of_Slides_Barret_notes';
        const extraPath = path.join(__dirname, 'extra-sources', extraKey + '.txt');
        if (fs.existsSync(extraPath)) {
            console.log(`\nTest 2c: GET /read/${extraKey} serves extra-source notes`);
            const extraRes = await axios.get(`${BASE_URL}/read/${encodeURIComponent(extraKey)}`);
            assert.strictEqual(extraRes.status, 200);
            assert.ok(extraRes.data.content.includes('NOT the official'));
            const filesNow = (await axios.get(`${BASE_URL}/files`)).data.files;
            assert.ok(filesNow.includes(extraKey));
            assert.ok(filesNow.includes('A_Map_of_Consciousness_enxautogen_html'), 'control lecture disappeared from /files');
            console.log('✅ Success: extra source is readable and listed.');
        } else {
            console.log('Test 2c: skip (extra-sources/ not present)');
        }

        // Test 3: Search endpoint (verify no-timestamps and correct structure)
        console.log('\nTest 3: GET /search?q=here is a wonderful t-shirt');
        const searchRes = await axios.get(`${BASE_URL}/search?q=${encodeURIComponent('here is a wonderful t-shirt')}&limit=10`);
        assert.strictEqual(searchRes.status, 200, 'Status should be 200');
        assert(searchRes.data.total_matches > 0, 'Should find matches');
        assert(Array.isArray(searchRes.data.results), 'Results should be an array');
        assert.strictEqual(searchRes.data.docs, '/api/docs', 'Should include docs link');

        const firstMatch = searchRes.data.results[0];
        assert(firstMatch.path, 'Match should have a path');
        assert(typeof firstMatch.snippet === 'string', 'Match should have a snippet string');

        // Ensure no timestamps exist in the snippet (the bug we fixed)
        assert(!firstMatch.snippet.includes('-->'), 'Snippet should not contain WebVTT timestamps (-->)');

        console.log(`✅ Success: Search works and returns clean snippets. Found ${searchRes.data.total_matches} matches.`);

        // Test 3b: Search a book with parsed chapters — chapter key always present
        // (null for front matter). filter=books ranking can put chapter-less
        // extra-sources first, so pin a known book rather than the top-5 mix.
        const chapterBook = 'letting_go__the_pathway_of_surrender';
        console.log(`\nTest 3b: GET /search?q=ego&filter=${chapterBook}&limit=20`);
        const bookSearchRes = await axios.get(`${BASE_URL}/search?q=${encodeURIComponent('ego')}&filter=${encodeURIComponent(chapterBook)}&limit=20`);
        assert.strictEqual(bookSearchRes.status, 200, 'Status should be 200');
        assert(bookSearchRes.data.results.length > 0, 'Should find book results');
        assert(bookSearchRes.data.results.every((r) => Object.prototype.hasOwnProperty.call(r, 'chapter')), 'Book-with-chapters results must include chapter');
        const resultsWithChapter = bookSearchRes.data.results.filter(r => typeof r.chapter === 'string' && r.chapter.startsWith('Chapter'));
        assert(resultsWithChapter.length > 0, 'Book results should include a Chapter N label');
        console.log(`✅ Success: Book results include chapter info. Example: "${resultsWithChapter[0].chapter}"`);

        // Test 3c: Search lectures — verify no chapter field
        console.log('\nTest 3c: GET /search?q=consciousness&filter=lectures&limit=5');
        const lectureSearchRes = await axios.get(`${BASE_URL}/search?q=${encodeURIComponent('consciousness')}&filter=lectures&limit=5`);
        assert.strictEqual(lectureSearchRes.status, 200, 'Status should be 200');
        if (lectureSearchRes.data.results.length > 0) {
            const withChapterKey = lectureSearchRes.data.results.filter(r => Object.prototype.hasOwnProperty.call(r, 'chapter'));
            assert.strictEqual(withChapterKey.length, 0, 'Lecture results should not have chapter field');
        }
        console.log('✅ Success: Lecture results do not include chapter field.');

        // Test 4: 404 for non-existent file
        console.log('\nTest 4: GET /read/non_existent_html (Expect 404)');
        try {
            await axios.get(`${BASE_URL}/read/non_existent_html`);
            assert.fail('Should have thrown a 404 error');
        } catch (error) {
            assert.strictEqual(error.response.status, 404, 'Status should be 404');
            console.log('✅ Success: Correctly returned 404.');
        }

        // Test 5: Path traversal security (Expect 403 or 404)
        console.log('\nTest 5: Security - Path Traversal (Expect 403 or 404)');
        try {
            await axios.get(`${BASE_URL}/read/../../api.js`);
            assert.fail('Should have denied access');
        } catch (error) {
            assert(error.response.status === 403 || error.response.status === 404, 'Status should be 403 or 404');
            console.log(`✅ Success: Security check passed (returned ${error.response.status}).`);
        }

        // Test 6: test-login is locked down outside test mode (Expect 403)
        // The gate's e2e suite (auth-e2e-test.js) exercises the full flow
        // against a server with AUTH_TEST_MODE=1; here we only verify the
        // route refuses to work when test mode is off.
        console.log('\nTest 6: GET /test-login (Expect 403 — test mode off)');
        try {
            await axios.get(`${BASE_URL}/test-login?user_id=1298076640043073548`);
            assert.fail('Should have returned 403');
        } catch (error) {
            assert.strictEqual(error.response.status, 403, 'Status should be 403');
            console.log('✅ Success: test-login is disabled without AUTH_TEST_MODE.');
        }

        console.log('\n--- All E2E Tests Passed Successfully ---');
    } catch (error) {
        console.error('\n❌ Test Suite Failed:');
        if (error.response) {
            console.error(`  Status: ${error.response.status}`);
            console.error(`  Data: ${JSON.stringify(error.response.data)}`);
        } else {
            console.error(`  Message: ${error.message}`);
        }
        process.exit(1);
    } finally {
        child.kill('SIGTERM');
    }
}

runTests();
