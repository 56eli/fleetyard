#!/usr/bin/env bash
# scripts/deploy.sh — DOC-037 / #62 production deploy runbook.
#
# Recreate the API container, then reload nginx — never one without the other.
# Never tear the stack down. Never enable the e2e session-setter env on prod.
#
# Usage (from the repo root, on main):
#   ./scripts/deploy.sh
#   SMOKE_BASE=https://docdocgo.lak.nz ./scripts/deploy.sh
#
# Env:
#   ALLOW_NON_MAIN=1   deploy from a non-main branch (debug only)
#   SKIP_PULL=1        do not git pull --ff-only origin main
#   SKIP_GITLAB=1      skip the gitlab.com mirror push
#   SMOKE_BASE         public URL for the smoke battery (default https://docdocgo.lak.nz)
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

echo "[deploy] cwd=$ROOT"

BRANCH="$(git rev-parse --abbrev-ref HEAD)"
if [ "$BRANCH" != "main" ] && [ "${ALLOW_NON_MAIN:-}" != "1" ]; then
  echo "[deploy] REFUSING: branch is $BRANCH (need main, or ALLOW_NON_MAIN=1)" >&2
  exit 1
fi

if [ "${SKIP_PULL:-}" != "1" ]; then
  echo "[deploy] git pull --ff-only origin main"
  git pull --ff-only origin main
fi

SHA="$(git rev-parse HEAD)"
SHORT="$(git rev-parse --short HEAD)"
echo "[deploy] sha=$SHORT ($SHA)"

# Stamp for entrypoint.sh /api/version (compose does not set these by default).
export BUILD_SHA="${BUILD_SHA:-$SHA}"
export DEPLOYED_AT="${DEPLOYED_AT:-$(date -u +%Y-%m-%dT%H:%M:%SZ)}"

echo "[deploy] docker compose up -d --build api"
docker compose up -d --build api

echo "[deploy] waiting for API health on :12854"
ready=0
i=0
while [ "$i" -lt 30 ]; do
  if curl -sf "http://127.0.0.1:12854/api/health" >/dev/null 2>&1; then
    ready=1
    break
  fi
  i=$((i + 1))
  sleep 2
done
if [ "$ready" != "1" ]; then
  echo "[deploy] API did not become ready" >&2
  docker compose logs api --tail 80 >&2 || true
  exit 1
fi

echo "[deploy] nginx -s reload (config is bind-mounted; recreate if reload fails)"
if docker compose exec -T nginx nginx -s reload; then
  echo "[deploy] nginx reloaded"
else
  echo "[deploy] reload failed — recreating nginx container"
  docker compose up -d nginx
fi

echo "[deploy] asserting catalogue log line"
if docker compose logs api --tail 400 | grep -F "Loaded catalogue metadata: 307 kinds" >/dev/null; then
  echo "[deploy] catalogue metadata: 307 kinds ✓"
else
  echo "[deploy] missing 'Loaded catalogue metadata: 307 kinds' in api logs" >&2
  docker compose logs api --tail 80 >&2 || true
  exit 1
fi

echo "[deploy] smoke-test.sh"
SMOKE_BASE="${SMOKE_BASE:-https://docdocgo.lak.nz}"
export SMOKE_BASE
bash "$ROOT/scripts/smoke-test.sh"

if [ "${SKIP_GITLAB:-}" != "1" ]; then
  echo "[deploy] push main to gitlab mirror (standing AGENTS.md task; best-effort)"
  if git remote get-url gitlab >/dev/null 2>&1; then
    git push gitlab main || echo "[deploy] WARN: git push gitlab main failed (CI host may be read-only)"
  else
    git push git@gitlab.com:lakshaynz/docdocgo.git main \
      || echo "[deploy] WARN: gitlab mirror push failed (no gitlab remote / read-only)"
  fi
fi

echo "[deploy] DONE $SHORT"
