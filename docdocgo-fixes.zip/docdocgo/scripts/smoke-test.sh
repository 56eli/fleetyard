#!/usr/bin/env bash
# scripts/smoke-test.sh — DOC-037 / #62 production smoke battery.
#
# Usage:
#   SMOKE_BASE=https://docdocgo.lak.nz scripts/smoke-test.sh
#   SMOKE_BASE=http://127.0.0.1:12853 scripts/smoke-test.sh   # local nginx
#
# Never tear the stack down. Read-only against the live URL.
set -euo pipefail

BASE="${SMOKE_BASE:-https://docdocgo.lak.nz}"
BASE="${BASE%/}"
API="${BASE}/api"

PASS=0
FAIL=0

pass() { PASS=$((PASS + 1)); echo "  PASS  $1"; }
fail() { FAIL=$((FAIL + 1)); echo "  FAIL  $1"; }

json_field() {
  node -e 'const d=JSON.parse(require("fs").readFileSync(0,"utf8")); process.stdout.write(String(d[process.argv[2]]));' "$1"
}

files_ok() {
  node -e 'const d=JSON.parse(require("fs").readFileSync(0,"utf8")); process.exit((d.count>=307 && d.kinds && Object.keys(d.kinds).length>=307)?0:1);'
}

matches_zero() {
  node -e 'const d=JSON.parse(require("fs").readFileSync(0,"utf8")); process.exit(Number(d.total_matches)===0?0:1);'
}

echo "=== DocDocGo smoke ($BASE) ==="

# /api/health 200
code=$(curl -sS -o /tmp/ddg-smoke-health.json -w "%{http_code}" "${API}/health" || true)
if [ "$code" = "200" ]; then
  pass "/api/health 200"
else
  fail "/api/health 200 (got ${code})"
fi

# /api/files count ≥ 307 with kinds present
code=$(curl -sS -o /tmp/ddg-smoke-files.json -w "%{http_code}" "${API}/files" || true)
if [ "$code" != "200" ]; then
  fail "/api/files 200 (got ${code})"
else
  if files_ok < /tmp/ddg-smoke-files.json; then
    count=$(json_field count < /tmp/ddg-smoke-files.json)
    pass "/api/files count=${count} ≥ 307 with kinds"
  else
    fail "/api/files count ≥ 307 with kinds present"
  fi
fi

# q==== → 0 (ingest-banner garbage must not match)
code=$(curl -sS -o /tmp/ddg-smoke-eq.json -w "%{http_code}" "${API}/search?q=%3D%3D%3D%3D&limit=5" || true)
if [ "$code" != "200" ]; then
  fail "q==== search 200 (got ${code})"
else
  if matches_zero < /tmp/ddg-smoke-eq.json; then
    pass "q==== → 0 matches"
  else
    tot=$(json_field total_matches < /tmp/ddg-smoke-eq.json || true)
    fail "q==== → 0 matches (got ${tot})"
  fi
fi

# new-name read 200 AND legacy alias read 200
NEW_NAME="letting_go__the_pathway_of_surrender"
LEGACY="letting_go__the_pathway_of_sur"
code=$(curl -sS -o /dev/null -w "%{http_code}" "${API}/read/${NEW_NAME}" || true)
if [ "$code" = "200" ]; then
  pass "new-name read /api/read/${NEW_NAME} 200"
else
  fail "new-name read /api/read/${NEW_NAME} 200 (got ${code})"
fi
code=$(curl -sS -o /dev/null -w "%{http_code}" "${API}/read/${LEGACY}" || true)
if [ "$code" = "200" ]; then
  pass "legacy alias read /api/read/${LEGACY} 200"
else
  fail "legacy alias read /api/read/${LEGACY} 200 (got ${code})"
fi

# q=Café matches truth_vs_falsehood
code=$(curl -sS -o /tmp/ddg-smoke-cafe.json -w "%{http_code}" "${API}/search?q=Caf%C3%A9&limit=20" || true)
if [ "$code" != "200" ]; then
  fail "q=Café search 200 (got ${code})"
else
  if grep -q "truth_vs_falsehood" /tmp/ddg-smoke-cafe.json; then
    pass "q=Café matches truth_vs_falsehood"
  else
    fail "q=Café matches truth_vs_falsehood"
  fi
fi

# redirect chain stays https-only (skip when BASE is already plain http / local)
check_https_chain() {
  url="$1"
  hop=0
  while [ "$hop" -lt 8 ]; do
    hop=$((hop + 1))
    hdr=$(curl -sS -D - -o /dev/null "$url" || true)
    loc=$(printf "%s" "$hdr" | awk 'tolower($1)=="location:"{sub(/\r$/,""); print $2; exit}')
    [ -z "$loc" ] && return 0
    case "$loc" in
      http://*)
        echo "$loc"
        return 1
        ;;
      https://*)
        url="$loc"
        ;;
      //*)
        echo "$loc"
        return 1
        ;;
      /*)
        # relative — stay on BASE host/scheme
        url="${BASE}${loc}"
        ;;
      *)
        url="$loc"
        ;;
    esac
  done
  return 0
}

case "$BASE" in
  https://*)
    if down=$(check_https_chain "${BASE}/"); then
      pass "redirect chain from / stays https-only"
    else
      fail "redirect chain from / stays https-only (downgrade to ${down})"
    fi
    ;;
  *)
    pass "redirect https-only skipped (SMOKE_BASE is not https)"
    ;;
esac

# /login contains history.back()
code=$(curl -sS -o /tmp/ddg-smoke-login.html -w "%{http_code}" "${BASE}/login" || true)
if [ "$code" != "200" ]; then
  fail "/login 200 (got ${code})"
elif grep -q "history.back()" /tmp/ddg-smoke-login.html; then
  pass "/login contains history.back()"
else
  fail "/login contains history.back()"
fi

echo ""
echo "========================================"
echo "  Smoke: ${PASS} passed, ${FAIL} failed"
echo "========================================"
if [ "$FAIL" -gt 0 ]; then
  exit 1
fi
exit 0
