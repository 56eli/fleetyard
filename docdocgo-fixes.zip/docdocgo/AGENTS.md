# Project agent memory

This file is the project's committed home for project-intrinsic agent knowledge: build, test, release, architecture, and sharp-edge notes that should travel with the code.

- Add durable project-specific notes here as they are discovered through real work.

## Book data formats and chapter parsing

- `html/merged-book-texts_json_1.js` holds books in two shapes: newline-separated (each `CHAPTER N` heading on its own line) and run-together (~830KB on one line, e.g. `I_reality_and_subj`, `ACIM_workbook`, `Lamsa_bible`, `I_AM_THAT`, `Be_as_you_are`). Do NOT regenerate/reformat the data files; parser fixes live in `api.js`.
- `parseChapters()` in `api.js` is three-pass: pass 1 matches `CHAPTER N` at line start (existing behavior, kept byte-identical); if zero chapters found, pass 2 scans mid-line markers (`Chapter 1:` / `CHAPTER ONE.`-style, all-caps spelled-out with optional hyphen, and space-separated `CHAPTER 1   Title` for `Be_as_you_are`). Mid-line titles get trailing section numerals/calibration digits stripped, cross-reference/citation patterns rejected (`(See ... Chapter 6.)`, `Chapter 13: ..., p. 265`), and body text after the title trimmed at the first `\s{2,}[A-Z]` gap. If still zero, pass 3 matches I_AM_THAT numbered dialogues (`1. Title   Questioner:`).
- `relocateTocChapters()` runs after parse when the hits sit in a tiny front-matter window (printed Contents). It snaps to body headings: spaced OCR `C HAPTER O NE` (Power vs Force) or `CHAPTER\n\n5` (Letting Go). `/api/read` returns that `chapters` array; the reader only shows Jump to chapter when the span covers the book.

## Corpus file layout (single-copy policy, 2026-09)

- Only the runtime sources are kept: `html/0-all-merged-no-timestamps_json.js` (280 lectures) and `html/merged-book-texts_json_1.js` (24 books), plus `overlays/<key>.txt` (230, replace the cleaned base text at load) and `extra-sources/*.txt`. The other 50 lectures (incl. `satsang_june_2010`) serve base text.
- Deleted as duplicates (recoverable from git history if a re-ingest is ever needed): `html/0-all-merged.html` (old export with timestamps), `html/0-all-merged-no-timestamps.js`, `html/merged-book-texts.{js,html}`, all 235 raw `html/**/*.en-x-autogen.html` pages, `html/Satsang Questions & Answers/satsang june 2010.html`, and `html/bible/Holy Bible_lamsa.txt` + `html/other_books/acim_workbook.txt` (verified exact text duplicates of the `Lamsa_bible` / `ACIM_workbook` keys). Do not re-add these exports — the merged JSON files are the single copy.

## Publisher/platform boilerplate (DOC-012)

- `stripPublisherBoilerplate()` in `lecture-text.js` runs on every load path via `loadCleanText()` (after `cleanIngestArtifacts`).
- Strips: Hay House newsletter promo + country URL directory, Audible intro/outro chrome, URL/email tokens, repeated medical-disclaimer + "All rights reserved" paragraphs.
- Spoken "www." / "WWW." (Emotions Apr 2004) is deliberately kept — only `www.\S` / `https?://\S` count as URLs.
- Chapter 1 body text is unchanged; only front/back matter shrinks.

## Copyright / © legal fluff

- `stripCopyrightFluff()` in `lecture-text.js` runs on every load path via `loadCleanText()` (after `stripPublisherBoilerplate`, before `stripRunningChrome`).
- Strips: `Copyright © …`, bare `© YEAR …`, Institute/Veritas map-footer chrome (including glued ©→body in `evolution_of_consciousness` and OCR typos like `Reeerch`/`bba`), Mooji recording boilerplate, TOC `Copyright Page` entries, and remaining `All rights reserved` crumbs.
- Preserves bio/bibliographic Institute/Veritas mentions and substantive "copyright" prose.

## Glued spaces + trailing ASR junk (GoluGit #20 / #34)

- `fixGluedSpaces()` in `lecture-text.js` runs inside `cleanIngestArtifacts()` (every load path). Single-space insertions only: `,`/`:`/`;` + letter (`Watts,Alan`, `AZ:Veritas`), `.`/`?` + capital (`worried.The`, `bootstraps?Why`), uncapped lowercase→Capital splits (`ofMaharshi`, `psychologistWilliam`) with `GLUE_CAMEL_ALLOW` (`iPod iPad eBay eBook iTube`), and `DrHawkinsInfo` → `Dr Hawkins Info` (kept out of `applyHawkinsHotwords` so the browser hotword mirror needs no sync).
- Deliberately NOT split: digit-letter glue (ordinals/decades `20th`/`1960s`), `?`-as-letter OCR damage (`de?ned` fi-ligature vs `it?creation` glue — indistinguishable), `U.S.Army`-style caps-initial glue (protects `U.S.`/`D.T.`).
- `stripTrailingAsrJunk()` runs end-anchored at the end of `loadCleanText()` AND at the end of `cleanLectureText()` (cue-number stripping + reflow expose tails the first pass cannot see, e.g. `truth.\n\n119\nhere`). Strips Amara credits (also stripped globally in `stripAudibleBoilerplate` — two lectures bake it mid-sentence), `you are`-loop runs (≥3 loop tokens or ≥2 with `you are`/`you know`, remainder must still end with sentence punctuation), and stray `here`/`there` after finished sentences. Source-truncated tails (`call the`, `wife a`) and unpunctuated-but-complete ASR tails stay — no text to recover.
- Side effect pinned consciously: `naïve` search count 137 → 138 (`naïveWestern` split reveals a whole-word hit); see `api-bugs-test.js`.
- `audit-pipeline-test.js` (runs in `npm test`) pins ingest issues #12/#14/#18/#20/#34 plus #90 (DOC-053 abrupt Part 2/3 openings).

## Lecture text cleanup (api.js `cleanLectureText`)

- Lecture data (`0-all-merged-no-timestamps_json.js`, 15.5MB) still contains WEBVTT headers and leftover cue numbers; data files are READ-ONLY, fixes live in code. `cleanLectureText()` strips those, reflows ~42-char WEBVTT shards into paragraph sentences, splits oversize lines at sentence boundaries (abbreviation-aware: `Dr.`/`Mr.`/single initials untouched), then applies deterministic Hawkins ASR hotword corrections (eagle→ego, tractor fields→attractor field, Gloria in Excelsior Steel→Gloria in Excelsis Deo, Romana/Ramona→Ramana, Godadamara→Nisargadatta Maharaj, duplicate-word collapse). Runs once at startup (~400ms for all 236 lectures).
- The hotword list is mirrored in THREE places — `api.js` `cleanLectureText`, `rag/populate.py` `_correct_lecture_text`, and `html/hawkins-lecture-fixes.js` (browser). Keep them in sync (order matters: specific → generic). NOTE: the JS duplicate-word collapse replaces only the FIRST match (no `g` flag); Python's re.sub collapses all.
- Lecture text loading + cleanup now live in `lecture-text.js` (shared by `api.js`, `quality-check.js`, `quality-tests.js`); `test-parser.js` extracts `loadJsonDataSource` from THERE now, not api.js.
- EVERY load path (lectures, books via `loadBookTexts`, extra sources, overlays) runs `cleanIngestArtifacts()` in `lecture-text.js` first: drops `====` ingest banners and full-line `-_=` separator rules (5+), collapses 4+ newline/interior-space runs, decodes mojibake/entities, strips C0/U+FFFD. Don't fix back: leading line indentation and `***` scene breaks are allowlisted on purpose, and keyword whole-word matching uses Unicode letter boundaries instead of ASCII `\b` so accented words (Café) match. The non-Latin strip AND `nonLatinShare` metric include Greek (a stray `τη` was invisible to the old Cyrillic/CJK-only ranges); `stripRunningChrome` also drops multi-dash digit page rules (`196------`), bare page-number echoes beside them, and dash-rules glued to prose line ends — calibration ranges (`190-195`) and table digits always survive. Pinned corpus-wide in api-bugs-test.js groups 12 + 15 and audit-pipeline-test.js. GoluGit #11/#14/#15/#16/#18.
- DOC-018 transcript normalisation (lectures/overlays only, still read-only data): after hygiene, fold curly quotes/dashes to straight, strip Audible platform intro/outro lines, measure period density, and tag below-band lectures `raw_asr` with word-count chunks (`NORMALISATION_VERSION`, band 8–40 periods/1k). Exposed on `/api/read` + `/api/files.transcript_normalisation`. ML punctuation restoration is out of scope; the done-when is band-or-`raw_asr`+chunks. Pinned in api-bugs-test.js (DOC-018 block). GoluGit #19.
- `looksAbruptStart()` flags lectures whose first 80 chars lack a capital start or begin with `...` / `and ` (DOC-053). Set on `lectureMeta.startsAbruptly`; `/api/read` and `/api/files.transcript_normalisation.starts_abruptly` expose it so the reader does not imply a clean Part N. Data files stay read-only — do not recut or add overlay files for these.

## ASR overlays (overlays/)

- Monthly re-ASR JSON is split into existing lecture keys (word-count weights from the previous cleaned parts, snapped to a sentence). Files live in `overlays/<key>.txt`. Data JS files stay read-only.
- `loadLectureTexts()` applies an overlay *after* `cleanLectureText` and does not re-run the generic eagle→ego pass on overlay text (protects "Eagle Scout").
- Revert a lecture by deleting its overlay file and restarting api. `LECTURE_OVERLAY_DIR` overrides the path.
- `overlay-tests.js` pins Eagle Scout, Ben Loudon→Bin Laden, control keys not overlaid, and overlayCount 0 or 230.
- `api.js` loads lectures only via `loadLectureTexts()` so `/api/read` and `/api/search` serve overlays. Partial overlay sets (not 0 and not 230) fail api startup. `e2e-test.js` Test 2b pins `/api/read` against the overlay file.


## Extra sources (extra-sources/)

- Sidecar `.txt` files loaded into the book map *after* `merged-book-texts_json_1.js`. Data JS stays read-only.
- Keys must match `EXTRA_KEY_RE` (`/^[a-zA-Z0-9_,-]+$/`, exported from `lecture-text.js` — stricter than `/api/read`'s `FILE_KEY_RE`, which also allows `&` for the six legacy `&` titles). A bad-charset key or a key that collides with an existing book fails api startup loudly.
- The three `Book_of_Slides_*` extra-sources are included in `hawkinsBooks` (and therefore `filter=all-hawkins-books`) per DOC-009 owner decision (2026-09-04). Other commentary sidecars still stay out of `hawkinsBooks` — they appear under filter=all and filter=books only.
- Revert a slides sidecar by deleting its `extra-sources/*.txt` file and removing its key from `source-config.json` categories/displayNames, then restart api.

## Catalogue metadata (source-config.json `kinds` / `variants` / `incomplete_series`)

- Every corpus key has a declared `kind` (`hawkins_book`, `reference`, `slides_ocr`, `health_lecture`, `satsang`, `q_and_a`, `lecture`); search filters derive from kinds, never title presence. Membership is byte-identical to the old category lists (books 27 / lectures 280 / hawkins 23). `lectureSeries` must list all 280 lectures — the 44 Satsang volumes were missing and are now appended.
- `variants` holds forward links only (`variant_of`, `same_session_as`, `source_lecture_of`, `variant_group`); api.js derives reverse `linked_by` in `variantInfo()`. Canonical June-2010 transcript is `satsang_june_2010`; the 16 health lectures point `source_lecture_of: healing_and_recovery`; the 3 slides share `variant_group: book_of_slides` with no canonical. Search emits `variant_groups` for variant sources on the page.
- Corpus keys are read-only, so series grouping is `seriesId()` in api.js (strip `_enxautogen_html`, drop non-alphanumerics, drop trailing `PartN`) — Dec 2003 commas and the 12 suffix-less files group in code, never by rename. `incomplete_series` flags the 4 unsourced parts + Volume VI + the Satsang IV–VIII note.
- Startup fails loudly on catalogue drift (key without kind, unknown variant target, present-part absent, flagged-missing part present) — same convention as the extra-source collide check. `catalogue-tests.js` (port 3223, runs as part of `npm test`) pins every catalogue done-when.

## Transcription-quality gate (quality-check.js)

- `quality-check.js` scores the whole lecture corpus after cleanup: HARD checks (residual WEBVTT headers, `-->` timestamps, isolated cue-number lines, empty lectures) exit 1; SOFT metrics (median line length, short-line ratio, run-on lines, lecture count vs `EXPECTED_LECTURES=280`) are warn-only — ASR hallucinations can't be fixed deterministically and a flaky hard gate would take prod down. Run: `node quality-check.js` (human) / `--json` (tests).
- Wired as a docker build gate (`RUN node quality-check.js` in the api stage, fails the build on hard failures) AND a pre-start gate: `api.js` calls `checkLectures()` on the corpus it just loaded, before listen (`checkAll()` stays the standalone load+check used by `quality-check.js` / `quality-tests.js`). This cleans the corpus once per start instead of twice (was `entrypoint.sh` running a separate `node quality-check.js` first); hard failures still abort the container start instead of serving garbage (verified fail-fast with a poisoned data mount). `quality-tests.js` pins `Spiritual_Traps_Oct_2005_Part_2_enxautogen_html` (known-bad transcription) + corpus-wide hard checks, runs as part of `npm test`.
- Known soft findings: many `_Part_3` lectures are fragment-y (median ~36 chars) and ~20 lectures have run-on lines >900 chars that the sentence-boundary splitter misses — candidates for a future reflow improvement, not blockers.
## Discord login + access gate (auth.js)

- Ported from hawkins-tv. `auth.js` owns everything: express-session, Discord OAuth2 (`/login`, `/login/discord`, `/callback`, `/logout`), grants store, nginx probe (`/auth/gate`), pending/login/admin pages, and the gate middleware. `api.js` mounts `sessionMiddleware → router`; the gate middleware is NOT applied to `/api/*` (reverted deliberately — internal tools call the API without a Discord session, so abuse protection is rate limiting, not auth). The gate still protects `/se/` at nginx and `/admin/*` in Express.
- Grants live in `GRANTS_FILE` (default `/app/grants/grants.json`, docker volume `docdocgo-grants`); source of truth, admin toggle applies next request. Captain id seeded granted+admin (env `CAPTAIN_DISCORD_ID`, default mirrors hawkins-tv's). `SESSION_SECRET` must be set in prod (default is a dev-only fallback).
- nginx: `/se/` static is gated via `auth_request /auth/gate`; on 401, `error_page` → `@auth_entry` which proxies to Express `/auth/entry` (login redirect or pending page). The `@auth_entry` proxy_pass MUST include a URI (`$api_upstream/auth/entry`) — without it the original `/se/` URI is passed through and the gate's login redirect fires instead of the pending page.
- `/api/test-login` (sets a session for e2e) is 403 unless `AUTH_TEST_MODE=1`. Gate e2e: `auth-e2e-test.js` (spawns its own server, runs as part of `npm test`) asserts the post-revert reality: `/api/*` stays open, `/auth/gate` + `/auth/entry` + `/admin/*` still enforce.
- Login page Back link is `history.back()`, never `href="/"`: `/` 301s to the gated `/se/`, which bounces logged-out browsers straight back to `/login` (sign-in loop). Same reason the 403 page links to `/se/` only for logged-in users.
- Scheme: nginx forwards the client scheme as `X-Forwarded-Proto` (`map` prefers Cloudflare's header, falls back to `$scheme`) on every proxied location, and the session cookie is `secure: 'auto'` — Secure on the https site, plain on local http dev. Without the header Express sees every request as http (HTTPS→HTTP downgrade). `site-ops-test.js` pins Secure/no-Secure via `/api/test-login` with and without the header (port 3205, runs as part of `npm test`).
- Unit tests for `parseChapters`/`findChapter` live in `test-chapters.js` (runs as part of `npm test`); API-level tests are `e2e-test.js` + `extended-tests.js`.

## Rate limiting on /api/* (api.js)

- All `/api/*` routes (public, unauthenticated) are rate-limited per client IP via `express-rate-limit`; `/api/health` and `/api/test-login` are exempt because the auth router (mounted first) serves them before the limiter.
- `app.set('trust proxy', 1)` + nginx appends `X-Forwarded-For $proxy_add_x_forwarded_for` on `/api/` so the real client IP (not the Cloudflare edge IP) keys the bucket.
- Limits env-tunable without a rebuild: `RATE_LIMIT_WINDOW_MS` (default 900000) and `RATE_LIMIT_MAX` (default 100), passed through in docker-compose.yml. Rate-limit e2e: `rate-limit-test.js` (spawns its own server with a tiny max, runs as part of `npm test`).
- Friendbot (issue #91) is exempt only when it sends `X-Internal-Token` matching env `INTERNAL_API_TOKEN` (compose passes the host env through; never commit the secret). Default-deny: unset env ⇒ no exemption, including loopback. Do **not** skip on loopback/docker-network IPs — Friendbot calls `https://docdocgo.lak.nz/api/search` via Cloudflare, and `trust proxy 1` plus the published `:12854` mapping would make a loopback skip spoofable via `X-Forwarded-For`. `/api/docs` `rate_limiting.internal_token` documents this. Pinned in `rate-limit-test.js` (public IP still 429; token path does not; wrong/unset token still 429).
- `/api/docs` `rate_limiting` interpolates the LIVE limit/window (never hard-code "100 per 15 min" — env tuning would make docs lie) and tells clients to wait `retry_after_seconds` with backoff; the search UI surfaces that value in its 429 message and `docdocgo-axi` parses it out of 429 bodies instead of dumping raw HTML.

## /api/search input validation (api.js)

- Issue #30 hardening: `q` must be a single string (duplicate `?q=a&q=b` arrives as an array → 400, not a 500 `rawQuery.replace` crash); `limit`/`max` must be an integer 1–1000 (else 400; was `|| 100` so `limit=-1` gave negative `total_pages`); `page` is clamped to ≥1 (`Math.max(1, parseInt(...) || 1)`, so 0/negatives/NaN → page 1, huge pages → empty results); `offset` is **not** a pagination param and returns 400 (DOC-045); `useRegex=true` with an invalid pattern → 400 (validated with `new RegExp(query,'g')` before the min-length early return).
- Query handling (GoluGit #4/#7/#8/#9): `q` is kept verbatim — never strip punctuation (a global comma-strip once corrupted `a{2,3}` into `a{23}`). Literal mode tokenizes with `/\d[\d,]*\d|\d|[^\s,]+/g`: comma-blind between words, digit-flanked commas stay in one token ("1,000"). A query that is entirely one balanced double-quoted span runs exact-phrase mode (`total_matches` = phrase occurrences); quoted spans inside a keyword query are required phrases in every result group. The min-3 gate counts RAW characters ("a,b" runs, "ab" does not) but exempts queries containing any non-alphanumeric-ASCII character (`"`, `é`, `—` are legitimate searches) — documented decisions, don't "fix" them back.
- Matching (GoluGit #8/#9): typographic variants fold at match time, both directions (`’`↔`'`, `“”`↔`"`, `—`/`–`↔`-`); the corpus is read-only — don't normalize it (DOC-018 is the separate pipeline issue). Literal-mode patterns use Unicode lookarounds `(?<![\p{L}\p{N}_])…(?![\p{L}\p{N}_])` instead of `\b` (ASCII-only `\b` can never bound `é`/`café`), under the `u` flag; user-supplied regex keeps plain flags — `u` would change its semantics. Pure-symbol tokens (`"`, `—`) and single non-ASCII letters skip whole-word wrapping.
- Counting (GoluGit #7): every response self-labels `search_mode` + `count_basis`; multi-word keyword responses add `phrase_match_count`; the 20,000-result cap AND the time budget both set `truncated: true` (the cap used to truncate silently). Full contract: `/api/docs` (`counting` note). Ground-truth numbers are pinned in `api-bugs-test.js` test 14 — update consciously when the corpus changes.
- Result schema is the same in keyword/phrase/regex (DOC-045): `path, offset, match_text, snippet, score, proximity, match_count`, plus `chapter` when that document has parsed chapters (omitted for lectures; null for front matter). `match_count` is per-group (unique query words in keyword mode; 1 in phrase/regex). Assembled in `decorateSearchHit()`; `/api/docs` `endpoints['/api/search'].results` is the contract. `offset` as a query param returns 400 (paginate with `page`+`limit`).
- Docs contract: `/api/docs` documents rate limiting (100 req/15min/IP default, `RATE_LIMIT_MAX`/`RATE_LIMIT_WINDOW_MS`), literal-text query matching (HTML-like queries like `<script>` are NOT stripped — corpus has no HTML markup, they return 0), and the validation rules. The `/api/read` example filename is `Worry,_Fear,_and_Anxiety_enxautogen_html` (real lecture key).
- `api-bugs-test.js` (runs as part of `npm test`) spawns its own server and covers all of the above.

## /se/ search UI (html/all-merged-books-serch.html)

- The live `/se/` index (nginx `index all-merged-books-serch.html`) is an **API client**, not a second search engine: data-script tags are commented out and `performSearch` calls `fetch('/api/search?...')` with `q` verbatim (URLSearchParams — no comma stripping). Folding, phrase mode, Unicode word boundaries, and honest counts live only in `api.js`; do NOT reintroduce a client-side corpus scan.
- UI responsibilities for parity (DOC-040 / GoluGit #40): (1) mirror the API's DOC-007 short-query gate (min-3 only for pure alphanumeric-ASCII; `"`, `é`, `—` pass through); (2) surface `search_mode` / `count_basis` / `phrase_match_count` / `notice` from the response so group totals are not mistaken for phrase hits; (3) stay forward-compatible if those fields are absent (pre-#39 API).
- Legacy offline pages (`all-books-and-lectures-search.html`, `all-merged-no-timestamps-serch*.html`) still load data JS locally — they are not the gated `/se/` path. Prefer routing users to `/se/` over porting folding there; do not grow a third search engine.
- Hotword list sync (above) still applies to `html/hawkins-lecture-fixes.js` for any offline lecture view; search itself must not duplicate folding/tokenizer logic out of `api.js`.

## /api/read + /api/quote filename validation (api.js)

- Corpus keys may contain `&` (six titles: `The_Levels_of_Consciousness_Subjective_&_Social_Consequences_Mar_2002_Part_1/2/3`, `Overcoming_Doubt,_Skepticism_&_Disbelief_Aug_2008_Part_1/2/3`), so both routes validate with **`FILE_KEY_RE`**, defined once in `lecture-text.js` and imported by `api.js` — one definition, no drift. Verified charset across all 307 keys: `A–Z a–z 0–9 _ , &` (hyphen allowed, currently unused). GoluGit issue #2 (DOC-001).
- Extra-sources use the deliberately stricter **`EXTRA_KEY_RE`** (no `&`, also exported from `lecture-text.js`); `loadExtraSources` **throws** on a bad-charset key — api.js's startup catch exits(1), same convention as the key-collide check (previously the key was silently skipped and quietly vanished from `/api/files`).
- The frontend requests `/api/read/${encodeURIComponent(path)}` (`&` → `%26`); Express decodes it back, and a raw `&` in the path works too. Keep both forms working.
- `api-bugs-test.js` derives the six `&` keys from `/api/files` (no hard-coded filenames), asserts all six open, rejects `../` traversal with 400, and loops every `/api/files` entry through `/api/read` (server spawned with `RATE_LIMIT_MAX=1000` so the loop isn't throttled) — a new key using a character outside the class fails the suite loudly.

## Docker-only support — test infra port map + spawned servers

- **Docker is the only supported runtime, test, and deploy environment.** Everything runs in the compose stack: `make test` / `make test-ci` (or `docker compose exec -T api npm test` and `docker compose exec -T api npm run test:extended`), the quality gate (`docker compose exec -T api node quality-check.js`, plus the api.js startup gate), deploys (`make deploy`), and Cypress (`cypress-compose.yml`). Bare-host `node`/`npm` runs are ad-hoc debugging only and NOT supported — on slow hosts a spawned `api.js` cold start exceeds a suite's readiness window (e.g. `api-bugs-test.js`'s budget server waits ~30s while load+clean takes ~31s here) and fails spuriously. Fix or re-run in docker; do not change product code or tests to chase host-run flakiness.
- Port 3000 on the host is the local GoluGit (Forgejo) git server, NOT the API. Every `npm test`/`test:extended` file spawns its own `api.js` on a dedicated port and kills it in a finally: `auth-e2e-test.js`=3199, `rate-limit-test.js`=3201, `api-bugs-test.js`=3222, `catalogue-tests.js`=3223, `e2e-test.js`=3203, `extended-tests.js`=3204. Never point these at `localhost:3000`.
- Spawned-server suites must set `axios.defaults.httpAgent = new http.Agent({ keepAlive: false })` (see `api-bugs-test.js`, `quote-tests.js`). Node 19+ enables keep-alive on the global agent: any in-process corpus load that blocks the test event loop past the server's 5s keepAliveTimeout turns the next pooled-socket reuse into a bogus `socket hang up`. Fresh sockets make every request independent.
- CI runs the same suite via `docker compose exec -T api npm test` (inside the api container, where :3000 IS the API). That is the supported path — there is no supported host path.
- `test.sh` never tears down a stack it didn't start: it snapshots `docker compose ps --status running` before `up -d`, and only runs `docker compose down` at the end if the stack was NOT already running (it destroyed the prod stack once — the pre-`up -d` snapshot is the guard). `--no-teardown` still forces skip.

## Cypress (docker, isolated stack)

- Cypress specs log in via `/api/test-login` (needs `AUTH_TEST_MODE=1` on the api) and visit `/se/` (the real gated path). `/all-merged-books-serch.html` at root is 404 by nginx design. NEVER enable `AUTH_TEST_MODE` on the production stack — it lets anyone mint a session.
- On the host, run against `cypress-compose.yml` (own project/network/ports, so prod containers are untouched): `docker compose -p docdocgo-cypress -f cypress-compose.yml up -d --build nginx api` then `docker compose -p docdocgo-cypress -f cypress-compose.yml run --rm cypress`. CI instead uses the `cypress` profile service with `AUTH_TEST_MODE=1`.

## RAG service — DISABLED (profile-gated)

- RAG (`rag`/`rag-populate`) is parked behind `profiles: ["rag"]` in docker-compose.yml; `api` no longer `depends_on` it. The vector-db + model-cache volumes were kept when the rag container was removed, so re-enabling is: build + populate (`docker compose --profile populate run --rm rag-populate`), `docker compose --profile rag up -d rag`, then drop the profile gates.
- RAG-down behavior (GoluGit #3 / DOC-002): the four RAG endpoints are wrapped in `ragGuard()` — a cached availability probe (GET /health against `RAG_HOST:RAG_PORT`, TTL `RAG_PROBE_TTL_MS`, bounded by `RAG_PROBE_TIMEOUT_MS`). Down ⇒ fast **503 JSON** with a hint pointing at `/api/search` — never a hang, bare 502, or crash; mid-flight failures return 502/504 JSON, and connection-level errors mark the cache down so the next request fast-fails. `GET /api/health/deps` (rate-limit-exempt, always 200) reports dependency state — it is a report, NOT a liveness probe; `/api/health` stays the uptime endpoint. Input validation runs before the guard (400s stay 400s when RAG is down).
- Re-enabling also means restoring the rag build/push + populate + `rag-tests.js` steps in `.gitlab-ci.yml` (they were removed when RAG was disabled).
- Memory caps (host VPS OOM protection, cgroup-kill per container): api 1g, nginx 256m, rag 4g, cypress 2g + 512m shm.

## Git topology (two remotes)

- `origin` = local GoluGit (Forgejo/Gitea on `127.0.0.1:3000`, token in URL). `gitlab` = gitlab.com `lakshaynz/docdocgo`, the configured default remote for `main` and the CI host. Sync main to BOTH after merging; glab token is expired and `@admin3612` currently has read-only rights on gitlab.com (pushes rejected → main lands there via MR or a rights bump).
- The GoluGit token lives in the `origin` remote URL (`git config`); don't print remote URLs in logs.

## Maintaining this file

Keep this file for knowledge useful to almost every future agent session in this project.
Do not repeat what the codebase already shows; point to the authoritative file or command instead.
Prefer rewriting or pruning existing entries over appending new ones.
When updating this file, preserve this bar for all agents and keep entries concise.
