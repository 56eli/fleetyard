// Audit-pipeline regression tests: one group per open GoluGit ingest issue.
// #12 truncated filenames, #14 running headers/page numbers, #18 ASR
// non-Latin noise are verified already-fixed on main (DOC-010/013/016/017,
// DOC-030 titles) — these pin the corpus so a re-ingest can never silently
// reintroduce them. #20 glued/missing spaces and #34 docs ending mid-sentence
// are fixed here (fixGluedSpaces / stripTrailingAsrJunk in lecture-text.js).
// Pure loader-level: no spawned server, runs in seconds.
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const lt = require('./lecture-text');

let passed = 0;
let failed = 0;
function test(name, fn) {
    try {
        fn();
        console.log(`  ✅ ${name}`);
        passed++;
    } catch (err) {
        console.log(`  ❌ ${name}`);
        console.log(`     ${err.message}`);
        failed++;
    }
}

const books = lt.loadBookTexts(path.join(__dirname, 'html')).the_json_obj_books;
const loadedLectures = lt.loadLectureTexts(path.join(__dirname, 'html'));
const lectures = loadedLectures.lectures;
const lectureMeta = loadedLectures.lectureMeta;
const all = Object.assign({}, books, lectures);
const sourceConfig = JSON.parse(fs.readFileSync(path.join(__dirname, 'source-config.json'), 'utf8'));

console.log('\n--- #12 truncated filenames (banners stripped, full titles) ---');

test('truncated ==== title banner is dropped, body intact', () => {
    const out = lt.loadCleanText('    ====_Letting Go_ the Pathway of Sur_====\nALSO BY THE AUTHOR');
    assert.strictEqual(out, 'ALSO BY THE AUTHOR');
});

test('no ==== banner lines survive in any served document', () => {
    const bad = Object.keys(all).filter((k) =>
        all[k].split('\n').some((l) => { const t = l.trim(); return t.startsWith('====') || t.endsWith('===='); }));
    assert.deepStrictEqual(bad, []);
});

test('every book key is a full slug; legacy truncations alias away', () => {
    const { BOOK_KEY_ALIASES, resolveBookKey } = lt;
    const names = sourceConfig.displayNames || {};
    const legacy = Object.keys(BOOK_KEY_ALIASES);
    // Canonical map must not retain truncated mid-word keys.
    const stillTruncated = Object.keys(books).filter((k) => legacy.includes(k));
    assert.deepStrictEqual(stillTruncated, [], `truncated keys still in book map: ${stillTruncated}`);
    for (const [from, to] of Object.entries(BOOK_KEY_ALIASES)) {
        assert.strictEqual(resolveBookKey(from), to);
        assert.ok(books[to], `canonical slug missing: ${to}`);
        assert.ok(names[to], `displayName missing for ${to}`);
        assert.ok(!books[from], `legacy key must not remain as a map entry: ${from}`);
    }
    assert.strictEqual(names.letting_go__the_pathway_of_surrender, 'Letting Go: The Pathway of Surrender');
    assert.strictEqual(names.power_vs_force__the_hidden_determinants_of_human_behavior, 'Power vs. Force');
    // No displayName value looks mid-word truncated.
    const truncatedNames = Object.values(names).filter((n) =>
        /(hidden de|pathway of sur|presence of g|realizing_|of it__t|levels of con|advancem|enlightenmen|expla)$/i.test(n));
    assert.deepStrictEqual(truncatedNames, []);
});

console.log('\n--- #14 running headers / page numbers (stripped, pinned) ---');

test('no known-chrome or OCR page-crumb lines survive in any served document', () => {
    const bad = [];
    for (const [k, t] of Object.entries(all)) {
        for (const line of t.split('\n')) {
            const s = line.trim();
            if (!s) continue;
            if (/^DAVID R\. HAWKINS, M\.D\., PH\.D\.[-–—.\s]*$/i.test(s)) bad.push(k + ': ' + s);
            else if (/^BOOK OF SLIDES[-–—.\s]*$/i.test(s)) bad.push(k + ': ' + s);
            else if (/^-?\s*Author:\s*Susan Hawkins$/i.test(s)) bad.push(k + ': ' + s);
            else if (/^\d{1,4}\s*[-–—]\s*$/.test(s)) bad.push(k + ': ' + s);
            // Multi-dash page rules (`196-----------------------`) and
            // dash-rules glued to prose line ends (`…Luciferic------`).
            else if (/^\d{1,4}[-–—_=]{2,}$/.test(s)) bad.push(k + ': ' + s);
            else if (/[-–—_=]{4,}$/.test(s)) bad.push(k + ': ' + s);
        }
    }
    assert.deepStrictEqual(bad.slice(0, 10), []);
});

test('page-rule fixtures: digit rules, bare digit echoes, glue tails (all stripped)', () => {
    const f = lt.loadCleanText;
    assert.strictEqual(f('prose before\n196-----------------------\nSPIRITUAL PRACTICE'), 'prose before\nSPIRITUAL PRACTICE');
    assert.strictEqual(f('56. Strive to be angelic vs. Luciferic--------------------------------------------------------------\n403-----------------\n403\n40\n101 WAYS TO PEACE (13)'),
        '56. Strive to be angelic vs. Luciferic\n101 WAYS TO PEACE (13)');
    // Calibration ranges and bare table digits survive (TVF cal tables).
    assert.ok(/190-195/.test(f('calibrates 190-195 in the table')));
    assert.ok(/^465$/.test(f('the value\n465\nnext line').split('\n')[1]));
});

test('no repeated ALL-CAPS running head survives (8+ repeats, non-structural)', () => {
    const STRUCTURAL = /^(chapter|part|section|contents|index|preface|appendix|introduction|acknowledgements?|foreword|afterword|bibliography|glossary|notes)$/i;
    const bad = [];
    for (const [k, t] of Object.entries(all)) {
        const freq = new Map();
        t.split('\n').forEach((l) => { const s = l.trim(); if (s && s.length <= 60) freq.set(s, (freq.get(s) || 0) + 1); });
        for (const [s, n] of freq) {
            if (n < 8 || STRUCTURAL.test(s) || /©|copyright|all rights reserved|\bpublish(?:er|ing)\b/i.test(s)) continue;
            const letters = s.replace(/[^A-Za-z]/g, '');
            if (letters.length < 3) continue;
            const upper = letters.replace(/[^A-Z]/g, '').length;
            if (upper / letters.length >= 0.85 && s.length <= 60) bad.push(`${k}: ${s} (x${n})`);
        }
    }
    assert.deepStrictEqual(bad.slice(0, 10), []);
});

console.log('\n--- #18 ASR non-Latin noise (stripped, pinned) ---');

test('non-Latin script noise and glossary fixtures', () => {
    assert.strictEqual(lt.loadCleanText('the 핑 hoggy runs').includes('핑'), false);
    // Greek is in the strip + metric ranges since the #18 residue audit
    // (a stray `τη` was invisible to nonLatinShare without the range).
    assert.strictEqual(lt.loadCleanText('not a vegan read τη fair it'), 'not a vegan read fair it');
    assert.strictEqual(lt.nonLatinShare('τη'), 1);
    assert.ok(lt.loadCleanText('the collaborated level of Consciousness').includes('calibrated level of Consciousness'));
    assert.ok(!/\.{4,}/.test(lt.loadCleanText('wait.... filler')));
});

test('zero non-Latin share in every served document', () => {
    const bad = Object.keys(all).filter((k) => lt.nonLatinShare(all[k]) !== 0);
    assert.deepStrictEqual(bad, []);
});

console.log('\n--- #20 glued / missing spaces (fixed here) ---');

test('punctuation-glue fixtures', () => {
    const f = lt.fixGluedSpaces;
    assert.strictEqual(f('Watts,Alan'), 'Watts, Alan');
    assert.strictEqual(f('Beach,Va.: Donning'), 'Beach, Va.: Donning');
    assert.strictEqual(f('Sedona, AZ:Veritas Publishing'), 'Sedona, AZ: Veritas Publishing');
    assert.strictEqual(f('surmise:Whereas'), 'surmise: Whereas');
    assert.strictEqual(f('(Huxley 1945;Wilber 1997)'), '(Huxley 1945; Wilber 1997)');
    assert.strictEqual(f('worried.The secret'), 'worried. The secret');
    assert.strictEqual(f('bootstraps?Why not'), 'bootstraps? Why not');
    // Exclusions: formatted numbers, times, initials, decimals, ellipsis, OCR damage.
    assert.strictEqual(f('1,000'), '1,000');
    assert.strictEqual(f('12:30'), '12:30');
    assert.strictEqual(f('U.S. Army'), 'U.S. Army');
    assert.strictEqual(f('word...The'), 'word...The');
    assert.strictEqual(f('de?ned by'), 'de?ned by');
});

test('camel-glue fixtures (allowlist intact)', () => {
    const f = lt.fixGluedSpaces;
    assert.strictEqual(f('ofMaharshi'), 'of Maharshi');
    assert.strictEqual(f('thisMap of'), 'this Map of');
    assert.strictEqual(f('psychologistWilliam James'), 'psychologist William James');
    assert.strictEqual(f('my brothers and mySelf,'), 'my brothers and my Self,');
    assert.strictEqual(f('DrHawkinsInfo.'), 'Dr Hawkins Info.');
    assert.strictEqual(f('DrHawkins.info'), 'Dr Hawkins info');
    for (const w of lt.GLUE_CAMEL_ALLOW) assert.strictEqual(f(`the ${w} here`), `the ${w} here`, `${w} must not split`);
});

test('no punctuation glue or unknown camel glue survives corpus-wide', () => {
    const bad = [];
    const res = [/,(?=[A-Za-z])/g, /(?<![0-9]):(?=[A-Za-z])/g, /;(?=[A-Za-z])/g,
        /(?<![A-Z0-9.])([A-Za-z])\.([A-Z][a-z])/g, /([a-z])([?!])([A-Z])/g];
    for (const [k, t] of Object.entries(all)) {
        for (const re of res) {
            const m = t.match(new RegExp(re.source, 'g'));
            if (m) bad.push(`${k}: ${m[0]}`);
        }
        let m;
        const rc = /(?<![A-Za-z])[a-z]+[A-Z][A-Za-z]+/g;
        while ((m = rc.exec(t))) {
            if (!lt.GLUE_CAMEL_ALLOW.has(m[0])) bad.push(`${k}: ${m[0]}`);
        }
    }
    assert.deepStrictEqual(bad.slice(0, 10), []);
});

test('fixGluedSpaces is a fixpoint on served text', () => {
    const bad = Object.keys(all).filter((k) => lt.fixGluedSpaces(all[k]) !== all[k]);
    assert.deepStrictEqual(bad, []);
});

console.log('\n--- #34 docs ending mid-sentence (trailing junk fixed here) ---');

test('trailing-junk fixtures: loops, Amara credit, stray here', () => {
    const s = lt.stripTrailingAsrJunk;
    assert.strictEqual(s('Truth.\nhere'), 'Truth.');
    assert.strictEqual(s("What's next? you are you are you are"), "What's next?");
    assert.strictEqual(s('Thank you, Dr. Hawkins. you are'), 'Thank you, Dr. Hawkins.');
    assert.strictEqual(s('O Lord.\nSubtitles by the Amara.org community'), 'O Lord.');
    assert.strictEqual(s('O Lord. Subtitles by the Amara.org community'), 'O Lord.');
    // Speech, not loops — stays.
    assert.strictEqual(s('truly grateful. actually'), 'truly grateful. actually');
    assert.strictEqual(s('killing him you see'), 'killing him you see');
    assert.strictEqual(s('Oh, yeah.\nOh.\nGod'), 'Oh, yeah.\nOh.\nGod');
    assert.strictEqual(s('bless you'), 'bless you');
});

test('known junk tails are gone from served documents', () => {
    const tail = (k) => all[k].trimEnd().slice(-60);
    assert.ok(tail('A_Map_of_Consciousness_enxautogen_html').endsWith('realization of the truth.'), 'A_Map');
    assert.ok(tail('Pain_and_Suffering_enxautogen_html').endsWith('who we really are.'), 'Pain');
    assert.ok(tail('God,_Religion,_and_Spirituality_Dec_2005_Part_1_enxautogen_html').endsWith("What's next?"), 'GodRel1');
    assert.ok(tail('Integration_of_Spirituality_and_Personal_Life_Feb_2003_Part_3_enxautogen_html').endsWith('O Lord.'), 'Amara');
    assert.ok(!/Subtitles by the Amara\.org community/i.test(
        Object.values(all).join('\n')), 'no Amara credit anywhere served');
});

test('stripTrailingAsrJunk is a fixpoint on served text', () => {
    const bad = Object.keys(all).filter((k) => lt.stripTrailingAsrJunk(all[k]) !== all[k]);
    assert.deepStrictEqual(bad, []);
});

console.log('\n--- #89 stuck-decoder identical-token runs at EOF (DOC-052) ---');

const POS3 = 'Positionality_and_Duality_Transcending_the_Opposites_Apr_2002_Part_3_enxautogen_html';
const POS3_LOOP_FIXTURE = 'They went from 431 to 440. Nine points. That\'s the equivalent of two lifetimes. You owe me. Two lifetimes earnings now. $10. Yeah, $10 for a lifetime. $10. $10. $10. $10. $10. $10. $10. $10. $10. $10. $10. $10. $10. $10. $10. Yeah, we went up 10 points. That\'s really nice.';
const POS3_LOOP_FIXED = 'They went from 431 to 440. Nine points. That\'s the equivalent of two lifetimes. You owe me. Two lifetimes earnings now. $10. Yeah, $10 for a lifetime. Yeah, we went up 10 points. That\'s really nice.';

test('15× $10. run collapses to the two legitimate mentions', () => {
    assert.strictEqual(lt.stripTrailingAsrJunk(POS3_LOOP_FIXTURE), POS3_LOOP_FIXED);
    assert.strictEqual((POS3_LOOP_FIXED.match(/\$10/g) || []).length, 2);
    // Three identical tokens is speech, not a decoder loop.
    assert.strictEqual(lt.stripTrailingAsrJunk('Done. no no no thanks.'), 'Done. no no no thanks.');
});

test('Positionality Apr 2002 Part 3 served text keeps two $10 mentions', () => {
    const t = lectures[POS3];
    assert.ok(t, `missing ${POS3}`);
    assert.strictEqual((t.match(/\$10/g) || []).length, 2, '$10 count');
    assert.ok(/Two lifetimes earnings now\.\s*\$10\./.test(t), 'first legitimate $10.');
    assert.ok(/\$10 for a lifetime/.test(t), 'second legitimate $10 for a lifetime');
    assert.ok(!/\$10\.\s+\$10\./.test(t.slice(-lt.IDENTICAL_TOKEN_TAIL_CHARS)), 'no consecutive $10. in tail');
    assert.ok(/That'?s really nice\.?\s*$/.test(t.trimEnd()), 'real closing sentence survives');
});

test('no 4+ identical-token run in last 800 chars of any served document', () => {
    const bad = [];
    const tokRe = /\$?\d+(?:\.\d+)?[.,]?|[A-Za-z']+[.,]?/g;
    for (const [k, t] of Object.entries(all)) {
        const tokens = (t.slice(-lt.IDENTICAL_TOKEN_TAIL_CHARS).match(tokRe) || []);
        let i = 0;
        while (i < tokens.length) {
            let j = i + 1;
            while (j < tokens.length && tokens[j] === tokens[i]) j++;
            if (j - i >= lt.IDENTICAL_TOKEN_MIN_RUN) bad.push(`${k}: ${tokens[i]} x${j - i}`);
            i = j;
        }
    }
    assert.deepStrictEqual(bad.slice(0, 10), []);
});

console.log('\n--- #90 lecture parts open mid-clause (DOC-053) ---');

const ABRUPT_FOUR = [
    'Dialogue,_Questions,_and_Answers_Dec_2003_Part_2_enxautogen_html',
    'Enlightenment_Aug_2003_Part_2_enxautogen_html',
    'God_Transcendent_and_Immanent_Nov_2002_Part_1_enxautogen_html',
    'Positionality_and_Duality_Transcending_the_Opposites_Apr_2002_Part_3_enxautogen_html'
];

test('looksAbruptStart fixtures: lowercase, ellipsis, and "and "', () => {
    assert.strictEqual(lt.looksAbruptStart('reality or value to any thought that is in contradiction'), true);
    assert.strictEqual(lt.looksAbruptStart('couple of times / and I landed in court'), true);
    assert.strictEqual(lt.looksAbruptStart("...with beauty, is that you can't function."), true);
    assert.strictEqual(lt.looksAbruptStart('and he starts astral projecting every night'), true);
    assert.strictEqual(lt.looksAbruptStart('Welcome to the lecture today.'), false);
    assert.strictEqual(lt.looksAbruptStart('And now we continue from last time.'), false);
});

test('the four cited openings are flagged startsAbruptly', () => {
    for (const k of ABRUPT_FOUR) {
        assert.ok(lectures[k], `missing ${k}`);
        assert.ok(lt.looksAbruptStart(lectures[k]), `${k} should still look abrupt (or be recut)`);
        assert.strictEqual(lectureMeta[k] && lectureMeta[k].startsAbruptly, true, `${k} not flagged`);
    }
});

test('every Part 2/3 whose first 80 chars lack a capital start (or begin with ... / and ) is flagged', () => {
    const unflagged = [];
    for (const [k, t] of Object.entries(lectures)) {
        if (!/_Part_[23](?:_|$)/i.test(k)) continue;
        if (!lt.looksAbruptStart(t)) continue;
        if (!(lectureMeta[k] && lectureMeta[k].startsAbruptly)) unflagged.push(k);
    }
    assert.deepStrictEqual(unflagged, []);
});

const ADV1 = 'Advaita_The_Way_to_God_Through_Mind_Aug_2002_Part_1_enxautogen_html';

test('DOC-046 #78: Advaita Aug 2002 Part 1 overlay is served (pipeline, not api.js)', () => {
    assert.ok(lectures[ADV1], 'missing Advaita Part 1 key');
    const served = lectures[ADV1];
    assert.ok(!/\bClomagnum\b/i.test(served), 'Clomagnum still present');
    assert.ok(!/\binfill man\b/i.test(served), 'infill man still present');
    assert.ok(!/\bKill-Town Man\b/i.test(served), 'Kill-Town still present');
    assert.ok(!/\bKilton man\b/i.test(served), 'Kilton still present');
    assert.ok(!/\bAustralopis\b/i.test(served), 'Australopis still present');
    assert.ok(!/\bAustralopopis\b/i.test(served), 'Australopopis still present');
    assert.ok(!/\bnon-integers\b/i.test(served), 'non-integers still present');
    assert.ok(!/\bDo you just said\b/i.test(served), 'Do you just said still present');
    assert.ok(!/\binlet that rode\b/i.test(served), 'inlet that rode still present');
    assert.ok(!/Homo erectus,\s*Antho,/i.test(served), 'Antho still present');
    assert.match(served, /Cro-Magnon/);
    assert.match(served, /Neanderthal man/);
    assert.match(served, /Australopithecus/);
    assert.match(served, /non-integrous/);
    assert.match(served, /Did you just say/);
    assert.match(served, /intellectual road/);
    assert.match(served, /that which is Caesar's/);
    assert.ok(!/which has to do with no mind, which has to do with no mind/i.test(served));
    assert.ok(!/the source of this wing movement is exactly the source of this wing movement/i.test(served));
    const maxLine = Math.max(...served.split('\n').map(l => l.length));
    assert.ok(maxLine < 900, `Advaita Part 1 still has a dump line (${maxLine})`);
});

test('DOC-046 #78: hotword + stutter collapse pins (no invented words)', () => {
    const names = lt.applyHawkinsHotwords(
        'Clomagnum, infill man, Kill-Town Man, Kilton man, Australopis Popis, Australopopis, non-integers, non-integrists, integrists, Do you just said, that which is Caesar, inlet that rode, Homo erectus, Antho, Australopithecus',
        { rewriteEagle: false }
    );
    assert.match(names, /Cro-Magnon/);
    assert.match(names, /Neanderthal man/);
    assert.ok(!/Kill-Town|Kilton|infill|Clomagnum|Australopis|Australopopis|Antho/i.test(names), names);
    assert.match(names, /non-integrous/);
    assert.match(names, /\bintegrous\b/);
    assert.match(names, /Did you just say/);
    assert.match(names, /that which is Caesar's/);
    assert.match(names, /intellectual road/);
    const loop = lt.collapseAsrStutters(
        'which has to do with no mind, which has to do with no mind, which has to do with no mind'
    );
    assert.strictEqual(loop, 'which has to do with no mind');
    const dups = lt.collapseAsrStutters('Same line.\nSame line.');
    assert.strictEqual(dups, 'Same line.');
});

test('DOC-046 leftover doubles (comment 1707): L49 let-it-go, L415 wings, L491 not-who', () => {
    const served = lectures[ADV1];
    assert.ok(!/, and as it comes up, you let it go/i.test(served), 'let-it-go still doubled');
    assert.match(served, /as each thing comes up, you let it go/);
    assert.ok(!/wings going up which does not cause the next thing of his wings going up/i.test(served),
        'hummingbird wings still doubled');
    assert.match(served, /does not cause the next thing of his wings going up/);
    const who = served.split('\n').filter(l => /looking for a not who/i.test(l));
    assert.strictEqual(who.length, 1, who);
    const collapsed = lt.collapseAsrStutters(
        "And you're looking for a not who.\nYou're looking for a not who."
    );
    assert.strictEqual(collapsed, "You're looking for a not who.");
});

const GODREL1 = 'God,_Religion,_and_Spirituality_Dec_2005_Part_1_enxautogen_html';

test('#104: cities ASR is siddhis (phrase-only, not biblical cities)', () => {
    const served = lectures[GODREL1];
    assert.ok(served, 'missing God Rel Dec 2005 Part 1');
    assert.ok(!/achieve the cities/i.test(served), 'achieve the cities still present');
    assert.ok(!/a certain city/i.test(served), 'a certain city still present');
    assert.match(served, /achieve the siddhis/i);
    assert.match(served, /a certain siddhi/i);
    const bible = lt.applyHawkinsHotwords(
        'And he overthrew those cities and all the plain.',
        { rewriteEagle: false }
    );
    assert.match(bible, /overthrew those cities/);
    assert.ok(!/siddhi/i.test(bible), bible);
});

test('DOC-051 #88: proper-name ASR (Arafat / Labrador / Catholic / Mingus / camels)', () => {
    const names = lt.applyHawkinsHotwords(
        "air fat, laboratory retrievers, Catholics Diocese, Mingu's Mountain, I understand Campbell's completely, Joseph Campbell",
        { rewriteEagle: false }
    );
    assert.match(names, /Arafat/);
    assert.match(names, /Labrador retrievers/);
    assert.match(names, /Catholic Diocese/);
    assert.match(names, /Mingus Mountain/);
    assert.match(names, /understand camels/);
    assert.match(names, /Joseph Campbell/);
    assert.ok(!/air fat/i.test(names), names);
    assert.ok(!/laboratory retrievers/i.test(names), names);
    assert.ok(!/Catholics Diocese/i.test(names), names);
    assert.ok(!/Mingu's Mountain/i.test(names), names);
    const perc = lectures['Perception_and_Illusion_Distortions_of_Reality_May_2002_Part_3_enxautogen_html'];
    assert.ok(perc && !/\bair fat\b/i.test(perc), 'air fat still in Perception May 2002 Part 3');
    assert.match(perc, /Arafat/);
    const enl = lectures['Enlightenment_Aug_2003_Part_3_enxautogen_html'];
    assert.match(enl, /Labrador retrievers/);
    const karma = lectures['Karma_and_the_Afterlife_Oct_2002_Part_3_enxautogen_html'];
    assert.match(karma, /Catholic Diocese/);
    const godt = lectures['God_Transcendent_and_Immanent_Nov_2002_Part_1_enxautogen_html'];
    assert.match(godt, /Mingus Mountain/);
    const pos = lectures['Positionality_and_Duality_Transcending_the_Opposites_Apr_2002_Part_1_enxautogen_html'];
    assert.match(pos, /understand camels/);
    assert.ok(!/understand Campbell's/i.test(pos));
    const comm = lectures['Spiritual_Community_Jun_2003_Part_2_enxautogen_html'];
    assert.match(comm, /Joseph Campbell/);
});

console.log('\n--- DOC-061 Gloria in Excelsis Deo ASR variants ---');

test('DOC-061: no Excelsior in lecture/health_lecture; no excelsious anywhere in lectures', () => {
    const kinds = sourceConfig.kinds || {};
    const excelsiorKeys = [];
    const excelsiousKeys = [];
    for (const [k, t] of Object.entries(lectures)) {
        const kind = kinds[k];
        if ((kind === 'lecture' || kind === 'health_lecture') && /Excelsior/i.test(t)) {
            excelsiorKeys.push(k);
        }
        if (/excelsious/i.test(t)) excelsiousKeys.push(k);
    }
    assert.deepStrictEqual(excelsiorKeys, [], excelsiorKeys.join(','));
    assert.deepStrictEqual(excelsiousKeys, [], excelsiousKeys.join(','));
});

test('DOC-061: nine named Gloria quotes read Gloria in Excelsis Deo', () => {
    const cases = [
        ['God,_Religion,_and_Spirituality_Dec_2005_Part_1_enxautogen_html', /Gloria in Excelsis Deo\. Peace on Earth, goodwill to men/],
        ['God,_Religion,_and_Spirituality_Dec_2005_Part_3_enxautogen_html', /Gloria in Excelsis Deo/],
        ['Live_Your_Life_Like_a_Prayer_Nov_2006_Part_1_enxautogen_html', /Gloria in Excelsis Deo/],
        ['Valid_Teachers_and_Teachings_Nov_2005_Part_1_enxautogen_html', /Gloria in Excelsis Deo\. If you're/],
        ['Valid_Teachers_and_Teachings_Nov_2005_Part_3_enxautogen_html', /Gloria in Excelsis Deo/],
        ['Is_the_Miraculous_Real_Dec_2006_Part_1_enxautogen_html', /Gloria in Excelsis Deo/],
        ['Perception_vs_Essence_Apr_2006_Part_1', /Gloria in Excelsis Deo/],
        ['Reason_vs_Truth_Aug_2006_Part_3_enxautogen_html', /Gloria in Excelsis Deo/]
    ];
    for (const [k, re] of cases) {
        const t = lectures[k];
        assert.ok(t, `missing ${k}`);
        assert.match(t, re, k);
        assert.ok(!/Excelsior/i.test(t), k);
        assert.ok(!/excelsious/i.test(t), k);
    }
    const valid1 = lectures['Valid_Teachers_and_Teachings_Nov_2005_Part_1_enxautogen_html'];
    assert.ok(!/excelsior's deal/i.test(valid1));
    const ross = lectures.Health_enxautogen_html;
    assert.match(ross, /Glorian Ross/);
});

test('DOC-039 #64: residual OCR six sites (ligature, ?-glue, ofthe, duplicated fragment)', () => {
    const extras = lt.loadExtraSources();
    const corpus = Object.assign({}, all, extras);
    const lig = [];
    const ofthe = [];
    for (const [k, t] of Object.entries(corpus)) {
        if (/[a-z]\?[a-z]/.test(t)) lig.push(k);
        if (/\bofthe\b/.test(t)) ofthe.push(k);
    }
    assert.deepStrictEqual(lig, [], `letter-?-letter remains: ${lig}`);
    assert.deepStrictEqual(ofthe, [], `ofthe remains: ${ofthe}`);
    const tvf = books.truth_vs_falsehood;
    assert.ok(tvf, 'missing truth_vs_falsehood');
    assert.match(tvf, /Free Speech defined by the Bill of Rights/);
    assert.match(tvf, /End Justifies the Means/);
    assert.match(tvf, /Selfish Considerate/);
    const st = lectures['Spiritual_Truth_vs_Spiritual_Fantasy_Jun_2006_Part_1_enxautogen_html'];
    assert.ok(st, 'missing Spiritual Truth Jun 2006 Part 1');
    assert.match(st, /Get it\? creation/);
    assert.ok(!/Get it\?creation/.test(st));
    const eyeKey = Object.keys(books).find((k) => k.startsWith('the_eye_of_the_i'));
    assert.ok(eyeKey, 'missing eye_of_the_i');
    assert.ok(!/the the mind is to see/.test(books[eyeKey]));
    assert.match(books[eyeKey], /the One/);
    assert.match(books[eyeKey], /way out of the mind is to see that the many and the one are the same/);
    const barret = extras.Book_of_Slides_Barret_notes;
    assert.ok(barret, 'missing Barret notes');
    assert.match(barret, /Realization of the Self as the I/);
});

console.log('\n--- DOC-064 #101 PvF letter-space + glue ---');

test('DOC-064 #101: PvF letter-space and glue leftovers; I was / A person survive', () => {
    const k = 'power_vs_force__the_hidden_determinants_of_human_behavior';
    const t = books[k];
    assert.ok(t, 'missing PvF');
    for (const bad of [
        'F OREWORD', 'I magine', 'P REFACE', 'A BOUT THE A UTHOR',
        'T he evolution', 'p atriotism', 'P atriotism', 'a mericanism',
        'A mericanism', 'g od', 'G od', 'f reedom', 'F reedom',
        'l iberty', 'L iberty', 'fr eedom',
        'DuringWorldWar', 'RamanaMaharshi', 'Nis-argadatta Maharaja',
        'JacquesMayol', 'all-or-nonemuscle', 'strongmuscle',
        'demonstrableweakening', 'testmus-cle', 'kinesiologicalmuscle'
    ]) {
        assert.ok(!t.includes(bad), 'still present: ' + bad);
    }
    assert.match(t, /FOREWORD/);
    assert.match(t, /Imagine—what if you had access/);
    assert.match(t, /PREFACE/);
    assert.match(t, /While the truths reported/);
    assert.match(t, /ABOUT THE AUTHOR/);
    assert.match(t, /The evolution of this work/);
    assert.match(t, /patriotism and Patriotism/);
    assert.match(t, /americanism and Americanism/);
    assert.match(t, /god and God/);
    assert.match(t, /freedom and Freedom/);
    assert.match(t, /liberty and Liberty/);
    assert.match(t, /During World War II/);
    assert.match(t, /Ramana Maharshi/);
    assert.match(t, /Nisargadatta Maharaj/);
    assert.match(t, /Jacques Mayol/);
    assert.match(t, /all-or-none muscle/);
    assert.match(t, /strong muscle/);
    assert.match(t, /demonstrable weakening of the test muscle/);
    assert.match(t, /kinesiological muscle/);
    assert.match(t, /\bI was\b/);
    assert.match(t, /\bA person\b/);
});

console.log('\n--- DOC-065 #129 common-word misspellings ---');

test('DOC-065 #129: publically and greatful gone; publicly/grateful remain', () => {
    const bad = [];
    for (const [k, t] of Object.entries(all)) {
        if (/\bpublically\b/i.test(t)) bad.push(k + ':publically');
        if (/\bgreatful\b/i.test(t)) bad.push(k + ':greatful');
    }
    assert.deepStrictEqual(bad, [], 'misspellings remain: ' + bad);
    const book = books.reality_spirituality_and_modern_man;
    assert.ok(book, 'missing reality_spirituality_and_modern_man');
    assert.match(book, /publicly funded/);
    const alc = lectures.Alcoholism_enxautogen_html;
    const can = lectures.Cancer_enxautogen_html;
    assert.ok(alc, 'missing Alcoholism');
    assert.ok(can, 'missing Cancer');
    assert.match(alc, /grateful/i);
    assert.match(can, /grateful/i);
    assert.ok((alc.match(/\bgrateful\b/gi) || []).length >= 1);
    assert.ok((can.match(/\bgrateful\b/gi) || []).length >= 1);
});

console.log('\n--- DOC-062 #100 Volume I-V / Verification lecture ASR/glue ---');

const VOL1P1 = 'Volume_I_Power_vs_Force_Muscle_Testing_Part_1_enxautogen_html';
const VOL1P2 = 'Volume_I_Power_vs_Force_Muscle_Testing_Part_2_enxautogen_html';
const VOL3P1 = 'Volume_III_Advanced_States_of_Consciousness_Part_1_enxautogen_html';
const VOL4P1 = 'Volume_IV_Consciousness_How_to_Tell_the_Truth_About_Anything_Part_1_enxautogen_html';
const VOL5P1 = 'Volume_V_Undoing_the_Barriers_to_Spiritual_Progress_Part_1_enxautogen_html';
const VOL5P2 = 'Volume_V_Undoing_the_Barriers_to_Spiritual_Progress_Part_2_enxautogen_html';
const VOL5P3 = 'Volume_V_Undoing_the_Barriers_to_Spiritual_Progress_Part_3_enxautogen_html';
const VERP2 = 'Verification_of_Spiritual_Realities_Part_2_enxautogen_html';
const VERP3 = 'Verification_of_Spiritual_Realities_Part_3_enxautogen_html';
const VOL5P3_LOOP_FIXTURE = "And that's a good afternoon's work.\nThank you so much. if you are not you are to you are";

test('DOC-062: phrase-scoped homophones (Force / Chartres / inner dictation / third-month)', () => {
    const names = lt.applyHawkinsHotwords(
        'the book power versus Forest. people who read power versus Forester or here election like this. shark Cathedral Notre Dame. third must stay in Sedona. She got it from interdication. Sherwood Forest. C.S. Forester wrote. a shark swims.',
        { rewriteEagle: false }
    );
    assert.match(names, /power versus Force/);
    assert.match(names, /hear a lecture like this/);
    assert.match(names, /Chartres Cathedral Notre Dame/);
    assert.match(names, /third-month stay in Sedona/);
    assert.match(names, /from inner dictation/);
    assert.match(names, /Sherwood Forest/);
    assert.match(names, /C\.S\. Forester wrote/);
    assert.match(names, /a shark swims/);
    assert.ok(!/power versus Forest/i.test(names), names);
    assert.ok(!/Forester or here election/i.test(names), names);
    assert.ok(!/shark Cathedral/i.test(names), names);
    assert.ok(!/interdication/i.test(names), names);
    assert.ok(!/third must stay/i.test(names), names);
});

test('DOC-062: Korean-introducer romanization dropped; David R. Hawkins kept', () => {
    const names = lt.applyHawkinsHotwords(
        "if David our Hawkins.\nThank you.\nSir, Dr. David Hawkins Tay reung's son Keck tosa.\nThank you.",
        { rewriteEagle: false }
    );
    assert.match(names, /Dr\. David R\. Hawkins/);
    assert.ok(!/David our Hawkins/i.test(names), names);
    assert.ok(!/Keck tosa/i.test(names), names);
    assert.ok(!/Tay reung/i.test(names), names);
});

test('DOC-062: served lectures lose Forest/Forester/shark Cathedral/interdication/Keck tosa', () => {
    const corpus = [lectures[VOL1P1], lectures[VOL1P2], lectures[VOL3P1], lectures[VOL4P1],
        lectures[VOL5P1], lectures[VOL5P2], lectures[VOL5P3], lectures[VERP2], lectures[VERP3]].join('\n');
    assert.ok(!/power versus Forest/i.test(corpus));
    assert.ok(!/versus Forester/i.test(corpus));
    assert.ok(!/shark Cathedral/i.test(corpus));
    assert.ok(!/interdication/i.test(corpus));
    assert.ok(!/Keck tosa/i.test(corpus));
    assert.match(lectures[VOL1P1], /power versus Force/);
    assert.match(lectures[VOL5P1], /power versus Force/);
    assert.match(lectures[VOL5P1], /hear a lecture like this/);
    assert.match(lectures[VERP2], /Chartres Cathedral/);
    assert.match(lectures[VOL3P1], /third-month stay in Sedona/);
    assert.match(lectures[VOL5P3], /inner dictation/);
    assert.match(lectures[VOL4P1], /Dr\. David R\. Hawkins/);
});

test('DOC-062: Volume I P2 opening is tagged inaudible demo, not video-game salad', () => {
    const t = lectures[VOL1P2];
    assert.ok(t, `missing ${VOL1P2}`);
    assert.ok(!/Rock Hill has positive energy/i.test(t));
    assert.ok(!/as a video game changes contract videos/i.test(t));
    assert.match(t, /\[inaudible demo\]/);
    assert.match(t, /test subject/);
});

test('DOC-062: stripTrailingAsrJunk drops if/not/to you-are remainder', () => {
    assert.strictEqual(lt.stripTrailingAsrJunk(VOL5P3_LOOP_FIXTURE),
        "And that's a good afternoon's work.\nThank you so much.");
    const t = lectures[VOL5P3];
    assert.ok(t, `missing ${VOL5P3}`);
    assert.ok(!/you are to you are\s*$/i.test(t.trimEnd()), t.trimEnd().slice(-80));
    assert.match(t.trimEnd(), /Thank you so much\.?\s*$/);
    assert.strictEqual(lt.stripTrailingAsrJunk('truly grateful. actually'), 'truly grateful. actually');
    assert.strictEqual(lt.stripTrailingAsrJunk('killing him you see'), 'killing him you see');
});

test('DOC-062: Volume V / Verification cue-word openings land on a sentence boundary', () => {
    assert.match(lectures[VOL5P1].trimStart(), /^Most places where you go to hear somebody speak/);
    assert.match(lectures[VOL5P2].trimStart(), /^One reason to calibrate things/);
    assert.match(lectures[VOL5P3].trimStart(), /^If you're dedicated to mankind/);
    assert.match(lectures[VERP2].trimStart(), /^What it takes to make people stop talking/);
    assert.match(lectures[VERP3].trimStart(), /^Take my word for it's always in your way/);
    assert.match(lectures[VERP3], /we're working on it here/);
});

console.log('\n--- DOC-066 #132 punctuation-spacing ---');

test('DOC-066 #132 fixtures: space-before punct, double-space, ~o; ellipsis/decimal/initials/tildes survive', () => {
    const f = lt.applyPunctuationSpacing;
    assert.strictEqual(f('word . Next'), 'word. Next');
    assert.strictEqual(f('hello , world'), 'hello, world');
    assert.strictEqual(f('two  spaces here'), 'two spaces here');
    assert.strictEqual(f('a   b    c'), 'a b c');
    assert.strictEqual(f('wait . . . go'), 'wait. . . go');
    assert.strictEqual(f('see J. S. here'), 'see J. S. here');
    assert.strictEqual(f('pi 3.14 stays'), 'pi 3.14 stays');
    assert.strictEqual(f('What makes me come I really ~o not know'),
        'What makes me come I really do not know');
    assert.strictEqual(f('(~180) and ~ 6 minutes'), '(~180) and ~ 6 minutes');
    // Joiners survive a spacing pass (never strip U+200C/U+200D).
    const syriac = 'ab  cd \u200d xy . z\u200c';
    assert.strictEqual(f(syriac), 'ab cd \u200d xy. z\u200c');
});

test('DOC-066 #132 corpus: no space-before punct, no word-word double-space, ~o gone', () => {
    const extras = lt.loadExtraSources();
    const corpus = Object.assign({}, all, extras);
    const spacePeriod = [];
    const spaceComma = [];
    const dbl = [];
    const tildeo = [];
    for (const [k, t] of Object.entries(corpus)) {
        if (/(?<!\.) \.(?!\.)/.test(t)) spacePeriod.push(k);
        if (/\w ,/.test(t)) spaceComma.push(k);
        if (/\w  \w/.test(t)) dbl.push(k);
        if (/~o/.test(t)) tildeo.push(k);
    }
    assert.deepStrictEqual(spacePeriod, [], 'space-before-period remain: ' + spacePeriod.slice(0, 8));
    assert.deepStrictEqual(spaceComma, [], 'space-before-comma remain: ' + spaceComma);
    assert.deepStrictEqual(dbl, [], 'double-space remain: ' + dbl);
    assert.deepStrictEqual(tildeo, [], '~o remain: ' + tildeo);
    assert.match(books.I_AM_THAT, /I really do not know/);
    assert.ok(!/~o/.test(books.I_AM_THAT));
});

test('DOC-066 #132 caret run kept as explicit notation; Lamsa Syriac joiners untouched', () => {
    const t = books.I_reality_and_subjectivity;
    assert.ok(t, 'missing I_reality_and_subjectivity');
    assert.match(t, /The dog chases the cat up the tree\. \^ \^ \^ \^ \^ \^ \^ \^/);
    const lamsa = books.Lamsa_bible;
    assert.ok(lamsa, 'missing Lamsa_bible');
    assert.strictEqual((lamsa.match(/\u200d/g) || []).length, 1);
    assert.strictEqual((lamsa.match(/\u200c/g) || []).length, 1);
    assert.match(lamsa, /\u200d\u0710/);
    assert.match(lamsa, /\u072c\u200c\u0710/);
});

console.log('\n--- DOC-067 #140 letter-space t he / T o ---');

test('DOC-067 #140 fixtures: T o and standalone t he join; n\'t he survives', () => {
    const f = lt.applyPvfOcrFixes;
    assert.strictEqual(f('T o better understand'), 'To better understand');
    assert.strictEqual(f('T he critical difference'), 'The critical difference');
    assert.strictEqual(f('t he world'), 'the world');
    assert.strictEqual(f("didn't he?"), "didn't he?");
    assert.strictEqual(f("isn't he?"), "isn't he?");
    assert.strictEqual(f("Doesn’t he know"), "Doesn’t he know");
    assert.strictEqual(f('I was'), 'I was');
    assert.strictEqual(f('A person'), 'A person');
});

test('DOC-067 #140 corpus: PvF T o gone; no standalone lecture t he; contractions kept', () => {
    const pvf = books.power_vs_force__the_hidden_determinants_of_human_behavior;
    assert.ok(pvf, 'missing PvF');
    assert.ok(!/\bT o\b/.test(pvf), 'T o remains in PvF');
    assert.match(pvf, /To better understand the critical difference between force and power/);
    const standalone = [];
    for (const [k, t] of Object.entries(lectures)) {
        if (/(?<![A-Za-z\u2019'])t he\b/.test(t) || /(?<![A-Za-z\u2019'])T he\b/.test(t)) {
            standalone.push(k);
        }
    }
    assert.deepStrictEqual(standalone, [], 'standalone t he remain: ' + standalone.slice(0, 8));
    const god = lectures.God_vs_Science_Limits_of_the_Mind_Feb_2007_Part_1_enxautogen_html;
    assert.ok(god, 'missing God_vs_Science P1');
    assert.match(god, /didn't he\?/);
});

console.log('\n--- #142 garbled ASR Integris / inlet / Forester ---');

test('#142 fixtures: Integris/inlet/Forester/integers; Forest-for-trees survives', () => {
    const f = (s) => lt.applyHawkinsHotwords(s);
    assert.match(f('the intention has to be Integris'), /integrous/i);
    assert.ok(!/Integris/i.test(f('differentiate Integris teachers')));
    assert.match(f('differentiate Integris teachers'), /integrous teachers/i);
    assert.strictEqual(f('the integers the intention'), 'the integrity the intention');
    assert.match(f("don't try to use your Inlet"), /intellect/i);
    assert.ok(!/\binlet\b/i.test(f('the inlet is the great block')));
    assert.match(f('No Forester intimidation next one.'), /No force or intimidation next one/i);
    assert.match(f('come through the art on Forest which is a big surprise'), /Ardennes Forest/);
    assert.match(f('come across through the yard and Forest so I would'), /Ardennes Forest/);
    assert.match(f('They miss the forest for the trees.'), /forest for the trees/);
    assert.match(f('the Amazon forest puts out'), /Amazon forest/);
});

test('#142 corpus: Integris/inlet/Forester gone; quoted lectures read clean; real Forest kept', () => {
    const bad = [];
    for (const [k, t] of Object.entries(lectures)) {
        if (/\bIntegris\b/i.test(t)) bad.push(k + ':Integris');
        if (/\binlet\b/i.test(t)) bad.push(k + ':inlet');
        if (/\bForester intimidation\b/i.test(t)) bad.push(k + ':Forester');
        if (/\bart on Forest\b/i.test(t)) bad.push(k + ':art on Forest');
        if (/\byard and Forest\b/i.test(t)) bad.push(k + ':yard and Forest');
    }
    assert.deepStrictEqual(bad, [], 'garbles remain: ' + bad.slice(0, 10));
    const conv = lectures.Conviction_Jul_2005_Part_1_enxautogen_html;
    assert.ok(conv);
    assert.match(conv, /intention has to be integrous/i);
    assert.match(conv, /The question has the integrity/);
    const valid = lectures.Valid_Teachers_and_Teachings_Nov_2005_Part_1_enxautogen_html;
    assert.ok(valid);
    assert.match(valid, /differentiate integrous teachers/i);
    assert.match(valid, /No force or intimidation next one/i);
    const v1p2 = lectures.Volume_I_Power_vs_Force_Muscle_Testing_Part_2_enxautogen_html;
    assert.ok(v1p2);
    assert.match(v1p2, /the intellect is the great block/i);
    const v4 = lectures.Volume_IV_Consciousness_How_to_Tell_the_Truth_About_Anything_Part_1_enxautogen_html;
    assert.ok(v4);
    assert.match(v4, /don't try to use your [Ii]ntellect/);
    const v5 = lectures.Volume_V_Undoing_the_Barriers_to_Spiritual_Progress_Part_1_enxautogen_html;
    assert.ok(v5);
    assert.match(v5, /Ardennes Forest/);
    const ver2 = lectures.Verification_of_Spiritual_Realities_Part_2_enxautogen_html;
    assert.ok(ver2);
    assert.match(ver2, /Ardennes Forest/);
    const ego = lectures.The_Ego_and_The_Self_Dec_2004_Part_1_enxautogen_html;
    assert.ok(ego);
    assert.match(ego, /forest for the trees/);
});

console.log(`\naudit-pipeline-tests: ${passed} passed, ${failed} failed`);
if (failed > 0) process.exit(1);
