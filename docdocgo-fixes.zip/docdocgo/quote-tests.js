// Tests for /api/quote/:path — shareable quote links without a database.
//
// A quote link is  /se/?read=<path>#q-<prefix>-<len>  where <prefix> is the
// first ~24 chars of the whitespace-collapsed lowercase quote and <len> its
// normalized length. The endpoint re-derives the quote from the served text
// (same overlays + hotwords as /api/read), retrying shorter prefixes so links
// survive minor corpus edits. Nothing is stored: the anchor is the content.
//
// Same style as api-bugs-test.js: spawns its own api.js on a dedicated port.
const { spawn } = require('child_process');
const path = require('path');
const axios = require('axios');
const assert = require('assert');

const TEST_PORT = 3204;
const BASE = `http://127.0.0.1:${TEST_PORT}`;

// Fresh socket per request — same keep-alive race as api-bugs-test.js: the
// in-process loadLectureTexts/loadBookTexts below blocks this event loop for
// seconds while the health-check socket idles past the server's 5s
// keepAliveTimeout, and reusing it then fails with `socket hang up`.
axios.defaults.httpAgent = new (require('http').Agent)({ keepAlive: false });

let child;

function startServer() {
    child = spawn(process.execPath, ['api.js'], {
        cwd: path.join(__dirname),
        env: { ...process.env, PORT: String(TEST_PORT) },
        stdio: ['ignore', 'pipe', 'pipe']
    });
    child.stderr.on('data', (d) => process.stderr.write(`[child] ${d}`));
}

async function waitForHealth() {
    for (let i = 0; i < 60; i++) {
        try {
            const res = await axios.get(`${BASE}/api/health`, { validateStatus: () => true, timeout: 5000 });
            if (res.status === 200) return;
        } catch (e) { /* not up yet */ }
        await new Promise((r) => setTimeout(r, 500));
    }
    throw new Error('api.js did not become healthy in time');
}

// Mirror of the client's link builder: normalize -> prefix(24) + len.
function makeAnchor(text) {
    const norm = String(text).toLowerCase().replace(/\s+/g, ' ').trim();
    return { prefix: norm.slice(0, 24), len: norm.length };
}

function norm(s) {
    return String(s).toLowerCase().replace(/\s+/g, ' ').trim();
}

let passed = 0;
let failed = 0;
function test(name, fn) {
    return Promise.resolve()
        .then(fn)
        .then(() => { console.log(`  ✅ ${name}`); passed++; })
        .catch((err) => { console.log(`  ❌ ${name}`); console.log(`     ${err.message}`); failed++; });
}

async function main() {
    startServer();
    await waitForHealth();

    const { loadLectureTexts, loadBookTexts } = require('./lecture-text');
    const loaded = loadLectureTexts(path.join(__dirname, 'html'));
    const lectures = loaded.lectures;
    // Same load path as the API (loadBookTexts applies ingest hygiene) so the
    // quote is picked from the text /api/quote actually serves.
    const books = loadBookTexts(path.join(__dirname, 'html')).the_json_obj_books || {};

    const lectureKey = 'Spiritual_Traps_Oct_2005_Part_2_enxautogen_html';
    const lectureText = lectures[lectureKey];
    assert.ok(lectureText && lectureText.length > 2000, `lecture ${lectureKey} too short to test`);

    // Pick a distinctive, moderately long quote from the middle of the text.
    const mid = Math.floor(lectureText.length / 2);
    const rawQuote = lectureText.slice(mid, mid + 220).split('\n').join(' ').replace(/\s+/g, ' ').trim();
    const { prefix, len } = makeAnchor(rawQuote);

    await test('lecture quote resolves and matches (200)', async () => {
        const res = await axios.get(`${BASE}/api/quote/${lectureKey}`, {
            params: { p: prefix, n: len },
            validateStatus: () => true,
            timeout: 10000
        });
        assert.strictEqual(res.status, 200, `status ${res.status}: ${JSON.stringify(res.data)}`);
        assert.strictEqual(res.data.path, lectureKey);
        assert.ok(res.data.quote.length > 50, `quote too short: ${res.data.quote.length}`);
        assert.ok(norm(res.data.quote).startsWith(norm(rawQuote).slice(0, 24)), 'resolved quote does not start with the prefix');
        assert.ok(norm(res.data.quote).includes(norm(rawQuote).slice(10, 60)), 'resolved quote diverges from the source quote');
        assert.ok(Number.isInteger(res.data.index) && res.data.index >= 0, 'bad index');
        assert.ok(typeof res.data.before === 'string' && typeof res.data.after === 'string', 'missing context');
    });

    await test('quote resolves with a 4-char-shorter prefix (edit tolerance)', async () => {
        const res = await axios.get(`${BASE}/api/quote/${lectureKey}`, {
            params: { p: prefix.slice(0, prefix.length - 4), n: len },
            validateStatus: () => true,
            timeout: 10000
        });
        assert.strictEqual(res.status, 200, `status ${res.status}`);
        assert.ok(norm(res.data.quote).length >= 50, 'quote too short');
    });

    await test('quote without n returns from match to end of text', async () => {
        const res = await axios.get(`${BASE}/api/quote/${lectureKey}`, {
            params: { p: prefix },
            validateStatus: () => true,
            timeout: 10000
        });
        assert.strictEqual(res.status, 200, `status ${res.status}`);
        assert.ok(res.data.quote.length > 0, 'empty quote');
    });

    await test('garbage prefix -> 404', async () => {
        const res = await axios.get(`${BASE}/api/quote/${lectureKey}`, {
            params: { p: 'zzzzqqqqwwww', n: 40 },
            validateStatus: () => true,
            timeout: 10000
        });
        assert.strictEqual(res.status, 404);
    });

    await test('unknown path -> 404', async () => {
        const res = await axios.get(`${BASE}/api/quote/No_Such_Lecture_Here`, {
            params: { p: 'anything', n: 40 },
            validateStatus: () => true,
            timeout: 10000
        });
        assert.strictEqual(res.status, 404);
    });

    await test('invalid path format -> 400', async () => {
        const res = await axios.get(`${BASE}/api/quote/bad%2Fpath%21`, {
            params: { p: 'anything', n: 40 },
            validateStatus: () => true,
            timeout: 10000
        });
        assert.strictEqual(res.status, 400);
    });

    await test('missing prefix -> 400', async () => {
        const res = await axios.get(`${BASE}/api/quote/${lectureKey}`, {
            params: { n: 40 },
            validateStatus: () => true,
            timeout: 10000
        });
        assert.strictEqual(res.status, 400);
    });

    await test('bad n -> 400', async () => {
        const res = await axios.get(`${BASE}/api/quote/${lectureKey}`, {
            params: { p: prefix, n: 'abc' },
            validateStatus: () => true,
            timeout: 10000
        });
        assert.strictEqual(res.status, 400);
    });

    const bookKey = Object.keys(books).find((k) => (books[k] || '').length > 2000);
    if (bookKey) {
        await test(`book quote resolves (${bookKey})`, async () => {
            const bt = books[bookKey];
            const bRaw = bt.slice(Math.floor(bt.length / 3), Math.floor(bt.length / 3) + 180).split('\n').join(' ').replace(/\s+/g, ' ').trim();
            const { prefix: bp, len: bl } = makeAnchor(bRaw);
            const res = await axios.get(`${BASE}/api/quote/${bookKey}`, {
                params: { p: bp, n: bl },
                validateStatus: () => true,
                timeout: 10000
            });
            assert.strictEqual(res.status, 200, `status ${res.status}: ${JSON.stringify(res.data)}`);
            assert.ok(res.data.quote.length > 50, 'book quote too short');
        });
    } else {
        console.log('  (skip — no book text to test against)');
    }

    child.kill();
    console.log(`\nquote-tests: ${passed} passed, ${failed} failed`);
    if (failed > 0) process.exit(1);
}

main().catch((err) => {
    console.error(err);
    if (child) child.kill();
    process.exit(1);
});
