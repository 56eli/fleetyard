const fs = require('fs');
const assert = require('assert');
const path = require('path');
const vm = require('vm');

// Extract the parser function from lecture-text.js (api.js requires it)
const apiCode = fs.readFileSync(path.join(__dirname, 'lecture-text.js'), 'utf8');
const loadFuncMatch = apiCode.match(/function loadJsonDataSource\(filePath, objectKey\) \{([\s\S]*?)\n\}/);
if (!loadFuncMatch) throw new Error("Could not extract loadJsonDataSource");

const loadJsonDataSource = new Function('filePath', 'objectKey', 'fs', 'vm', `
function inner() {${loadFuncMatch[1]}}
return inner();
`);

console.log('--- Unit Testing loadJsonDataSource ---');

// Create a mock JS file
const testFile = path.join(__dirname, 'test_mock_data.js');
const mockCode = `
const the_test_obj = {
"file1_html" : \`
==== file1 ====
content line 1
content line 2
\`,
"file2_html" : \`
==== file2 ====
some other content
\`
}
`;

fs.writeFileSync(testFile, mockCode);

try {
    const parsed = loadJsonDataSource(testFile, 'the_test_obj', fs, vm);
    const obj = parsed.the_test_obj;

    assert(obj, "Parsed object should exist");
    assert.strictEqual(Object.keys(obj).length, 2, "Should parse 2 keys");
    assert.strictEqual(obj["file1_html"].trim(), "==== file1 ====\ncontent line 1\ncontent line 2", "File 1 content should match");
    assert.strictEqual(obj["file2_html"].trim(), "==== file2 ====\nsome other content", "File 2 content should match");

    console.log("✅ Custom regex parser works exactly as expected.");
} catch (err) {
    console.error("❌ Test failed:", err.message);
    process.exit(1);
} finally {
    fs.unlinkSync(testFile);
}
