# DocDocGO

> Gloria in Excelsis Deo!

![GitLab CI](https://gitlab.com/lakshaynz/docdocgo/badges/main/pipeline.svg)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)

The Beloved Doc's lectures transcriptions search app — a spiritual knowledge base with full-text search and consciousness calibration tools.

**Hosted at:** [https://docdocgo.lak.nz/](https://docdocgo.lak.nz/)

---

## Quick Start

```bash
# Start the stack (api + nginx; the quality gate runs at build and container start)
make up

# Run all tests (safe against a live prod stack — leaves it untouched)
bash test.sh
```

- Search UI: `http://localhost:12853`
- API: `http://localhost:12854`

> RAG vector search is **currently disabled** (parked behind the `rag` profile).
> The `rag` service port 9432 and populate/rerank targets are dormant until
> re-enabled — see [RAG Pipeline](#rag-pipeline-disabled).

---


## Agent CLI: `docdocgo-axi` (https://axi.md/)

The [DocDocGo Axi](https://docdocgo.lak.nz/api/docs) — spiritual wisdom for the 90% excellent bar (http://axi.md/ principles: deterministic input, observable output, secure-by-default, cost-aware).

```bash
docdocgo-axi "why is there suffering" --limit 3        # human: snippets + RAG chunks + citations
docdocgo-axi --json --limit 3 "purpose of life"         # machine: JSON for firstmate pre-decision
docdocgo-axi --search "god within" --limit 5            # keyword snippets only (fast)
docdocgo-axi --rag "what is enlightenment" --json       # RAG chunks only
```

Install from this repo (or `~/bin/docdocgo-axi` on the VPS):
`cp docdocgo-axi ~/bin/docdocgo-axi && chmod +x ~/bin/docdocgo-axi`

API: `GET /api/search?q=…&limit=…&context=…` (ranked snippets) + `POST /api/rag` `{query, top_k}` (vector chunks; the RAG service is disabled — see below).

## Architecture

| Component | Description |
|-----------|-------------|
| **api.js** | Express API server with relevance-ranked search, calibration, and lecture/books parsing |
| **lecture-text.js** | Shared lecture loading + WEBVTT/cue cleanup + Hawkins ASR hotword fixes (used by api + quality gate) |
| **quality-check.js** | Transcription-quality gate (docker build + container pre-start + npm test) |
| **auth.js** | Discord OAuth2 login + admin approval gate |
| **rag/rag_service.py** | Python Flask RAG microservice — **disabled**, parked behind the `rag` profile |
| **rag/populate.py** | Vector database ingestion — mirrors the lecture text cleanup hotwords |
| **html/** | Static HTML search pages and preprocessed data files (read-only) |
| **nginx.conf** | Reverse proxy configuration + gate for `/se/` |

## API Documentation

The project includes a REST API to programmatically list and read document contents.

### Base URL
- Local: `http://localhost:12854` (direct) or `http://localhost:12853/api` (via Nginx)
- Production: `https://docdocgo.lak.nz/api`

### Endpoints

#### 1. List Files
Returns a JSON array of relative paths for all available HTML documents.
- **URL:** `/files`
- **Method:** `GET`
- **Response:** `["A_Map_of_Consciousness_enxautogen_html", ...]`

#### 2. Read File Content
Returns the text content and path of a specific document.
- **URL:** `/read/<filename>`
- **Method:** `GET`
- **Example:** `/read/A_Map_of_Consciousness_enxautogen_html`
- **Response:** `{"path": "...", "content": "..."}`

#### 3. Search Documents
Scans all documents for a keyword or phrase with relevance ranking.
- **URL:** `/search`
- **Method:** `GET`
- **Query Parameters:**
  - `q`: Search term (required, min 4 characters)
  - `context`: Number of characters around match (default: 300)
  - `limit`: Results per page (default: 100)
  - `filter`: Filter by `books`, `lectures`, or specific filename (default: all)
  - `case`: Case sensitive if `true`
  - `whole`: Set to `false` to disable whole-word matching (default: true)
  - `regex`: Treat `q` as regex if `true`
  - `page`: Page number (default: 1)
- **Response:**
  ```json
  {
    "query": "meditation",
    "total_matches": 732,
    "files_count": 166,
    "page": 1,
    "limit": 100,
    "total_pages": 8,
    "options": { "wholeWords": true, ... },
    "results": [
      {
        "path": "...",
        "score": 2,
        "match_text": ["meditation"],
        "match_count": 1,
        "snippet": "...",
        "offset": 258412
      }
    ]
  }
  ```

#### 4. RAG Search
Vector-based semantic search with optional Ettin reranking.
- **URL:** `/api/rag`
- **Method:** `POST`
- **Body:**
  ```json
  {
    "query": "What is the map of consciousness?",
    "sources": ["david_r_hawkins.txt"],
    "top_k": 5
  }
  ```

#### 5. RAG Context
Builds LLM-ready context block from retrieved chunks with system instructions.
- **URL:** `/api/rag/context`
- **Method:** `POST`

#### 6. Calibrate
Calibrate text against the Map of Consciousness using RAG context.
- **URL:** `/api/calibrate`
- **Method:** `POST`

#### 7. RAG Sources
List available source files in the vector database.
- **URL:** `/api/rag/sources`
- **Method:** `GET`

> Endpoints 4–7 proxy to the RAG service, which is currently **disabled**. While
> it is down they respond with a graceful error instead of a 500. Re-enable steps
> in the [RAG Pipeline](#rag-pipeline-disabled) section.

### Scoring

Results are ranked by relevance using a unified score:
- **Score = match_count × 3 + log(1 + doc_groups) / 10 + proximity_bonus**
- Unique query words in the group dominate (a 1-word group never outranks a 2-word group)
- Per-document keyword-group frequency breaks the old single-keyword all-score-3 tie
- Exact phrase of all query words inside the group gets a 0.5 proximity bonus; otherwise the bonus is damped by span
- Stop words (the, and, is, etc.) are filtered from matching to prevent dilution

### Sort Integrity

The API includes automatic sort integrity checks:
- Violations are logged at debug level
- Results are auto-corrected (re-sorted) if violations detected
- Under `LOG_LEVEL=verbose`, response includes `sort_integrity` field

## RAG Pipeline (disabled)

RAG (retrieve-then-rerank vector search) is **parked** — it was memory-heavy for this
VPS (OOM risk) and is not currently part of the stack. The services are profile-gated
in `docker-compose.yml` and `api.js` no longer depends on them (proxies fail gracefully).

Re-enable:

```bash
# 1. Build + populate the vector DB (first run)
docker compose --profile populate run --rm rag-populate
# 2. Start the RAG service
docker compose --profile rag up -d rag
# 3. Remove the `profiles:` gates from docker-compose.yml, then restore the
#    rag build/push + populate + rag-tests steps in .gitlab-ci.yml
```

### Configuration

| Environment Variable | Default | Description |
|---------------------|---------|-------------|
| `ENABLE_RERANKER` | `false` | Enable/disable Ettin reranker |
| `TOP_K_RETRIEVAL` | `12` | Candidates from cosine similarity |
| `TOP_K_RERANK` | `5` | Final results after reranking |
| `VECTOR_DB_DIR` | `/app/vector-db` | Path to vector database |
| `RERANKER_MODEL` | `cross-encoder/ettin-reranker-68m-v1` | HuggingFace model ID |
| `LOG_LEVEL` | `info` | Logging verbosity (`low`, `info`, `verbose`) |
| `MAX_QUERY_LENGTH` | `1000` | Maximum query/input length |

## Development

Run the stack locally with Docker Compose:

```bash
make up
```

> **Docker-only support.** Docker Compose is the only supported way to run
> DocDocGo — stack, tests, quality gate, and deploys. Running `api.js` or
> `npm test` directly on the host is a debugging convenience and is not
> supported; the supported suite runs inside the api container (`make test`).

### Production deploy (DOC-037)

```bash
make deploy          # scripts/deploy.sh — rebuild api, then nginx -s reload, then smoke
make smoke           # scripts/smoke-test.sh against SMOKE_BASE (default https://docdocgo.lak.nz)
```

Never tear the stack down. Deploy refuses unless the branch is `main`. The smoke battery is pinned in `deploy-scripts-test.js`.

### Running Tests

```bash
# Quick E2E test (starts the stack, tests endpoints; leaves a pre-existing stack running)
bash test.sh

# Full test suite (unit + chapters + quality gate + API e2e + auth + rate-limit) — docker only
make test

# Extended API tests only (94 cases) — docker only
docker compose exec api npm run test:extended

# Transcription-quality gate report (hard checks block; soft metrics warn) — docker only
docker compose exec api node quality-check.js

# Lint JavaScript source
npm run lint

# Cypress E2E (isolated stack, prod containers untouched)
docker compose -p docdocgo-cypress -f cypress-compose.yml up -d --build nginx api
docker compose -p docdocgo-cypress -f cypress-compose.yml run --rm cypress
```

### Test scripts

| Script | Description |
|--------|-------------|
| `test.sh` | E2E shell test — starts stack, tests endpoints, cleans up (never tears down a stack it didn't start) |
| `scripts/deploy.sh` | Prod runbook (DOC-037): rebuild api, reload nginx, catalogue log, smoke, gitlab mirror |
| `scripts/smoke-test.sh` | Read-only prod/local smoke battery (`SMOKE_BASE`) |
| `deploy-scripts-test.js` | Pins the deploy/smoke runbook contents |
| `test-chapters.js` | Unit tests for `parseChapters`/`findChapter` (incl. I_AM_THAT + Be_as_you_are cases) |
| `test-parser.js` | Unit test for the JSON data source parser |
| `quality-tests.js` | Transcription-quality regression tests (corpus hard checks + `Spiritual_Traps_Oct_2005_Part_2` pins) |
| `api-bugs-test.js` | `/api/search` input-validation hardening tests |
| `e2e-test.js` | Node.js E2E API tests (spawns its own server) |
| `extended-tests.js` | Comprehensive API tests, 94 cases (spawns its own server) |
| `auth-e2e-test.js` | Discord gate + admin grant tests (spawns its own server) |
| `rate-limit-test.js` | Rate-limiting tests (spawns its own server) |
| `rag-tests.js` | Node.js RAG endpoint tests — dormant (RAG disabled) |
| Cypress | Browser-based E2E tests (isolated `cypress-compose.yml` stack) |

> Note: every Node test file spawns its own `api.js` on a dedicated port
> (3199, 3201–3204). Never point tests at `localhost:3000` — that's the local
> GoluGit/Forgejo git server, not the API. Run the suite in docker (`make test`);
> bare-host `node`/`npm` runs are not supported.

## Transcription-quality gate

Lecture transcripts (WEBVTT-sourced) are cleaned in code (data files are read-only):
`lecture-text.js` strips WEBVTT headers/cue numbers, reflows ~40-char shards into
sentences, splits run-on lines, and applies deterministic Hawkins ASR hotword fixes.
`quality-check.js` scores the whole corpus:

- **Hard checks** (residual WEBVTT headers, `-->` timestamps, isolated cue numbers,
  empty lectures) fail the docker build (`RUN node quality-check.js`) and the
  container pre-start (`api.js` runs the same checks on the corpus it just loaded,
  before listen) — broken data stops the container instead of being served.
- **Soft metrics** (median line length, short-line ratio, run-on lines, lecture count
  vs 280) are warnings only — ASR hallucinations can't be fixed deterministically.

## CI/CD

The project uses GitLab CI with three stages:
1. **lint** — ESLint static analysis
2. **test** — API/extended tests + Cypress E2E (`AUTH_TEST_MODE` only on the test stack)
3. **build** — Docker image build and push (main branch only)

> CI currently runs nothing: pushes to gitlab.com are blocked for `@admin3612`
> (read-only). Land `main` via MR from the `admin3612/docdocgo` fork
> (`https://gitlab.com/lakshaynz/docdocgo/-/compare/main...admin3612:main`) to
> re-arm the pipeline.

## Project Status

![GitLab CI](https://gitlab.com/lakshaynz/docdocgo/badges/main/pipeline.svg)

- **License:** MIT
- **Node:** 18 LTS (Alpine)
- **Python:** 3.12 (slim)
